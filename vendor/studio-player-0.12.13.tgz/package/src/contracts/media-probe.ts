import type { AudioDecodeTrack, VideoDecodeTrack } from './media-support.js';

export interface ProbedMediaTrack {
  readonly index: number;
  readonly kind: 'video' | 'audio';
  readonly default: boolean;
  readonly codecName?: string;
  readonly profile?: string;
  readonly level?: number;
  readonly pixelFormat?: string;
  readonly bitDepth?: number;
  /** 未准确识别容器/编码时保留 undefined。 */
  readonly decoding?: VideoDecodeTrack | AudioDecodeTrack;
}

export interface ProbedMedia {
  readonly source: 'ffprobe';
  readonly format?: string;
  readonly container?: { readonly kind: 'mp4' | 'mov' | 'webm' | 'matroska' | 'mp3' | 'flac' | 'wav' | 'ogg' | 'mpegts'; readonly mimeType: string };
  readonly durationSeconds?: number;
  /** Complete input or successfully read indexed track declarations; not file integrity. */
  readonly tracksComplete: boolean;
  readonly tracks: readonly ProbedMediaTrack[];
}

export interface ProbedMediaSelection {
  /** 未指定时选 default，其次首轨；null 表示显式不选择。 */
  readonly video?: number | null;
  readonly audio?: number | null;
}

export type MediaProbeErrorCode = 'invalid-input' | 'unavailable' | 'busy' | 'timeout'
  | 'cancelled' | 'read-failed' | 'output-limit' | 'probe-limit' | 'invalid-media';

/** 不包含路径、凭据、原始 stderr 或系统异常。 */
export class MediaProbeError extends Error {
  readonly name = 'MediaProbeError';
  constructor(public readonly code: MediaProbeErrorCode) {
    super(`Media probe failed: ${code}`);
  }
}
