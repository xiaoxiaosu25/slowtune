/**
 * 播放进度记忆契约
 * 
 * 目标：把进度记忆的纯逻辑与存储介质（数据库/localStorage/云端 API）解耦。
 */

/** 结构化进度记忆记录对象（支持时间戳仲裁与扩展） */
export interface ProgressRecord {
  /** 当前播放秒数 */
  positionSeconds: number;
  /** 媒体总时长（秒，已知时提供） */
  durationSeconds?: number;
  /** 更新时间戳（毫秒级 Unix Timestamp，用于多端同步 Last-Write-Wins 仲裁） */
  updatedAt: number;
  /** 播放进度百分比（0.0 ~ 1.0） */
  percentage?: number;
}

/** 进度持久化存储端口接口（由宿主/产品注入） */
export interface ProgressStoragePort {
  /**
   * 读取指定资源的上次保存进度
   * @param resourceId 媒体资源唯一标识
   * @returns 上次保存的记录对象或秒数；若无记录返回 null 或 undefined
   */
  load(resourceId: string): Promise<ProgressRecord | number | null | undefined> | ProgressRecord | number | null | undefined;

  /**
   * 保存当前播放进度
   * @param resourceId 媒体资源唯一标识
   * @param positionSeconds 当前播放秒数
   * @param durationSeconds 媒体总时长（秒，已知时传入）
   * @param record 结构化记录（含 updatedAt 时间戳）
   */
  save(
    resourceId: string,
    positionSeconds: number,
    durationSeconds?: number,
    record?: ProgressRecord
  ): Promise<void> | void;

  /**
   * 清除指定资源的进度（如用户手动重置、或媒体自然播完）
   * @param resourceId 媒体资源唯一标识
   */
  clear(resourceId: string): Promise<void> | void;
}

/** 进度处理与恢复策略参数 */
export interface ProgressPolicy {
  /**
   * 起播忽略阈值（秒）。
   * 若保存的进度小于此阈值，视为刚开始播放，自动重置为 0 秒从头起播。
   * 默认值：5 秒。
   */
  startThresholdSeconds?: number;

  /**
   * 尾部完成固定阈值（秒）。
   * 若距离媒体结尾不足此秒数，视为已看完，不恢复进度并清除记录。
   * 默认值：10 秒。
   */
  endThresholdSeconds?: number;

  /**
   * 尾部完成百分比阈值（0.0 ~ 1.0）。
   * 若当前进度超过总时长的比例，视为已看完。
   * 默认值：0.95（即 95%）。
   */
  endThresholdPercentage?: number;

  /**
   * 持久化写入尾部防抖间隔（毫秒）。
   * 避免停止动作时的高频抖动。
   * 默认值：2000 毫秒（2 秒）。
   */
  saveDebounceMs?: number;

  /**
   * 持续播放时的强制节流心跳间隔（毫秒）。
   * 防止连续播放期间因防抖不断被重置导致长时间不落盘，
   * 确保每隔固定时间至少写入一次持久化存储。
   * 默认值：5000 毫秒（5 秒）。
   */
  saveThrottleIntervalMs?: number;
}

/** 统一默认策略 */
export const DEFAULT_PROGRESS_POLICY: Required<ProgressPolicy> = {
  startThresholdSeconds: 5,
  endThresholdSeconds: 10,
  endThresholdPercentage: 0.95,
  saveDebounceMs: 2000,
  saveThrottleIntervalMs: 5000,
};
