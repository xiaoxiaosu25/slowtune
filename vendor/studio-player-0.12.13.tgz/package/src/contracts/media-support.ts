/** 已选择的轨道信息，由来源提供；不从扩展名推断编码。 */
export interface MediaDecodeTrack {
  /** 单轨 MIME，如 video/mp4、audio/mp4；不含 codecs 参数。 */
  readonly mimeType: string;
  /** RFC 6381 编码标识；未知时省略，不能仅填 h264/hevc 等显示名称。 */
  readonly codec?: string;
  readonly bitrate?: number;
}

export interface VideoDecodeTrack extends MediaDecodeTrack {
  readonly width?: number;
  readonly height?: number;
  readonly framerate?: number;
  /** Observed pixel depth; independent of HDR/output support. */
  readonly bitDepth?: number;
}

export interface AudioDecodeTrack extends MediaDecodeTrack {
  readonly channels?: string;
  readonly samplerate?: number;
}

/** null 明确无该轨道，undefined 表示信息未知。这里只评估所选轨道。 */
export interface BrowserMediaDescription {
  readonly transport: 'range' | 'hls' | 'dash' | 'webrtc';
  /** Actual container MIME; optional for existing external descriptions. */
  readonly container?: { readonly mimeType: string };
  /** Explicit route. HLS requires this; MSE also requires the host's actual adapter capability. */
  readonly route?: 'file' | 'native-hls' | 'mse-hls';
  /** Host-declared output container after HLS transmuxing; preserves selected codec strings. */
  readonly mseContainer?: { readonly mimeType: string };
  readonly video?: VideoDecodeTrack | null;
  readonly audio?: AudioDecodeTrack | null;
}

export type MediaSupportStatus = 'expected-supported' | 'unsupported' | 'unknown';
export type MediaSupportReason =
  | 'api-supported' | 'api-unsupported' | 'api-conflict' | 'api-unavailable'
  | 'api-error' | 'api-inconclusive' | 'query-timeout'
  | 'metadata-incomplete' | 'transport-not-assessed' | 'no-tracks' | 'path-not-configured';

export interface MediaSupportEvidence {
  readonly target: 'container' | 'video' | 'audio' | 'combined' | 'path';
  readonly api: 'canPlayType' | 'decodingInfo' | 'isTypeSupported' | 'hlsAdapter';
  readonly result: 'supported' | 'unsupported' | 'unknown' | 'error' | 'timeout';
}

/** 预测，不代表文件完整、真实解码成功或设备输出已验证。无 URL/凭据。 */
export interface BrowserMediaSupport {
  readonly status: MediaSupportStatus;
  readonly reason: MediaSupportReason;
  readonly evidence: readonly MediaSupportEvidence[];
  /** Per-dimension explanations. A missing track is not an unsupported track. */
  readonly checks: readonly { readonly target: MediaSupportEvidence['target']; readonly status: MediaSupportStatus; readonly reason: MediaSupportReason }[];
  /** Advice only, never changes a backend or performs processing. */
  readonly suggestedPath: 'direct' | 'verify' | 'compatible-source-or-explicit-host';
  /** MediaCapabilities 的估计值，不是硬解或性能验收。 */
  readonly smooth?: boolean;
  readonly powerEfficient?: boolean;
}
