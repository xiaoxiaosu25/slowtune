/** 不携带 URL、请求头、资源 ID 或原始错误文本，可由宿主选择记录。 */
export interface PlaybackDiagnostic {
  readonly code: 'resolve-start' | 'resolve-success' | 'resolve-failed' | 'resolve-cancelled'
    | 'resolve-timeout' | 'initial-timeout' | 'stall-timeout' | 'playback-started'
    | 'buffering-started' | 'buffering-ended' | 'data-progress' | 'media-error' | 'play-rejected' | 'fallback';
  readonly timestamp: number;
  readonly elapsedMs?: number;
  readonly timeoutSeconds?: number;
  readonly reason?: 'expired' | 'fallback' | 'retry';
  readonly recovery?: 'fallback' | 'none' | 'limit';
}

export type PlaybackTimeoutPhase = 'resolve' | 'initial' | 'stall';

export class PlaybackTimeoutError extends Error {
  readonly name = 'TimeoutError';
  constructor(public readonly phase: PlaybackTimeoutPhase, public readonly timeoutSeconds: number) {
    super(`Playback ${phase} timed out after ${timeoutSeconds} seconds`);
  }
}
