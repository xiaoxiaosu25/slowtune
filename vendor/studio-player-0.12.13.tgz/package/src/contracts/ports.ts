/**
 * U5-2 的播放器与宿主端口契约。
 *
 * 这里仅定义无宿主依赖的事实、操作和 IPC 边界。Electron、Node、native
 * helper、HWND、命名管道和产品路径都不能进入本模块。
 */

import type { AdaptedSourceResult } from './delivery.js';
import type { PlayableInput } from './plan.js';
import { isPlaybackPlan, isSimpleMediaSource } from './plan.js';

/** U5 当前只定稿这两条已存在的播放后端。 */
export type PlayerBackend = 'videojs' | 'mpv' | 'native-audio';

/** 核心已有播放状态；端口不另建一份状态机。 */
export type PlaybackState =
  | 'idle'
  | 'loading'
  | 'ready'
  | 'playing'
  | 'paused'
  | 'stopped'
  | 'ended'
  | 'error';

/** 现有 StudioPlayer 事实/事件通道的类型名，供端口复用。 */
export type PlaybackEventType =
  | 'play'
  | 'playintent'
  | 'playing'
  | 'playerror'
  | 'diagnostic'
  | 'pause'
  | 'timeupdate'
  | 'durationchange'
  | 'beforeended'
  | 'ended'
  | 'error'
  | 'fallback'
  | 'sourcechange'
  | 'resume'
  | 'statechange'
  | 'loadstart'
  | 'pauseintent'
  | 'stop'
  | 'closeintent'
  | 'closerequest'
  | 'volumechange'
  | 'ratechange'
  | 'seeked'
  | 'mediachange'
  | 'detach'
  | 'destroy';

export type PlaybackEventListener = (...args: any[]) => void;

declare const playerInstanceIdBrand: unique symbol;
declare const surfaceSenderIdBrand: unique symbol;

/** 只允许由宿主分配的、可安全跨 IPC 传输的播放器实例标识。 */
export type PlayerInstanceId = string & { readonly [playerInstanceIdBrand]: true };

/** 主进程内部使用的 sender 标识；不会下发给 renderer。 */
export type SurfaceSenderId = string & { readonly [surfaceSenderIdBrand]: true };

export type PortContractErrorCode =
  | 'invalid-instance-id'
  | 'invalid-sender-id'
  | 'invalid-backend'
  | 'invalid-request'
  | 'unknown-operation'
  | 'invalid-geometry'
  | 'unregistered-instance'
  | 'sender-mismatch'
  | 'invalid-lifecycle'
  | 'invalid-binding';

export class PortContractError extends Error {
  constructor(public readonly code: PortContractErrorCode, message: string) {
    super(message);
    this.name = 'PortContractError';
  }
}

const SAFE_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;

export function isPlayerInstanceId(value: unknown): value is PlayerInstanceId {
  return typeof value === 'string' && SAFE_IDENTIFIER.test(value);
}

export function createPlayerInstanceId(value: string): PlayerInstanceId {
  if (!isPlayerInstanceId(value)) {
    throw new PortContractError('invalid-instance-id', '播放器实例标识必须是 1–128 位安全字符串');
  }
  return value;
}

export function createSurfaceSenderId(value: string): SurfaceSenderId {
  if (typeof value !== 'string' || !SAFE_IDENTIFIER.test(value)) {
    throw new PortContractError('invalid-sender-id', 'renderer sender 标识必须是 1–128 位安全字符串');
  }
  return value as SurfaceSenderId;
}

export interface PlayerInstance {
  readonly instanceId: PlayerInstanceId;
  readonly backend: PlayerBackend;
}

export function createPlayerInstance(instanceId: string, backend: PlayerBackend): PlayerInstance {
  const id = createPlayerInstanceId(instanceId);
  if (backend !== 'videojs' && backend !== 'mpv' && backend !== 'native-audio') {
    throw new PortContractError('invalid-backend', `未支持的播放后端：${String(backend)}`);
  }
  return Object.freeze({ instanceId: id, backend });
}

/**
 * 播放端口只描述 StudioPlayer 已有的操作与事实；事件仍来自 StudioPlayer，
 * 不新增一个包揽所有状态的总线。
 */
export interface PlaybackPort {
  readonly instance: PlayerInstance;
  readonly state: PlaybackState;
  readonly currentTime: number;
  readonly duration: number;
  readonly paused: boolean;
  readonly playbackRate: number;
  readonly volume: number;
  readonly muted: boolean;
  readonly failed: boolean;
  readonly playbackRequested: boolean;
  load(input: PlayableInput, options?: { readonly restart?: boolean }): Promise<AdaptedSourceResult>;
  replaceSource(input: PlayableInput): AdaptedSourceResult;
  requestPlayback(): boolean;
  play(options?: { readonly signal?: AbortSignal }): Promise<void>;
  pause(): void;
  seek(positionSeconds: number): void;
  setVolume(volume: number): void;
  setMuted(muted: boolean): void;
  setPlaybackRate(rate: number): void;
  stop(): Promise<void>;
  close(options?: { readonly signal?: AbortSignal }): Promise<void>;
  on(event: PlaybackEventType, listener: PlaybackEventListener): () => void;
  destroy(): void;
}

/** 轨道端口只承接音轨/字幕事实与选择，不承接画质或整播放器状态。 */
export interface TrackPortOption {
  readonly id: string;
  readonly label: string;
  readonly language?: string;
  readonly selected: boolean;
  readonly status: 'ready' | 'loading' | 'unavailable' | 'error';
  readonly reason?: string;
}

export interface TrackPortSnapshot {
  readonly audio: readonly TrackPortOption[];
  readonly subtitles: readonly TrackPortOption[];
  readonly audioTrack: string | null;
  readonly subtitle: string;
}

export interface TrackPort {
  readonly instance: PlayerInstance;
  readonly snapshot: TrackPortSnapshot;
  selectAudioTrack(id: string): Promise<void> | void;
  selectSubtitle(id: string): Promise<void> | void;
  onChange(listener: () => void): () => void;
}

/**
 * native child surface 的宿主端口。端口已按实例绑定，方法不接受任意命令，
 * 也不返回 HWND、命名管道、子进程或文件句柄。
 */
export interface SurfacePort {
  readonly instance: PlayerInstance;
  create(geometry: SurfaceGeometry): Promise<void> | void;
  resize(geometry: SurfaceGeometry): Promise<void> | void;
  show(): Promise<void> | void;
  hide(): Promise<void> | void;
  focus(): Promise<void> | void;
  requestFullscreen(enabled: boolean): Promise<void> | void;
  destroy(): Promise<void> | void;
}

/** 每个播放器实例显式绑定后端和端口；mpv 实例必须有 surface 端口。 */
export interface PlayerPorts {
  readonly instance: PlayerInstance;
  readonly playback: PlaybackPort;
  readonly tracks?: TrackPort;
  readonly surface?: SurfacePort;
}

/** 校验端口绑定没有把不同实例或错误的后端拼在一起。 */
export function assertPlayerPorts(ports: PlayerPorts): void {
  if (!ports || !ports.instance || !ports.playback || ports.playback.instance !== ports.instance) {
    throw new PortContractError('invalid-binding', '播放端口必须绑定同一个播放器实例');
  }
  if (ports.surface && ports.surface.instance !== ports.instance) {
    throw new PortContractError('invalid-binding', 'surface 端口必须绑定同一个播放器实例');
  }
  if (ports.tracks && ports.tracks.instance !== ports.instance) {
    throw new PortContractError('invalid-binding', '轨道端口必须绑定同一个播放器实例');
  }
  if (ports.instance.backend === 'mpv' && !ports.surface) {
    throw new PortContractError('invalid-binding', 'mpv 播放器实例必须注入 surface 端口');
  }
  if (ports.instance.backend !== 'mpv' && ports.surface) {
    throw new PortContractError('invalid-binding', 'Video.js 默认路径不接受 native surface 端口');
  }
}

export interface SurfaceRect {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export interface SurfaceGeometry {
  readonly rect: SurfaceRect;
  readonly devicePixelRatio: number;
}

/**
 * renderer 只能报告有限 CSS 几何和 DPI。范围是协议安全上限，不是对真实屏幕尺寸的支持声明。
 */
export const SURFACE_GEOMETRY_LIMITS = Object.freeze({
  maxCoordinate: 16_384,
  maxDimension: 16_384,
  maxArea: 16_384 * 16_384,
  minDevicePixelRatio: 0.5,
  maxDevicePixelRatio: 4,
});

function recordOf(value: unknown, label: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new PortContractError('invalid-request', `${label} 必须是对象`);
  }
  return value as Record<string, unknown>;
}

function hasOwn(value: Record<string, unknown>, key: string): boolean {
  return Object.prototype.hasOwnProperty.call(value, key);
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[], label: string): void {
  const allowed = new Set(keys);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) throw new PortContractError('invalid-request', `${label} 包含未允许字段：${key}`);
  }
  for (const key of keys) {
    if (!hasOwn(value, key)) throw new PortContractError('invalid-request', `${label} 缺少字段：${key}`);
  }
}

function numberField(value: unknown, label: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new PortContractError('invalid-geometry', `${label} 必须是有限数字`);
  }
  return value;
}

/** 校验并复制 renderer 上报的矩形与 DPI，拒绝 NaN、Infinity、负值和超大区域。 */
export function validateSurfaceGeometry(value: unknown): SurfaceGeometry {
  const input = recordOf(value, 'surface geometry');
  exactKeys(input, ['rect', 'devicePixelRatio'], 'surface geometry');
  const rawRect = recordOf(input.rect, 'surface rect');
  exactKeys(rawRect, ['x', 'y', 'width', 'height'], 'surface rect');
  const x = numberField(rawRect.x, 'surface rect.x');
  const y = numberField(rawRect.y, 'surface rect.y');
  const width = numberField(rawRect.width, 'surface rect.width');
  const height = numberField(rawRect.height, 'surface rect.height');
  const dpr = numberField(input.devicePixelRatio, 'surface devicePixelRatio');
  const { maxCoordinate, maxDimension, maxArea, minDevicePixelRatio, maxDevicePixelRatio } = SURFACE_GEOMETRY_LIMITS;
  if (x < 0 || y < 0 || x > maxCoordinate || y > maxCoordinate
    || width <= 0 || height <= 0 || width > maxDimension || height > maxDimension
    || x + width > maxCoordinate || y + height > maxCoordinate || width * height > maxArea
    || dpr < minDevicePixelRatio || dpr > maxDevicePixelRatio) {
    throw new PortContractError('invalid-geometry', 'surface 矩形或 devicePixelRatio 超出允许范围');
  }
  return Object.freeze({
    rect: Object.freeze({ x, y, width, height }),
    devicePixelRatio: dpr,
  });
}

export const PLAYER_PLAYBACK_CHANNEL = 'studio.player.playback';
export const PLAYER_SURFACE_CHANNEL = 'studio.player.surface';

export const PLAYBACK_OPERATIONS = [
  'load', 'play', 'pause', 'seek', 'setVolume', 'setMuted', 'setPlaybackRate', 'stop', 'destroy',
] as const;
export type PlaybackOperation = typeof PLAYBACK_OPERATIONS[number];

type PlaybackRequestBase = {
  readonly channel: typeof PLAYER_PLAYBACK_CHANNEL;
  readonly instanceId: PlayerInstanceId;
};

export type PlaybackRequest =
  | (PlaybackRequestBase & { readonly operation: 'load'; readonly input: PlayableInput; readonly restart?: boolean })
  | (PlaybackRequestBase & { readonly operation: 'play' | 'pause' | 'stop' | 'destroy' })
  | (PlaybackRequestBase & { readonly operation: 'seek'; readonly seconds: number })
  | (PlaybackRequestBase & { readonly operation: 'setVolume'; readonly volume: number })
  | (PlaybackRequestBase & { readonly operation: 'setMuted'; readonly muted: boolean })
  | (PlaybackRequestBase & { readonly operation: 'setPlaybackRate'; readonly rate: number });

function instanceIdOf(input: Record<string, unknown>): PlayerInstanceId {
  if (!hasOwn(input, 'instanceId') || typeof input.instanceId !== 'string') {
    throw new PortContractError('invalid-instance-id', '请求缺少有效的播放器实例标识');
  }
  return createPlayerInstanceId(input.instanceId);
}

function operationOf(input: Record<string, unknown>, operations: readonly string[]): string {
  if (!hasOwn(input, 'operation') || typeof input.operation !== 'string') {
    throw new PortContractError('invalid-request', '请求缺少操作名');
  }
  if (!operations.includes(input.operation)) {
    throw new PortContractError('unknown-operation', `未允许的操作：${input.operation}`);
  }
  return input.operation;
}

function isPlayableInput(value: unknown): value is PlayableInput {
  return typeof value === 'string'
    || (typeof value === 'object' && value !== null
      && (isPlaybackPlan(value as PlayableInput) || isSimpleMediaSource(value as PlayableInput)));
}

/** 解析 renderer/preload 传入的播放请求；任意 execute/command 都在这里被拒绝。 */
export function parsePlaybackRequest(value: unknown): PlaybackRequest {
  const input = recordOf(value, 'playback request');
  if (!hasOwn(input, 'channel') || input.channel !== PLAYER_PLAYBACK_CHANNEL) {
    throw new PortContractError('invalid-request', '请求不属于播放白名单通道');
  }
  const operation = operationOf(input, PLAYBACK_OPERATIONS);
  const instanceId = instanceIdOf(input);
  switch (operation) {
    case 'load': {
      const allowed = ['channel', 'operation', 'instanceId', 'input', 'restart'];
      for (const key of Object.keys(input)) if (!allowed.includes(key)) {
        throw new PortContractError('invalid-request', `load 包含未允许字段：${key}`);
      }
      if (!hasOwn(input, 'input') || !isPlayableInput(input.input)) {
        throw new PortContractError('invalid-request', 'load.input 不是可播放来源');
      }
      if (hasOwn(input, 'restart') && typeof input.restart !== 'boolean') {
        throw new PortContractError('invalid-request', 'load.restart 必须是布尔值');
      }
      return Object.freeze({
        channel: PLAYER_PLAYBACK_CHANNEL,
        operation,
        instanceId,
        input: input.input,
        ...(hasOwn(input, 'restart') ? { restart: input.restart as boolean } : {}),
      });
    }
    case 'play':
    case 'pause':
    case 'stop':
    case 'destroy':
      exactKeys(input, ['channel', 'operation', 'instanceId'], `${operation} request`);
      return Object.freeze({ channel: PLAYER_PLAYBACK_CHANNEL, operation, instanceId });
    case 'seek':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'seconds'], 'seek request');
      if (typeof input.seconds !== 'number' || !Number.isFinite(input.seconds)) {
        throw new PortContractError('invalid-request', 'seek.seconds 必须是有限数字');
      }
      return Object.freeze({ channel: PLAYER_PLAYBACK_CHANNEL, operation, instanceId, seconds: input.seconds });
    case 'setVolume':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'volume'], 'setVolume request');
      if (typeof input.volume !== 'number' || !Number.isFinite(input.volume) || input.volume < 0 || input.volume > 1) {
        throw new PortContractError('invalid-request', 'setVolume.volume 必须在 0–1 之间');
      }
      return Object.freeze({ channel: PLAYER_PLAYBACK_CHANNEL, operation, instanceId, volume: input.volume });
    case 'setMuted':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'muted'], 'setMuted request');
      if (typeof input.muted !== 'boolean') throw new PortContractError('invalid-request', 'setMuted.muted 必须是布尔值');
      return Object.freeze({ channel: PLAYER_PLAYBACK_CHANNEL, operation, instanceId, muted: input.muted });
    case 'setPlaybackRate':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'rate'], 'setPlaybackRate request');
      if (typeof input.rate !== 'number' || !Number.isFinite(input.rate) || input.rate <= 0) {
        throw new PortContractError('invalid-request', 'setPlaybackRate.rate 必须是正数');
      }
      return Object.freeze({ channel: PLAYER_PLAYBACK_CHANNEL, operation, instanceId, rate: input.rate });
    default:
      throw new PortContractError('unknown-operation', `未允许的播放操作：${operation}`);
  }
}

export const SURFACE_OPERATIONS = [
  'create', 'resize', 'show', 'hide', 'focus', 'requestFullscreen', 'destroy',
] as const;
export type SurfaceOperation = typeof SURFACE_OPERATIONS[number];

type SurfaceRequestBase = {
  readonly channel: typeof PLAYER_SURFACE_CHANNEL;
  readonly instanceId: PlayerInstanceId;
};

export type SurfaceRequest =
  | (SurfaceRequestBase & { readonly operation: 'create' | 'resize'; readonly geometry: SurfaceGeometry })
  | (SurfaceRequestBase & { readonly operation: 'show' | 'hide' | 'focus' | 'destroy' })
  | (SurfaceRequestBase & { readonly operation: 'requestFullscreen'; readonly enabled: boolean });

/** 解析 surface 白名单请求；请求中没有 native handle、进程或文件字段。 */
export function parseSurfaceRequest(value: unknown): SurfaceRequest {
  const input = recordOf(value, 'surface request');
  if (!hasOwn(input, 'channel') || input.channel !== PLAYER_SURFACE_CHANNEL) {
    throw new PortContractError('invalid-request', '请求不属于 surface 白名单通道');
  }
  const operation = operationOf(input, SURFACE_OPERATIONS);
  const instanceId = instanceIdOf(input);
  switch (operation) {
    case 'create':
    case 'resize':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'geometry'], `${operation} request`);
      return Object.freeze({ channel: PLAYER_SURFACE_CHANNEL, operation, instanceId, geometry: validateSurfaceGeometry(input.geometry) });
    case 'show':
    case 'hide':
    case 'focus':
    case 'destroy':
      exactKeys(input, ['channel', 'operation', 'instanceId'], `${operation} request`);
      return Object.freeze({ channel: PLAYER_SURFACE_CHANNEL, operation, instanceId });
    case 'requestFullscreen':
      exactKeys(input, ['channel', 'operation', 'instanceId', 'enabled'], 'requestFullscreen request');
      if (typeof input.enabled !== 'boolean') {
        throw new PortContractError('invalid-request', 'requestFullscreen.enabled 必须是布尔值');
      }
      return Object.freeze({ channel: PLAYER_SURFACE_CHANNEL, operation, instanceId, enabled: input.enabled });
    default:
      throw new PortContractError('unknown-operation', `未允许的 surface 操作：${operation}`);
  }
}

export function isPlaybackRequest(value: unknown): value is PlaybackRequest {
  try { parsePlaybackRequest(value); return true; } catch { return false; }
}

export function isSurfaceRequest(value: unknown): value is SurfaceRequest {
  try { parseSurfaceRequest(value); return true; } catch { return false; }
}

/** 所有端口资源共用这一份生命周期定义。 */
export type PlayerLifecycleState = 'new' | 'active' | 'destroyed';

export interface SurfaceCommandResult {
  readonly operation: SurfaceOperation;
  readonly instanceId: PlayerInstanceId;
  readonly lifecycle: PlayerLifecycleState;
  readonly idempotent: boolean;
}

interface SurfaceRecord {
  readonly senderId: SurfaceSenderId;
  lifecycle: PlayerLifecycleState;
  geometry: SurfaceGeometry | null;
  visible: boolean;
  fullscreen: boolean;
}

/**
 * main 侧授权门：注册实例所有权，验证 sender/实例匹配和调用顺序，且不保存任何 native handle。
 * `release()` 由 main 在真实资源已释放后调用，避免 tombstone 变成句柄/所有权泄漏。
 */
export class SurfaceCommandGate {
  private readonly records = new Map<PlayerInstanceId, SurfaceRecord>();

  get size(): number { return this.records.size; }

  register(instanceId: string | PlayerInstanceId, senderId: string | SurfaceSenderId): void {
    const id = createPlayerInstanceId(instanceId);
    const sender = createSurfaceSenderId(senderId);
    if (this.records.has(id)) {
      throw new PortContractError('invalid-lifecycle', `实例 ${id} 已注册，不能重复绑定`);
    }
    this.records.set(id, { senderId: sender, lifecycle: 'new', geometry: null, visible: false, fullscreen: false });
  }

  dispatch(senderId: string | SurfaceSenderId, value: unknown): SurfaceCommandResult {
    const sender = createSurfaceSenderId(senderId);
    const request = parseSurfaceRequest(value);
    const record = this.records.get(request.instanceId);
    if (!record) throw new PortContractError('unregistered-instance', `实例 ${request.instanceId} 未注册`);
    if (record.senderId !== sender) {
      throw new PortContractError('sender-mismatch', `sender 无权访问实例 ${request.instanceId}`);
    }

    if (request.operation === 'destroy') {
      if (record.lifecycle === 'destroyed') return this.result(request, record, true);
      record.lifecycle = 'destroyed';
      record.geometry = null;
      record.visible = false;
      record.fullscreen = false;
      return this.result(request, record, false);
    }

    if (record.lifecycle === 'destroyed') {
      throw new PortContractError('invalid-lifecycle', `实例 ${request.instanceId} 已销毁`);
    }
    if (request.operation === 'create') {
      if (record.lifecycle !== 'new') throw new PortContractError('invalid-lifecycle', 'surface 已创建，不能重复 create');
      record.geometry = request.geometry;
      record.lifecycle = 'active';
      return this.result(request, record, false);
    }
    if (record.lifecycle !== 'active') {
      throw new PortContractError('invalid-lifecycle', 'surface 必须先 create');
    }
    if (request.operation === 'resize') record.geometry = request.geometry;
    if (request.operation === 'show') record.visible = true;
    if (request.operation === 'hide') record.visible = false;
    if (request.operation === 'requestFullscreen') record.fullscreen = request.enabled;
    return this.result(request, record, false);
  }

  /** 真实 native surface/helper 已释放后清掉主进程登记；之前不能释放。 */
  release(instanceId: string | PlayerInstanceId, senderId: string | SurfaceSenderId): void {
    const id = createPlayerInstanceId(instanceId);
    const sender = createSurfaceSenderId(senderId);
    const record = this.records.get(id);
    if (!record) return;
    if (record.senderId !== sender) throw new PortContractError('sender-mismatch', `sender 无权释放实例 ${id}`);
    if (record.lifecycle === 'active') throw new PortContractError('invalid-lifecycle', 'surface 仍处于活动状态，不能 release');
    this.records.delete(id);
  }

  private result(request: SurfaceRequest, record: SurfaceRecord, idempotent: boolean): SurfaceCommandResult {
    return Object.freeze({ operation: request.operation, instanceId: request.instanceId, lifecycle: record.lifecycle, idempotent });
  }
}

export const PLAYER_CLEANUP_TRIGGERS = [
  'ui-unmount',
  'renderer-reload',
  'browser-window-close',
  'ipc-disconnect',
  'mpv-exit',
  'helper-exit',
] as const;
export type PlayerCleanupTrigger = typeof PLAYER_CLEANUP_TRIGGERS[number];

/** 所有上述触发源必须执行同一份清理顺序；实现可在每一步内部保持幂等。 */
export const PLAYER_CLEANUP_ORDER = [
  'stop-playback',
  'destroy-playback',
  'release-ipc',
  'destroy-surface',
  'clear-renderer-listeners',
] as const;
export type PlayerCleanupStep = typeof PLAYER_CLEANUP_ORDER[number];

export function cleanupOrderFor(trigger: PlayerCleanupTrigger): readonly PlayerCleanupStep[] {
  if (!(PLAYER_CLEANUP_TRIGGERS as readonly string[]).includes(trigger)) {
    throw new PortContractError('invalid-request', `未允许的生命周期触发源：${String(trigger)}`);
  }
  return PLAYER_CLEANUP_ORDER;
}
