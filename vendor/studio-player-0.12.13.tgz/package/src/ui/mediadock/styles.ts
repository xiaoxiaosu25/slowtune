import { sourceStyles } from './source-styles.js';

export const styles = sourceStyles + `
:host { display:block; font:14px var(--font-body); --studio-player-text:var(--text-body); --studio-player-surface:var(--surface-1); --studio-player-border:var(--line); --studio-player-accent:var(--accent-deep); --studio-player-text-muted:var(--text-dim); }
* { box-sizing:border-box; } button,input,select { font:inherit; } button { cursor:pointer; } svg { width:24px;height:24px; }
[hidden],.hidden { display:none!important; }
#m-now {border:0;margin:0;max-width:none;max-height:none;width:100%;}
#m-now::backdrop {background:var(--surface-0);}
:host([data-layout=desktop]) #m-mini,:host([data-layout=desktop]) #m-now { display:none!important; }
:host([data-layout=mobile]) #globalAudioPlayer,:host([data-layout=mobile]) #playerMiniTrigger,:host([data-layout=mobile]) #playerPlaylistPanel { display:none!important; }
:host([data-layout=mobile]) #m-mini { position:fixed;inset:auto 0 var(--mediadock-bottom-inset,env(safe-area-inset-bottom,0px));z-index:var(--z-player); }
:host([data-layout=mobile]) #m-now { z-index:var(--z-player-modal); }
:host([data-layout=mobile]) #m-now .lucide { max-width:100%; }
#m-now-seek { touch-action:pan-y; }
.seek-step-btn { position:relative; }.seek-step-label { position:absolute;font-size:8px;font-weight:700; }
#globalAudioPlayer .control-btn,#globalAudioPlayer .player-extras .control-btn,.playlist-close-btn { min-width:44px;min-height:44px; }
#globalAudioPlayer .rate-trigger { min-height:44px; } #globalAudioPlayer .player-content { grid-template-columns:minmax(150px,1fr) minmax(260px,1.3fr) minmax(310px,1fr); }
@media(max-width:1100px) { #globalAudioPlayer .player-content {grid-template-columns:minmax(120px,1fr) minmax(230px,1.2fr) 290px;gap:12px;} }
@media(max-width:900px) { #globalAudioPlayer .player-content {grid-template-columns:1fr;gap:12px;} #globalAudioPlayer .player-extras {display:flex;justify-content:space-between;flex-wrap:wrap;} }
.dock-sleep {width:min(460px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;border:1px solid var(--line);border-radius:20px;padding:20px;color:var(--text-body);background:var(--surface-1);} .dock-sleep::backdrop {background:var(--overlay);backdrop-filter:blur(12px);}
.dock-sleep > header {display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px;}.dock-sleep > header button {border:0;color:inherit;background:transparent;min-width:44px;min-height:44px;}
.dock-sleep h2 {font-size:18px;margin:0;}
@media(prefers-reduced-motion:reduce) { *,*::before,*::after {animation:none!important;transition:none!important;} }
`;
