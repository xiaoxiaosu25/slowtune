import { mountVideoPlayer, type VideoControlsOptions, type VideoControlsPlacement } from '../video/index.js';
import type { MediaDockPlayerOptions, MediaDockPlayerUI } from './index.js';

export interface MediaDockVideoPlayerUI extends MediaDockPlayerUI {
  readonly controls: VideoControlsPlacement;
  setControls(options: VideoControlsOptions): void;
  handleBack(): boolean;
}

/** 兼容 MediaDock 子路径；视频正式实现与 Stream 共用，音频设计独立维护。 */
export async function mountMediaDockVideoPlayer(root: HTMLElement, options: MediaDockPlayerOptions = {}): Promise<MediaDockVideoPlayerUI> {
  if (options.features?.queue === false) throw new TypeError('MediaDock UI requires its shared queue');
  const { palette = 'mint', view, originalFileUrl: _original, features, ...rest } = options;
  if (!['mint', 'studio'].includes(palette)) throw new TypeError(`Unknown MediaDock palette: ${palette}`);
  if (view && !['bar', 'mini', 'expanded'].includes(view)) throw new TypeError(`Unknown MediaDock view: ${view}`);
  const { queue: featureQueue, videoTracks: _tracks, ...videoFeatures } = features ?? {};
  const ui = await mountVideoPlayer(root, { ...rest, variant: 'mediadock', features: videoFeatures,
    queue: options.queue ?? (typeof featureQueue === 'object' ? featureQueue : undefined) });
  ui.element.dataset.studioMediaDock = 'video'; ui.element.dataset.palette = palette;
  const publicFeatures = Object.freeze({ queue: ui.queue, sleepTimer: ui.sleepTimer, mediaSession: ui.mediaSession, videoTracks: ui.videoTracks, mainMedia: ui.mainMedia });
  return { ...ui, features: publicFeatures,
    get controls() { return ui.controls; },
    setPalette(value) { if (!['mint', 'studio'].includes(value)) throw new TypeError(`Unknown MediaDock palette: ${value}`); if (ui.isDestroyed) throw new Error('Video UI has been destroyed'); ui.element.dataset.palette = value; },
    // 旧音频形态参数在视频入口继续兼容；视频始终为完整舞台。
    setView(value) { if (!['bar', 'mini', 'expanded'].includes(value)) throw new TypeError(`Unknown MediaDock view: ${value}`); ui.setView('standard'); },
  };
}
