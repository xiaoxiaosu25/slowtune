/** Consistent pointer/keyboard hints for the video surface, without native title duplication. */
export function createControlTooltips(screen: HTMLElement, signal: AbortSignal) {
  const doc = screen.ownerDocument;
  const root = screen.getRootNode() as ShadowRoot;
  const tip = doc.createElement('span');
  tip.className = 'video-tooltip'; tip.hidden = true; tip.setAttribute('aria-hidden', 'true');
  screen.append(tip);
  const shortcuts: Record<string, string> = { play: 'K', mute: 'M', fullscreen: 'F', wide: 'T', pip: 'I', captions: 'C', next: 'Shift+N' };
  let timer: ReturnType<typeof setTimeout> | undefined;
  let active: HTMLButtonElement | null = null;
  function button(target: EventTarget | null) {
    const node = (target as Element | null)?.closest?.<HTMLButtonElement>('button');
    return node && screen.contains(node) && !node.closest('[data-popup-surface]') && !node.disabled ? node : null;
  }
  function hide() { clearTimeout(timer); active = null; tip.hidden = true; }
  function show(target: HTMLButtonElement, delay: number) {
    hide(); active = target;
    timer = setTimeout(() => {
      if (active !== target || !target.getClientRects().length || getComputedStyle(target).visibility === 'hidden') return;
      const label = target.getAttribute('aria-label');
      if (!label) return;
      const key = shortcuts[target.dataset.action ?? ''];
      tip.textContent = key ? `${label} (${key})` : label;
      tip.hidden = false;
      const box = target.getBoundingClientRect(), bounds = screen.getBoundingClientRect();
      const size = tip.getBoundingClientRect();
      const below = Boolean(target.closest('.screen-heading'));
      tip.style.left = `${Math.max(8, Math.min(box.left - bounds.left + (box.width - size.width) / 2, bounds.width - size.width - 8))}px`;
      tip.style.top = `${Math.max(8, Math.min(below ? box.bottom - bounds.top + 8 : box.top - bounds.top - size.height - 8, bounds.height - size.height - 8))}px`;
    }, delay);
  }
  screen.addEventListener('pointerover', event => {
    if (event.pointerType === 'touch') return;
    const target = button(event.target);
    if (target && target !== button(event.relatedTarget)) show(target, 400);
  }, { signal });
  screen.addEventListener('pointerout', event => { if (button(event.target) !== button(event.relatedTarget)) hide(); }, { signal });
  root.addEventListener('focusin', event => { const target = button(event.target); if (target?.matches(':focus-visible')) show(target, 0); }, { signal });
  root.addEventListener('focusout', hide, { signal });
  root.addEventListener('pointerdown', hide, { signal });
  root.addEventListener('keydown', hide, { signal });
  signal.addEventListener('abort', () => { hide(); tip.remove(); }, { once: true });
  return {
    hide,
    refresh() {
      for (const control of screen.querySelectorAll<HTMLButtonElement>('button[data-action]')) {
        control.removeAttribute('title');
        const key = shortcuts[control.dataset.action ?? ''];
        if (key) control.setAttribute('aria-keyshortcuts', key);
      }
    },
  };
}
