import { sharedVideoStyles } from './styles-shared.js';

/**
 * Stream 保真变体皮肤（`variant: 'stream'`）。
 *
 * 数值来自真实播放器的运行时测量；判据与参照采集见 labs/audio-video/player/video-check/README.md
 * 的"Stream 保真变体"一节。与实测的两处**有意差异**：
 *   1. 控制条按钮取 44px 命中区（Stream 实测 40px），视觉随之高 4px，其余间距一致；
 *   2. 进度条的**视觉**是实测的 6px，元素盒放大到 20px 以得到可用命中区（用负外边距抵消布局影响）。
 * 不复制 Stream 的 CSS、图标路径与设计令牌；字体走系统栈，不自托管。
 */
export const streamStyles = `
:host {
  display: block;
  min-width: 0;
  color-scheme: dark;
  font: 14px/1.5 var(--studio-video-font,Roboto,Arial,"PingFang SC","Microsoft YaHei",sans-serif);
  --stream-text: #eee;
  --stream-white: #fff;
  --stream-muted: rgba(255, 255, 255, 0.7);
  --stream-btn-bg: rgba(0, 0, 0, 0.3);
  --stream-menu-bg: rgba(0, 0, 0, 0.6);
  --stream-hover: rgba(255, 255, 255, 0.1);
  --stream-red: #ff0033;
  --stream-pink: #ff2791;
  --stream-loader: #ff0033;
  --stream-playlist-bg: #212121;
  --stream-ease: cubic-bezier(0.4, 0, 1, 1);
  --stream-page-bg: #0f0f0f;
  --stream-page-text: #f1f1f1;
  --stream-page-muted: #aaa;
  --stream-page-border: #ffffff26;
  --stream-page-surface: #ffffff12;
  --stream-page-error: #ff8a80;
  /* 透传给 mountSleepTimerSettings Shadow DOM 的公共变量 */
  --studio-player-text: var(--stream-text);
  --studio-player-text-muted: var(--stream-muted);
  --studio-player-surface: rgba(255, 255, 255, 0.08);
  --studio-player-option-background: #212121;
  --studio-player-border: rgba(255, 255, 255, 0.2);
  --studio-player-accent: var(--stream-red);
  --studio-player-error: #ff8a80;
  --studio-player-radius: 8px;
}
:host([data-theme=light]) { color-scheme:light; --stream-page-bg:#fff; --stream-page-text:#0f0f0f; --stream-page-muted:#606060; --stream-page-border:#00000026; --stream-page-surface:#0000000d; --stream-page-error:#b42338; }
@media (prefers-color-scheme: light) { :host([data-theme=auto]) { color-scheme:light; --stream-page-bg:#fff; --stream-page-text:#0f0f0f; --stream-page-muted:#606060; --stream-page-border:#00000026; --stream-page-surface:#0000000d; --stream-page-error:#b42338; } }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
video-player, media-container { display: block; min-width: 0; }
button, input { font: inherit; color: inherit; }
button { border: 0; background: none; cursor: pointer; touch-action: manipulation; }
button:disabled { opacity: .4; cursor: default; }
svg { display: block; flex: none; pointer-events: none; }
.stream-icon { width: 24px; height: 24px; }
:is(button, input, [role=slider], .screen):focus-visible { outline: 3px solid #3ea6ff; outline-offset: 2px; }

.root {
  --timeline: var(--studio-video-timeline, var(--stream-red));
  --accent: var(--studio-video-accent, #3ea6ff);
  --text: var(--studio-video-text, var(--stream-page-text));
  --muted: var(--studio-video-text-muted, var(--stream-page-muted));
  --border: var(--studio-video-border, var(--stream-page-border));
  --surface: var(--studio-video-surface, var(--stream-page-surface));
  --radius: var(--studio-video-radius, 12px);
  color: var(--text);
  position: relative;
  isolation: isolate;
  background: var(--studio-video-background, var(--stream-page-bg));
}
.stream-stage { position: relative; overflow: hidden; background: #000; }
/* 宽屏由宿主提供可用宽度；组件始终留在挂载容器内。 */
.root[data-view=wide] .stream-stage { width:100%; margin:0; border-radius:0; }
.root[data-view=wide] .screen { aspect-ratio:21/9; }
.screen {
  position: relative;
  isolation: isolate;
  overflow: hidden;
  aspect-ratio: 16 / 9;
  background: #000;
  color: var(--stream-text);
  user-select: none;
}
.screen:focus-visible { outline-offset: -3px; }
.media-slot, .media-slot > * {
  display: block;
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: contain;
  --media-object-fit: contain;
  --media-caption-track-y: 0px;
}
/* mpv 的原生子窗口由宿主贴在 surface slot；给控制条保留可点击区域，避免它遮住浮层。 */
.root[data-backend=mpv] .media-slot {
  bottom: 96px;
  height: calc(100% - 96px);
  pointer-events: none;
}
.screen ::cue { background: rgba(8, 8, 8, .75); color: #fff; font: 20px/1.5 Roboto, Arial, sans-serif; }

/* 顶部标题条：实测 48px 高、上深下透的渐变，标题 18px 左内缩 4px。 */
.screen-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  position: absolute;
  inset: 0 0 auto;
  height: 48px;
  padding: 12px 12px 0;
  background: linear-gradient(180deg, rgba(0, 0, 0, .5), rgba(0, 0, 0, 0));
  font-size: 18px;
  z-index: 4;
}
.screen-title { flex:1; min-width:0; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; }
.feature-shortcuts { display:contents; }
.source-options-title { font-size:12px; color:var(--stream-muted); padding:12px 16px 0; margin:0; border-top:1px solid #ffffff24; }
.control-placement-panel label { display:flex; align-items:center; justify-content:space-between; gap:16px; margin:8px 16px; }
.control-placement-panel > .hint { margin:12px 16px 16px; color:var(--stream-muted); font-size:12px; line-height:1.5; }
.control-placement-panel select { min-height:44px; border:1px solid #ffffff38; border-radius:8px; padding:4px 8px; background:#181818; color:#eee; font:inherit; }
.control-presets { display:flex; gap:8px; padding:12px 16px; }
.control-presets button { border:1px solid #ffffff38; border-radius:8px; padding:8px 12px; min-height:44px; }
.control-presets button[aria-pressed=true] { color:#fff; background:#ffffff24; border-color:var(--timeline); }
.screen-actions { display: flex; align-items: center; flex: none; gap: 8px; }
/* 顶部右侧入口保留 44px 命中区，避免窄屏触控时贴边误触。 */
.screen-heading .stream-btn { width: 44px; height: 44px; padding: 10px; border-radius: 50%; background: rgba(0, 0, 0, .6); }
.screen-heading .stream-btn:hover:enabled { background: rgba(0, 0, 0, .8); }

/* 控制条：实测左右内缩 12px、按钮行 56px、底部 3px；下方渐变约 61px（上 37px 透明）。 */
.controls {
  position: absolute;
  inset: auto 0 0;
  z-index: 3;
  padding: 37px 12px 0;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0) 37px, rgba(0, 0, 0, .28) 52px, rgba(0, 0, 0, .5) 100%);
}
.control-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; height: 56px; min-width: 0; }
.transport {
  display: flex;
  align-items: center;
  flex: 0 1 auto;
  min-width: 0;
  height: 56px;
  padding: 0;
  border-radius: 0;
  background: transparent;
}
.tools { display: flex; align-items: center; flex: none; height: 44px; margin: 0; padding: 0 4px; background: var(--stream-btn-bg); border-radius: 28px; }

/* 左簇：Stream 不给整组加底色，只给播放与音量入口各自加圆形/药丸底。 */
.stream-btn, .mute-control, .pip-control, .fullscreen-control {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 44px;
  height: 44px;
  padding: 10px;
  margin: 0;
  color: var(--stream-text);
  background: none;
  border-radius: 0;
}
.transport > .stream-btn, .transport .mute-control {
  flex: 0 0 44px;
  background: transparent;
  border-radius: 0;
}
.transport > [data-action=play] { background: var(--stream-btn-bg); border-radius: 50%; }
.transport > [data-action=play]:hover:enabled { background: rgba(0, 0, 0, .6); }
.transport > [data-action=next]:disabled { display: none; }
.volume {
  display: flex;
  align-items: center;
  flex: 0 0 44px;
  width: 44px;
  min-width: 44px;
  height: 44px;
  margin: 0 0 0 8px;
  padding-right: 0;
  border-radius: 22px;
  background: var(--stream-btn-bg);
  transition: width .2s var(--stream-ease), flex-basis .2s var(--stream-ease), padding-right .2s var(--stream-ease);
}
.volume .mute-control {
  flex: 0 0 44px;
  border-radius: 0;
  background: transparent;
}
/* 轨道 64px + thumb 向右外溢 6px，壳体额外留 6px 安全边界；右内边距共 12px。 */
.volume:hover, .volume:focus-within { flex-basis: 120px; width: 120px; padding-right: 12px; }
/* 音量条收起时不占空间；展开后固定占位，时间不会被 flex-shrink 挤窄。 */
.volume .volume-range {
  display: flex;
  align-items: center;
  flex: 0 0 0;
  width: 0;
  overflow: hidden;
  height: 20px;
  opacity: 0;
  transition: width .2s var(--stream-ease), flex-basis .2s var(--stream-ease), opacity .12s var(--stream-ease);
  cursor: pointer;
  touch-action: none;
}
.volume:hover .volume-range, .volume:focus-within .volume-range {
  flex-basis: 64px;
  width: 64px;
  opacity: 1;
}
.time {
  font-size: 14px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--stream-white);
  flex: 0 0 auto;
  min-width: max-content;
  margin-left: 8px;
  padding: 8px;
  white-space: nowrap;
  line-height: 40px;
  height: 56px;
  text-shadow: rgba(0, 0, 0, .5) 0 0 2px;
}
.time-divider, .time [data-duration] { font-weight: 400; }

/* 右簇：单个 28px 圆角药丸，内部按钮 48×44（实测 48×40）。 */
.tools .stream-btn, .tools .pip-control, .tools .fullscreen-control { width: 48px; height: 44px; padding: 10px 12px; border-radius: 0; }
.tools > :first-child { border-radius: 26px 0 0 26px; }
.tools > :last-child { border-radius: 0 26px 26px 0; }
.tools .stream-btn:hover:enabled, .tools .pip-control:hover, .tools .fullscreen-control:hover { background: rgba(255, 255, 255, .1); }
.stream-text-btn { min-height: 36px; padding: 0 16px; border-radius: 18px; background: rgba(255, 255, 255, .1); color: var(--stream-white); font-size: 14px; font-weight: 500; }
.stream-text-btn:hover:enabled { background: rgba(255, 255, 255, .2); }
.stream-text-btn.primary { background: #fff; color: #0f0f0f; }

/* 自动播放：Stream 右侧只保留 48px 开关槽位，文字由 tooltip/aria-label 提供。 */
.stream-switch-cell { display: inline-flex; align-items: center; justify-content: center; position: relative; gap: 0; width: 48px; min-width: 48px; height: 44px; padding: 0; cursor: pointer; }
.stream-switch-cell input, .stream-loop input { position: absolute; inset: 0; width: 100%; height: 100%; margin: 0; opacity: 0; cursor: pointer; }
.stream-switch { pointer-events: none; display: block; position: relative; width: 40px; height: 24px; border-radius: 12px; background: rgba(255, 255, 255, .3); transition: background .08s var(--stream-ease); }
.stream-switch-label { display: none; }
.stream-switch::after { content: ""; position: absolute; top: 2px; left: 2px; width: 20px; height: 20px; border-radius: 50%; background: #fff; transition: transform .08s var(--stream-ease), background .08s var(--stream-ease); }
.stream-switch-cell input:checked + .stream-switch, .stream-loop input:checked + .stream-switch { background: rgba(255, 255, 255, .9); }
.stream-switch-cell input:checked + .stream-switch::after, .stream-loop input:checked + .stream-switch::after { transform: translateX(16px); background: #212121; }
.stream-switch-cell input:focus-visible + .stream-switch, .stream-loop input:focus-visible + .stream-switch { outline: 2px solid #3ea6ff; outline-offset: 2px; }
.stream-loop { display: inline-flex; align-items: center; gap: 10px; position: relative; font-size: 13px; color: var(--stream-muted); }

/* 进度条：视觉 6px（实测），元素盒 20px 用于命中，靠负外边距保持视觉位置。 */
.controls .time-range {
  display: flex;
  align-items: center;
  position: relative;
  height: 20px;
  margin: -7px 0 -7px;
  min-width: 0;
  cursor: pointer;
  touch-action: none;
}
.controls .volume-range { position: relative; min-width: 0; }
.controls .range-track { display: block; position: relative; height: 4px; width: 100%; border-radius: 3px; background: rgba(40, 40, 40, .6); transition: height .1s var(--stream-ease); }
.controls .time-range:hover .range-track,
.controls .time-range:focus-within .range-track { height: 6px; }
.controls .range-buffer, .controls .range-fill { display: block; position: absolute; top: 0; left: 0; height: 100%; }
.controls .range-buffer { width: var(--range-buffer); background: rgba(255, 255, 255, .4); }
.controls .range-fill { width: var(--range-fill); background: linear-gradient(90deg, var(--stream-red) 80%, var(--stream-pink)); }
/* 音量轨道的静止态：白 30% */
.volume-range .range-track { background: rgba(255, 255, 255, .3); border-radius: 3px; }
.volume-range .range-fill { background: #fff; border-radius: 3px; }
.controls .range-thumb {
  display: block;
  position: absolute;
  left: var(--range-fill);
  top: 50%;
  width: 12px;
  height: 12px;
  margin: 0;
  border-radius: 50%;
  background: var(--stream-red);
  transform: translate(-50%, -50%) scale(1);
  transition: transform .1s var(--stream-ease);
}
/* 音量 thumb 两端各留半径 6px，避免被 .volume-range 的裁剪边界切掉一半。 */
.controls .volume-range .range-thumb { left: clamp(6px, var(--range-fill), calc(100% - 6px)); }
.volume-range .range-thumb { background: #fff; }
.controls .time-range:hover .range-thumb,
.controls .time-range:focus-within .range-thumb { transform: translate(-50%, -50%) scale(1.67); }

/* 居中大播放键：实测 68×48、居中偏移 -24/-34，深色圆角底 + 白色三角。 */
.center { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 18px; padding: 24px; text-align: center; pointer-events: none; }
.center-copy { display: none; }
.root[data-state=empty] .center-copy, .root[data-state=error] .center-copy, .root[data-state=stopped] .center-copy { display: block; }
.center-copy h2 { margin: 0 0 8px; font-size: clamp(18px, 2.4vw, 26px); font-weight: 500; }
.center-copy p { margin: 0; font-size: 14px; color: #ddd; }
.eyebrow { margin: 0 0 6px; font-size: 12px; letter-spacing: .04em; color: var(--stream-muted); }
.center-actions { display: flex; align-items: center; gap: 16px; pointer-events: auto; }
.center .stream-btn, .center .stream-text-btn { pointer-events: auto; }
.center-play {
  width: 68px;
  height: 48px;
  border-radius: 10px;
  background: rgba(33, 33, 33, .8);
  color: #fff;
  transition: background .1s var(--stream-ease), opacity .25s cubic-bezier(0, 0, .2, 1);
}
.center-play .stream-icon { width: 30px; height: 30px; }
.center-play:hover:enabled { background: var(--stream-red); }
.root[data-state=playing] .center, .root[data-state=ended] .center { display: none; }
.stream-end-slate { position: absolute; inset: 0; z-index: 2; display: flex; align-items: center; justify-content: center; padding: 24px; background: linear-gradient(180deg, rgba(0, 0, 0, .12), rgba(0, 0, 0, .5)); pointer-events: none; }
.stream-end-card { width: min(480px, 100%); padding: 24px 28px; border: 1px solid rgba(255, 255, 255, .14); border-radius: 12px; background: rgba(15, 15, 15, .88); box-shadow: 0 12px 36px rgba(0, 0, 0, .45); color: var(--stream-white); text-align: center; pointer-events: auto; }
.stream-end-kicker { display: block; margin-bottom: 8px; color: var(--stream-muted); font-size: 12px; }
.stream-end-title { margin: 0; font-size: 22px; font-weight: 500; line-height: 1.35; overflow-wrap: anywhere; }
.stream-end-description { margin: 8px 0 20px; color: var(--stream-muted); font-size: 14px; }
.stream-end-actions { display: flex; justify-content: center; gap: 8px; flex-wrap: wrap; }
.stream-end-btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; min-height: 44px; padding: 0 16px; border-radius: 22px; background: rgba(255, 255, 255, .12); color: var(--stream-white); font-size: 14px; font-weight: 500; }
.stream-end-btn .stream-icon { width: 20px; height: 20px; }
.stream-end-btn:hover:enabled { background: rgba(255, 255, 255, .2); }
.stream-end-btn.primary { background: var(--stream-white); color: #0f0f0f; }
.stream-end-btn.primary:hover:enabled { background: #fff; }
.touch-seek { display: none; }
.buffering { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; pointer-events: none; }
.spinner { width: 44px; height: 44px; border: 4px solid rgba(255, 255, 255, .25); border-top-color: var(--stream-loader); border-radius: 50%; animation: stream-spin .9s linear infinite; }
@keyframes stream-spin { to { transform: rotate(360deg); } }
.root[data-controls-hidden=true] .controls, .root[data-controls-hidden=true] .screen-heading { opacity: 0; pointer-events: none; }
.root[data-controls-hidden=true] .screen { cursor: none; }
.controls, .screen-heading { transition: opacity .25s cubic-bezier(0, 0, .2, 1); }

/* 播放列表：播放器内右侧栏（实测面板底色 #212121、宽 400、行高 48 的标题区）。 */
.stream-playlist {
  position: absolute;
  inset: 0 0 0 auto;
  z-index: 5;
  display: flex;
  flex-direction: column;
  width: min(400px, 100%);
  background: var(--stream-playlist-bg);
  color: var(--stream-text);
  box-shadow: -8px 0 24px rgba(0, 0, 0, .4);
}
.stream-playlist-header { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 8px 8px 16px; border-bottom: 1px solid rgba(255, 255, 255, .1); }
.stream-playlist-heading { display: flex; align-items: baseline; gap: 10px; min-width: 0; }
.stream-playlist-heading h2 { margin: 0; font-size: 16px; font-weight: 500; }
.stream-playlist-heading span { color: var(--stream-muted); font-size: 13px; }
.stream-playlist-actions { display: flex; align-items: center; gap: 4px; }
.stream-playlist .stream-btn:hover:enabled { background: rgba(255, 255, 255, .1); border-radius: 50%; }
.episode-list { list-style: none; margin: 0; padding: 8px 0; overflow: auto; overscroll-behavior: contain; scrollbar-width: thin; }
.episode-row { display: grid; grid-template-columns: 100px minmax(0, 1fr); gap: 8px; align-items: center; width: 100%; min-height: 68px; padding: 4px 8px; text-align: left; color: inherit; }
.episode-row:hover { background: rgba(255, 255, 255, .1); }
.episode-row[aria-current=true] { background: rgba(255, 255, 255, .16); }
.episode-thumb { position: relative; display: grid; place-items: center; width: 100px; aspect-ratio: 16 / 9; border-radius: 8px; overflow: hidden; background: #000; color: var(--stream-text); font-size: 13px; font-weight: 500; }
.episode-thumb img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.episode-copy { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
.episode-copy strong { font-size: 14px; font-weight: 500; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.episode-copy small { color: var(--stream-muted); font-size: 12px; }
.stream-empty, .stream-note { margin: 0; padding: 8px 16px; color: var(--stream-muted); font-size: 12px; }

/* 播放器下方信息条：只保留标题/状态/宿主动作，watch 页外壳不在本变体范围。 */
.now { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 16px 16px 8px; }
.now-copy { min-width: 0; }
.now h2 { margin: 0 0 6px; font-size: 20px; font-weight: 700; line-height: 1.35; overflow-wrap: anywhere; }
.now-copy > p:last-child { margin: 0; color: var(--muted); font-size: 14px; overflow-wrap: anywhere; }
.host-actions { display: flex; gap: 8px; flex: none; }
.host-actions button { min-height: 36px; padding: 0 14px; border-radius: 18px; background: var(--surface); font-size: 14px; font-weight: 500; }
.host-actions button:hover { filter: brightness(1.15); }
.statusline { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 0 16px 16px; color: var(--muted); font-size: 12px; }
.statusline p { margin: 0; }
.statusline > span { color: var(--accent); }
.error { margin: 0 16px 16px; padding: 10px 12px; border-radius: var(--radius); background: var(--surface); color: var(--studio-video-error, #ff8a80); font-size: 13px; }
.closed { display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 32px; border-radius: var(--radius); border: 1px solid var(--border); background: var(--bg, transparent); }
.closed h2 { margin: 0 0 6px; font-size: 22px; }
.closed p { margin: 0; color: var(--muted); font-size: 14px; }

/* ---------- 浮层皮肤：覆盖核的默认值（核样式后注入，因此这里统一提高一级特异性） ---------- */
.stream-root .studio-overlay {
  --studio-overlay-background: var(--stream-menu-bg);
  --studio-overlay-text: var(--stream-text);
  --studio-overlay-muted: var(--stream-muted);
  --studio-overlay-border: transparent;
  --studio-overlay-hover: var(--stream-hover);
  --studio-overlay-accent: var(--stream-text);
  --studio-overlay-focus: #3ea6ff;
  --studio-overlay-font-label: 12px;
  --studio-overlay-font-item: 14px;
  --studio-overlay-font-meta: 14px;
  border-radius: 12px;
  border: 0;
  box-shadow: 0 4px 32px rgba(0, 0, 0, .35);
  text-shadow: rgba(0, 0, 0, .5) 0 0 2px;
}
.stream-root .studio-overlay-panel { padding: 8px 0; min-width: 250px; }
/* 面板宽度随内容变化（实测：根 274、播放速度 330、休眠定时器 251）。 */
.stream-root [data-popup-panel=settings] { min-width: 274px; }
.stream-root [data-popup-panel=rate] { min-width: 330px; }
.stream-root [data-popup-panel=sleep] { min-width: 251px; }
.stream-root [data-popup-panel=sleep-settings] { min-width: 330px; }
/* 子面板头：实测总高 57px（返回键 48 + 上下各 4.5px），面板内边距 8px。 */
.stream-root .studio-overlay-header { min-height: 57px; padding: 4.5px 0; gap: 0; font-size: 12px; font-weight: 400; }
.stream-root .studio-overlay-back { width: 48px; height: 48px; border-radius: 0; }
.stream-root .studio-overlay-back:hover { background: var(--stream-hover); }
.stream-root .studio-overlay-back .stream-icon { width: 24px; height: 24px; }
.stream-root .studio-overlay-title { padding-right: 16px; }
.stream-root [data-popup-item] { min-height: 48px; padding: 0; gap: 0; font-size: 14px; font-weight: 400; }
.stream-root [data-popup-item]:not([aria-disabled=true]):hover { background: var(--stream-hover); }
.stream-root [data-popup-item][aria-checked=true] { color: var(--stream-text); font-weight: 400; }
.stream-root .studio-overlay-item-icon { width: 56px; justify-content: center; padding: 0 0 0 0; color: var(--stream-text); }
.stream-root .studio-overlay-item-icon .stream-icon { width: 24px; height: 24px; }
.stream-root .studio-overlay-item-label { padding-right: 15px; line-height: 18.2px; }
.stream-root .studio-overlay-item-value { max-width: none; padding: 0 8px 0 15px; color: var(--stream-muted); font-size: 14px; }
.stream-root .studio-overlay-item-arrow { width: 40px; justify-content: center; padding-right: 8px; color: var(--stream-text); }
.stream-root .studio-overlay-item-arrow .stream-icon { width: 20px; height: 20px; }
/* 子面板的单选行：标签左内缩 35px（实测），选中勾落在左侧图标位（8px 起）。 */
.stream-root [data-popup-item].stream-option { padding-left: 35px; }
.stream-root [data-popup-item][role=menuitemradio] { position: relative; }
.stream-root [data-popup-item][role=menuitemradio]::after { content: ""; position: absolute; left: 8px; top: 50%; width: 24px; height: 24px; margin: 0; transform: translateY(-50%); }
.stream-root [data-popup-item][role=menuitemradio][aria-checked=true]::after {
  background: var(--stream-text);
  mask: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z'/></svg>") center / 24px 24px no-repeat;
}
.stream-root .studio-overlay-hint { margin: 0; padding: 4px 16px 8px; color: var(--stream-muted); font-size: 12px; line-height: 1.6; }
.stream-root .studio-overlay [data-sleep-settings] { padding: 0 16px 8px; }
.stream-root .studio-overlay [data-popup-panel=sleep] [data-sleep-status] { margin-left: auto; padding-right: 16px; }
.stream-root .stream-rate-control { display: flex; flex-direction: column; gap: 4px; padding: 4px 16px 8px; border-bottom: 1px solid rgba(255, 255, 255, .12); }
.stream-root .stream-rate-current { min-height: 24px; color: var(--stream-text); font-size: 18px; font-weight: 700; line-height: 22px; text-align: center; }
.stream-root .stream-rate-control input[type=range] { width: 100%; height: 20px; margin: 0; accent-color: var(--stream-text); cursor: pointer; }
.stream-root .stream-rate-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 4px; padding: 8px; }
.stream-root .stream-rate-grid [data-popup-item] { min-height: 40px; padding: 0 8px; border-radius: 6px; justify-content: center; }
.stream-root .stream-rate-grid [data-popup-item] .studio-overlay-item-label { padding: 0; text-align: center; }
/* 倍速档位只在左侧保留一个 16px 选中列，避免 24px 伪元素压住数值；档位本身不重复显示 x。 */
.stream-root .stream-rate-grid [data-popup-item][role=menuitemradio]::after { left: 4px; width: 16px; height: 16px; }

/* 全屏与移动 */
media-container:fullscreen { height: 100dvh; background: #000; padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left); }
media-container:fullscreen .stream-stage { height: 100%; }
media-container:fullscreen .screen { height: 100%; aspect-ratio: auto; }
media-container:fullscreen :is(.now, .statusline, .error) { display: none; }
	.range-control { position: relative; min-width: 0; cursor: pointer; touch-action: none; }
	.range-input { appearance: none; position: absolute; inset: 50% 0 auto; width: 100%; height: 44px; margin: 0; transform: translateY(-50%); background: transparent; cursor: inherit; z-index: 2; }
	.range-input:disabled { cursor: default; }
	.range-input::-webkit-slider-runnable-track { height: 100%; background: transparent; }
	.range-input::-webkit-slider-thumb { appearance: none; width: 44px; height: 44px; border: 0; border-radius: 50%; background: transparent; }
	.range-input::-moz-range-track { height: 100%; background: transparent; }
	.range-input::-moz-range-thumb { width: 44px; height: 44px; border: 0; border-radius: 50%; background: transparent; }
	.range-control[data-disabled] { cursor: default; opacity: .55; }
	.range-input:focus-visible { outline: 3px solid #3ea6ff; outline-offset: 2px; }
	@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
.stream-root .stream-stage{border-radius:var(--radius)}
.stream-root .screen{color-scheme:dark;color:var(--studio-video-controls,var(--stream-text))}
.stream-root .controls .range-fill{background:var(--studio-video-timeline,linear-gradient(90deg,var(--stream-red) 80%,var(--stream-pink)))}
.stream-root .controls .range-thumb{background:var(--timeline)}
.stream-root .volume-range .range-fill,.stream-root .volume-range .range-thumb{background:#fff}
.stream-root .stream-btn{color:var(--studio-video-controls,var(--stream-text))}
.stream-root .control-row{height:auto;min-height:56px;flex-wrap:wrap}
.stream-root .tools{margin-left:auto}
.stream-root .screen-heading{height:auto;min-height:56px;padding:8px 12px;align-items:center}
.stream-root .error{color:var(--studio-video-error,var(--stream-page-error))}
.stream-root .now .eyebrow{color:var(--muted)}
.stream-root .stream-text-btn{min-height:44px}
.stream-root .stream-playlist{min-height:0}
.stream-root .stream-playlist-header,.stream-root .stream-note{flex-shrink:0}
.stream-root .stream-playlist .episode-list{flex:1;min-height:0}
.stream-root .episode-thumb b{position:relative;z-index:1;border-radius:4px;padding:1px 5px;background:#000b;color:#fff}
.stream-root .studio-overlay{color-scheme:dark;--studio-overlay-background:rgba(24,24,24,.96);--studio-overlay-focus:var(--studio-video-focus,#3ea6ff)}
.stream-root .studio-overlay-item-value{max-width:140px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.stream-root .studio-overlay-panel{min-width:min(250px,calc(100vw - 24px))}
.stream-root [data-popup-panel=rate],.stream-root [data-popup-panel=sleep-settings]{min-width:min(330px,calc(100vw - 24px))}
.stream-root [data-popup-panel=settings]{min-width:min(274px,calc(100vw - 24px))}
.stream-root [data-popup-panel=sleep]{min-width:min(251px,calc(100vw - 24px))}
.stream-root .stream-rate-control input[type=range],.stream-root .stream-rate-grid [data-popup-item]{min-height:44px}
.stream-root .stream-end-slate{padding:56px 16px 132px}
.stream-root .stream-end-card{padding:16px 20px}
.stream-root .stream-end-title{font-size:18px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.stream-root .stream-end-description{margin:6px 0 12px;font-size:12px}
.stream-root .stream-end-kicker{margin-bottom:4px}
@container studio-video (max-width:640px){
  .stream-root .screen{min-height:280px}
  .stream-root:is([data-state=empty],[data-state=error],[data-state=ended],[data-state=stopped]) .screen{min-height:360px}
  .stream-root .center{padding:56px 16px 140px;gap:12px}
  .stream-root .center-actions{gap:12px}
  .stream-root .stream-end-description{display:none}
}

media-container:fullscreen .stream-stage{width:100%;margin:0;border-radius:0}
media-container:fullscreen .screen{min-height:0}
.stream-root media-container:fullscreen .screen{min-height:0}
@media(max-height:420px){
  .stream-root media-container:fullscreen :is(.center,.stream-end-slate){padding:52px 12px 136px}
  .stream-root media-container:fullscreen .stream-end-card{padding:8px 12px;max-height:100%;overflow-y:auto}
  .stream-root media-container:fullscreen :is(.stream-end-kicker,.stream-end-description){display:none}
}
.stream-root{--video-control-radius:50%}
.stream-root .tools{background:none;padding:0;gap:2px;border:0}
.stream-root .tools :is(.stream-btn,.fullscreen-control){width:44px;padding:10px}
.stream-root .stream-rate-grid [data-popup-item]{padding:0 8px}
.stream-root .stream-rate-grid [data-popup-item]::after{display:none}
.stream-root .stream-rate-grid [data-popup-item][aria-checked=true]{box-shadow:inset 0 0 0 1px #ffffff65}
.stream-root .stream-playlist{box-shadow:-12px 0 36px #0004;border-left:1px solid #ffffff1a;animation:stream-playlist-in 180ms ease-out}
.stream-root .episode-row[aria-current=true]{background:#ffffff16;box-shadow:inset 3px 0 var(--timeline)}
.stream-root .controls{background:linear-gradient(transparent,#000b);padding-top:20px}
@keyframes stream-playlist-in{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:none}}
.stream-root .stream-autoplay{display:flex;align-items:center;justify-content:space-between;padding:4px 16px;font-size:13px;color:var(--stream-text)}
${sharedVideoStyles}
.stream-root .center-play{width:72px;height:52px;border-radius:16px}
.stream-root .studio-overlay [data-popup-item][role=menuitemradio]::after{width:18px;height:18px}
.stream-root .studio-overlay-item-label{padding-right:12px}
.stream-root .studio-overlay-item-value{padding-left:4px}
.stream-root .studio-overlay-item-icon{width:44px}
.stream-root .studio-overlay-item-arrow{width:28px}
`;
