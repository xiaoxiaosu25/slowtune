import type { StudioPlayer } from '../../player.js';
import type { VideoTracksController } from '../../video-tracks/index.js';
import { readSubtitleFile } from '../../video-tracks/index.js';

/** 同资源字幕导入。晚到文件读取不能覆盖换集/关闭/销毁后的会话。 */
export function createVideoSourceFeatures(player: StudioPlayer, tracks: VideoTracksController) {
  let disposed = false, revision = 0, subtitleURL: string | null = null, selecting = false;
  const release = () => { revision++; selecting = false; if (subtitleURL) URL.revokeObjectURL(subtitleURL); subtitleURL = null; };
  const changed = () => {
    if (selecting && tracks.snapshot.subtitles.some(track => track.id === 'imported' && !['error', 'unavailable'].includes(track.status ?? ''))) {
      selecting = false; tracks.selectSubtitle('imported');
    }
  };
  const off = [player.on('loadstart', release), player.on('closerequest', release), player.on('stop', release)];
  const canImport = () => Boolean(player.currentPlan && player.state !== 'stopped');
  tracks.addEventListener('change', changed);
  return {
    async importSubtitle(file: File): Promise<void> {
      if (disposed) throw new Error('Video UI has been destroyed');
      if (!/\.(srt|vtt)$/i.test(file.name)) throw new TypeError('Choose SRT or WebVTT subtitles');
      if (!canImport()) throw new Error('Load a video playback plan before importing subtitles');
      const request = ++revision, resource = player.currentResourceId;
      const text = await readSubtitleFile(file);
      if (disposed || request !== revision || resource !== player.currentResourceId || !player.currentPlan || !canImport()) return;
      const url = URL.createObjectURL(new Blob([text], { type: 'text/vtt' }));
      const previous = subtitleURL;
      selecting = true;
      try {
        player.replaceSource({ ...player.currentPlan, tracks: { ...player.currentPlan.tracks,
          subtitles: [...(player.currentPlan.tracks?.subtitles?.filter(track => track.id !== 'imported') ?? []),
            { id: 'imported', src: url, type: 'text/vtt', label: file.name, language: 'und', default: true }] } });
        subtitleURL = url; changed();
        if (previous) URL.revokeObjectURL(previous);
      } catch (error) { selecting = false; URL.revokeObjectURL(url); throw error; }
    },
    cancelPending() { revision++; },
    destroy() { if (disposed) return; disposed = true; release(); off.forEach(cleanup => cleanup()); tracks.removeEventListener('change', changed); },
  };
}
