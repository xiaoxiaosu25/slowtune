import { RATE_VALUES, rateLabel, sleepQuickMarkup, infoFactsMarkup, playbackSettingsMarkup, createSettingsContent } from './settings-content.js';
import type { StudioPlayer } from '../../player.js';
import type { SleepTimerController } from '../../sleep-timer/index.js';
import type { VideoTracksController, VideoTrackOption } from '../../video-tracks/index.js';
import type { VideoPlayerTheme } from './index.js';
import { createOverlaySurface, type OverlaySurface } from '../overlay/index.js';
import { streamIcon } from './template-stream.js';
import { VIDEO_CONTROL_FEATURES, resolveVideoControls, type VideoControlFeature, type VideoControlsOptions, type VideoControlsPlacement } from './controls.js';

type StreamOptionName = 'subtitle' | 'audio' | 'quality';
type StreamPanel = 'settings' | 'advanced' | 'rate' | 'quality' | 'subtitle' | 'audio' | 'theme' | 'sleep' | 'sleep-settings' | 'info' | 'playback' | 'controls';

export interface StreamViewContext {
  readonly shadow: ShadowRoot;
  readonly player: StudioPlayer;
  readonly videoTracks: VideoTracksController;
  readonly sleepTimer: SleepTimerController | null;
  readonly perform: (action: () => unknown | Promise<unknown>) => void;
  readonly showControls: () => void;
  readonly setTheme: (theme: VideoPlayerTheme) => void;
  readonly importSubtitle: (file: File) => Promise<void>;
  readonly outputHeights: readonly number[];
  readonly setControls: (controls: VideoControlsOptions) => void;
}

export interface StreamViewRenderState {
  readonly title: string;
  readonly playbackRate: number;
  readonly sleepRemaining: string;
  readonly sleepBadge: string;
  readonly sleepRunning: boolean;
  readonly ended: boolean;
  readonly canNext: boolean;
}

export interface StreamView {
  applyTheme(theme: VideoPlayerTheme): void;
  dismiss(): void;
  back(): boolean;
  setControls(placement: VideoControlsPlacement, compact: boolean, inline?: boolean): void;
  renderOptions(name: StreamOptionName, entries: readonly VideoTrackOption[], value: string, extra?: readonly [string, string], available?: boolean, reason?: string | null): void;
  render(state: StreamViewRenderState): void;
  /** 触发按钮的入口动作；不是本变体处理的入口时返回 false，交回公共 UI 默认处理。 */
  handleAction(action: string | undefined): boolean;
  bind(signal: AbortSignal): void;
}

const FEATURE_ACTIONS: Readonly<Record<VideoControlFeature, string>> = { rate: 'rate', subtitle: 'captions', audio: 'audio', quality: 'quality', sleep: 'sleep', info: 'info' };
const TRIGGERS: ReadonlyArray<readonly [string, StreamPanel]> = [['settings', 'settings'], ...VIDEO_CONTROL_FEATURES.map(name => [FEATURE_ACTIONS[name], name] as const)];
const OPTION_PANELS: Readonly<Record<StreamOptionName, StreamPanel>> = { subtitle: 'subtitle', audio: 'audio', quality: 'quality' };
const THEMES: ReadonlyArray<readonly [VideoPlayerTheme, string]> = [['auto', '跟随系统'], ['light', '明亮'], ['dark', '深色']];
const OPTION_LABELS: Readonly<Record<StreamOptionName, string>> = { subtitle: '字幕', audio: '音轨', quality: '画质' };

function span(document: Document, className: string, text?: string): HTMLSpanElement {
  const node = document.createElement('span');
  node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Stream / MediaDock 共用功能面板、选项与焦点规则；入口位置可热切换。 */
export function createStreamView(context: StreamViewContext): StreamView {
  const { shadow, player, videoTracks, sleepTimer, perform, setTheme } = context;
  const document = shadow.host.ownerDocument;
  const anchor = shadow.querySelector<HTMLElement>('[data-controls] input[data-range=time]')
    ?? shadow.querySelector<HTMLElement>('[data-controls]')
    ?? shadow.querySelector<HTMLElement>('[data-screen]');
  const container = shadow.querySelector<HTMLElement>('media-container') ?? shadow.host as HTMLElement;
  const playlist = shadow.querySelector<HTMLElement>('[data-episodes]');
  const playlistTrigger = shadow.querySelector<HTMLElement>('[data-action=episodes]');
  const playlistClose = shadow.querySelector<HTMLElement>('[data-action=dismiss-episodes]');
  const rootValues = new Map<string, HTMLElement>();
  let disposed = false;
  let overlay: OverlaySurface;
  let placement: VideoControlsPlacement | null = null, compact = false, inlinePlaylist = false, controlsKey = '';
  const availability: Record<StreamOptionName, boolean> = { subtitle: false, audio: false, quality: false };

  /** 子面板头：48×48 返回键 + 12px 标题（实测值见规格 §4.2）。 */
  function panelHeader(title: string, titleId?: string): HTMLElement {
    const head = document.createElement('div');
    head.className = 'studio-overlay-header';
    const back = document.createElement('button');
    back.type = 'button';
    back.className = 'studio-overlay-back';
    back.setAttribute('data-popup-back', '');
    back.setAttribute('aria-label', '返回上级菜单');
    back.innerHTML = streamIcon('chevronLeft');
    back.addEventListener('click', () => overlay.back());
    const label = span(document, 'studio-overlay-title', title);
    if (titleId) label.id = titleId;
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'studio-overlay-close';
    close.setAttribute('data-popup-close', '');
    close.setAttribute('aria-label', '关闭菜单');
    close.innerHTML = streamIcon('close');
    close.addEventListener('click', () => overlay.close());
    head.append(back, label, close);
    return head;
  }

  /** 设置菜单的入口行：图标 + 标签 + 当前值 + 右箭头。 */
  function submenuItem(target: StreamPanel, icon: Parameters<typeof streamIcon>[0], label: string): HTMLElement {
    const item = document.createElement('button');
    item.type = 'button';
    item.setAttribute('data-popup-item', '');
    item.setAttribute('data-popup-target', target);
    item.setAttribute('role', 'menuitem');
    item.setAttribute('aria-haspopup', 'true');
    const mark = span(document, 'studio-overlay-item-icon');
    mark.innerHTML = streamIcon(icon);
    const value = span(document, 'studio-overlay-item-value', '');
    value.setAttribute('data-menu-val', target);
    const arrow = span(document, 'studio-overlay-item-arrow');
    arrow.innerHTML = streamIcon('chevronRight');
    item.append(mark, span(document, 'studio-overlay-item-label', label), value, arrow);
    item.addEventListener('click', () => overlay.push(target));
    rootValues.set(target, value);
    return item;
  }

  function setPlaylistOpen(open: boolean, restoreFocus = true): void {
    if (!playlist) return;
    if (inlinePlaylist) {
      if (playlist.matches(':popover-open')) playlist.hidePopover();
      playlist.removeAttribute('popover'); playlist.hidden = false;
      playlist.setAttribute('aria-hidden', 'false'); playlistTrigger?.setAttribute('aria-expanded', 'true');
      return;
    }
    if (open) overlay.close(false);
    playlist.hidden = !open;
    if (typeof playlist.showPopover === 'function') {
      if (open && compact && !playlist.matches(':popover-open')) { playlist.setAttribute('popover', 'manual'); playlist.showPopover(); }
      else if ((!open || !compact) && playlist.matches(':popover-open')) { playlist.hidePopover(); playlist.removeAttribute('popover'); }
    }
    fitPlaylist();
    context.showControls();
    playlist.setAttribute('aria-hidden', String(!open));
    playlistTrigger?.setAttribute('aria-expanded', String(open));
    if (open) playlistClose?.focus({ preventScroll: true });
    else if (restoreFocus) playlistTrigger?.focus({ preventScroll: true });
  }

  function fitPlaylist(): void {
    if (!playlist || playlist.hidden) return;
    if (compact || inlinePlaylist) { playlist.style.removeProperty('max-height'); return; }
    const viewport = document.defaultView?.visualViewport;
    const bottom = (viewport?.offsetTop ?? 0) + (viewport?.height ?? document.documentElement.clientHeight);
    playlist.style.maxHeight = `${Math.max(120, bottom - playlist.getBoundingClientRect().top - 12)}px`;
  }

  /** 子面板单选行；选中态由核写 aria-checked（与 classic 同约定）。 */
  function optionItem(panel: StreamPanel, value: string, label: string, disabled = false): HTMLButtonElement {
    const item = document.createElement('button');
    item.type = 'button';
    item.setAttribute('data-popup-item', '');
    item.setAttribute('data-popup-value', value);
    item.setAttribute('role', 'menuitemradio');
    item.setAttribute('aria-checked', 'false');
    item.classList.add('stream-option');
    item.disabled = disabled;
    if (disabled) item.setAttribute('aria-disabled', 'true');
    item.append(span(document, 'studio-overlay-item-label', label));
    item.addEventListener('click', () => { if (!disabled) choose(panel, value); });
    return item;
  }

  /** 选择即生效并关闭。 */
  function choose(panel: StreamPanel, value: string): void {
    perform(() => {
      if (panel === 'rate') {
        player.setPlaybackRate(Number(value));
        overlay.markSelected('rate', String(player.playbackRate));
        return;
      }
      if (panel === 'theme') return setTheme(value as VideoPlayerTheme);
      if (panel === 'subtitle') return videoTracks.selectSubtitle(value);
      if (panel === 'audio') return videoTracks.selectAudioTrack(value);
      if (panel === 'quality') return videoTracks.selectQuality(value);
    });
    overlay.close();
  }

  function optionPanel(name: StreamOptionName): HTMLElement {
    const wrap = document.createElement('div');
    const list = document.createElement('div');
    list.setAttribute('data-popup-list', name);
    const hint = document.createElement('p');
    hint.className = 'hint studio-overlay-hint';
    hint.setAttribute('data-reason', name);
    hint.hidden = true;
    wrap.append(panelHeader(OPTION_LABELS[name]));
    if (name !== 'subtitle') { const title = document.createElement('h3'); title.className = 'source-options-title'; title.textContent = name === 'audio' ? '播放器音轨' : '流媒体画质'; wrap.append(title); }
    wrap.append(list, hint);
    const extra = document.createElement('div'); extra.dataset.sourceOptions = name; wrap.append(extra);
    if (name === 'subtitle' && player.backend === 'videojs') {
      const input = document.createElement('input'); input.type = 'file'; input.accept = '.srt,.vtt'; input.hidden = true; input.dataset.subtitleFile = '';
      const button = document.createElement('button'); button.type = 'button'; button.dataset.subtitleImport = ''; button.dataset.popupItem = ''; button.className = 'stream-option'; button.textContent = '导入 SRT / WebVTT 字幕';
      button.addEventListener('click', () => input.click());
      input.addEventListener('change', () => { const file = input.files?.[0]; input.value = ''; if (file) perform(() => context.importSubtitle(file)); });
      const reason = document.createElement('p'); reason.className = 'hint studio-overlay-hint'; reason.dataset.importReason = '';
      extra.append(button, input, reason);
    }
    return wrap;
  }

  overlay = createOverlaySurface({
    document,
    root: container,
    anchor: anchor ?? undefined,
    boundary: shadow.querySelector<HTMLElement>('[data-screen]') ?? undefined,
    touchSheet: true,
    onStateChange: () => context.showControls(),
    panels: [
      {
        id: 'settings', label: '设置', role: 'menu',
        build: () => {
          const wrap = document.createElement('div');
          wrap.append(
            panelHeader('播放设置'),
            submenuItem('rate', 'speed', '播放速度'),
            submenuItem('quality', 'quality', '画质'),
            submenuItem('subtitle', 'captions', '字幕'),
            submenuItem('audio', 'audio', '音轨'),
            ...(sleepTimer ? [submenuItem('sleep', 'sleep', '睡眠定时')] : []),
            submenuItem('playback', 'volume', '声音与显示'),
            submenuItem('info', 'info', '视频信息'),
            submenuItem('advanced', 'settings', '更多设置'),
          );
          return wrap;
        },
      },
      {
        id: 'advanced', label: '更多设置', role: 'menu',
        build: () => {
          const wrap = document.createElement('div');
          wrap.append(panelHeader('更多设置'), submenuItem('theme', 'theme', '外观'), submenuItem('controls', 'settings', '按钮布局'));
          return wrap;
        },
      },
      { id: 'subtitle', label: '字幕选择', role: 'menu', build: () => optionPanel('subtitle') },
      { id: 'audio', label: '音轨选择', role: 'menu', build: () => optionPanel('audio') },
      { id: 'quality', label: '画质清晰度', role: 'menu', build: () => optionPanel('quality') },
      {
        id: 'rate', label: '播放速度', role: 'menu',
        build: () => {
          const wrap = document.createElement('div');
          const current = span(document, 'stream-rate-current', rateLabel(1));
          current.setAttribute('data-rate-current', '');
          const range = document.createElement('input');
          range.type = 'range';
          range.min = RATE_VALUES[0];
          range.max = RATE_VALUES.at(-1)!;
          range.step = '0.25';
          range.value = '1';
          range.setAttribute('data-rate-range', '');
          range.setAttribute('aria-label', '播放速度');
          range.setAttribute('aria-valuetext', rateLabel(1));
          range.addEventListener('input', () => {
            current.textContent = rateLabel(range.value);
            range.setAttribute('aria-valuetext', rateLabel(range.value));
            perform(() => player.setPlaybackRate(range.valueAsNumber));
          });
          const rateControl = document.createElement('div');
          rateControl.className = 'stream-rate-control';
          rateControl.append(current, range);
          const options = document.createElement('div');
          options.className = 'stream-rate-grid';
          for (const value of RATE_VALUES) options.append(optionItem('rate', value, rateLabel(value)));
          wrap.append(panelHeader('播放速度'), rateControl, options);
          return wrap;
        },
      },
      {
        id: 'theme', label: '外观', role: 'menu',
        build: () => {
          const wrap = document.createElement('div');
          wrap.append(panelHeader('外观'));
          for (const [value, label] of THEMES) wrap.append(optionItem('theme', value, label));
          return wrap;
        },
      },
      {
        id: 'sleep', label: '睡眠定时', role: 'dialog', labelledBy: 'stream-sleep-title',
        build: () => {
          const wrap = document.createElement('div');
          const head = panelHeader('睡眠定时', 'stream-sleep-title');
          const status = span(document, 'studio-overlay-item-value', '');
          status.setAttribute('data-sleep-status', '');
          const statusLine = document.createElement('p'); statusLine.className = 'video-sleep-status'; statusLine.append(status);
          const quick = createSettingsContent(document, sleepQuickMarkup);
          const more = document.createElement('button');
          more.type = 'button';
          more.setAttribute('data-popup-item', '');
          more.setAttribute('data-stream-sleep-more', '');
          more.setAttribute('role', 'menuitem');
          more.classList.add('stream-option');
          more.append(span(document, 'studio-overlay-item-label', '更多条件与结束动作'));
          more.addEventListener('click', () => overlay.push('sleep-settings'));
          wrap.append(head, statusLine, quick, more);
          return wrap;
        },
      },
      ...(['playback', 'info'] as const).map(id => ({
        id, label: id === 'info' ? '视频信息' : '声音与显示', role: 'dialog' as const,
        build: () => {
          const wrap = document.createElement('div');
          wrap.append(panelHeader(id === 'info' ? '视频信息' : '声音与显示'), createSettingsContent(document,
            id === 'info' ? '<h3 class="video-info-title" data-title></h3><p class="video-settings-hint" data-description></p>' + infoFactsMarkup + '<div class="host-actions" data-host-actions></div>' : playbackSettingsMarkup));
          return wrap;
        },
      })),
      {
        id: 'controls', label: '按钮布局', role: 'dialog',
        build: () => {
          const wrap = document.createElement('div'); wrap.className = 'control-placement-panel'; wrap.append(panelHeader('按钮布局'));
          const presets = document.createElement('div'); presets.className = 'control-presets';
          for (const [preset, label] of [['concentrated', '集中在设置'], ['balanced', '常用按钮外置']] as const) {
            const button = document.createElement('button'); button.type = 'button'; button.dataset.controlsPreset = preset; button.textContent = label;
            button.addEventListener('click', () => context.setControls({ preset })); presets.append(button);
          }
          const labels: Record<VideoControlFeature, string> = { rate: '倍速', subtitle: '字幕', audio: '音轨', quality: '画质', sleep: '睡眠', info: '视频信息' };
          wrap.append(presets);
          for (const feature of VIDEO_CONTROL_FEATURES) {
            const row = document.createElement('label'); const name = document.createElement('span'); name.textContent = labels[feature];
            const select = document.createElement('select'); select.dataset.controlPlacement = feature; select.setAttribute('aria-label', `${labels[feature]}按钮位置`);
            for (const [value, label] of [['settings', '设置里面'], ['toolbar', '与设置并列']]) { const option = document.createElement('option'); option.value = value; option.textContent = label; select.append(option); }
            select.addEventListener('change', () => context.setControls({ preset: 'custom', placement: { ...placement!, [feature]: select.value } })); row.append(name, select); wrap.append(row);
          }
          const hint = document.createElement('p'); hint.className = 'hint studio-overlay-hint'; hint.dataset.controlsHint = ''; wrap.append(hint); return wrap;
        },
      },
      {
        id: 'sleep-settings', label: '睡眠设置', role: 'dialog', labelledBy: 'stream-sleep-settings-title',
        build: () => {
          const wrap = document.createElement('div');
          wrap.append(panelHeader('睡眠设置', 'stream-sleep-settings-title'));
          const settings = document.createElement('div');
          settings.setAttribute('data-sleep-settings', '');
          wrap.append(settings);
          return wrap;
        },
      },
    ],
  });

  function trigger(action: string): HTMLElement | undefined { return shadow.querySelector<HTMLElement>(`[data-action=${action}]`) ?? undefined; }
  /** 菜单保留能力说明；不可用轨道的选项禁用。 */
  function rowItem(panel: StreamPanel): HTMLElement | null {
    return overlay.element.querySelector<HTMLElement>(`[data-popup-item][data-popup-target=${panel}]`);
  }

  function sourceChoices(name: 'audio' | 'quality', entries: readonly { id: string; label: string }[], selected: string): void {
    const host = overlay.element.querySelector<HTMLElement>(`[data-source-options=${name}]`)!;
    const signature = JSON.stringify(entries);
    if (host.dataset.signature !== signature) {
      host.dataset.signature = signature; host.replaceChildren();
      if (entries.length) {
        const heading = document.createElement('h3'); heading.className = 'source-options-title'; heading.textContent = name === 'audio' ? '服务端音轨' : '处理输出尺寸'; host.append(heading);
        for (const entry of entries) {
          const button = document.createElement('button'); button.type = 'button'; button.dataset.popupItem = ''; button.dataset.sourceChoice = entry.id; button.setAttribute('role', 'menuitemradio'); button.className = 'stream-option'; button.textContent = entry.label;
          button.addEventListener('click', () => { perform(() => player.prepareSource(name === 'audio' ? { reason: 'audio-track', audioTrackId: entry.id } : { reason: 'output-height', outputHeight: Number(entry.id) })); overlay.close(); });
          host.append(button);
        }
      }
    }
    for (const button of host.querySelectorAll<HTMLButtonElement>('[data-source-choice]')) button.setAttribute('aria-checked', String(button.dataset.sourceChoice === selected));
  }
  function renderSourceOptions(): void {
    const plan = player.currentPlan;
    const serverAudio = player.canPrepareSource ? plan?.tracks?.audio?.filter(track => track.delivery === 'server') ?? [] : [];
    sourceChoices('audio', serverAudio.length > 1 ? serverAudio : [], serverAudio.find(track => track.default)?.id ?? '');
    sourceChoices('quality', player.canPrepareSource && plan?.processing?.available ? context.outputHeights.map(height => ({ id: String(height), label: height ? `${height}p` : '原始尺寸' })) : [], String(player.currentMetadata?.outputHeight ?? 0));
    if (!availability.audio && serverAudio.length > 1) rootValues.get('audio')!.textContent = serverAudio.find(track => track.default)?.label ?? '服务端音轨';
    if (!availability.quality && player.canPrepareSource && plan?.processing?.available && context.outputHeights.length) rootValues.get('quality')!.textContent = `处理 · ${player.currentMetadata?.outputHeight ? `${player.currentMetadata.outputHeight}p` : '原始尺寸'}`;
    const input = overlay.element.querySelector<HTMLButtonElement>('[data-subtitle-import]');
    if (input) input.disabled = !plan || player.state === 'stopped';
    const reason = overlay.element.querySelector<HTMLElement>('[data-import-reason]');
    if (reason) { reason.hidden = Boolean(plan) && player.state !== 'stopped'; reason.textContent = '加载视频播放计划后可导入字幕。'; }
  }
  function renderControls(): void {
    if (!placement) return;
    const plan = player.currentPlan;
    const supported: Record<VideoControlFeature, boolean> = {
      rate: true, info: true, sleep: Boolean(sleepTimer),
      subtitle: availability.subtitle || Boolean(plan && player.backend === 'videojs' && player.state !== 'stopped'),
      audio: availability.audio || Boolean(player.canPrepareSource && (plan?.tracks?.audio?.filter(track => track.delivery === 'server').length ?? 0) > 1),
      quality: availability.quality || Boolean(player.canPrepareSource && plan?.processing?.available && context.outputHeights.length),
    };
    const width = shadow.querySelector<HTMLElement>('[data-screen]')!.getBoundingClientRect().width;
    const count = VIDEO_CONTROL_FEATURES.filter(name => placement![name] === 'toolbar' && supported[name]).length;
    // 包含音量条展开和按钮间距，键盘进入音量条后底栏仍可完整容纳。
    const minimum = (shadow.querySelector('[data-stage-dialog]') ? 716 : 604) + count * 52;
    const folded = compact || (width > 0 && width < minimum);
    const hint = overlay.element.querySelector<HTMLElement>('[data-controls-hint]');
    if (hint) hint.textContent = folded ? '窄屏保留常用的并列倍速，其余入口收进设置。所选位置仍保留，空间足够后自动恢复。' : '按功能选择入口位置；调整按钮与打开面板不会重建播放会话。';
    for (const name of VIDEO_CONTROL_FEATURES) {
      const button = trigger(FEATURE_ACTIONS[name]);
      const external = placement[name] === 'toolbar' && supported[name] && (!folded || (compact && name === 'rate' && width >= 360));
      if (button) button.hidden = !external;
      const row = rowItem(name);
      if (row) row.hidden = (!compact && external) || (name === 'sleep' && !sleepTimer) || (!supported[name] && player.backend === 'mpv');
    }
    for (const select of overlay.element.querySelectorAll<HTMLSelectElement>('[data-control-placement]')) select.value = placement[select.dataset.controlPlacement as VideoControlFeature];
    for (const button of overlay.element.querySelectorAll<HTMLButtonElement>('[data-controls-preset]')) {
      const preset = resolveVideoControls({ preset: button.dataset.controlsPreset as 'concentrated' | 'balanced' });
      button.setAttribute('aria-pressed', String(VIDEO_CONTROL_FEATURES.every(name => placement![name] === preset[name])));
    }
    if (shadow.activeElement instanceof HTMLElement && shadow.activeElement.hidden) trigger('settings')?.focus({ preventScroll: true });
  }

  return {
    applyTheme(theme) {
      overlay.markSelected('theme', theme);
      const value = rootValues.get('theme');
      if (value) value.textContent = THEMES.find(([name]) => name === theme)?.[1] ?? theme;
    },

    dismiss() { if (!disposed) { setPlaylistOpen(false, false); overlay.close(); } },
    back() {
      if (overlay.isOpen) { overlay.back(); return true; }
      if (!inlinePlaylist && playlist && !playlist.hidden) { setPlaylistOpen(false); return true; }
      return false;
    },

    setControls(next, narrow, inline = false) {
      const key = JSON.stringify([next, narrow]);
      if (key !== controlsKey) { if (overlay.currentPanel !== 'controls') overlay.close(); controlsKey = key; }
      const playlistOpen = playlist && !playlist.hidden;
      const changedLayout = compact !== narrow || inlinePlaylist !== inline;
      const wasInline = inlinePlaylist;
      placement = next; compact = narrow; inlinePlaylist = inline;
      if (inline || wasInline) setPlaylistOpen(inline, false);
      else if (changedLayout && playlistOpen) setPlaylistOpen(true, false);
      else if (playlistOpen) fitPlaylist();
      renderControls();
    },

    renderOptions(name, entries, value, extra, available = true, reason = null) {
      const panel = OPTION_PANELS[name];
      availability[name] = available;
      const list = overlay.element.querySelector<HTMLElement>(`[data-popup-list=${name}]`);
      if (list) {
        // 只在条目集合变化时重建：重建会移除当前焦点元素，而 renderTracks 会在每次状态变化时调用。
        const signature = JSON.stringify([extra ?? null, available, reason, entries.map(entry => [entry.id, entry.label, entry.status])]);
        if (list.dataset.signature !== signature) {
          list.dataset.signature = signature;
          const items: HTMLButtonElement[] = [];
          if (extra) items.push(optionItem(panel, extra[0], extra[1], !available));
          for (const entry of entries) {
            items.push(optionItem(panel, entry.id, entry.label + (entry.status === 'loading' ? ' · 加载中' : ''), !available || entry.status === 'unavailable' || entry.status === 'error'));
          }
          list.replaceChildren(...items);
        }
      }
      overlay.markSelected(panel, value);
      const current = rootValues.get(name);
      if (current) current.textContent = extra?.[0] === value ? extra[1] : entries.find(entry => entry.id === value)?.label ?? '默认';
      if (current && !available) current.textContent = '不可用';
      const button = trigger(FEATURE_ACTIONS[name]);
      button?.setAttribute('aria-label', `${OPTION_LABELS[name]} · ${current?.textContent ?? '默认'}`);
      renderSourceOptions(); renderControls();
    },

    render(state) {
      overlay.markSelected('rate', String(state.playbackRate));
      const rate = rootValues.get('rate');
      if (rate) rate.textContent = rateLabel(state.playbackRate);
      trigger('rate')?.setAttribute('aria-label', `播放速度 · ${rateLabel(state.playbackRate)}`);
      const compactRate = shadow.querySelector<HTMLElement>('[data-rate-display]');
      if (compactRate) compactRate.textContent = `${Number.isInteger(state.playbackRate) ? state.playbackRate.toFixed(1) : state.playbackRate}×`;
      const rateValue = String(state.playbackRate);
      const rateCurrent = overlay.element.querySelector<HTMLElement>('[data-rate-current]');
      if (rateCurrent && !shadow.activeElement?.matches('[data-rate-range]')) rateCurrent.textContent = rateLabel(state.playbackRate);
      const rateRange = overlay.element.querySelector<HTMLInputElement>('[data-rate-range]');
      if (rateRange && shadow.activeElement !== rateRange) rateRange.value = rateValue;
      rateRange?.setAttribute('aria-valuetext', rateLabel(rateValue));
      const sleep = rootValues.get('sleep');
      if (sleep) sleep.textContent = state.sleepRunning ? state.sleepBadge || '已开启' : '关闭';
      renderSourceOptions(); renderControls();
    },

    handleAction(action) {
      // 播放列表是播放器内的右栏面板，不走浮层核。
      if (action === 'episodes') {
        if (inlinePlaylist) { playlist?.scrollIntoView({ block: 'nearest', behavior: 'auto' }); return true; }
        if (playlist) setPlaylistOpen(playlist.hidden);
        return true;
      }
      if (action === 'dismiss-episodes') { setPlaylistOpen(false); return true; }
      const entry = TRIGGERS.find(([name]) => name === action);
      if (!entry) return false;
      setPlaylistOpen(false, false);
      if (entry[1] === 'settings') overlay.toggle('settings', trigger('settings'));
      else {
        if (overlay.isOpen && overlay.currentPanel === entry[1]) { overlay.close(); return true; }
        const button = trigger(entry[0]);
        overlay.open('settings', button?.getClientRects().length && !button.hidden ? button : trigger('settings'));
        overlay.push(entry[1]);
      }
      return true;
    },

    bind(signal) {
      for (const [action, panel] of TRIGGERS) {
        const button = trigger(action);
        if (button) overlay.bindTrigger(button, panel);
      }
      if (playlist) {
        if (!playlist.id) playlist.id = 'stream-playlist';
        playlist.setAttribute('aria-hidden', String(playlist.hidden));
        playlistTrigger?.setAttribute('aria-controls', playlist.id);
        playlistTrigger?.setAttribute('aria-expanded', String(!playlist.hidden));
      }
      shadow.addEventListener('keydown', event => {
        const key = event as KeyboardEvent;
        if (!playlist || playlist.hidden || inlinePlaylist) return;
        if (key.key === 'Escape') { event.preventDefault(); event.stopPropagation(); setPlaylistOpen(false); }
        if (key.key === 'Tab') {
          const nodes = [...playlist.querySelectorAll<HTMLElement>('button,input')].filter(node => !node.matches(':disabled,[hidden]') && node.getClientRects().length);
          const active = shadow.activeElement as HTMLElement;
          const index = nodes.indexOf(active);
          key.preventDefault(); nodes[(index + (key.shiftKey ? -1 : 1) + nodes.length) % nodes.length]?.focus();
        }
      }, { signal, capture: true });
      document.addEventListener('pointerdown', event => {
        if (!playlist || playlist.hidden || inlinePlaylist || event.composedPath().includes(playlist) || event.composedPath().includes(playlistTrigger!)) return;
        setPlaylistOpen(false, false);
      }, { signal, capture: true });
      signal.addEventListener('abort', () => { disposed = true; overlay.destroy(); }, { once: true });
    },
  };
}
