export const VIDEO_CONTROL_FEATURES = ['rate', 'subtitle', 'audio', 'quality', 'sleep', 'info'] as const;
export type VideoControlFeature = typeof VIDEO_CONTROL_FEATURES[number];
export type VideoControlPlacement = 'settings' | 'toolbar';
export type VideoControlPreset = 'concentrated' | 'balanced' | 'custom';
export interface VideoControlsOptions {
  /** concentrated 全部收进设置；balanced 外置倍速、字幕、睡眠；custom 逐项配置。 */
  preset?: VideoControlPreset;
  placement?: Partial<Record<VideoControlFeature, VideoControlPlacement>>;
}
export type VideoControlsPlacement = Readonly<Record<VideoControlFeature, VideoControlPlacement>>;

/** 纯配置；不触碰媒体、队列、计时器或来源。每次返回独立、不可变的完整映射。 */
export function resolveVideoControls(options: VideoControlsOptions = {}, fallback: VideoControlPreset = 'concentrated'): VideoControlsPlacement {
  if (!options || typeof options !== 'object' || Array.isArray(options) || Object.keys(options).some(key => !['preset', 'placement'].includes(key))) throw new TypeError('Invalid video controls options');
  if (options.placement !== undefined && (!options.placement || typeof options.placement !== 'object' || Array.isArray(options.placement))) throw new TypeError('Invalid video controls placement');
  const preset = options.preset ?? fallback;
  if (!['concentrated', 'balanced', 'custom'].includes(preset)) throw new TypeError(`Unknown video controls preset: ${preset}`);
  const result = Object.fromEntries(VIDEO_CONTROL_FEATURES.map(name => [name,
    preset === 'balanced' && ['rate', 'subtitle', 'sleep'].includes(name) ? 'toolbar' : 'settings'])) as Record<VideoControlFeature, VideoControlPlacement>;
  for (const [name, value] of Object.entries(options.placement ?? {})) {
    if (!(VIDEO_CONTROL_FEATURES as readonly string[]).includes(name) || !['settings', 'toolbar'].includes(value)) {
      throw new TypeError(`Unknown video control placement: ${name}=${value}`);
    }
    result[name as VideoControlFeature] = value;
  }
  return Object.freeze(result);
}
