/** Presentation only: playback truth continues to come from StudioPlayer. */
export function createPlaybackFeedback(shadow: ShadowRoot, icon: (name: 'play' | 'pause') => string) {
  const document = shadow.host.ownerDocument;
  const screen = shadow.querySelector<HTMLElement>('[data-screen]')!;
  const buttons = [...shadow.querySelectorAll<HTMLButtonElement>('[data-action=play]')];
  for (const button of buttons) {
    const label = button.querySelector('[data-mobile-play-label]');
    button.innerHTML = `<span class="playback-glyph" aria-hidden="true"><span data-glyph="play">${icon('play')}</span><span data-glyph="pause">${icon('pause')}</span></span>`;
    if (label) button.append(label);
  }
  const feedback = document.createElement('div');
  feedback.className = 'playback-feedback';
  feedback.setAttribute('aria-hidden', 'true');
  feedback.hidden = true;
  screen.append(feedback);
  let pending: 'play' | 'pause' | null = null;
  let timer: ReturnType<typeof setTimeout> | undefined;

  function clear() {
    pending = null;
    clearTimeout(timer);
    feedback.hidden = true;
  }

  return {
    request(action: 'play' | 'pause') { pending = action; },
    clear,
    render(pause: boolean, playing: boolean, blocked: boolean) {
      for (const button of buttons) button.dataset.playback = pause ? 'pause' : 'play';
      if (blocked) { clear(); return; }
      if (!pending || (pending === 'play' ? !playing : pause)) return;
      const action = pending;
      pending = null;
      clearTimeout(timer);
      feedback.innerHTML = `${icon(action)}<span>${action === 'play' ? '正在播放' : '已暂停'}</span>`;
      feedback.hidden = false;
      // Restart without replacing the focused control or relying on animationend
      // (reduced-motion deliberately disables animations).
      feedback.getAnimations().forEach(animation => animation.cancel());
      if (!document.defaultView?.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        feedback.animate([
          { opacity: 0, transform: 'translate(-50%, 6px)' },
          { opacity: 1, transform: 'translate(-50%, 0)', offset: 0.18 },
          { opacity: 1, transform: 'translate(-50%, 0)', offset: 0.72 },
          { opacity: 0, transform: 'translate(-50%, -4px)' },
        ], { duration: 650, easing: 'ease-out' });
      }
      timer = setTimeout(() => { feedback.hidden = true; }, 650);
    },
    destroy() { clear(); feedback.remove(); },
  };
}
