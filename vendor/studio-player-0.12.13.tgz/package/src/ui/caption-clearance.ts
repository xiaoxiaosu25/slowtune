/** Keep native, automatically positioned WebVTT cues above the visible controls. */
export function createCaptionClearance(screen: HTMLElement, controls: HTMLElement, mediaElement: () => HTMLElement | null, controlsVisible?: () => boolean) {
  const win = screen.ownerDocument.defaultView!;
  type Position = Pick<VTTCue, 'line' | 'snapToLines' | 'lineAlign'>;
  const positions = new Map<VTTCue, Position>();
  let frame = 0, destroyed = false;
  let media: HTMLVideoElement | null = null;
  let listeners = new AbortController();
  const tracks = new Set<TextTrack>();

  function restore(cue: VTTCue, position: Position) {
    cue.line = position.line;
    cue.snapToLines = position.snapToLines;
    cue.lineAlign = position.lineAlign;
    positions.delete(cue);
  }
  function reset() {
    listeners.abort(); listeners = new AbortController(); tracks.clear();
    for (const [cue, position] of positions) restore(cue, position);
    screen.removeAttribute('data-captions-active');
  }
  function update() {
    frame = 0;
    if (destroyed) return;
    const element = mediaElement() as (HTMLVideoElement & { target?: HTMLVideoElement }) | null;
    const next = element?.target ?? element;
    if (next !== media) {
      reset(); media = next;
      media?.textTracks?.addEventListener('addtrack', schedule, { signal: listeners.signal });
      media?.textTracks?.addEventListener('change', schedule, { signal: listeners.signal });
      for (const event of ['loadedmetadata', 'resize', 'emptied', 'enterpictureinpicture', 'leavepictureinpicture']) {
        media?.addEventListener(event, schedule, { signal: listeners.signal });
      }
    }
    if (!media?.textTracks) return;
    const active = new Set<VTTCue>();
    const video = media.getBoundingClientRect();
    // 渐变内边距不属于交互区；按首个进度控件避让，避免横屏字幕被推到中央播放键下。
    const chrome = (controls.querySelector<HTMLElement>('[data-range-control=time], .cinema-progress-wrap') ?? controls).getBoundingClientRect();
    const root = screen.closest<HTMLElement>('.root');
    const pipRoot = media.getRootNode() as Document | ShadowRoot;
    const pictureInPicture = pipRoot.pictureInPictureElement === media || pipRoot.pictureInPictureElement === element
      || screen.ownerDocument.pictureInPictureElement === media || screen.ownerDocument.pictureInPictureElement === element;
    const visible = (controlsVisible?.() ?? root?.dataset.controlsHidden !== 'true') && video.height > 0 && chrome.top < video.bottom && !pictureInPicture;
    // Percentage cue lines use the video viewport, including its letterbox area.
    // Reserve line height above the controls (lineAlign=end differs between engines).
    const font = video.height * 0.05;
    const columns = Math.max(1, Math.floor(video.width / Math.max(1, font)));
    for (const track of Array.from(media.textTracks)) {
      if (!tracks.has(track)) {
        tracks.add(track); track.addEventListener('cuechange', schedule, { signal: listeners.signal });
      }
      if (!visible || track.mode !== 'showing' || !['subtitles', 'captions'].includes(track.kind)) continue;
      for (const item of Array.from(track.activeCues ?? [])) {
        const cue = item as VTTCue;
        // Preserve authored positioning, vertical writing and regions.
        if ((!positions.has(cue) && cue.line !== 'auto') || cue.vertical || cue.region) continue;
        active.add(cue);
        if (!positions.has(cue)) positions.set(cue, { line: cue.line, snapToLines: cue.snapToLines, lineAlign: cue.lineAlign });
        const lines = cue.text.replace(/<[^>]*>/g, '').split('\n').reduce((count, text) => count + Math.max(1, Math.ceil(text.length / columns)), 0);
        const top = Math.max(video.top, chrome.top - 24 - lines * font * 1.4);
        const line = video.height > 0 ? Math.max(0, Math.min(90, (top - video.top) / video.height * 100)) : 90;
        if (cue.snapToLines) cue.snapToLines = false;
        if (cue.lineAlign !== 'start') cue.lineAlign = 'start';
        if (cue.line !== line) cue.line = line;
      }
    }
    for (const [cue, position] of positions) if (!active.has(cue)) restore(cue, position);
    screen.toggleAttribute('data-captions-active', active.size > 0);
  }
  function schedule() { if (!destroyed && !frame) frame = win.requestAnimationFrame(update); }
  const resize = win.ResizeObserver ? new win.ResizeObserver(schedule) : null;
  resize?.observe(screen); resize?.observe(controls);
  return {
    schedule,
    destroy() { destroyed = true; win.cancelAnimationFrame(frame); resize?.disconnect(); reset(); },
  };
}
