import { StudioPlayer, type StudioPlayerOptions } from '../../player.js';
import type { PlayableInput } from '../../contracts/plan.js';
import type { MainMediaCoordinator, MainMediaController } from '../../main-media/index.js';
import { previewStyles } from './styles.js';

export type PreviewPlayerTheme = 'auto' | 'light' | 'dark';
export type PreviewPlayerView = 'card' | 'mini';
export interface PreviewPlayerTokens {
  background?: string; surface?: string; text?: string; 'text-muted'?: string;
  border?: string; accent?: string; focus?: string; error?: string; radius?: string; font?: string;
}
export interface PreviewMedia { source: PlayableInput; title?: string; poster?: string; }
export interface PreviewPlayerOptions extends Omit<StudioPlayerOptions, 'nativeElementTag'> {
  media?: PreviewMedia;
  theme?: PreviewPlayerTheme;
  view?: PreviewPlayerView;
  tokens?: PreviewPlayerTokens;
  /** 仅 card + hover/fine 指针；默认关闭，延迟 250ms 静音起播。 */
  hoverPreview?: boolean;
  hoverDelayMs?: number;
  /** 仅显式提供 scope 时，有声操作才加入；不创建全局实例。 */
  mainMedia?: { scope: MainMediaCoordinator };
  /** 首次播放才调用；返回的媒体由 UI 拥有，迟到结果会被释放。 */
  createMediaElement?: (document: Document) => HTMLElement | Promise<HTMLElement>;
  onClose?: () => void;
  onError?: (error: unknown) => void;
}
export interface PreviewPlayerUI {
  readonly element: HTMLElement;
  readonly player: StudioPlayer;
  readonly isClosed: boolean;
  readonly isDestroyed: boolean;
  setMedia(media: PreviewMedia | null): Promise<boolean>;
  setView(view: PreviewPlayerView): void;
  setTheme(theme: PreviewPlayerTheme): void;
  setTokens(tokens: PreviewPlayerTokens): void;
  play(): Promise<void>;
  pause(): void;
  stop(): Promise<void>;
  setMuted(muted: boolean): Promise<void>;
  open(): void;
  close(): Promise<void>;
  destroy(): void;
}
const tokenNames = ['background','surface','text','text-muted','border','accent','focus','error','radius','font'];
const abortError = () => new DOMException('Preview operation was cancelled', 'AbortError');
function choice(value: string, values: readonly string[]) { if (!values.includes(value)) throw new TypeError(`Invalid preview option: ${value}`); }
function time(value: number) { const n = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0; return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`; }
async function createDefaultMedia(document: Document) {
  await import('@videojs/html/media/hlsjs-video');
  return document.createElement('hlsjs-video' as string);
}

/** 同步挂载封面和操作；引擎在首次播放时异步导入。无需等待即可 close/destroy。 */
export function mountPreviewPlayer(root: HTMLElement, options: PreviewPlayerOptions = {}): PreviewPlayerUI {
  if (!root?.ownerDocument || typeof root.append !== 'function') throw new TypeError('A preview UI mount element is required');
  choice(options.theme ?? 'auto', ['auto','light','dark']); choice(options.view ?? 'card', ['card','mini']);
  const delay = options.hoverDelayMs ?? 250;
  if (!Number.isFinite(delay) || delay < 0) throw new TypeError('hoverDelayMs must be nonnegative');
  const { media: initial, theme = 'auto', view: initialView = 'card', tokens = {}, hoverPreview, hoverDelayMs: _delay,
    mainMedia, createMediaElement = createDefaultMedia, onClose, onError, ...coreOptions } = options;
  // 最小 preview 组合：直接复用 core；不引用 presets 的可选控制器图。
  const player = new StudioPlayer(coreOptions);
  const document = root.ownerDocument;
  const element = document.createElement('div'); element.dataset.studioPreview = ''; element.dataset.theme = theme;
  const shadow = element.attachShadow({ mode: 'open' });
  shadow.innerHTML = `<style>${previewStyles}</style><section class="root"><div data-body><div class="screen"><img alt="" hidden></div><div class="heading"><strong></strong><button data-action="close" aria-label="关闭预览">关闭</button></div><div class="timeline"><input data-progress type="range" min="0" max="100" step="0.1" value="0" aria-label="播放进度"><output>0:00 / 0:00</output></div><div class="controls"><button data-action="play" aria-label="播放预览">播放</button><button data-action="stop" aria-label="停止预览">停止</button><button data-action="mute" aria-label="静音">静音</button><label class="volume">音量<input data-volume type="range" min="0" max="1" step="0.05" value="1" aria-label="音量"></label></div></div><p class="status" role="status" aria-live="polite"></p><button data-action="open" hidden>重新打开</button></section>`;
  const get = <T extends HTMLElement = HTMLElement>(selector: string) => shadow.querySelector<T>(selector)!;
  const subscriptions: Array<() => void> = [];
  const listeners: Array<() => void> = [];
  let media = initial ?? null, view = initialView, disposed = false, closed = false;
  let revision = 0, pending: AbortController | null = null, timer: ReturnType<typeof setTimeout> | undefined;
  let owner: MainMediaController | null = null, ownCommand = false, muted = false, volume = 1;
  let hovering = false, busy = false, actuallyPlaying = false, lastError: unknown = null;
  let appliedTokens: string[] = [];
  function live() { if (disposed) throw new Error('Preview UI has been destroyed'); }
  function cancel() { revision++; pending?.abort(); pending = null; clearTimeout(timer); timer = undefined; busy = false; }
  function internal<T>(fn: () => T): T { const previous = ownCommand; ownCommand = true; try { return fn(); } finally { ownCommand = previous; } }
  function report(error: unknown) { if (disposed || (error as Error)?.name === 'AbortError') return; if (lastError !== error) { lastError = error; onError?.(error); } render(); }
  function listen(target: EventTarget, name: string, fn: EventListener) { target.addEventListener(name, fn); listeners.push(() => target.removeEventListener(name, fn)); }
  function releaseElement(node: HTMLElement) {
    const m = node as HTMLMediaElement; m.pause?.(); node.removeAttribute('src'); m.load?.(); node.remove();
  }
  function coordinate(claim = true) {
    if (!muted && mainMedia && claim) { owner ??= mainMedia.scope.register(player); if (!owner.activate()) throw abortError(); }
    else if (owner) { internal(() => owner!.destroy()); owner = null; }
  }
  function render() {
    if (disposed) return;
    get('.root').dataset.view = view; get('[data-body]').hidden = closed; get('[data-action=open]').hidden = !closed;
    get('strong').textContent = media?.title || '媒体预览'; get('strong').title = media?.title || '媒体预览';
    const image = get<HTMLImageElement>('img');
    if (media?.poster) { if (image.getAttribute('src') !== media.poster) image.src = media.poster; }
    else image.removeAttribute('src');
    const input = media?.source;
    const audio = player.sourceController.getCurrentSource()?.type?.startsWith('audio/')
      || typeof input === 'object' && input && ('mediaType' in input ? input.mediaType === 'audio' : 'type' in input && input.type?.startsWith('audio/'));
    image.hidden = !media?.poster || (!audio && !!player.currentResourceId && !['stopped','idle','error'].includes(player.state));
    const playing = actuallyPlaying && !player.paused;
    const button = get<HTMLButtonElement>('[data-action=play]'); button.disabled = !media;
    button.textContent = busy ? '取消播放' : playing ? '暂停' : lastError ? '点击继续' : player.state === 'ended' ? '重播' : '播放';
    button.setAttribute('aria-label', button.textContent + '预览');
    get('[data-action=mute]').textContent = muted ? '开启声音' : '静音';
    get('[data-action=mute]').setAttribute('aria-label', muted ? '开启声音' : '静音');
    get('[data-action=mute]').setAttribute('aria-pressed', String(muted));
    get<HTMLInputElement>('[data-volume]').value = String(volume);
    const progress = get<HTMLInputElement>('[data-progress]'); progress.disabled = !player.currentResourceId || !Number.isFinite(player.duration) || player.duration <= 0;
    progress.max = String(Number.isFinite(player.duration) && player.duration > 0 ? player.duration : 100); progress.value = String(player.currentTime);
    get('output').textContent = `${time(player.currentTime)} / ${time(player.duration)}`;
    const status = get('.status'); status.dataset.error = String(!!lastError);
    status.textContent = lastError ? ((lastError as Error)?.name === 'NotAllowedError' ? '播放受限，请点击继续。' : '操作失败，请重试：' + ((lastError as Error)?.message ?? String(lastError)))
      : closed ? '已关闭，重新打开不会自动播放。' : !media ? '请选择媒体。' : busy || player.state === 'loading' ? '正在加载…' : playing ? '正在播放' : player.state === 'ended' ? '播放结束，可以重播。' : player.state === 'stopped' ? '已停止，点击播放重新加载。' : '点击播放预览';
  }
  async function start(hover = false): Promise<void> {
    live(); if (!media || closed) return;
    cancel(); const current = revision; const controller = pending = new AbortController();
    const selected = media; busy = true; lastError = null;
    if (hover) { muted = true; hovering = true; }
    const ensure = () => { if (disposed || closed || current !== revision || controller.signal.aborted) throw abortError(); };
    render();
    try {
      coordinate(); ensure();
      if (!player.element) {
        const node = await createMediaElement(document);
        if (disposed || closed || current !== revision) { releaseElement(node); throw abortError(); }
        try { node.setAttribute('playsinline',''); node.setAttribute('preload','none'); get('.screen').append(node); player.attach(node); }
        catch (error) { releaseElement(node); throw error; }
      }
      ensure(); player.setMuted(muted); player.setVolume(volume);
      if (!player.currentResourceId || player.failed || player.state === 'stopped') await player.load(selected.source);
      ensure(); player.setMuted(muted); player.setVolume(volume);
      if (player.state === 'ended') player.seek(0);
      await player.play({ signal: controller.signal }); ensure(); actuallyPlaying = !player.paused;
    } catch (error) { if (current === revision) { report(error); if (current === revision && (error as Error)?.name !== 'AbortError') internal(() => owner?.release()); } throw error; }
    finally { if (current === revision) { busy = false; pending = null; render(); } }
  }
  function pause() { live(); cancel(); hovering = false; player.pause(); actuallyPlaying = false; render(); }
  async function stop() { live(); cancel(); hovering = false; lastError = null; const current = revision; try { await internal(() => player.stop()); } catch (error) { if (current === revision) report(error); throw error; } finally { render(); } }
  async function close() {
    live(); cancel(); hovering = false; lastError = null; const current = revision; const controller = pending = new AbortController();
    try { await internal(() => player.close({ signal: controller.signal })); }
    catch (error) { if (current === revision) report(error); throw error; }
    finally { if (current === revision) pending = null; render(); }
  }
  function open() {
    live(); const restoreFocus = closed; cancel(); closed = false; lastError = null; render();
    if (restoreFocus) get(media ? '[data-action=play]' : '[data-action=close]').focus();
  }
  async function setMedia(next: PreviewMedia | null) {
    live(); cancel(); hovering = false; const current = revision; lastError = null;
    const stopping = internal(() => player.stop()); media = next; render();
    try { await stopping; return current === revision && !disposed; }
    catch (error) { if (current === revision) report(error); throw error; }
  }
  async function setMuted(next: boolean) {
    live(); const current = revision;
    // 协调器退出会暂停并取消待起播；仅在已有播放意图时续接，不因静音设置启动空闲预览。
    const resume = player.playbackRequested || actuallyPlaying && !player.paused;
    muted = Boolean(next);
    try {
      coordinate(!closed && (busy || resume));
      if (disposed || current !== revision) throw abortError();
      player.setMuted(muted);
    }
    catch (error) { if (!disposed && current === revision) { muted = true; player.setMuted(true); report(error); } throw error; }
    finally { render(); }
    // start 自行按代次处理错误；旧续播的拒绝不能再修改较新资源的静音状态。
    if (resume && player.paused) await start();
  }
  function setTokens(next: PreviewPlayerTokens) {
    live(); for (const [key,value] of Object.entries(next)) if (!tokenNames.includes(key) || typeof value !== 'string') throw new TypeError(`Invalid preview token: ${key}`);
    for (const key of appliedTokens) element.style.removeProperty('--studio-preview-' + key);
    appliedTokens = Object.keys(next); for (const [key,value] of Object.entries(next)) element.style.setProperty('--studio-preview-' + key,value);
  }
  function setView(next: PreviewPlayerView) { live(); choice(next,['card','mini']); clearTimeout(timer); timer = undefined; view = next; if (next === 'mini') hovering = false; render(); }
  function destroy() { if (disposed) return; disposed = true; cancel(); for (const remove of listeners) remove(); for (const unsubscribe of subscriptions) unsubscribe(); owner?.destroy(); owner = null; player.destroy(); element.remove(); }
  subscriptions.push(player.on('destroy', destroy), player.on('pauseintent', () => { if (!ownCommand) cancel(); actuallyPlaying = false; render(); }),
    player.on('playing', () => { actuallyPlaying = true; render(); }), player.on('pause', () => { actuallyPlaying = false; render(); }),
    player.on('closerequest', () => { closed = true; render(); get('[data-action=open]').focus(); onClose?.(); }),
    player.on('error', (error, switched) => { if (!switched) report(error); }), player.on('playerror', report),
    player.on('volumechange', () => { muted = player.muted; volume = player.volume; render(); }));
  for (const event of ['statechange','timeupdate','durationchange','ended','stop'] as const) subscriptions.push(player.on(event, render));
  const run = (promise: Promise<unknown>) => { void promise.catch(() => {}); };
  listen(get('[data-action=play]'),'click', () => { if (busy || actuallyPlaying && !player.paused) pause(); else run(start()); });
  listen(get('[data-action=stop]'),'click', () => run(stop())); listen(get('[data-action=close]'),'click', () => run(close()));
  listen(get('[data-action=open]'),'click', open); listen(get('[data-action=mute]'),'click', () => run(setMuted(!muted)));
  listen(get('[data-progress]'),'input', () => { player.seek(Number(get<HTMLInputElement>('[data-progress]').value)); render(); });
  listen(get('[data-volume]'),'input', () => { volume = Number(get<HTMLInputElement>('[data-volume]').value); player.setVolume(volume); render(); });
  listen(element,'pointerenter', event => {
    if (!hoverPreview || view !== 'card' || closed || disposed || !media || (event as PointerEvent).pointerType === 'touch'
      || !document.defaultView?.matchMedia('(hover: hover) and (pointer: fine)').matches || player.currentResourceId || busy) return;
    clearTimeout(timer); timer = setTimeout(() => { timer = undefined; run(start(true)); }, delay);
  });
  listen(element,'pointerleave', () => { clearTimeout(timer); timer = undefined; if (view === 'card' && hovering) run(stop()); });
  const ui: PreviewPlayerUI = { element, player, get isClosed() { return closed; }, get isDestroyed() { return disposed; },
    setMedia, setView, setTokens, setTheme(next) { live(); choice(next,['auto','light','dark']); element.dataset.theme = next; },
    play: () => start(), pause, stop, setMuted, open, close, destroy };
  try { setTokens(tokens); root.append(element); render(); } catch (error) { destroy(); throw error; }
  return ui;
}
