/**
 * 浮层核（方案 P1）：单容器 + 面板栈。
 *
 * 冻结契约（本文件声明，检查脚本断言）：
 *   容器 [data-popup-surface]（单实例、hidden + aria-hidden、role 随当前面板）
 *   面板 [data-popup-panel=<id>]；返回 [data-popup-back]；项 [data-popup-item]
 *
 * 设计约束：**零运行时导入**。构建产物是自包含 ESM，可被隔离夹具直接注入验证，
 * 也让这个模块不把 UI 依赖带进任何调用方。
 */

/** 面板语义：列表面板用 menu，含表单控件的面板用 dialog。 */
export type OverlayPanelRole = 'menu' | 'dialog';

/**
 * 摆放模式（窄视口一律转底部抽屉，与方案 S6 一致）：
 *   anchor —— 锚定在参照元素上方并做边界避让（控制条弹层，视频侧全部用它）
 *   drawer —— 贴右侧、纵向居中（侧栏式抽屉，如音频的播放队列）
 *   center —— 视口居中（居中卡片，如表单类对话框）
 */
export type OverlayPlacement = 'anchor' | 'drawer' | 'center';

export interface OverlayPanelDefinition {
  /** 面板 id，同时是 [data-popup-panel] 的取值。 */
  readonly id: string;
  /** 无障碍名称，写到 aria-label。 */
  readonly label: string;
  /** 默认 menu。 */
  readonly role?: OverlayPanelRole;
  /**
   * 面板内标题元素的 id；提供时容器改用 aria-labelledby（含表单控件的 dialog 面板用）。
   * id 只在 shadow 树内解析，不会与页面其它 id 冲突。
   */
  readonly labelledBy?: string;
  /**
   * 真模态：打开时给容器加 `aria-modal`、显示背板、把同层其它内容设为 `inert` 并锁页面滚动。
   * 默认 false（锚定在控制条上的菜单与弹层应当保持非模态，背景可继续操作）。
   * 表单类面板（需要"完成/取消"语义、不希望背景被误操作）才开。
   */
  readonly modal?: boolean;
  /** 摆放模式，默认 anchor；窄视口一律转底部抽屉。 */
  readonly placement?: OverlayPlacement;
  /** 构建一次面板内容。 */
  build(document: Document): HTMLElement;
  /** 每次打开该面板时同步内容（状态、选中项、可用性）。 */
  sync?(): void;
}

export interface OverlayState {
  readonly open: boolean;
  readonly panel: string | null;
  readonly trigger: HTMLElement | null;
}

export interface OverlayOptions {
  readonly document: Document;
  /** 挂载点，通常是 shadow root。 */
  readonly root: ShadowRoot | HTMLElement;
  /** 定位参照；省略时用挂载点的宿主元素。 */
  readonly anchor?: HTMLElement;
  /** Optional video boundary: narrow popovers stay beside the picture instead of the page bottom. */
  readonly boundary?: HTMLElement;
  /** Video touch menus use a viewport sheet; audio keeps its existing anchor rules. */
  readonly touchSheet?: boolean;
  readonly panels: readonly OverlayPanelDefinition[];
  /** 每一次打开/关闭/换面板后回调，供调用方同步自身状态。 */
  onStateChange?(state: OverlayState): void;
}

export interface OverlaySurface {
  readonly element: HTMLElement;
  readonly isOpen: boolean;
  readonly currentPanel: string | null;
  /** 把触发按钮登记到某个面板：写入 aria-haspopup 并同步 aria-expanded。 */
  bindTrigger(element: HTMLElement, panelId: string): void;
  open(panelId: string, trigger?: HTMLElement): void;
  toggle(panelId: string, trigger?: HTMLElement): void;
  /** 面板栈：推进一个子面板。 */
  push(panelId: string): void;
  /** 面板栈：回到上一层。 */
  back(): void;
  close(restoreFocus?: boolean): void;
  /** 按 [data-popup-value] 把选中态写成 aria-checked。 */
  markSelected(panelId: string, value: string): void;
  destroy(): void;
}

/** 视口留边：容器不得贴边或溢出。 */
const SURFACE_MARGIN = 12;
/** 窄视口阈值：以下转为底部抽屉（方案 S6，与 classic 现有断点一致）。 */
const NARROW_VIEWPORT = 740;
/** 面板切换时长，与契约要求的 250ms 一致。 */
const PANEL_ANIMATION_MS = 250;
const ITEM_SELECTOR = '[data-popup-item]';

/**
 * 核自带样式：度量、动效与项的版式在这里统一定义一次，调用方不再各写一套。
 * 颜色与皮肤全部走 --studio-overlay-* 变量，各变体只需在自己的样式表里声明变量值（方案 §3/S8）：
 *   --studio-overlay-background / -text / -muted / -border / -hover / -accent / -focus
 *   --studio-overlay-font-label(15) / -font-item(14) / -font-meta(12)  三级字号阶梯
 */
export const overlayStyles = `
[hidden] { display: none !important; }
/* 背板只在真模态面板打开时显示（z-index 低于容器，点击由 document 上的点外判定处理）。 */
.studio-overlay-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147482999;
  background: var(--studio-overlay-backdrop, rgba(8, 12, 16, 0.45));
}
.studio-overlay {
  position: fixed;
  z-index: 2147483000;
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  inset: auto;
  overflow: hidden;
  transition: width ${PANEL_ANIMATION_MS}ms cubic-bezier(0.4, 0, 0.2, 1), height ${PANEL_ANIMATION_MS}ms cubic-bezier(0.4, 0, 0.2, 1), opacity 100ms cubic-bezier(0, 0, 0.2, 1);
  will-change: width, height;
}
/*
 * 主题默认值放在 :where() 里（零特异性）：核把自己的样式注入在浮层元素内部，晚于变体样式表；
 * 若用同特异性的 .studio-overlay 声明，变体皮肤（cinema 的 18px 圆角与辉光、classic 的 radius
 * token）会被静默覆盖（评审 F1）。零特异性让外观真正由变体决定，与两份样式表的先后顺序无关。
 */
:where(.studio-overlay) {
  border-radius: 12px;
  background: var(--studio-overlay-background, rgba(20, 24, 30, 0.96));
  color: var(--studio-overlay-text, #f4f7fa);
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.55);
  border: 1px solid var(--studio-overlay-border, rgba(255, 255, 255, 0.12));
}
.studio-overlay * { box-sizing: border-box; }
.studio-overlay-panel {
  box-sizing: border-box;
  padding: 8px 0;
  min-width: 250px;
  overflow-y: auto;
  overscroll-behavior: contain;
  transition: transform ${PANEL_ANIMATION_MS}ms cubic-bezier(0.4, 0, 0.2, 1), opacity ${PANEL_ANIMATION_MS}ms cubic-bezier(0.4, 0, 0.2, 1);
}
.studio-overlay-header {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 48px;
  padding: 0 12px;
  font-size: var(--studio-overlay-font-label, 15px);
  font-weight: 600;
}
.studio-overlay-title { flex: 1; min-width: 0; }
.studio-overlay-back {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  margin: 0;
  border: 0;
  border-radius: 10px;
  background: none;
  color: inherit;
  cursor: pointer;
}
.studio-overlay-back:hover { background: var(--studio-overlay-hover, rgba(255, 255, 255, 0.1)); }
[data-popup-item] {
  display: flex;
  align-items: center;
  gap: 12px;
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 8px 16px;
  border: 0;
  background: none;
  color: inherit;
  font: inherit;
  font-size: var(--studio-overlay-font-item, 14px);
  text-align: left;
  cursor: pointer;
}
[data-popup-item]:not([aria-disabled=true]):hover { background: var(--studio-overlay-hover, rgba(255, 255, 255, 0.1)); }
[data-popup-item][aria-disabled=true] { opacity: 0.45; cursor: default; }
[data-popup-item][aria-checked=true] { color: var(--studio-overlay-accent, currentColor); font-weight: 600; }
[data-popup-item][role=menuitemradio]::after { content: ""; width: 16px; height: 16px; flex: none; }
[data-popup-item][role=menuitemradio][aria-checked=true]::after {
  background: currentColor;
  mask: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z'/></svg>") center / contain no-repeat;
}
.studio-overlay-item-icon { display: inline-flex; flex: none; color: var(--studio-overlay-muted, rgba(244, 247, 250, 0.66)); }
.studio-overlay-item-icon svg { width: 16px; height: 16px; }
.studio-overlay-item-label { flex: 1; min-width: 0; }
.studio-overlay-item-value {
  flex: none;
  max-width: 96px;
  overflow: hidden;
  color: var(--studio-overlay-muted, rgba(244, 247, 250, 0.66));
  font-size: var(--studio-overlay-font-meta, 12px);
  text-overflow: ellipsis;
  white-space: nowrap;
}
.studio-overlay-item-arrow { display: inline-flex; flex: none; color: var(--studio-overlay-muted, rgba(244, 247, 250, 0.66)); }
.studio-overlay-item-arrow svg { width: 14px; height: 14px; }
.studio-overlay :is([data-popup-item], .studio-overlay-back):focus-visible,
.studio-overlay-panel:focus-visible { outline: 2px solid var(--studio-overlay-focus, #6cb2ff); outline-offset: -2px; }
@media (prefers-reduced-motion: reduce) {
  .studio-overlay, .studio-overlay-panel { transition-duration: 0s !important; }
}
`;

interface PanelRecord {
  readonly definition: OverlayPanelDefinition;
  readonly element: HTMLElement;
}

/** 创建一个浮层核实例。同一实例承载全部面板，并保证同一时刻只有一个可见。 */
export function createOverlaySurface(options: OverlayOptions): OverlaySurface {
  const doc = options.document;
  const win = doc.defaultView;
  const root = options.root;
  const host = options.anchor ?? ((root as ShadowRoot).host as HTMLElement | undefined) ?? (root as HTMLElement);

  const element = doc.createElement('div');
  element.className = 'studio-overlay';
  element.setAttribute('data-popup-surface', '');
  element.hidden = true;
  element.setAttribute('aria-hidden', 'true');

  const style = doc.createElement('style');
  style.textContent = overlayStyles;
  element.append(style);

  /** 真模态的背板：与容器同层、默认隐藏，只有 `modal` 面板打开时显示。 */
  const backdrop = doc.createElement('div');
  backdrop.className = 'studio-overlay-backdrop';
  backdrop.setAttribute('data-popup-backdrop', '');
  backdrop.hidden = true;
  root.append(backdrop);

  const records = new Map<string, PanelRecord>();
  for (const definition of options.panels) {
    const panel = doc.createElement('div');
    panel.className = 'studio-overlay-panel';
    panel.setAttribute('data-popup-panel', definition.id);
    // 角色与无障碍名称记在容器上（方案 §2.1）：同一时刻只有一个面板可见，
    // 面板本身保持通用容器，避免出现「菜单套菜单」的嵌套语义。
    panel.tabIndex = -1;
    panel.hidden = true;
    panel.append(definition.build(doc));
    element.append(panel);
    records.set(definition.id, { definition, element: panel });
  }
  root.append(element);

  const knownTriggers = new Set<HTMLElement>();
  const stack: string[] = [];
  let trigger: HTMLElement | null = null;
  /** 当前可见面板。不能靠扫描 DOM：面板切换期间旧面板仍在位，扫描会拿到要退出的那个。 */
  let visibleId: string | null = null;
  let animating = false;
  let animatingIncoming: HTMLElement | null = null;
  let animatingOutgoing: HTMLElement | null = null;
  let animationTimer: ReturnType<typeof setTimeout> | null = null;

  const reducedMotion = (): boolean => Boolean(win?.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  const visiblePanel = (): HTMLElement | null => (visibleId ? records.get(visibleId)?.element ?? null : null);
  const currentId = (): string | null => stack.at(-1) ?? null;

  /**
   * 当前焦点元素。焦点通常落在 shadow 树内部，而 document.activeElement 只会给出宿主元素；
   * 挂载点也可能只是 shadow 树里的一个普通节点，因此必须从自己的 root node 取 activeElement。
   */
  function activeIn(): HTMLElement | null {
    const scope = element.getRootNode() as Document | ShadowRoot;
    let active = (scope.activeElement ?? doc.activeElement) as HTMLElement | null;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement as HTMLElement;
    return active;
  }

  function items(panel: HTMLElement): HTMLElement[] {
    return [...panel.querySelectorAll<HTMLElement>(ITEM_SELECTOR)].filter(item => !item.matches(':disabled,[aria-disabled=true],[hidden]') && item.getClientRects().length > 0);
  }

  /** 面板内可见、可聚焦的元素；穿透开放 shadow root（睡眠表单是自定义元素，控件在自己的影子树里）。 */
  function focusables(panel: HTMLElement): HTMLElement[] {
    const result: HTMLElement[] = [];
    const visit = (parent: Element | ShadowRoot): void => {
      for (const child of parent.children) {
        const node = child as HTMLElement;
        if (node.matches('button, [href], input, select, textarea, [tabindex]')) {
          const declared = node.getAttribute('tabindex');
          // 菜单项用 roving tabindex：`-1` 只表示"当前不是被选中的那一项"，不代表不可 Tab。
          // 若候选集合只认"当前 tabindex >= 0"，焦点一旦移到返回键，所有菜单项都停在 -1，
          // Tab 就再也回不到菜单项（实测 6 次 Tab 全部停在返回键）。候选与 roving 状态解耦。
          const tabbable = node.hasAttribute('data-popup-item')
            ? true
            : declared === null ? node.tabIndex >= 0 : Number(declared) >= 0;
          if (tabbable && !node.hasAttribute('disabled') && node.getAttribute('aria-disabled') !== 'true' && node.getClientRects().length) result.push(node);
        }
        if (node.shadowRoot) visit(node.shadowRoot);
        visit(node);
      }
    };
    visit(panel);
    return result;
  }

  function focusFirst(panel: HTMLElement): void {
    const list = items(panel);
    const preferred = list.find(item => item.getAttribute('aria-checked') === 'true') ?? list[0];
    for (const item of list) item.tabIndex = item === preferred ? 0 : -1;
    (preferred ?? panel).focus({ preventScroll: true });
  }

  /** 把焦点移到面板内的下一个/上一个可聚焦元素；Tab 始终留在容器里（方案 S3）。 */
  function moveFocus(panel: HTMLElement, step: number): void {
    const list = focusables(panel);
    for (const item of items(panel)) item.tabIndex = -1;
    if (!list.length) { panel.focus({ preventScroll: true }); return; }
    const current = activeIn();
    const index = list.indexOf(current as HTMLElement);
    const next = index < 0 ? (step > 0 ? 0 : list.length - 1) : (index + step + list.length) % list.length;
    list[next].tabIndex = 0;
    list[next].focus({ preventScroll: true });
    list[next].scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }

  /** 度量并把容器尺寸固定到当前面板；返回测量结果，供过渡使用。 */
  function fit(panel: HTMLElement): { width: number; height: number } {
    element.style.width = 'auto';
    element.style.height = 'auto';
    panel.style.position = '';
    panel.style.width = '';
    panel.style.height = '';
    panel.style.maxHeight = '';
    const rect = panel.getBoundingClientRect();
    const { width: viewportWidth, height: viewportHeight } = viewportBounds();
    // 按视口封顶，避免高面板把容器顶出屏幕；超出部分由面板内部滚动承担。
    const narrowWidth = options.boundary?.getBoundingClientRect().width || viewportWidth;
    const narrow = viewportWidth <= (options.touchSheet ? 840 : NARROW_VIEWPORT);
    const portraitSheet = options.touchSheet && narrow && viewportHeight > viewportWidth;
    const margin = portraitSheet ? 0 : SURFACE_MARGIN;
    element.dataset.touchSheet = portraitSheet ? 'portrait' : 'none';
    const width = Math.max(0, Math.min(narrow ? options.touchSheet ? viewportWidth : narrowWidth : Math.ceil(rect.width) + 2, viewportWidth - margin * 2));
    const height = Math.max(0, Math.min(Math.ceil(rect.height) + 2 + (portraitSheet ? 12 : 0), portraitSheet ? viewportHeight * .82 : viewportHeight - margin * 2));
    element.style.width = `${width}px`;
    element.style.height = `${height}px`;
    panel.style.maxHeight = `${Math.max(0, height - (portraitSheet ? 14 : 2))}px`;
    return { width, height };
  }

  function viewportBounds() {
    const viewport = win?.visualViewport;
    return { left: viewport?.offsetLeft ?? 0, top: viewport?.offsetTop ?? 0,
      width: viewport?.width ?? win?.innerWidth ?? doc.documentElement.clientWidth,
      height: viewport?.height ?? win?.innerHeight ?? doc.documentElement.clientHeight };
  }

  /**
   * 摆放当前面板：窄视口一律转底部抽屉（方案 S6），宽视口按面板声明的 `placement` 分三种。
   * 三种模式都保证四边不溢出视口。
   */
  function place(): void {
    const viewport = viewportBounds();
    const viewportWidth = viewport.width, viewportHeight = viewport.height;
    const size = element.getBoundingClientRect();
    if (options.touchSheet && viewportWidth <= 840 && viewportHeight > viewportWidth) {
      element.style.left = `${viewport.left}px`;
      element.style.top = `${viewport.top + viewportHeight - size.height}px`;
      return;
    }
    if (options.touchSheet && viewportHeight <= 540 && viewportWidth > viewportHeight) {
      element.style.left = `${viewport.left + Math.max(SURFACE_MARGIN, viewportWidth - size.width - SURFACE_MARGIN)}px`;
      element.style.top = `${viewport.top + Math.max(SURFACE_MARGIN, (viewportHeight - size.height) / 2)}px`;
      return;
    }
    if (options.touchSheet && viewportWidth <= 840) {
      element.style.left = `${viewport.left + SURFACE_MARGIN}px`;
      element.style.top = `${viewport.top + Math.max(SURFACE_MARGIN, viewportHeight - size.height - SURFACE_MARGIN)}px`;
      return;
    }
    if (viewportWidth <= NARROW_VIEWPORT) {
      const boundary = options.boundary?.getBoundingClientRect();
      if (boundary) {
        const below = boundary.bottom + 8;
        const above = boundary.top - size.height - 8;
        const top = below + size.height <= viewportHeight - SURFACE_MARGIN ? below
          : above >= SURFACE_MARGIN ? above : boundary.bottom - size.height;
        element.style.left = `${Math.max(SURFACE_MARGIN, Math.min(boundary.left, viewportWidth - size.width - SURFACE_MARGIN))}px`;
        element.style.top = `${Math.max(SURFACE_MARGIN, Math.min(top, viewportHeight - size.height - SURFACE_MARGIN))}px`;
        return;
      }
      element.style.left = `${SURFACE_MARGIN}px`;
      element.style.top = `${Math.round(Math.max(SURFACE_MARGIN, viewportHeight - size.height - SURFACE_MARGIN))}px`;
      return;
    }
    const clampTop = (value: number): number => Math.round(Math.max(SURFACE_MARGIN, Math.min(viewportHeight - size.height - SURFACE_MARGIN, value)));
    const clampLeft = (value: number): number => Math.round(Math.max(SURFACE_MARGIN, Math.min(viewportWidth - size.width - SURFACE_MARGIN, value)));
    const placement = (visibleId ? records.get(visibleId)?.definition.placement : undefined) ?? 'anchor';
    if (placement === 'center') {
      element.style.left = `${clampLeft((viewportWidth - size.width) / 2)}px`;
      element.style.top = `${clampTop((viewportHeight - size.height) / 2)}px`;
      return;
    }
    if (placement === 'drawer') {
      // 右侧贴边 + 纵向居中，与"侧栏式抽屉"的既有观感一致。
      element.style.left = `${clampLeft(viewportWidth - size.width - SURFACE_MARGIN)}px`;
      element.style.top = `${clampTop((viewportHeight - size.height) / 2)}px`;
      return;
    }
    const anchorRect = host?.getBoundingClientRect?.() ?? { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
    const right = anchorRect.right || viewportWidth - SURFACE_MARGIN;
    const bottom = anchorRect.top || viewportHeight - SURFACE_MARGIN;
    element.style.left = `${clampLeft(right - size.width)}px`;
    element.style.top = `${clampTop(bottom - size.height - 8)}px`;
  }

  function runAnimation(incoming: HTMLElement, outgoing: HTMLElement | null, forward: boolean): void {
    // 上一次过渡必须先真正结束：它的计时器仍然挂着，若让它稍后触发，会隐藏**这一次**的
    // 面板并取消这一次的过渡（表现为「Escape 之后旧面板还在」）。
    finishAnimation();
    animating = true;
    animatingIncoming = incoming;
    animatingOutgoing = outgoing;
    if (outgoing) {
      const rect = outgoing.getBoundingClientRect();
      outgoing.style.position = 'absolute';
      outgoing.style.top = '0';
      outgoing.style.left = '0';
      outgoing.style.width = `${Math.round(rect.width)}px`;
      outgoing.style.height = `${Math.round(rect.height)}px`;
      outgoing.style.transform = `translateX(${forward ? '-100%' : '100%'})`;
      outgoing.style.opacity = '0';
    }
    // 入场起点由 show() 在**显形之前**写好（见那里的注释）；这里只负责落到终点。
    // 不要再写成"写起点 → 强制回流 → 写回终点"：对刚从 display:none 显形的元素，Chromium 会把
    // 过渡起点记成 none，写回 0 与起点等价，过渡被立即取消（实测入场面板位移恒为 0）。
    incoming.style.transform = 'translateX(0)';
    incoming.style.opacity = '1';

    if (reducedMotion()) { finishAnimation(); return; }
    animationTimer = win?.setTimeout(finishAnimation, PANEL_ANIMATION_MS + 20) ?? null;
  }

  /** 结束当前过渡：清掉计时器、卸载旧面板、清掉位移与透明度。可重复调用。 */
  function finishAnimation(): void {
    if (animationTimer !== null) { clearTimeout(animationTimer); animationTimer = null; }
    if (!animating) return;
    animating = false;
    if (animatingOutgoing) {
      animatingOutgoing.hidden = true;
      animatingOutgoing.style.position = '';
      animatingOutgoing.style.width = '';
      animatingOutgoing.style.height = '';
    }
    if (animatingIncoming) {
      animatingIncoming.style.transform = '';
      animatingIncoming.style.opacity = '';
    }
    animatingIncoming = null;
    animatingOutgoing = null;
  }

  /**
   * 真模态能力（逐面板声明，默认关闭）。打开时：容器加 `aria-modal`、显示背板、把同层其它内容
   * 设为 `inert`（容器在 shadow 树里，同层通常是播放器主体）、锁页面滚动。关闭时逐项还原。
   *
   * 这是 shadow DOM 内可做到的模态：焦点本来就困在容器里（Tab 陷阱），背板挡指针，`aria-modal`
   * 告诉辅助技术忽略背景，滚动被锁。它不是浏览器 top layer 的原生模态（那要 `<dialog>.showModal()`），
   * 所以**同一时刻只应有一个浮层核**实例在模态态——单实例容器本来就保证这一点。
   */
  let inertedSiblings: HTMLElement[] = [];
  let scrollLocked: { element: HTMLElement; overflow: string } | null = null;
  function applyModality(modal: boolean): void {
    if (modal) element.setAttribute('aria-modal', 'true');
    else element.removeAttribute('aria-modal');
    backdrop.hidden = !modal;

    const parent = element.parentNode as ParentNode | null;
    const siblings = parent ? [...parent.children] as HTMLElement[] : [];
    for (const sibling of siblings) {
      if (sibling === element || sibling === backdrop) continue;
      if (modal) {
        if (!sibling.hasAttribute('inert')) { sibling.setAttribute('inert', ''); inertedSiblings.push(sibling); }
      }
    }
    // 只有"退出模态"时才清空记录：在 modal=true 的分支里清空会让下次无法还原（实测 main 一直保持 inert）。
    if (!modal) {
      for (const sibling of inertedSiblings) sibling.removeAttribute('inert');
      inertedSiblings = [];
    }

    const scrolling = doc.scrollingElement as HTMLElement | null;
    if (modal && scrolling && !scrollLocked) {
      scrollLocked = { element: scrolling, overflow: scrolling.style.overflow };
      scrolling.style.overflow = 'hidden';
    } else if (!modal && scrollLocked) {
      scrollLocked.element.style.overflow = scrollLocked.overflow;
      scrollLocked = null;
    }
  }

  /** 显示某个面板；同一容器内换面板时带上方向位移。 */
  function show(panelId: string, direction: 'none' | 'forward' | 'back'): void {
    const record = records.get(panelId);
    if (!record) throw new TypeError(`unknown overlay panel: ${panelId}`);
    finishAnimation();
    const outgoing = visiblePanel();
    if (outgoing === record.element) { record.definition.sync?.(); fit(record.element); place(); return; }
    // 入场起点必须在**显形之前**写好：面板若以 `transform: none` 完成首次渲染，Chromium 会把
    // 过渡起点记成 none，随后写回 `translateX(0)` 与起点等价而取消过渡——表现为退场面板照常被
    // 推走、入场面板却瞬间就位（实测入场位移恒为 0，`transitionrun` 后立刻 `transitioncancel`）。
    // 起点先落、再显形、再在 runAnimation() 里写终点，位移才真正发生。
    if (direction !== 'none' && outgoing) {
      record.element.style.transform = `translateX(${direction === 'forward' ? '100%' : '-100%'})`;
      record.element.style.opacity = '0';
    }
    record.element.hidden = false;
    if (record.element.querySelector('[data-popup-close]')) {
      for (const back of record.element.querySelectorAll<HTMLElement>('[data-popup-back]')) back.hidden = stack.length <= 1;
    }
    fit(record.element);
    record.definition.sync?.();
    fit(record.element);
    visibleId = panelId;
    element.setAttribute('role', record.definition.role ?? 'menu');
    if (record.definition.labelledBy) {
      element.removeAttribute('aria-label');
      element.setAttribute('aria-labelledby', record.definition.labelledBy);
    } else {
      element.removeAttribute('aria-labelledby');
      element.setAttribute('aria-label', record.definition.label);
    }
    const touchViewport = viewportBounds();
    applyModality(Boolean(record.definition.modal) || Boolean(options.touchSheet && (touchViewport.width <= 840 || touchViewport.height <= 540)));
    place();
    if (direction === 'none' || !outgoing) {
      if (outgoing) outgoing.hidden = true;
    } else {
      runAnimation(record.element, outgoing, direction === 'forward');
    }
    focusFirst(record.element);
    syncTriggers();
    options.onStateChange?.({ open: true, panel: panelId, trigger });
  }

  function syncTriggers(): void {
    for (const button of knownTriggers) {
      button.setAttribute('aria-expanded', String(Boolean(!element.hidden && button === trigger)));
    }
  }

  function open(panelId: string, nextTrigger?: HTMLElement): void {
    if (nextTrigger) trigger = nextTrigger;
    stack.length = 0;
    stack.push(panelId);
    element.hidden = false;
    if (typeof element.showPopover === 'function' && !element.matches(':popover-open')) {
      element.setAttribute('popover', 'manual');
      element.showPopover();
    }
    element.setAttribute('aria-hidden', 'false');
    // 根入口之间直接切换不做方向位移：位移表示面板栈的进/退。容器尺寸仍带过渡（S1/S5），
    // 并且这样始终满足「同一时刻只有一个面板可见」（S1）。
    show(panelId, 'none');
  }

  function close(restoreFocus = true): void {
    if (element.hidden) return;
    stack.length = 0;
    visibleId = null;
    finishAnimation();
    applyModality(false);
    if (typeof element.hidePopover === 'function' && element.matches(':popover-open')) element.hidePopover();
    element.hidden = true;
    element.setAttribute('aria-hidden', 'true');
    for (const record of records.values()) {
      record.element.hidden = true;
      record.element.style.transform = '';
      record.element.style.opacity = '';
      record.element.style.position = '';
    }
    syncTriggers();
    if (restoreFocus && trigger?.isConnected && trigger.getClientRects().length) trigger.focus({ preventScroll: true });
    options.onStateChange?.({ open: false, panel: null, trigger });
    trigger = null;
  }

  /** 面板栈回退：栈底之上退一层，否则关闭。 */
  function back(): void {
    if (stack.length <= 1) { close(); return; }
    stack.pop();
    show(currentId()!, 'back');
  }

  function onDocumentPointerDown(event: Event): void {
    if (element.hidden) return;
    const path = typeof (event as PointerEvent).composedPath === 'function' ? (event as PointerEvent).composedPath() : [];
    if (path.includes(element)) return;
    if (path.some(node => node instanceof Element && knownTriggers.has(node as HTMLElement))) return;
    close(false);
  }

  function onKeyDown(event: KeyboardEvent): void {
    if (element.hidden) return;
    const key = event.key;
    if (key === 'Escape') {
      event.preventDefault();
      if (stack.length > 1) back(); else close();
      return;
    }
    if (!event.composedPath().includes(element) && !element.contains(activeIn())) return;
    const panel = visiblePanel();
    if (!panel) return;
    if ((event.composedPath()[0] as HTMLElement)?.matches?.('input,select,textarea,[contenteditable=true]') && key !== 'Tab') return;
    const list = items(panel);
    const active = activeIn();
    const index = list.indexOf(active as HTMLElement);
    if (key === 'ArrowDown' || key === 'ArrowUp') {
      event.preventDefault();
      if (!list.length) return;
      const step = key === 'ArrowDown' ? 1 : -1;
      const next = index < 0 ? (step > 0 ? 0 : list.length - 1) : (index + step + list.length) % list.length;
      for (const item of list) item.tabIndex = -1;
      list[next].tabIndex = 0;
      list[next].focus({ preventScroll: true });
      list[next].scrollIntoView({ block: 'nearest', inline: 'nearest' });
      return;
    }
    if (key === 'Home' || key === 'End') {
      if (!list.length) return;
      event.preventDefault();
      const target = key === 'Home' ? list[0] : list.at(-1)!;
      for (const item of list) item.tabIndex = -1;
      target.tabIndex = 0;
      target.focus({ preventScroll: true });
      target.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      return;
    }
    if (key === 'Tab') {
      // 全部接管而不是只在首尾换向：菜单项用 roving tabindex，浏览器默认的 Tab
      // 顺序会直接走出容器（方案 S3「Tab 不出容器」）。
      event.preventDefault();
      moveFocus(panel, event.shiftKey ? -1 : 1);
    }
  }

  function onViewportChange(): void { if (!element.hidden) { fit(visiblePanel() ?? element); place(); } }

  doc.addEventListener('pointerdown', onDocumentPointerDown, true);
  doc.addEventListener('keydown', onKeyDown, true);
  win?.addEventListener('resize', onViewportChange);
  win?.addEventListener('scroll', onViewportChange, true);
  win?.visualViewport?.addEventListener('resize', onViewportChange);
  win?.visualViewport?.addEventListener('scroll', onViewportChange);

  return {
    element,
    get isOpen() { return !element.hidden; },
    get currentPanel() { return currentId(); },
    bindTrigger(button, panelId) {
      knownTriggers.add(button);
      button.dataset.popupTarget = panelId;
      button.setAttribute('aria-haspopup', records.get(panelId)?.definition.role ?? 'menu');
      button.setAttribute('aria-expanded', String(Boolean(!element.hidden && currentId() === panelId)));
    },
    open,
    toggle(panelId, nextTrigger) {
      if (!element.hidden && (nextTrigger === trigger || currentId() === panelId)) { close(); return; }
      open(panelId, nextTrigger);
    },
    push(panelId) {
      if (element.hidden) { open(panelId); return; }
      if (currentId() === panelId) return;
      stack.push(panelId);
      show(panelId, 'forward');
    },
    back,
    close,
    markSelected(panelId, value) {
      const record = records.get(panelId);
      if (!record) return;
      for (const item of record.element.querySelectorAll<HTMLElement>('[data-popup-value]')) {
        item.setAttribute('aria-checked', String(item.dataset.popupValue === value));
      }
    },
    destroy() {
      doc.removeEventListener('pointerdown', onDocumentPointerDown, true);
      doc.removeEventListener('keydown', onKeyDown, true);
      win?.removeEventListener('resize', onViewportChange);
      win?.removeEventListener('scroll', onViewportChange, true);
      win?.visualViewport?.removeEventListener('resize', onViewportChange);
      win?.visualViewport?.removeEventListener('scroll', onViewportChange);
      finishAnimation();
      applyModality(false);
      for (const button of knownTriggers) {
        button.removeAttribute('aria-expanded');
        button.removeAttribute('aria-haspopup');
        delete button.dataset.popupTarget;
      }
      knownTriggers.clear();
      backdrop.remove();
      element.remove();
    },
  };
}
