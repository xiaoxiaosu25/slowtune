/**
 * @studio/player - 共享音视频播放能力库
 * 
 * 核心设计遵循：BASELINE BL-0002 的"已采用"一节
 * - 底层与无界面状态核心委托给成熟上游 Video.js v10
 * - 本库维护：播放计划来源适配、可拆卸进度记忆、产品层功能契约与宿主扩展
 */

// 契约层
export * from './contracts/index.js';

// 来源适配层
export * from './source-adapter/index.js';

// 进度记忆层
export * from './progress/index.js';

// 统一装配调度器
export * from './player.js';

// 可选产品功能：导入本身不创建定时器、系统会话或存储。
export * from './queue/index.js';
export * from './sleep-timer/index.js';
export * from './media-session/index.js';
export * from './main-media/index.js';
export * from './video-tracks/index.js';

// 场景默认配置与显式装配，复用以上唯一实现。
export * from './presets/index.js';
