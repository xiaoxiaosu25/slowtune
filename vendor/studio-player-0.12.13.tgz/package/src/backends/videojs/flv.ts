import type { DeliveryTarget } from '../../contracts/delivery.js';
export interface FlvDelivery { apply(target: DeliveryTarget): void; release(): void }
const adapters = new WeakMap<object, FlvDelivery>();
export function registerFlv(element: object, adapter: FlvDelivery): () => void {
  if (adapters.has(element)) throw new Error('FLV adapter already installed');
  adapters.set(element, adapter);
  return () => { if (adapters.get(element) === adapter) { adapter.release(); adapters.delete(element); } };
}
export function flvFor(element: object) { return adapters.get(element); }
export function isFlv(target: DeliveryTarget) { return target.transport === 'flv' || target.type?.split(';')[0].trim() === 'video/x-flv'; }
