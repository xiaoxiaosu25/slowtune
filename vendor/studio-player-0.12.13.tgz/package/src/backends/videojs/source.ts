/**
 * Video.js 后端：来源描述
 *
 * 本模块承载 Video.js 后端的来源描述结构与组装、等价来源判定，以及 HLS 判定与
 * MIME 表；`source-adapter` 只做中立推导与结果组装，不再持有上游约定。
 *
 * 依赖方向是单向的：`source-adapter` → 本模块。本模块只从 `contracts/delivery.ts`
 * 取中立类型，不反向导入 `source-adapter` 或 `player.ts`。这是 U1 的单后端现状：
 * U2 第 2 步接入 mpv 时**没有**建立注入点——后端选择走核心内部的进程环境信号，
 * 按 P-11 冻结的接缝签名未变，接缝的最终形态与包归属留给 U6。
 */

import type { DeliveryCarrier, DeliveryTarget } from '../../contracts/delivery.js';

/** HLS 媒体类型（上游 MSE 路径的唯一判定依据） */
export const HLS_MIME_TYPE = 'application/vnd.apple.mpegurl';

/** 常见 HLS MIME 别名；输出时统一为上游要求的规范值。 */
export const HLS_MIME_ALIASES = new Set([
  HLS_MIME_TYPE,
  'application/x-mpegurl',
  'audio/mpegurl',
  'audio/x-mpegurl',
]);

/** Video.js v10 接受的标准 source 描述结构 */
export interface VideojsSourceDescription {
  src: string;
  type?: string;
  preferPlayback?: 'mse' | 'native';
  engine?: {
    hlsJs?: {
      xhrSetup?: (xhr: any, url: string) => void;
      [key: string]: unknown;
    };
    [key: string]: unknown;
  };
}

/** 判定某个地址是否只能按 HLS 处理（无扩展名等歧义地址返回 false） */
export function isHlsIndicator(url: string, transport?: string, declaredMime?: string): boolean {
  if (declaredMime && declaredMime.trim().length > 0) {
    return HLS_MIME_ALIASES.has(declaredMime.split(';', 1)[0].trim().toLowerCase());
  }
  if (transport === 'hls') return true;
  return url.split('?')[0].toLowerCase().endsWith('.m3u8');
}

/** 交付目标对应的承载方式；`managed` 等价于今天"需要 MSE 路径"。 */
export function carrierOf(target: DeliveryTarget): DeliveryCarrier {
  return isHlsIndicator(target.src, target.transport, target.type) ? 'managed' : 'native';
}

/**
 * 把中立交付目标组装成上游 Video.js 的 source 描述。
 *
 * - `managed`：`preferPlayback: 'mse'`，进入 hls.js；此时若目标带请求头，
 *   经 `engine.hlsJs.xhrSetup` 注入。
 * - `native`：`preferPlayback: 'native'`；自定义请求头当前只对 HLS/XHR 链路生效，
 *   原生 HTML 媒体路径没有公开的任意请求头注入能力，不能伪装成通用 headers 支持。
 *
 * `DeliveryTarget.type` 原样透传，不做二次推导：HLS 的规范 MIME 已由适配阶段写定。
 *
 * 上游 HlsJsAdapter 的播放路径判定（实测 `@videojs/hlsjs-video@10.0.0-rc.2`
 * `dist/dev/adapter.js:196,298`）：
 *   useMse = Hls.isSupported() && contentType === 'application/vnd.apple.mpegurl'
 *            && preferPlayback !== 'native'
 * 而 `inferContentType()` 只识别 `.mp4`，其余一律回退为 M3U8。
 * 因此**只有明确 HLS 的源才允许进入该元素的 MSE 路径**，其它类型必须
 * 显式声明为原生可播类型，否则会被 hls.js 当作 HLS 解封装而失败。
 */
export function toVideojsSource(target: DeliveryTarget, carrier: DeliveryCarrier): VideojsSourceDescription {
  const managed = carrier === 'managed';
  const source: VideojsSourceDescription = {
    src: target.src,
    type: target.type,
    preferPlayback: managed ? 'mse' : 'native',
  };

  const headers = target.headers;
  if (managed && headers && Object.keys(headers).length > 0) {
    source.engine = {
      hlsJs: {
        xhrSetup: (xhr: any) => {
          for (const [key, value] of Object.entries(headers)) {
            xhr.setRequestHeader(key, value);
          }
        }
      }
    };
  }

  return source;
}

/**
 * 判定两次 Video.js 来源描述是否等价。
 *
 * 等价来源由上游 setter 去重，调用方据此补一次公开 `load()` 重播；
 * 比较 `src`、`type`、`preferPlayback` 与 `engine`，与既有实现一致。
 */
export function isSameVideojsSource(
  previous: VideojsSourceDescription | null | undefined,
  next: VideojsSourceDescription
): boolean {
  return Boolean(previous)
    && previous?.src === next.src
    && previous?.type === next.type
    && previous?.preferPlayback === next.preferPlayback
    && previous?.engine === next.engine;
}
