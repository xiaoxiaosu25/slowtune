/**
 * mpv 后端：内部入口
 *
 * 本目录是 mpv 播放后端的全部实现（能力声明、会话、进程与 JSON IPC）。它**不从任何公开入口
 * 导出**：公开契约不新增引擎专属字段，也不新增公开注入项（P-11 已定稿的接缝签名不变）。
 *
 * 进程环境仅供 U2 smoke/诊断的无参数构造使用。生产宿主通过 `StudioPlayer` 为每个实例显式提供受控
 * 启动配置与 `SurfacePort`，不会由环境变量选择 binary 或启动参数：
 *
 * | 环境变量 | 作用 |
 * | --- | --- |
 * | `STUDIO_PLAYER_BACKEND=mpv` | 选择 mpv 后端。其它取值（含未设置）都走既有路径 |
 * | `STUDIO_PLAYER_MPV_BIN` | 官方 mpv 可执行文件路径；未指定时该后端在加载来源时明确拒绝 |
 * | `STUDIO_PLAYER_MPV_ARGS` | 附加 mpv 参数（空格分隔）；验证与宿主覆盖输出面时用 |
 *
 * 为什么不把环境变量升级成公开选择器：U2 的信号只服务 smoke/诊断；U5 的长期路径是按实例绑定启动配置和端口，
 * 混合产品 UI 不共享进程级开关。后端实现仍不从包公开入口导出，宿主配置由调用方注入。
 *
 * 依赖方向：核心 → 本模块 → `session.ts` →（运行时）Node 内建模块。本模块不导入核心。
 */

import { MpvSession, type MpvSessionOptions } from './session.js';

export {
  MPV_CAPABILITIES,
  mpvSupportsTarget,
  type MpvCapabilities,
  type MpvSupportVerdict,
  type MpvTrackKind,
  type MpvTransport,
} from './capabilities.js';
export {
  MpvSession,
  MPV_MINIMUM_VERSION,
  MPV_OUTPUT_MODE,
  type MpvBufferedFact,
  type MpvSessionOptions,
  type MpvTrack,
} from './session.js';

export const MPV_BACKEND_ENV = 'STUDIO_PLAYER_BACKEND';
export const MPV_BIN_ENV = 'STUDIO_PLAYER_MPV_BIN';
export const MPV_ARGS_ENV = 'STUDIO_PLAYER_MPV_ARGS';

/** 当前进程环境；浏览器与 Web Worker 里没有 `process`，取不到就是不选择。 */
function environment(): Record<string, string | undefined> | undefined {
  return (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
}

/** 内部后端信号：调用方是否显式选择 mpv 后端。 */
export function isMpvBackendSelected(): boolean {
  return environment()?.[MPV_BACKEND_ENV]?.trim().toLowerCase() === 'mpv';
}

/** 核心识别"非 DOM 承载"的标记；它不在任何公开类型里。 */
export function isMpvSession(value: unknown): boolean {
  return Boolean(value) && typeof value === 'object'
    && (value as { backendName?: unknown }).backendName === 'mpv';
}

/** 用显式配置创建尚未启动的会话；无参数调用只保留 U2 smoke/诊断环境兼容。 */
export function createMpvSession(options?: MpvSessionOptions): MpvSession {
  if (options !== undefined) return new MpvSession(options);
  const env = environment();
  return new MpvSession({
    executable: env?.[MPV_BIN_ENV]?.trim() ?? '',
    extraArgs: splitArgs(env?.[MPV_ARGS_ENV]),
  });
}

function splitArgs(value?: string): string[] {
  return (value ?? '').split(' ').map(part => part.trim()).filter(Boolean);
}
