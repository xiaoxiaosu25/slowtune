import type { NativeAudioEvent, NativeAudioPort } from '../../contracts/native-audio.js';
import type { DeliveryTarget } from '../../contracts/delivery.js';
import type { PlaybackPlan } from '../../contracts/plan.js';
import { playbackAbortError } from '../../reliability.js';

let serial = 0;
/** 内部媒体面映射，公开 element 为 null；状态完全来自服务回报。 */
export class NativeAudioSession extends EventTarget {
  private id = '';
  private position = 0;
  duration = 0;
  paused = true;
  ended = false;
  seeking = false;
  error: unknown = null;
  private ready = false;
  private controls = { volume: 1, muted: false, rate: 1 };
  private pending: {resolve():void;reject(error:unknown):void} | null = null;
  private off: () => void;
  constructor(private port: NativeAudioPort) { super(); this.off = port.subscribe(event => this.receive(event)); }
  get currentTime() { return this.position; }
  set currentTime(value: number) { this.port.seek(value); this.seeking = true; }
  get volume() { return this.controls.volume; }
  set volume(value: number) { this.controls.volume=value;this.preferences('volumechange'); }
  get muted() { return this.controls.muted; }
  set muted(value: boolean) { this.controls.muted=value;this.preferences('volumechange'); }
  get playbackRate() { return this.controls.rate; }
  set playbackRate(value: number) { this.controls.rate=value;this.preferences('ratechange'); }
  private preferences(event:string) { this.port.setPreferences(this.volume,this.muted,this.playbackRate);this.dispatchEvent(new Event(event)); }
  apply(source: DeliveryTarget, plan: PlaybackPlan | null) {
    if(plan && plan.mediaType!=='audio')throw new TypeError('Native audio accepts audio plans only');
    this.release();this.id=`studio-native-audio-${++serial}`;this.position=0;this.duration=0;this.ready=false;this.error=null;this.ended=false;
    this.port.load({playbackId:this.id,source,metadata:plan?.metadata??{},durationSeconds:plan?.durationSeconds});
    return {deduped:false};
  }
  play(): Promise<void> {
    this.pending?.reject(playbackAbortError());
    return new Promise((resolve,reject)=>{this.pending={resolve,reject};try{this.port.play();}catch(error){this.pending=null;reject(error);}});
  }
  pause() { this.pending?.reject(playbackAbortError());this.pending=null;this.port.pause(); }
  release() { this.pending?.reject(playbackAbortError());this.pending=null;this.id='';this.port.stop();this.position=0;this.duration=0;this.paused=true;this.ended=false; }
  dispose() {this.release();this.off();}
  private receive(event: NativeAudioEvent) {
    if(!this.id || event.playbackId!==this.id)return;
    if(event.type==='progress') {
      if(!Number.isFinite(event.positionSeconds)||event.positionSeconds<0||!Number.isFinite(event.durationSeconds)||event.durationSeconds<0)return;
      this.position=event.positionSeconds;this.duration=event.durationSeconds;
      if(event.ready&&!this.ready){this.ready=true;this.dispatchEvent(new Event('loadedmetadata'));}
      if(this.seeking){this.seeking=false;this.dispatchEvent(new Event('seeked'));}
      this.dispatchEvent(new Event('durationchange'));this.dispatchEvent(new Event('timeupdate'));
    } else if(event.type==='state') {
      if(event.state==='playing'){this.paused=false;this.ended=false;this.dispatchEvent(new Event('play'));this.dispatchEvent(new Event('playing'));this.pending?.resolve();this.pending=null;}
      else if(event.state==='paused'){this.paused=true;this.dispatchEvent(new Event('pause'));}
      else if(event.state==='buffering')this.dispatchEvent(new Event('waiting'));
    } else if(event.type==='ended'){this.ended=true;this.paused=true;this.dispatchEvent(new Event('ended'));}
    else {this.error=event.error;this.pending?.reject(event.error);this.pending=null;this.dispatchEvent(new Event('error'));}
  }
}
