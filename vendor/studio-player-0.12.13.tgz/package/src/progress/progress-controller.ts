/**
 * 进度记忆控制器（ProgressController）
 * 
 * 契约见 contracts/progress.ts。
 * 职责：
 * 1. 与存储端口（ProgressStoragePort）交互，不假设具体存储媒介（localStorage/IndexedDB/REST API）
 * 2. 纯逻辑断点计算：起播前 N 秒归零从头播，恢复位置接近结尾时视为看完；实时写入
 *    只在连续播放跨越完播边界或 StudioPlayer 收到 ended 时清空
 * 3. 异步写入防抖（Debounce），避免高频 timeupdate 打爆持久化
 */

import {
  type ProgressStoragePort,
  type ProgressPolicy,
  type ProgressRecord,
  DEFAULT_PROGRESS_POLICY,
} from '../contracts/progress.js';

export interface PendingSaveRecord {
  resourceId: string;
  position: number;
  duration?: number;
  updatedAt: number;
  timer: any;
  lastSavedTime: number;
}

export class ProgressController {
  private storagePort: ProgressStoragePort;
  private policy: Required<ProgressPolicy>;
  private pendingSaves: Map<string, PendingSaveRecord> = new Map();
  private lastPositions: Map<string, number> = new Map();
  private completedResources = new Set<string>();
  private storageWrites = new Map<string, Promise<void>>();
  private unsyncedRecords = new Map<string, ProgressRecord>();

  /** 同一资源的保存与清除按调用顺序提交；不同资源互不阻塞。 */
  private enqueueWrite(resourceId: string, operation: () => void | Promise<void>): Promise<void> {
    const previous = this.storageWrites.get(resourceId);
    let result: Promise<void>;
    if (previous) {
      result = previous.then(operation);
    } else {
      // 无积压时立即调用端口，保留 localStorage 在 pagehide 时同步落盘的行为。
      try {
        result = Promise.resolve(operation());
      } catch (error) {
        result = Promise.reject(error);
      }
    }
    const settled = result.catch(() => {});
    this.storageWrites.set(resourceId, settled);
    void settled.then(() => {
      if (this.storageWrites.get(resourceId) === settled) this.storageWrites.delete(resourceId);
    });
    return result;
  }

  private saveProgress(resourceId: string, position: number, duration: number | undefined, updatedAt = Date.now()): Promise<void> {
    const record: ProgressRecord = {
      positionSeconds: position,
      durationSeconds: duration,
      updatedAt,
      percentage: duration ? position / duration : undefined,
    };
    this.unsyncedRecords.set(resourceId, record);
    return this.enqueueWrite(resourceId, () => this.storagePort.save(resourceId, position, duration, record)).then(() => {
      if (this.unsyncedRecords.get(resourceId) === record) this.unsyncedRecords.delete(resourceId);
    });
  }

  private clearStoredProgress(resourceId: string): Promise<void> {
    const cleared: ProgressRecord = { positionSeconds: 0, updatedAt: Date.now() };
    this.unsyncedRecords.set(resourceId, cleared);
    return this.enqueueWrite(resourceId, () => this.storagePort.clear(resourceId)).then(() => {
      if (this.unsyncedRecords.get(resourceId) === cleared) this.unsyncedRecords.delete(resourceId);
    });
  }

  constructor(storagePort: ProgressStoragePort, policy?: ProgressPolicy) {
    this.storagePort = storagePort;
    this.policy = {
      ...DEFAULT_PROGRESS_POLICY,
      ...policy,
    };
  }

  /**
   * 计算指定资源是否应当恢复播放，以及恢复到第几秒
   * @param saved 从存储端取回的秒数或结构化记录对象
   * @param duration 媒体已知总时长（秒）
   * @returns 实际应当 seek 到的起播秒数（0 表示从头播放）
   */
  public calculateResumePosition(
    saved: ProgressRecord | number | null | undefined,
    duration?: number
  ): number {
    if (saved == null) return 0;
    const savedPosition = typeof saved === 'object' ? saved.positionSeconds : saved;
    if (savedPosition == null || isNaN(savedPosition) || savedPosition <= 0) {
      return 0;
    }

    // 动态计算适应用于当前媒体时长的有效起播/完播阈值
    // 防止短媒体（如 15 秒短片）因固定阈值（如尾部 10 秒）被误判为完播清空
    const effectiveStartThreshold = (duration != null && duration > 0 && duration < this.policy.startThresholdSeconds * 3)
      ? Math.min(this.policy.startThresholdSeconds, duration * 0.1)
      : this.policy.startThresholdSeconds;

    // 1. 若上次播放不足起播阈值（如 < 5 秒），直接从头播放
    if (savedPosition < effectiveStartThreshold) {
      return 0;
    }

    // 2. 若已知总时长，检查是否已接近尾声
    if (duration != null && duration > 0) {
      const remainingSeconds = duration - savedPosition;
      const effectiveEndThreshold = (duration < this.policy.endThresholdSeconds * 2)
        ? Math.min(this.policy.endThresholdSeconds, duration * 0.05)
        : this.policy.endThresholdSeconds;

      // 剩余时间不足尾部阈值（如 < 10 秒）
      if (remainingSeconds <= effectiveEndThreshold) {
        return 0;
      }

      // 进度已达到百分比阈值（如 >= 95%）
      if ((savedPosition / duration) >= this.policy.endThresholdPercentage) {
        return 0;
      }
    }

    return savedPosition;
  }

  /**
   * 从存储端拉取并计算起播秒数
   */
  public async getResumePosition(resourceId: string, duration?: number): Promise<number> {
    try {
      const local = this.unsyncedRecords.get(resourceId);
      if (local) return this.calculateResumePosition(local, duration);
      const pendingWrite = this.storageWrites.get(resourceId);
      if (pendingWrite) await pendingWrite;
      const raw = await this.storagePort.load(resourceId);
      return this.calculateResumePosition(raw, duration);
    } catch (err) {
      console.warn('[ProgressController] Failed to load progress for:', resourceId, err);
      return 0;
    }
  }

  /**
   * 记录实时进度（内置心跳节流、尾部防抖与播完自动清空）
   * @param resourceId 资源标识
   * @param positionSeconds 当前播放秒数
   * @param durationSeconds 媒体总时长
   * @param fromContinuousPlayback 本次上报是否来自**连续播放推进**（默认 true）。
   *        只有连续播放**跨越**完播边界才算看完：拖动、定位、换源续播都是跳变，
   *        必须传 false；暂停期间未定位的位置上报传 'paused'。
   *        完播后忽略尾部上报，直到显式定位（false）或重播回到边界之前。
   *        判定用"上一次位置在边界之前、本次位置到达或越过边界"，
   *        不依赖步长大小，因此在后台标签页被限流、上报间隔变大时同样成立。
   */
  public recordProgress(
    resourceId: string,
    positionSeconds: number,
    durationSeconds?: number,
    fromContinuousPlayback: boolean | 'paused' = true
  ): void {
    if (!resourceId || !Number.isFinite(positionSeconds) || positionSeconds < 0) {
      return;
    }

    const previousPosition = this.lastPositions.get(resourceId);
    this.lastPositions.set(resourceId, positionSeconds);

    const endThreshold = durationSeconds != null && durationSeconds < this.policy.endThresholdSeconds * 2
      ? Math.min(this.policy.endThresholdSeconds, durationSeconds * 0.05)
      : this.policy.endThresholdSeconds;
    const completionBoundary = durationSeconds != null && durationSeconds > 0
      ? Math.min(durationSeconds - endThreshold, durationSeconds * this.policy.endThresholdPercentage)
      : Infinity;

    if (this.completedResources.has(resourceId)) {
      if (fromContinuousPlayback === false
        || (Number.isFinite(completionBoundary) && positionSeconds < completionBoundary)) {
        this.completedResources.delete(resourceId);
      } else {
        return;
      }
    }

    if (fromContinuousPlayback === true && previousPosition != null
      && previousPosition < completionBoundary && positionSeconds >= completionBoundary) {
      this.completedResources.add(resourceId);
      this.cancelPending(resourceId);
      void this.clearStoredProgress(resourceId).catch((error) => {
        console.warn('[ProgressController] Failed to clear progress on finish:', error);
      });
      return;
    }

    const now = Date.now();
    const existing = this.pendingSaves.get(resourceId);
    const record: PendingSaveRecord = existing ?? {
      resourceId, position: positionSeconds, duration: durationSeconds,
      updatedAt: now, timer: null, lastSavedTime: now,
    };
    record.position = positionSeconds;
    record.duration = durationSeconds;
    record.updatedAt = now;
    clearTimeout(record.timer);

    if (existing && now - record.lastSavedTime >= this.policy.saveThrottleIntervalMs) {
      record.lastSavedTime = now;
      void this.saveProgress(resourceId, record.position, record.duration, now).catch((error) => {
        console.warn('[ProgressController] Throttled save failed for:', resourceId, error);
      });
    }

    record.timer = setTimeout(() => {
      this.pendingSaves.delete(resourceId);
      void this.saveProgress(resourceId, record.position, record.duration).catch((error) => {
        console.warn('[ProgressController] Debounced save failed for:', resourceId, error);
      });
    }, this.policy.saveDebounceMs);
    this.pendingSaves.set(resourceId, record);
  }

  /** 显式停止保存当时的位置，不套用连续完播阈值；失败返回给调用方。 */
  public async saveCheckpoint(resourceId: string, positionSeconds: number, durationSeconds?: number): Promise<void> {
    if (!resourceId || !Number.isFinite(positionSeconds) || positionSeconds < 0) {
      throw new RangeError('A checkpoint requires a resource ID and a finite non-negative position');
    }
    this.cancelPending(resourceId);
    this.completedResources.delete(resourceId);
    this.lastPositions.set(resourceId, positionSeconds);
    await this.saveProgress(resourceId, positionSeconds, Number.isFinite(durationSeconds) ? durationSeconds : undefined);
  }

  /**
   * 立即将所有待保存的进度刷入存储端（例如切歌、暂停、关闭窗口时）
   */
  public async flush(): Promise<void> {
    const promises: Promise<void>[] = [];
    const now = Date.now();

    for (const [id, record] of this.pendingSaves.entries()) {
      clearTimeout(record.timer);
      promises.push(
        this.saveProgress(id, record.position, record.duration, now).catch((err) => {
          console.warn('[ProgressController] Failed to flush progress for:', id, err);
        })
      );
    }

    this.pendingSaves.clear();
    await Promise.all([...promises, ...this.storageWrites.values()]);
  }

  /**
   * 手动清除某资源的进度
   */
  public async clearProgress(resourceId: string): Promise<void> {
    this.cancelPending(resourceId);
    this.lastPositions.delete(resourceId);
    this.completedResources.delete(resourceId);
    await this.clearStoredProgress(resourceId);
  }

  /** 销毁控制器并清空定时器 */
  public destroy(): void {
    for (const record of this.pendingSaves.values()) {
      clearTimeout(record.timer);
    }
    this.pendingSaves.clear();
    this.lastPositions.clear();
    this.completedResources.clear();
  }

  private cancelPending(resourceId: string) {
    const existing = this.pendingSaves.get(resourceId);
    if (existing) {
      clearTimeout(existing.timer);
      this.pendingSaves.delete(resourceId);
    }
  }
}
