/**
 * StudioPlayer - 核心装配调度类
 *
 * 职责：
 * 1. 组合 SourceController 与 ProgressController
 * 2. 挂载到 HTML5 media 或 Video.js 自定义元素上；显式选择 mpv 时由会话承载，画面由宿主 SurfacePort 管理
 * 3. 统一驱动起播断点恢复、timeupdate 自动防抖记录、故障备用源自动降级与生命周期管理
 *
 * 设计约束（阶段 4 审查 P1 修复）：
 * - 换源只有一条应用通路：`SourceController.onSourceChange` → `applySourceToMedia`，
 *   刷新与回退的调用方不再各自应用一次。
 * - 备用源尝试有上限，超过后进入失败终态，由 `error` 事件的 `code` 区分。
 * - 只有确实播完（`ended`）或播放中到达结尾才清空断点。
 */

import type { PlayableInput, PlaybackPlan } from './contracts/plan.js';
import type { AdaptedSourceResult, DeliveryCarrier, DeliveryTarget } from './contracts/delivery.js';
import type { ProgressStoragePort, ProgressPolicy } from './contracts/progress.js';
import type { SourceResolverPort } from './contracts/resolver.js';
import type { MediaProcessingSession } from './contracts/media-processing.js';
import type {
  PlayerBackend,
  PlayerInstance,
  PlayerPorts,
  PlaybackEventListener,
  PlaybackEventType,
  PlaybackPort,
  PlaybackState,
  SurfacePort,
  TrackPort,
} from './contracts/ports.js';
import { assertPlayerPorts, createPlayerInstance } from './contracts/ports.js';
import { SourceController, type SourceControllerOptions } from './source-adapter/source-controller.js';
import { ProgressController } from './progress/progress-controller.js';
import { applyDelivery, hostOf, releaseDelivery, resolveElement } from './backends/videojs/element.js';
import { createVideojsTrackPort } from './backends/videojs/tracks.js';
import {
  createMpvSession,
  isMpvBackendSelected,
  isMpvSession,
  type MpvSession,
} from './backends/mpv/index.js';
import { createMpvTrackPort } from './backends/mpv/tracks.js';
import { PlaybackTimeoutError, type PlaybackDiagnostic } from './contracts/diagnostics.js';
import { playbackAbortError, timeoutMilliseconds, waitWithSignal } from './reliability.js';
import { originalDuration, originalRanges, timelineOffset, type PlaybackRange } from './source-adapter/timeline.js';
import type { SourcePreparationContext } from './contracts/resolver.js';
import type { NativeAudioPort } from './contracts/native-audio.js';
import { NativeAudioSession } from './backends/native-audio/session.js';

/** 装配阶段与反馈；实际播放/暂停、位置、时长以承载元素或后端会话的实时事实为准。 */
export type PlayerState = PlaybackState;

/** 错误事件附带的原因码 */
export type PlayerErrorCode =
  | 'attempted-fallback' // 主源失败，已成功切至备用源
  | 'no-fallback'        // 失败且没有可用备用源
  | 'fallback-limit';    // 备用源也已失败，且达到尝试上限

export type PlaybackEndAction = 'pause' | 'stop' | 'close';

export interface PlaybackCompletion {
  readonly resourceId: string | null;
  readonly positionSeconds: number;
  readonly durationSeconds: number;
  /** 跳至末尾不算自然完成；手动切换不会产生此事件。 */
  readonly natural: boolean;
}

export interface PlayerCloseOptions {
  /** 取消等待中的界面关闭请求；已经执行的停止不会回滚。 */
  signal?: AbortSignal;
}

export interface PlayerPlayOptions {
  /** 仅取消本次尚未起播的请求；已起播或被较新请求接替后不再影响播放。 */
  signal?: AbortSignal;
}

export interface PlayerLoadOptions {
  /** 本次从头加载，忽略计划/存储断点；不伪造手动 seek。 */
  restart?: boolean;
}

/**
 * Main-process-owned mpv startup configuration for one explicitly bound player.
 * The renderer never receives this object; it receives only PlaybackPort and SurfacePort operations.
 */
export interface MpvInstanceLaunchConfiguration {
  readonly instanceId: string;
  readonly executable: string;
  /** IPC pipe name, without a pipe path; the session creates and owns the connection. */
  readonly ipcName: string;
  readonly surfaceTarget: {
    readonly type: 'native-window';
    readonly windowId: string;
  };
  readonly videoOutput: 'gpu-next';
  readonly audioOutput: 'wasapi';
  readonly logFile?: string;
}

export interface StudioPlayerOptions {
  /** 单实例显式选择后端；只有无实例参数的 U2 smoke/诊断构造才读取环境变量。 */
  backend?: PlayerBackend;
  /** 宿主与端口契约使用的稳定实例标识。 */
  instanceId?: string;
  /** 宿主已经分配的实例事实；传入后与 surface/tracks 端口共享同一对象。 */
  instance?: PlayerInstance;
  /** mpv 路径使用的宿主原生 surface 端口。 */
  surfacePort?: SurfacePort;
  /** Electron main 为该 mpv 实例生成并校验的可执行文件、surface 与 IPC 启动配置。 */
  mpv?: MpvInstanceLaunchConfiguration;
  /** 宿主注入的进度持久化端口；若不传则不启用进度记忆（满足 R04） */
  progressStorage?: ProgressStoragePort;
  /** 进度记忆策略 */
  progressPolicy?: ProgressPolicy;
  /** 动态取址与转码心跳端口 */
  sourceResolver?: SourceResolverPort;
  /** 来源控制器细化配置（过期检查间隔、回退上限等） */
  sourceOptions?: Omit<SourceControllerOptions, 'resolver'>;
  /** 是否在起播时自动恢复断点（默认 true） */
  autoResume?: boolean;
  /** 用户可选的媒体元素标签：回退到原生元素时按媒体大类选择（默认 video） */
  nativeElementTag?: 'video' | 'audio';
  /** 显式选 native-audio 时必需；没有原生服务时不会隐式降级。 */
  nativeAudioPort?: NativeAudioPort;
}

const MPV_LAUNCH_CONFIGURATION_KEYS = new Set([
  'instanceId', 'executable', 'ipcName', 'surfaceTarget', 'videoOutput', 'audioOutput', 'logFile',
]);

function normalizeMpvLaunchConfiguration(value: unknown, instance: PlayerInstance): MpvInstanceLaunchConfiguration {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('StudioPlayer mpv launch configuration must be an object');
  }
  const raw = value as Record<string, unknown>;
  if (Object.keys(raw).some(key => !MPV_LAUNCH_CONFIGURATION_KEYS.has(key))) {
    throw new TypeError('StudioPlayer mpv launch configuration contains unsupported fields');
  }
  if (raw.instanceId !== instance.instanceId) {
    throw new TypeError('StudioPlayer mpv launch configuration belongs to another instance');
  }
  if (typeof raw.executable !== 'string' || !raw.executable.trim() || raw.executable.includes('\0')) {
    throw new TypeError('StudioPlayer mpv executable must be a non-empty path');
  }
  if (typeof raw.ipcName !== 'string' || !/^studio-player-mpv-[a-z0-9-]{1,140}$/.test(raw.ipcName)) {
    throw new TypeError('StudioPlayer mpv IPC name is invalid');
  }
  if (!raw.surfaceTarget || typeof raw.surfaceTarget !== 'object' || Array.isArray(raw.surfaceTarget)) {
    throw new TypeError('StudioPlayer mpv surface target is required');
  }
  const target = raw.surfaceTarget as Record<string, unknown>;
  if (Object.keys(target).some(key => key !== 'type' && key !== 'windowId')
    || target.type !== 'native-window'
    || typeof target.windowId !== 'string'
    || !/^[1-9]\d*$/.test(target.windowId)) {
    throw new TypeError('StudioPlayer mpv surface target must name one native window');
  }
  try {
    const windowId = BigInt(target.windowId);
    if (windowId <= 0n || windowId > 0xffffffffffffffffn) throw new Error('range');
  } catch {
    throw new TypeError('StudioPlayer mpv surface target is outside the HWND range');
  }
  if (raw.videoOutput !== 'gpu-next' || raw.audioOutput !== 'wasapi') {
    throw new TypeError('StudioPlayer mpv output settings are not in the supported allowlist');
  }
  if (raw.logFile !== undefined && (typeof raw.logFile !== 'string' || !raw.logFile.trim() || raw.logFile.includes('\0'))) {
    throw new TypeError('StudioPlayer mpv logFile must be a path');
  }
  return Object.freeze({
    instanceId: instance.instanceId,
    executable: raw.executable.trim(),
    ipcName: raw.ipcName,
    surfaceTarget: Object.freeze({ type: 'native-window' as const, windowId: BigInt(target.windowId).toString() }),
    videoOutput: 'gpu-next' as const,
    audioOutput: 'wasapi' as const,
    ...(typeof raw.logFile === 'string' ? { logFile: raw.logFile } : {}),
  });
}

export type PlayerEventType = PlaybackEventType;
export type PlayerEventListener = PlaybackEventListener;

interface SourceContinuity {
  generation: number;
  position: number;
  shouldResume: boolean;
  rate: number;
  volume: number;
  muted: boolean;
  positionKnown: boolean;
}

let playerInstanceSerial = 0;

/**
 * 核心真正驱动的“媒体面”。
 *
 * 承载元素（上游自定义媒体元素或原生元素）与独立进程后端（mpv 会话）都按这一面被核心使用：
 * 位置、时长、暂停、结束、定位、音量、静音、倍速、错误，加上播放、暂停、释放与事件订阅。
 * 会话不是 `HTMLMediaElement`，进入媒体槽时只能断言；**把这一面写成类型而不只写断言**，
 * 是为了让会话侧改名或漏实现变成编译期错误——否则核心会把缺失的成员读成 `undefined`
 * 并静默走偏（例如完播判定读 `seeking`）。
 */
interface BackendMediaFace {
  currentTime: number;
  duration: number;
  paused: boolean;
  ended: boolean;
  seeking: boolean;
  volume: number;
  muted: boolean;
  playbackRate: number;
  readonly error: unknown;
  play?(): Promise<void>;
  pause?(): void;
  load?(): unknown;
  addEventListener(type: string, listener: (...args: any[]) => void): void;
  removeEventListener(type: string, listener: (...args: any[]) => void): void;
}

/** 编译期断言：后端会话必须实现核心驱动的媒体面。 */
function assertMediaFace<T extends BackendMediaFace>(session: T): T {
  return session;
}

export class StudioPlayer implements PlaybackPort {
  public readonly sourceController: SourceController;
  public readonly progressController: ProgressController | null = null;
  public readonly autoResume: boolean;

  private readonly portInstance: PlayerInstance;
  private readonly surfacePortValue: SurfacePort | null;
  private readonly mpvLaunchConfiguration: MpvInstanceLaunchConfiguration | null;
  private readonly usesLegacyMpvEnvironment: boolean;
  private media: (HTMLMediaElement & { source?: any }) | null = null;
  private attachedHost: any = null;
  /**
   * 本次会话选中的非 DOM 后端（mpv）。它在媒体槽里取代承载元素：没有元素可挂、也没有 MSE
   * 通路，核心按同一个媒体面驱动它；若由宿主显式绑定 SurfacePort，画面生命周期由宿主负责。
   * null 表示既有的承载元素路径（默认，Video.js 一路）。
   *
   * 未传显式实例时才保留进程环境（[`MPV_BACKEND_ENV`]）选择，这是 U2 smoke/诊断兼容路径；
   * 显式 `backend`/`instance`/`surfacePort` 用于宿主按实例绑定端口，不改变核心的媒体面接缝。
   */
  private mpvSession: MpvSession | null = null;
  private eventListeners: Map<PlayerEventType, Set<PlayerEventListener>> = new Map();
  private boundMediaHandlers: Array<{ target: any; event: string; fn: (...args: any[]) => void }> = [];
  private boundLifecycleHandlers: Array<{ target: any; event: string; fn: (...args: any[]) => void }> = [];
  /** 每个来源只恢复一次；定位取消位置恢复，但不取消换源前的播放意图。 */
  private resumeState: { started: boolean; positionCancelled: boolean; position?: number } = { started: false, positionCancelled: false };
  private mediaFailed = false;
  private playbackState: PlayerState = 'idle';
  private readonly nativeElementTag: 'video' | 'audio';
  private mediaGeneration = 0;
  private loadRequestId = 0;
  private destroyed = false;
  private wantsPlayback = false;
  private playRequestId = 0;
  private pendingPlay: { id: number; media: NonNullable<StudioPlayer['media']>; generation: number; started: boolean } | null = null;
  private playedInCycle = false;
  private completionHandled = false;
  private completionWrite: Promise<void> | null = null;
  private pendingSourceContinuity: SourceContinuity | null = null;
  /** 媒体报告过定位（seeking）后，下一次位置上报属于跳变而非连续推进。 */
  private positionDiscontinuous = false;
  /** 最近定位的时间轴位置；只有其后实际推进才可计作自然完播。 */
  private completionSeekPosition: number | null = null;
  private replacingSource = false;
  private trackPortValue: TrackPort | null = null;
  private playAbort: AbortController | null = null;
  private playbackStarted = false;
  private playbackWatch: { timer: ReturnType<typeof setTimeout>; phase: 'initial' | 'stall'; startedAt: number; position: number } | null = null;
  private appliedPlan: PlaybackPlan | null = null;
  private readonly nativeAudioPort?: NativeAudioPort;
  private nativeAudioSession: NativeAudioSession | null = null;
  private recovering: { position: number; positionKnown: boolean } | null = null;
  private lastBufferedEnd = 0;
  private restartResource: string | null = null;

  constructor(options: StudioPlayerOptions = {}) {
    this.usesLegacyMpvEnvironment = options.backend === undefined
      && options.instance === undefined
      && options.instanceId === undefined
      && options.surfacePort === undefined
      && isMpvBackendSelected();
    const backend = options.backend ?? options.instance?.backend ?? (this.usesLegacyMpvEnvironment ? 'mpv' : 'videojs');
    this.portInstance = options.instance ?? createPlayerInstance(
      options.instanceId ?? `player-${++playerInstanceSerial}`,
      backend,
    );
    if (options.backend !== undefined && this.portInstance.backend !== options.backend) {
      throw new TypeError('StudioPlayer instance/backend options do not match');
    }
    if (options.instanceId !== undefined && this.portInstance.instanceId !== options.instanceId) {
      throw new TypeError('StudioPlayer instance/instanceId options do not match');
    }
    this.surfacePortValue = options.surfacePort ?? null;
    if (options.backend !== undefined || options.instance !== undefined || options.instanceId !== undefined || options.surfacePort !== undefined) {
      assertPlayerPorts({
        instance: this.portInstance,
        playback: this,
        ...(this.surfacePortValue ? { surface: this.surfacePortValue } : {}),
      });
    }
    if (options.mpv !== undefined && this.portInstance.backend !== 'mpv') {
      throw new TypeError('StudioPlayer mpv launch configuration requires the mpv backend');
    }
    if (this.portInstance.backend === 'mpv' && !this.usesLegacyMpvEnvironment && options.mpv === undefined) {
      throw new TypeError('An explicitly bound mpv player requires a main-process launch configuration');
    }
    this.mpvLaunchConfiguration = options.mpv === undefined
      ? null
      : normalizeMpvLaunchConfiguration(options.mpv, this.portInstance);
    this.sourceController = new SourceController({
      resolver: options.sourceResolver,
      ...options.sourceOptions,
    });
    this.autoResume = options.autoResume ?? true;
    if (backend === 'native-audio' && !options.nativeAudioPort) throw new TypeError('native-audio requires a native audio port');
    if (backend !== 'native-audio' && options.nativeAudioPort) throw new TypeError('Native audio port requires native-audio backend');
    this.nativeAudioPort = options.nativeAudioPort;
    this.nativeElementTag = options.nativeElementTag ?? 'video';
    this.sourceController.onDiagnostic(diagnostic => this.emit('diagnostic', diagnostic));

    if (options.progressStorage) {
      this.progressController = new ProgressController(options.progressStorage, options.progressPolicy);
    }

    // 监听来源变更（仅此一处应用来源：刷新、回退、初始加载统一走这里）
    this.sourceController.onSourceChange((_source, result) => {
      // 换源与回退同样可能发生在后端选择之后：先按内部信号准备承载。
      this.ensureBackendHandle();
      const positionWasStarted = this.playbackStarted;
      this.cancelPendingPlay();
      this.clearPlaybackWatch();
      this.playbackStarted = false;
      const previousPosition = this.resumeState.positionCancelled
        ? this.currentTime
        : this.pendingSourceContinuity?.positionKnown ? this.pendingSourceContinuity.position
          : !this.resumeState.started ? this.resumeState.position ?? this.currentTime : this.currentTime;
      const shouldResume = this.wantsPlayback || Boolean(this.media && !this.media.paused && !this.media.ended);
      const controls = { rate: this.playbackRate, volume: this.volume, muted: this.muted };
      const positionKnown = (this.replacingSource && this.pendingSourceContinuity?.positionKnown !== false)
        || positionWasStarted || this.resumeState.positionCancelled || this.resumeState.position !== undefined
        || this.pendingSourceContinuity?.positionKnown === true || previousPosition > 0;
      this.wantsPlayback = shouldResume;

      this.mediaGeneration += 1;
      this.resumeState = { started: false, positionCancelled: false };
      this.mediaFailed = false;
      this.pendingSourceContinuity = this.media
        ? {
            generation: this.mediaGeneration,
            position: Number.isFinite(previousPosition) ? Math.max(0, previousPosition) : 0,
            shouldResume,
            ...controls,
            positionKnown,
          }
        : null;

      // fallback/refresh 也可能改变 HLS ↔ native 路径，不能只在公开 load()
      // 时重绑媒体元素。
      this.rebindIfPlaybackPathChanged(result);
      if (this.media) {
        this.media.volume = controls.volume;
        this.media.muted = controls.muted;
        this.media.playbackRate = controls.rate;
        this.rebindMediaEvents();
        this.applySourceToMedia(result.source, result.carrier, true);
      }
      // 同步拒绝来源可能已再次回退，不能用旧通知覆盖备用源或失败状态。
      if (!this.mediaFailed && this.sourceController.getCurrentSource() === result.source) {
        this.emit('sourcechange', result.source, result);
      }
    });
  }

  /**
   * 挂载到宿主页面中的媒体元素（`<video>` / `<audio>` 或上游自定义媒体元素），
   * 或包含该元素的容器
   *
   * 容器内找不到媒体元素时**抛出 TypeError**，而不是回退到页面中其它同名元素或把容器
   * 当作媒体元素静默接受：静默接受会让后续所有 play/seek 调用无声失效，难以排查。
   *
   * 选择了 mpv 后端（非 DOM 媒体面；画面可由宿主 native surface 承载）时同样抛 TypeError：那条路径不需要挂载，
   * 元素只会落在与调用方预期不同的对象上。
   */
  public attach(element: any, applyCurrentSource: boolean = true): void {
    if (this.destroyed) throw new Error('Cannot attach a destroyed player');
    if (!element) return;

    if (this.portInstance.backend !== 'videojs') {
      // mpv 后端没有可挂载的媒体元素：它不需要 attach()，画面由宿主的 SurfacePort 承载。
      // 静默忽略会让调用方以为传入的元素在承载播放，而实际控制的是另一个对象。
      throw new TypeError(
        `[StudioPlayer] 已选择 ${this.portInstance.backend} 后端，它没有可挂载的承载元素：`
        + '不需要也不接受 attach()，请直接使用 load()/play()。'
      );
    }

    const target = resolveElement(element, this.sourceController.carrier(), this.nativeElementTag);
    if (!target) {
      throw new TypeError(
        '[StudioPlayer] attach() 找不到可承载播放的媒体元素：请传入媒体元素（如 <video>/<audio>），'
        + '或传入内部含有媒体元素的容器。'
        + '本方法不会回退到页面中其它同名元素；使用上游自定义媒体元素时请直接传入该元素。'
      );
    }
    if (this.media === target) return;
    // 播放路径重绑只更换承载元素，不卸载队列/定时器等会话功能。
    this.releaseAttachedMedia();

    this.media = target;
    this.attachedHost = element === target ? hostOf(target) : element;
    this.trackPortValue = createVideojsTrackPort(
      target,
      this.portInstance,
      () => this.currentPlan?.tracks?.subtitles ?? [],
      () => timelineOffset(this.currentPlan),
    );
    this.bindMediaEvents();
    this.bindLifecycleEvents();

    // 若挂载前已调用了 load，立即应用
    const currentSource = this.sourceController.getCurrentSource();
    if (currentSource && applyCurrentSource) {
      this.applySourceToMedia(currentSource, this.sourceController.carrier());
    }
    this.emit('mediachange', this.media);
  }

  /**
   * 解除 DOM 元素挂载
   */
  public detach(): void {
    this.recovering = null;
    this.sourceController.cancelSourcePreparation();
    this.clearPlaybackWatch();
    this.cancelPendingPlay();
    this.sourceController.cancelRefresh();
    this.wantsPlayback = false;
    this.playRequestId += 1;
    this.pendingSourceContinuity = null;
    this.loadRequestId += 1;
    this.mediaGeneration += 1;
    this.releaseAttachedMedia();
    this.closeMpvSession();
    this.attachedHost = null;
    this.nativeAudioSession?.dispose(); this.nativeAudioSession = null;
    this.setState('idle');
    this.emit('detach');
  }

  private releaseAttachedMedia(): void {
    this.clearPlaybackWatch();
    this.playbackStarted = false;
    if (!this.media) return;

    const media = this.media;

    // 解绑 DOM 事件监听后停止并清理媒体。仅把 this.media 置空会让原生
    // <video>/<audio> 继续播放，也无法满足生命周期释放契约。
    this.unbindMediaEvents();
    this.unbindLifecycleEvents();
    this.clearTrackPort();
    this.releaseMediaSource(media);
    this.resumeState = { started: false, positionCancelled: false };

    // 保存残留进度
    this.progressController?.flush();
    this.media = null;
  }

  /**
   * 加载媒体（支持 PlaybackPlan、SimpleMediaSource 或 URL 字符串）
   */
  public async load(input: PlayableInput, options: PlayerLoadOptions = {}): Promise<AdaptedSourceResult> {
    const stopped = this.playbackState === 'stopped';
    this.recovering = null;
    const inputResource = typeof input === 'string' ? input : input.resourceId ?? ('src' in input ? input.src : null);
    const restart = options.restart === true || this.restartResource !== null && this.restartResource === inputResource;
    const controls = {rate:this.playbackRate,volume:this.volume,muted:this.muted};
    this.sourceController.cancelSourcePreparation();
    this.clearPlaybackWatch();
    this.cancelPendingPlay();
    this.sourceController.cancelRefresh();
    this.playbackStarted = false;
    this.wantsPlayback = false;
    this.playRequestId += 1;
    const requestId = ++this.loadRequestId;
    const ensureCurrentRequest = () => {
      if (this.destroyed || requestId !== this.loadRequestId) {
        const error = new Error('Playback load was superseded or the player was destroyed');
        error.name = 'AbortError';
        throw error;
      }
    };
    ensureCurrentRequest();
    this.emit('loadstart', input);
    ensureCurrentRequest();
    // 先切换会话代次，让旧媒体在等待进度刷盘期间产生的迟到事件失效。
    this.mediaGeneration += 1;
    this.pendingSourceContinuity = {generation:this.mediaGeneration,position:0,positionKnown:false,shouldResume:false,...controls};
    this.resumeState = { started: false, positionCancelled: restart };
    this.mediaFailed = false;
    this.positionDiscontinuous = false;
    this.completionSeekPosition = null;
    this.playedInCycle = false;
    this.completionHandled = false;
    this.completionWrite = null;

    // 立即停止旧来源的声音，不能在等待存储时仍播放上一条却已展示新选择。
    // 旧代次事件已经失效，这里的内部暂停不取消新队列操作的播放意图。
    if (this.media && !this.media.paused) this.media.pause?.();
    this.setState('loading');
    ensureCurrentRequest();

    // 换源前先刷入旧媒体未保存的进度
    if (this.progressController && !stopped) {
      await this.progressController.flush();
    }

    ensureCurrentRequest();

    this.setState('loading');
    ensureCurrentRequest();

    let prepared: PlayableInput;
    try { prepared = await this.sourceController.prepareInput(input, restart); }
    catch (error) {
      ensureCurrentRequest();
      this.mediaFailed = true; this.setState('error'); this.emit('playerror', error);
      throw error;
    }
    try { ensureCurrentRequest(); }
    catch (error) {
      if (typeof prepared === 'object' && 'playUrl' in prepared) this.sourceController.releaseUnusedPlan(prepared);
      throw error;
    }
    const result = this.sourceController.loadInput(prepared);
    this.restartResource = null;
    ensureCurrentRequest();

    // 非 DOM 后端在这一步进入媒体槽：没有承载元素，来源直接作用在会话上。
    this.ensureBackendHandle();

    // 播放路径可能在换源后变化（HLS ↔ 原生），此时需要重绑媒体元素
    this.rebindIfPlaybackPathChanged(result);

    if (restart) this.resumeState.positionCancelled = true;
    if (this.media) {
      this.rebindMediaEvents();
      this.applySourceToMedia(result.source, result.carrier, true);
    }

    ensureCurrentRequest();
    if (!this.mediaFailed && this.sourceController.getCurrentSource() === result.source) {
      this.emit('sourcechange', result.source, result);
    }
    await this.sourceController.flushProcessing();
    ensureCurrentRequest();
    return result;
  }

  /**
   * 播放控制
   */
  /** 在异步加载前声明播放意图，供消费者范围的协调器同步抢占；不会实际起播。 */
  public requestPlayback(): boolean {
    if (this.destroyed) return false;
    this.cancelPendingPlay();
    const request = ++this.playRequestId;
    this.wantsPlayback = true;
    this.emit('playintent');
    return request === this.playRequestId && this.wantsPlayback && !this.destroyed;
  }

  /** 替换同一资源的交付来源；不触发新选集、不重置队列/睡眠/完播计数。 */
  public replaceSource(input: PlayableInput): AdaptedSourceResult {
    if (this.destroyed || !this.currentResourceId || this.state === 'stopped') throw new Error('No active source to replace');
    // 验证在取消前完成，非法跨资源替换不破坏当前会话。
    this.sourceController.validateReplacement(input);
    this.sourceController.cancelSourcePreparation();
    this.loadRequestId += 1;
    this.playRequestId += 1;
    this.replacingSource = true;
    try { return this.sourceController.replaceInput(input); }
    finally { this.replacingSource = false; }
  }

  /** Explicit processing choice; existing media remains usable during preparation. */
  public async replaceProcessedSource(session: MediaProcessingSession): Promise<AdaptedSourceResult> {
    const request = this.loadRequestId;
    const plan = await this.sourceController.prepareProcessing(session);
    if (this.destroyed || request !== this.loadRequestId) {
      await session.release(); throw playbackAbortError();
    }
    const previous = this.currentPlan;
    let result: AdaptedSourceResult;
    try {
      result = this.replaceSource({ ...plan, metadata: previous?.metadata ?? plan.metadata,
        tracks: previous?.tracks ?? plan.tracks });
    } catch (error) { await session.release(); throw error; }
    // Ownership has transferred. A failure releasing the old source must not release this one.
    await this.sourceController.flushProcessing();
    return result;
  }

  public get playbackRequested(): boolean { return this.wantsPlayback; }
  /** 当前来源与宿主均提供同资源重建能力，供功能入口使用。 */
  public get canPrepareSource(): boolean { return !this.destroyed && this.state !== 'stopped' && this.sourceController.canPrepareSource; }

  /** 保留队列和播放意图，重新准备同一资源；位置采用原始时间轴。 */
  public async prepareSource(context: Omit<SourcePreparationContext, 'signal' | 'positionSeconds' | 'paused'> & { positionSeconds?: number }): Promise<void> {
    const request = this.loadRequestId;
    const position = this.currentPlan?.live ? 0 : context.positionSeconds ?? this.currentTime;
    if (!Number.isFinite(position) || position < 0) throw new TypeError('Invalid source position');
    const plan = await this.sourceController.prepareReplacement({ ...context, positionSeconds: position, paused: this.paused && !this.wantsPlayback });
    if (this.destroyed || request !== this.loadRequestId) { this.sourceController.releaseUnusedPlan(plan); throw playbackAbortError(); }
    this.pendingSourceContinuity = { generation: this.mediaGeneration, position, positionKnown: true,
      shouldResume: this.wantsPlayback, rate: this.playbackRate, volume: this.volume, muted: this.muted };
    this.resumeState.positionCancelled = false;
    this.replaceSource(plan);
  }

  /** 窗口外定位由产品重新准备来源，绝不将负的媒体位置写入元素。 */
  public async seekAsync(positionSeconds: number): Promise<void> {
    if (this.currentPlan?.live) return;
    if (!Number.isFinite(positionSeconds)) throw new TypeError('Invalid seek position');
    const target = Math.max(0, Number.isFinite(this.duration) && this.duration > 0 ? Math.min(positionSeconds, this.duration) : positionSeconds);
    if (this.currentPlan?.timeline && !this.canSeekLocally(target)) await this.prepareSource({ reason: 'seek', positionSeconds: target });
    else this.seek(target);
  }

  private canSeekLocally(position: number): boolean {
    const relative = position - timelineOffset(this.appliedPlan);
    if (relative < 0 || (Number.isFinite(this.media?.duration) && relative > this.media!.duration)) return false;
    const ranges = this.media?.seekable;
    if (!ranges) return true;
    for (let i = 0; i < ranges.length; i++) if (relative >= ranges.start(i) && relative <= ranges.end(i)) return true;
    return false;
  }

  /** MediaDock 的显式归零动作；普通 stop() 继续保存实际断点。 */
  public async stopAndReset(): Promise<void> {
    const resourceId = this.currentResourceId;
    const live = this.currentPlan?.live;
    const pending = this.stop();
    const request = this.loadRequestId;
    await pending;
    if (request !== this.loadRequestId || this.destroyed) throw playbackAbortError();
    this.restartResource = resourceId;
    if (resourceId && !live) await this.progressController?.clearProgress(resourceId);
  }

  public async play(options: PlayerPlayOptions = {}): Promise<void> {
    options.signal?.throwIfAborted();
    if (!this.media || typeof this.media.play !== 'function') return;
    if (this.playbackState === 'stopped') {
      const error = new Error('Player is stopped; load a source or select a queue item before playing');
      error.name = 'InvalidStateError';
      throw error;
    }
    if (this.mediaFailed) {
      const error = new Error('No playable source; load a new source before playing');
      error.name = 'NotSupportedError';
      throw error;
    }
    if (!this.requestPlayback()) {
      const error = new Error('Playback intent was superseded');
      error.name = 'AbortError';
      throw error;
    }
    const media = this.media;
    const generation = this.mediaGeneration;
    const request = { id: ++this.playRequestId, media, generation, started: false };
    this.pendingPlay = request;
    const abort = this.portInstance.backend !== 'mpv' ? new AbortController() : null;
    if (abort) this.playAbort = abort;
    let operationSettled = false;
    const cancel = () => {
      if (this.pendingPlay === request && request.id === this.playRequestId && !request.started
        && this.media === media && this.mediaGeneration === generation) this.pause();
    };
    options.signal?.addEventListener('abort', cancel, { once: true });
    try {
      // playintent 的同步监听也可能卸载请求的拥有者。
      if (options.signal?.aborted) { cancel(); options.signal.throwIfAborted(); }
      if (!this.playbackStarted || media.paused) this.startPlaybackWatch('initial');
      if (this.currentPlan?.live && media.paused && media.seekable?.length) {
        const last = media.seekable.length - 1;
        media.currentTime = Math.max(media.seekable.start(last), media.seekable.end(last) - 2);
      }
      const operation = Promise.resolve(media.play()).then(() => {
        operationSettled = true;
        // 即使等待已取消，也要抑制底层迟到的实际起播。
        if ((request.id !== this.playRequestId || this.media !== media || this.mediaGeneration !== generation || this.destroyed)
          && (this.media !== media || !this.wantsPlayback)) media.pause?.();
        if (abort?.signal.aborted && this.pendingPlay === request) this.pendingPlay = null;
      }, error => {
        operationSettled = true;
        if (abort?.signal.aborted && this.pendingPlay === request) this.pendingPlay = null;
        throw error;
      });
      await (abort ? waitWithSignal(operation, abort.signal) : operation);
      if (request.id !== this.playRequestId || this.media !== media || this.mediaGeneration !== generation || this.destroyed) {
        // 同一元素可能已被新会话使用；只停止旧元素或已被明确取消的播放。
        if (this.media !== media || !this.wantsPlayback) media.pause?.();
        const cancelled = new Error('Playback request was cancelled');
        cancelled.name = 'AbortError';
        throw cancelled;
      }
    } catch (error) {
      // 终态超时保留原因；已转入备用源的旧请求按取消处理，避免队列把恢复误报为失败。
      if (abort?.signal.reason instanceof PlaybackTimeoutError && this.mediaFailed) throw abort.signal.reason;
      if (request.id !== this.playRequestId || this.media !== media || this.mediaGeneration !== generation || this.destroyed) {
        const cancelled = new Error('Playback request belongs to a superseded source');
        cancelled.name = 'AbortError';
        throw cancelled;
      }
      this.wantsPlayback = false;
      this.clearPlaybackWatch();
      // 独立调用 play() 与队列/自动续播共用失败出口；协调器据此释放归属。
      // AbortError 是取消，不作为播放失败重复通知。
      if ((error as any)?.name !== 'AbortError') {
        this.diagnose({ code: 'play-rejected' });
        this.emit('playerror', error);
      }
      throw error;
    } finally {
      options.signal?.removeEventListener('abort', cancel);
      if (this.pendingPlay === request && (operationSettled || !abort?.signal.aborted)) this.pendingPlay = null;
      if (this.playAbort === abort) this.playAbort = null;
    }
  }

  public pause(): void {
    this.clearPlaybackWatch();
    this.cancelPendingPlay();
    this.playbackStarted = false;
    this.wantsPlayback = false;
    this.playRequestId += 1;
    // 已经暂停或正在等待异步 load 时也要取消功能层的后续自动播放。
    this.emit('pauseintent');
    if (this.media && typeof this.media.pause === 'function') {
      this.media.pause();
    }
  }

  /** 保存当前断点并释放播放来源，保留列表、控制器和挂载位置。 */
  public async stop(): Promise<void> {
    if (this.destroyed) return;
    this.recovering = null;
    const resourceId = this.currentResourceId;
    const continuity = this.pendingSourceContinuity;
    const pendingPosition = continuity?.generation === this.mediaGeneration && continuity.positionKnown
      ? continuity.position : null;
    const position = !this.resumeState.positionCancelled && pendingPosition !== null ? pendingPosition : this.currentTime;
    const duration = this.duration;
    const completed = this.completionHandled || Boolean(this.media?.ended);
    const completionWrite = this.completionWrite;
    // 正在读取起播断点时不要用尚未恢复的 0 秒覆盖存储。
    const hasPosition = this.playedInCycle || this.resumeState.positionCancelled
      || this.playbackState === 'paused' || pendingPosition !== null;
    const requestId = ++this.loadRequestId;
    this.mediaGeneration += 1;
    this.pendingSourceContinuity = null;
    this.unbindMediaEvents();
    this.pause();
    if (requestId !== this.loadRequestId || this.destroyed) {
      const error = new Error('Stop was superseded by another playback operation');
      error.name = 'AbortError';
      throw error;
    }

    const checkpoint = !this.currentPlan?.live && !completed && hasPosition && resourceId && this.progressController
      ? this.progressController.saveCheckpoint(resourceId, position, duration)
      : Promise.resolve();
    const writes = this.progressController?.flush();
    if (this.media) this.releaseMediaSource(this.media);
    this.sourceController.unload();
    this.resumeState = { started: false, positionCancelled: false };
    this.positionDiscontinuous = false;
    this.playedInCycle = false;
    this.mediaFailed = false;
    this.setState('stopped');
    this.emit('stop', { resourceId, positionSeconds: position, durationSeconds: duration, completed });
    // 即使持久化失败，播放资源也已经释放；调用者仍能收到失败反馈。
    await Promise.all([checkpoint, writes, completionWrite, this.sourceController.flushProcessing()]);
  }

  /** 立即通知界面退出；Promise 与 closerequest 仍表示停止、保存及清理完成。 */
  public async close(options: PlayerCloseOptions = {}): Promise<void> {
    options.signal?.throwIfAborted();
    const stopping = this.stop();
    const requestId = this.loadRequestId;
    this.emit('closeintent');
    await stopping;
    options.signal?.throwIfAborted();
    if (this.destroyed || requestId !== this.loadRequestId) {
      const error = new Error('Close was superseded by another playback operation');
      error.name = 'AbortError';
      throw error;
    }
    this.emit('closerequest');
  }

  public seek(positionSeconds: number): void {
    if (this.currentPlan?.live) return;
    if (!this.media || this.mediaFailed || !Number.isFinite(positionSeconds)) return;
    const duration = this.duration;
    let target = Math.max(0, positionSeconds);
    if (Number.isFinite(duration) && duration > 0) {
      target = Math.min(target, duration);
    }
    if (this.currentPlan?.timeline && !this.canSeekLocally(target)) {
      void this.seekAsync(target).catch(error => { if ((error as Error)?.name !== 'AbortError') this.emit('playerror', error); });
      return;
    }
    if (this.recovering) {
      this.recovering.position = target;
      this.recovering.positionKnown = true;
    }
    else this.sourceController.cancelSourcePreparation();
    this.resumeState.positionCancelled = true;
    this.positionDiscontinuous = true;
    this.completionSeekPosition = target;
    this.media.currentTime = target - timelineOffset(this.appliedPlan);
    const resourceId = this.sourceController.getCurrentResourceId();
    if (resourceId && this.progressController) {
      // seek 是跳变，不是连续播放推进：即使媒体处于播放中也必须传 false，
      // 否则拖到结尾附近会被误判为看完而清除断点。
      this.progressController.recordProgress(resourceId, target, duration, false);
    }
  }

  public setVolume(volume: number): void {
    if (!this.media || !Number.isFinite(volume)) return;
    this.media.volume = Math.max(0, Math.min(1, volume));
    if (this.pendingSourceContinuity) this.pendingSourceContinuity.volume = this.media.volume;
  }

  public setMuted(muted: boolean): void {
    if (!this.media) return;
    this.media.muted = Boolean(muted);
    if (this.pendingSourceContinuity) this.pendingSourceContinuity.muted = this.media.muted;
  }

  public setPlaybackRate(rate: number): void {
    if (this.currentPlan?.live && rate !== 1) return;
    if (!this.media || isNaN(rate) || rate <= 0) return;
    this.media.playbackRate = rate;
    if (this.pendingSourceContinuity) this.pendingSourceContinuity.rate = this.media.playbackRate;
  }

  public get playbackRate(): number {
    return this.media?.playbackRate ?? 1;
  }

  public get volume(): number {
    return this.media?.volume ?? 1;
  }

  public get muted(): boolean {
    return this.media?.muted ?? false;
  }

  /** 当前状态流 */
  public get state(): PlayerState {
    return this.playbackState;
  }

  /** 当前会话是否已进入失败终态 */
  public get failed(): boolean {
    return this.mediaFailed;
  }

  public get isDestroyed(): boolean {
    return this.destroyed;
  }

  /** 当前是否还有可尝试的备用源 */
  public get canFallback(): boolean {
    return this.sourceController.canFallback();
  }

  /** 当前挂载的媒体元素（宿主用于自定义控件或诊断） */
  public get element(): (HTMLMediaElement & { source?: any }) | null {
    // 独立进程后端没有承载元素：这里返回 null，不把引擎会话句柄当成元素交给宿主。
    return this.mpvSession || this.nativeAudioSession ? null : this.media;
  }

  /** 当前后端的窄轨道端口；DOM/IPC 细节留在各自后端适配。 */
  public get trackPort(): TrackPort | null {
    return this.trackPortValue;
  }

  public get instance(): PlayerInstance {
    return this.portInstance;
  }

  public get backend(): PlayerBackend {
    return this.portInstance.backend;
  }

  public get surfacePort(): SurfacePort | null {
    return this.surfacePortValue;
  }

  public get ports(): PlayerPorts {
    return {
      instance: this.portInstance,
      playback: this,
      ...(this.trackPortValue ? { tracks: this.trackPortValue } : {}),
      ...(this.surfacePortValue ? { surface: this.surfacePortValue } : {}),
    };
  }

  /** 基础状态 getter */
  public get currentTime(): number {
    return this.media ? (this.media.currentTime || 0) + timelineOffset(this.appliedPlan) : 0;
  }

  public get duration(): number {
    if (this.currentPlan?.live) return Infinity;
    return this.media ? originalDuration(this.appliedPlan, this.media.duration) : 0;
  }

  public get buffered(): readonly PlaybackRange[] { return originalRanges(this.media?.buffered, this.appliedPlan); }
  public get seekable(): readonly PlaybackRange[] { return originalRanges(this.media?.seekable, this.appliedPlan); }

  public get paused(): boolean {
    return this.media?.paused ?? true;
  }

  public get currentPlan(): PlaybackPlan | null {
    return this.sourceController.getCurrentPlan();
  }

  public get currentMetadata(): Readonly<Record<string, unknown>> | null {
    return this.sourceController.getCurrentMetadata();
  }

  public get currentResourceId(): string | null {
    return this.sourceController.getCurrentResourceId();
  }

  /**
   * 切换到备用回退源（手动或故障时被动调用）
   *
   * 来源由 onSourceChange 统一应用，这里不再重复赋值。
   */
  public switchToFallback(): boolean {
    const fallbackResult = this.sourceController.switchToFallback();
    if (!fallbackResult) return false;

    if (!this.mediaFailed && this.sourceController.getCurrentSource() === fallbackResult.source) {
      this.diagnose({ code: 'fallback', recovery: 'fallback' });
      this.emit('fallback', fallbackResult.source, fallbackResult.originalPlan);
    }
    return true;
  }

  /**
   * 销毁并彻底释放资源
   */
  public destroy(): void {
    if (this.destroyed) return;
    this.wantsPlayback = false;
    this.destroyed = true;
    this.emit('destroy');
    this.loadRequestId += 1;
    this.detach();
    this.sourceController.destroy();
    this.progressController?.destroy();
    this.eventListeners.clear();
    this.playbackState = 'idle';
    this.mediaFailed = false;
  }

  /** Await local processing termination in hosts that own asynchronous resources. */
  public async destroyAsync(): Promise<void> {
    this.destroy(); await this.sourceController.flushProcessing();
  }

  /** 事件监听 */
  public on(event: 'diagnostic', listener: (diagnostic: PlaybackDiagnostic) => void): () => void;
  public on(event: Exclude<PlayerEventType, 'diagnostic'>, listener: PlayerEventListener): () => void;
  public on(event: PlayerEventType, listener: PlayerEventListener): () => void;
  public on(event: PlayerEventType, listener: PlayerEventListener): () => void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, new Set());
    }
    this.eventListeners.get(event)!.add(listener);
    return () => this.off(event, listener);
  }

  public off(event: PlayerEventType, listener: PlayerEventListener): void {
    this.eventListeners.get(event)?.delete(listener);
  }

  private emit(event: PlayerEventType, ...args: any[]): void {
    const listeners = this.eventListeners.get(event);
    if (!listeners) return;
    for (const fn of listeners) {
      try {
        fn(...args);
      } catch (err) {
        console.error(`[StudioPlayer] Error in ${event} listener:`, err);
      }
    }
  }

  private setState(next: PlayerState): void {
    if (this.playbackState === next) return;
    this.playbackState = next;
    this.emit('statechange', next);
  }

  /** 换源后若承载方式发生变化（受管 ↔ 原生），重新绑定对应媒体元素 */
  private rebindIfPlaybackPathChanged(result: AdaptedSourceResult): void {
    if (!this.media) return;
    // 独立进程后端没有承载元素可换：承载方式变化不涉及重绑。
    if (this.mpvSession || this.nativeAudioSession) return;
    const host = this.attachedHost && this.attachedHost !== this.media ? this.attachedHost : hostOf(this.media);
    const desired = resolveElement(host, result.carrier, this.nativeElementTag);
    if (desired && desired !== this.media) {
      this.attach(host, false);
    }
  }

  /**
   * 按实例绑定或旧环境信号准备承载：选择 mpv 时，会话取代承载元素进入媒体槽。
   *
   * 会话对象同步创建、进程在首次加载来源时启动，因此公开的同步通路（`load`、`replaceSource`
   * 触发的换源）都不需要等待进程。没有选择 mpv 时这里什么也不做，既有路径一行不变。
   */
  private ensureBackendHandle(): void {
    if (this.portInstance.backend === 'native-audio') {
      if (this.nativeAudioSession) return;
      const session = new NativeAudioSession(this.nativeAudioPort!);
      assertMediaFace(session);
      this.nativeAudioSession = session; this.media = session as unknown as NonNullable<StudioPlayer['media']>;
      this.bindLifecycleEvents(); return;
    }
    if (this.mpvSession || this.portInstance.backend !== 'mpv') return;
    const configuration = this.mpvLaunchConfiguration;
    if (!configuration && !this.usesLegacyMpvEnvironment) {
      throw new TypeError('An explicitly bound mpv player requires a main-process launch configuration');
    }
    // 会话按媒体面进入媒体槽：这里的断言是编译期的（见 BackendMediaFace），不是赋值处强转。
    const session = assertMediaFace(configuration
      ? createMpvSession({
        executable: configuration.executable,
        pipeName: configuration.ipcName,
        nativeWindowId: configuration.surfaceTarget.windowId,
        videoOutput: configuration.videoOutput,
        audioOutput: configuration.audioOutput,
        ...(configuration.logFile === undefined ? {} : { logFile: configuration.logFile }),
      })
      : createMpvSession());
    this.mpvSession = session;
    this.media = session as unknown as NonNullable<StudioPlayer['media']>;
    this.trackPortValue = createMpvTrackPort(session, this.portInstance);
    // 这条路径没有 attach() 可走，页面生命周期刷盘钩子在这里补齐；否则关页面时还没落盘的
    // 进度会丢。承载元素路径由 attach() 注册同一组监听，两次调用之间由内部的长度守卫去重。
    this.bindLifecycleEvents();
  }

  /** 结束 mpv 会话进程并清空后端句柄；`detach`/`destroy` 与重新装配时调用。 */
  private closeMpvSession(): void {
    const session = this.mpvSession;
    if (!session) return;
    this.mpvSession = null;
    this.clearTrackPort();
    void session.close();
  }

  private clearTrackPort(): void {
    const port = this.trackPortValue as (TrackPort & { dispose?: () => void }) | null;
    port?.dispose?.();
    this.trackPortValue = null;
  }

  private applySourceToMedia(source: DeliveryTarget, carrier: DeliveryCarrier, beginLoading: boolean = false): void {
    if (!this.media) return;
    this.appliedPlan = this.currentPlan;
    if (this.appliedPlan?.live) this.media.playbackRate = 1;
    this.mediaFailed = false;
    if (beginLoading) this.setState('loading');

    try {
      if (this.portInstance.backend !== 'mpv') {
        timeoutMilliseconds(this.currentPlan?.timeouts?.initial);
        timeoutMilliseconds(this.currentPlan?.timeouts?.stall);
        if (this.wantsPlayback) this.startPlaybackWatch('initial');
      }
      const media = this.media;
      // mpv 会话直接承接来源：能力声明之外的来源在这里同步拒绝，与承载元素路径共用同一条
      // "来源拒绝 → 备用源 → error"规则；等价来源的判定与补一次 load 的规则也一致。
      const { deduped } = this.nativeAudioSession ? this.nativeAudioSession.apply(source, this.currentPlan) : this.mpvSession
        ? this.mpvSession.applyDelivery(source)
        : applyDelivery(media, source, carrier);
      // load/重播是命令式的新会话，不能停在 loading 或沿用上一条目的位置。
      // 只有等价来源补一次公开 load，不对已变化的来源重复加载。
      if (deduped && !this.mediaFailed && this.sourceController.getCurrentSource() === source) {
        const generation = this.mediaGeneration;
        void Promise.resolve(media.load?.()).catch(error => {
          if (!this.destroyed && this.media === media && this.mediaGeneration === generation) this.handleMediaError(error);
        });
      }
    } catch (error) {
      // 拒绝新来源时必须先停止旧媒体。否则其时间会被记到新资源上，
      // 回退还可能继承上一资源的位置与播放意图。
      this.handleMediaError(error, true);
    }
  }

  private releaseMediaSource(media: NonNullable<StudioPlayer['media']>): void {
    this.appliedPlan = null;
    try {
      media.pause?.();
      // 独立进程后端没有元素来源可清：释放当前来源，会话进程归 closeMpvSession()。
      if (this.nativeAudioSession) this.nativeAudioSession.release();
      else if (isMpvSession(media)) this.mpvSession?.release();
      else releaseDelivery(media);
    } catch (error) {
      console.warn('[StudioPlayer] Failed to release media element:', error);
    }
  }

  private clearCurrentMediaSource(): void {
    if (!this.media) return;
    this.mediaGeneration += 1;
    this.resumeState = { started: false, positionCancelled: false };
    this.unbindMediaEvents();
    this.releaseMediaSource(this.media);
    this.bindMediaEvents();
  }

  /** 同步来源拒绝与媒体 error 共用回退预算、终态和错误码。 */
  private handleMediaError(error: unknown, sourceRejected = false, skipRecovery = false): void {
    if (this.recovering) return;
    if (!sourceRejected && !skipRecovery && this.sourceController.canRecover) {
      const request = this.loadRequestId;
      const continuity = this.pendingSourceContinuity?.generation === this.mediaGeneration
        ? this.pendingSourceContinuity : null;
      // 初次载入失败时媒体的 0 秒仍可能是未知位置，不能取消尚未读取的断点。
      const positionKnown = this.playbackStarted || this.resumeState.positionCancelled
        || this.resumeState.position !== undefined || continuity?.positionKnown === true || this.currentTime > 0;
      // 仅在断点尚待应用时使用缓存；完成恢复后即使暂停，也应保留实际位置。
      const position = !this.resumeState.positionCancelled && continuity?.positionKnown
        ? continuity.position : !this.resumeState.started && !this.resumeState.positionCancelled
          ? this.resumeState.position ?? this.currentTime : this.currentTime;
      const wanted = this.wantsPlayback;
      const recovery = this.currentPlan?.live ? { position: 0, positionKnown: true } : { position, positionKnown };
      this.recovering = recovery;
      this.playRequestId += 1;
      this.clearPlaybackWatch(); this.cancelPendingPlay();
      this.media?.pause?.(); this.wantsPlayback = wanted;
      this.setState('loading');
      void this.sourceController.recover(error, recovery.position, !wanted).then(plan => {
        if (this.recovering !== recovery) { if (plan) this.sourceController.releaseUnusedPlan(plan); return; }
        this.recovering = null;
        if (this.destroyed || request !== this.loadRequestId) { if (plan) this.sourceController.releaseUnusedPlan(plan); return; }
        if (plan) {
          this.pendingSourceContinuity = {generation:this.mediaGeneration,position:recovery.position,positionKnown:recovery.positionKnown,shouldResume:this.wantsPlayback,rate:this.playbackRate,volume:this.volume,muted:this.muted};
          this.resumeState.positionCancelled = false;
          this.replaceSource(plan); this.emit('error',error,true,'attempted-fallback');
        } else this.handleMediaError(error, sourceRejected, true);
      }, failure => {
        if (this.recovering !== recovery) return;
        this.recovering = null;
        if (!this.destroyed && request === this.loadRequestId && (failure as Error)?.name !== 'AbortError') this.handleMediaError(error, sourceRejected, true);
      });
      return;
    }
    this.clearPlaybackWatch();
    console.warn('[StudioPlayer] Media playback error encountered:', error);
    if (sourceRejected) this.clearCurrentMediaSource();
    if (this.switchToFallback()) {
      // 备用源可能在 setter/canPlayType 中同步失败；该失败已自行上报。
      if (!this.mediaFailed) this.emit('error', error, true, 'attempted-fallback');
      return;
    }
    if (!sourceRejected && !this.mediaFailed) this.clearCurrentMediaSource();
    this.mediaFailed = true;
    this.sourceController.cancelRefresh();
    this.cancelPendingPlay();
    this.wantsPlayback = false;
    this.pendingSourceContinuity = null;
    this.setState('error');
    const code: PlayerErrorCode = this.sourceController.isFallbackExhausted() ? 'fallback-limit' : 'no-fallback';
    this.diagnose({ code: 'media-error', recovery: code === 'fallback-limit' ? 'limit' : 'none' });
    this.emit('error', error, false, code);
  }

  private diagnose(value: Omit<PlaybackDiagnostic, 'timestamp'>): void {
    this.emit('diagnostic', Object.freeze({ ...value, timestamp: Date.now() }));
  }

  private cancelPendingPlay(error: Error = playbackAbortError()): void {
    this.playAbort?.abort(error);
    this.playAbort = null;
  }

  private clearPlaybackWatch(): void {
    if (this.playbackWatch) clearTimeout(this.playbackWatch.timer);
    this.playbackWatch = null;
  }

  /** 只观测 Video.js/原生媒体事件；不声称观察网络连接或首帧。 */
  private startPlaybackWatch(phase: 'initial' | 'stall'): void {
    if (this.portInstance.backend === 'mpv' || !this.media || !this.wantsPlayback || this.mediaFailed || this.destroyed) return;
    const duration = timeoutMilliseconds(this.currentPlan?.timeouts?.[phase]);
    if (!duration || this.playbackWatch?.phase === phase) return;
    this.clearPlaybackWatch();
    const generation = this.mediaGeneration;
    const media = this.media;
    const watch = { phase, startedAt: Date.now(), position: media.currentTime, timer: setTimeout(() => {
      if (this.playbackWatch !== watch || this.mediaGeneration !== generation || this.media !== media || !this.wantsPlayback || this.destroyed) return;
      // 卡顿只在已起播、未暂停且时间未推进时成立；seek 的位置跳变也取消旧观察。
      if (phase === 'stall' && (media.paused || media.ended || media.currentTime !== watch.position)) { this.clearPlaybackWatch(); return; }
      this.clearPlaybackWatch();
      const error = new PlaybackTimeoutError(phase, duration / 1000);
      this.diagnose({ code: phase === 'initial' ? 'initial-timeout' : 'stall-timeout', elapsedMs: Date.now() - watch.startedAt, timeoutSeconds: duration / 1000 });
      // 订阅者可能在诊断中暂停、换源或销毁；旧超时不得作用到新操作。
      if (this.mediaGeneration !== generation || this.media !== media || !this.wantsPlayback || this.destroyed) return;
      this.cancelPendingPlay(error);
      this.handleMediaError(error);
    }, duration) };
    this.playbackWatch = watch;
    if (phase === 'stall') this.diagnose({ code: 'buffering-started' });
  }

  private playbackProgressed(started: boolean): void {
    const watch = this.playbackWatch;
    if (watch && (started || (watch.phase === 'stall' && this.media?.currentTime !== watch.position))) {
      this.clearPlaybackWatch();
      this.diagnose({ code: watch.phase === 'initial' ? 'playback-started' : 'buffering-ended', elapsedMs: Date.now() - watch.startedAt });
    }
    if (started) this.playbackStarted = true;
  }

  private unbindMediaEvents(): void {
    for (const { target, event, fn } of this.boundMediaHandlers) {
      target?.removeEventListener?.(event, fn);
    }
    this.boundMediaHandlers = [];
  }

  private unbindLifecycleEvents(): void {
    for (const { target, event, fn } of this.boundLifecycleHandlers) {
      target?.removeEventListener?.(event, fn);
    }
    this.boundLifecycleHandlers = [];
  }

  /**
   * 换源后只重绑媒体事件：新来源的事件必须捕获新的媒体代次。
   *
   * 页面生命周期监听（pagehide/visibilitychange 等）与媒体代次无关，它们只负责
   * 把待保存进度刷盘，因此**不随换源重绑、也不做代次判断**；否则换源后这些
   * 监听会被代次守卫判为过期，关页面时进度会静默丢失。
   */
  private rebindMediaEvents(): void {
    if (!this.media) return;
    this.unbindMediaEvents();
    this.bindMediaEvents();
  }

  /** 绑定页面生命周期监听；只在 attach 时绑一次，与来源切换无关。 */
  private bindLifecycleEvents(): void {
    if (this.boundLifecycleHandlers.length > 0) return;

    const addLifecycleListener = (target: any, event: string, fn: (...args: any[]) => void) => {
      target?.addEventListener?.(event, fn);
      this.boundLifecycleHandlers.push({ target, event, fn });
    };

    if (typeof window !== 'undefined') {
      addLifecycleListener(window, 'pagehide', () => {
        this.progressController?.flush();
      });
      addLifecycleListener(window, 'beforeunload', () => {
        this.progressController?.flush();
      });
    }
    if (typeof document !== 'undefined') {
      addLifecycleListener(document, 'visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
          this.progressController?.flush();
        }
      });
    }
  }

  private bindMediaEvents(): void {
    if (!this.media) return;

    const boundMedia = this.media;
    const boundGeneration = this.mediaGeneration;
    const isCurrentEvent = () => !this.destroyed && this.media === boundMedia && this.mediaGeneration === boundGeneration;
    this.lastBufferedEnd = 0;

    const addListener = (target: any, event: string, fn: (...args: any[]) => void) => {
      target?.addEventListener?.(event, fn);
      this.boundMediaHandlers.push({ target, event, fn });
    };

    addListener(this.media, 'play', () => {
      if (!isCurrentEvent() || this.mediaFailed || boundMedia.paused) return;
      const pending = this.pendingPlay;
      if (pending?.media === boundMedia && pending.generation === boundGeneration
        && pending.id !== this.playRequestId && !this.wantsPlayback) {
        boundMedia.pause();
        return;
      }
      // 上游/原生控件也加入同一协调范围；自身 play() 已在调用媒体前声明意图。
      if (!pending && !this.requestPlayback()) { boundMedia.pause(); return; }
      if (boundMedia.paused || !isCurrentEvent()) return;
      this.wantsPlayback = true;
      if (!this.playbackStarted) this.startPlaybackWatch('initial');
      this.playedInCycle = true;
      this.completionHandled = false;
      this.completionWrite = null;
      this.setState('playing');
      this.emit('play');
    });

    addListener(this.media, 'pause', () => {
      // 同一元素快速换源后，旧 pause 可能在新 play() 之后才派发。
      // 以当前媒体事实判断，不能用这条迟到通知取消新的播放意图。
      // 恢复期间的内部暂停也保留意图；用户 pause() 已显式撤销播放请求。
      if (!isCurrentEvent() || !boundMedia.paused || this.recovering) return;
      this.clearPlaybackWatch();
      this.playbackStarted = false;
      if (!boundMedia.ended) this.cancelPendingPlay();
      if (!this.media?.ended) this.wantsPlayback = false;
      this.progressController?.flush();
      if (!this.mediaFailed) this.setState(this.media?.ended ? 'ended' : 'paused');
      this.emit('pause');
    });

    for (const event of ['volumechange', 'ratechange', 'seeked', 'playing'] as const) {
      addListener(this.media, event, () => {
        if (!isCurrentEvent()) return;
        if (event === 'playing') this.playbackProgressed(true);
        const pending = this.pendingPlay;
        if (event === 'playing' && pending?.media === boundMedia && pending.generation === boundGeneration
          && pending.id === this.playRequestId) pending.started = true;
        this.emit(event);
      });
    }

    // 媒体自身报告定位开始：下一次位置上报是跳变，不能当作连续播放推进。
    // 这样即使拖动来自原生控件或上游皮肤（不经过 seek()），也不会误判完播。
    addListener(this.media, 'seeking', () => {
      if (!isCurrentEvent()) return;
      this.positionDiscontinuous = true;
      this.completionSeekPosition = this.currentTime;
      this.resumeState.positionCancelled = true;
    });

    addListener(this.media, 'timeupdate', () => {
      if (!isCurrentEvent() || this.mediaFailed || this.media?.ended || this.playbackState === 'ended') return;
      this.playbackProgressed(false);
      const resourceId = this.sourceController.getCurrentResourceId();
      const curr = this.currentTime;
      const dur = this.duration;
      const fromContinuousPlayback = this.positionDiscontinuous ? false : (this.media?.paused ? 'paused' : true);
      this.positionDiscontinuous = false;

      this.sourceController.updateCurrentTime(this.currentPlan?.live ? 0 : curr);
      // 新媒体的 load()/play 请求可能先报告 0 秒；断点定位完成前不覆盖存储。
      const positionReady = this.resumeState.positionCancelled
        || this.resumeState.position !== undefined && this.resumeState.started
        || !this.resumeState.started && curr > 0;
      if (!this.currentPlan?.live && resourceId && this.progressController && positionReady) {
        this.progressController.recordProgress(resourceId, curr, dur, fromContinuousPlayback);
      }
      this.emit('timeupdate', curr, dur);
    });

    addListener(this.media, 'durationchange', () => {
      if (!isCurrentEvent()) return;
      const dur = this.duration;
      if (!this.mediaFailed && this.playbackState === 'loading' && Number.isFinite(dur) && dur > 0) {
        this.setState('ready');
      }
      this.emit('durationchange', dur);
    });

    addListener(this.media, 'loadedmetadata', () => {
      if (!isCurrentEvent()) return;
      if (!this.mediaFailed && this.playbackState === 'loading') this.setState('ready');
      void this.handleAutoResume();
    });

    addListener(this.media, 'canplay', () => {
      if (!isCurrentEvent()) return;
      void this.handleAutoResume();
    });
    addListener(this.media, 'progress', () => {
      if (!isCurrentEvent()) return;
      void this.handleAutoResume();
      const ranges = this.buffered;
      const end = ranges.at(-1)?.end ?? 0;
      if (end > this.lastBufferedEnd) { this.lastBufferedEnd = end; this.diagnose({code:'data-progress'}); }
    });

    addListener(this.media, 'ended', () => {
      if (!isCurrentEvent() || this.mediaFailed || this.completionHandled || !boundMedia.ended) return;
      if (this.currentPlan?.live) { this.handleMediaError(new Error('Live stream ended')); return; }
      this.clearPlaybackWatch();
      this.completionHandled = true;
      this.wantsPlayback = false;
      const resourceId = this.sourceController.getCurrentResourceId();
      const completion: PlaybackCompletion = Object.freeze({
        resourceId,
        positionSeconds: this.currentTime,
        durationSeconds: this.duration,
        natural: this.playedInCycle && !boundMedia.seeking
          && (this.completionSeekPosition === null || this.currentTime > this.completionSeekPosition),
      });
      if (resourceId && this.progressController) {
        this.completionWrite = this.progressController.clearProgress(resourceId);
        // 独立完播也处理拒绝；stop/close 仍等待原始 Promise 并把失败返回给调用方。
        void this.completionWrite.catch(error => {
          console.warn('[StudioPlayer] Failed to clear completed progress:', error);
        });
      }
      this.setState('ended');
      // 睡眠/结束策略先决定，随后才通知队列接续；不依赖功能装配顺序。
      this.emit('beforeended', completion);
      this.emit('ended', completion);
    });

    addListener(this.media, 'error', (e: any) => {
      if (!isCurrentEvent()) return;
      this.handleMediaError((this.media as any)?.error || e);
    });
    if (this.portInstance.backend !== 'mpv') {
      for (const event of ['waiting', 'stalled']) addListener(this.media, event, () => {
        if (isCurrentEvent() && this.playbackStarted && !boundMedia.paused && !boundMedia.ended) this.startPlaybackWatch('stall');
      });
    }
  }

  /** play() 已统一通知失败；自动恢复只消费拒绝，避免产生未处理 Promise。 */
  private async resumePlaybackForCurrentSource(): Promise<void> {
    try {
      await this.play();
    } catch { /* 取消或已通过 playerror 通知的失败。 */ }
  }

  private async handleAutoResume(): Promise<void> {
    if (this.resumeState.started || !this.media || this.mediaFailed || this.media.ended) return;
    const generationAtStart = this.mediaGeneration;
    const mediaAtStart = this.media;
    const duration = this.duration;
    const resourceId = this.sourceController.getCurrentResourceId();
    if (!resourceId || !(duration > 0 || duration === Infinity)) return;

    const resumeState = this.resumeState;
    // 读取期间阻止并发恢复；定位范围尚未就绪时保留结果供后续事件重试。
    resumeState.started = true;

    // fallback/刷新换源优先恢复当前会话的位置，而不是重新读取旧的持久化
    // 断点；这样换源不会把正在播放的媒体跳回 0 秒。
    const continuity = this.pendingSourceContinuity;
    const hasContinuity = continuity?.generation === generationAtStart;
    let resumePos = this.currentPlan?.live ? 0 : resumeState.position ?? (hasContinuity && continuity.position > 0 && continuity.position < duration
      ? continuity.position : 0);

    if (!this.currentPlan?.live && resumeState.position === undefined && !resumeState.positionCancelled && !(hasContinuity && continuity.positionKnown) && !resumePos && this.autoResume) {
      resumePos = this.sourceController.getCurrentPlan()?.resumePositionSeconds ?? 0;
      if (!resumePos && this.progressController) {
        resumePos = await this.progressController.getResumePosition(resourceId, duration);
      }
    }

    // 异步等待期间可能已经换源或重新加载同一资源，迟到的恢复不能作用于新媒体
    if (
      this.media !== mediaAtStart
      || this.mediaGeneration !== generationAtStart
      || this.resumeState !== resumeState
      || this.mediaFailed
      || this.sourceController.getCurrentResourceId() !== resourceId
    ) return;

    resumeState.position = resumePos;
    if (!resumeState.positionCancelled && resumePos > 0 && resumePos < duration) {
      if (!this.canSeekLocally(resumePos)) {
        resumeState.started = false;
        return;
      }
      this.positionDiscontinuous = true;
      this.media.currentTime = resumePos - timelineOffset(this.appliedPlan);
      this.emit('resume', resumePos);
    }

    // 保留快照到应用结束，等待期间及 resume 监听中的新控制设置可同步到它。
    if (hasContinuity && this.pendingSourceContinuity === continuity) {
      this.media.playbackRate = this.currentPlan?.live ? 1 : continuity.rate;
      this.media.volume = continuity.volume;
      this.media.muted = continuity.muted;
      this.pendingSourceContinuity = null;
      if (continuity.shouldResume && this.wantsPlayback) await this.resumePlaybackForCurrentSource();
    }
  }
}
