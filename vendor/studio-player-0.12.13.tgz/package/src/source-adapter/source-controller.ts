/**
 * 来源适配控制器（SourceController）
 *
 * 职责：
 * 1. 持有当前播放计划与解析后的 Video.js Source
 * 2. 协调 SourceResolverPort（处理到期换源、心跳与故障回退）
 * 3. 对播放器上层屏蔽换源与重试细节
 * 4. 保证"来源只应用一次"：换源统一经 onSourceChange 通知，调用方不再重复应用
 */

import { isDeferredMediaSource, isPlaybackPlan, type PlayableInput, type PlaybackPlan } from '../contracts/plan.js';
import type { AdaptedSourceResult, DeliveryCarrier, DeliveryTarget } from '../contracts/delivery.js';
import type { SourceResolverPort, ResolveReason, SourcePreparationContext } from '../contracts/resolver.js';
import { adaptPlayableToSource } from './plan-to-source.js';
import { PlaybackTimeoutError, type PlaybackDiagnostic } from '../contracts/diagnostics.js';
import { playbackAbortError, timeoutMilliseconds, waitWithSignal } from '../reliability.js';
import type { MediaProcessingSession } from '../contracts/media-processing.js';

export interface SourceChangeCallback {
  (newSource: DeliveryTarget, result: AdaptedSourceResult): void;
}

export interface SourceControllerOptions {
  /** 动态取址与转码心跳端口 */
  resolver?: SourceResolverPort;
  /** 周期检查链接过期的间隔（毫秒）。默认 30 000；设为 0 关闭自动刷新 */
  expiryCheckIntervalMs?: number;
  /** 判定"临近过期"的安全缓冲（秒）。默认 60 */
  expiryBufferSeconds?: number;
  /** 同一资源允许尝试的备用源次数上限。默认 1；超过后不再回退，交由调用方进入失败终态 */
  maxFallbackAttempts?: number;
}

export class SourceController {
  private currentResult: AdaptedSourceResult | null = null;
  private resolverPort?: SourceResolverPort;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private expiryTimer: ReturnType<typeof setInterval> | null = null;
  /**
   * 正在进行的刷新。单个字段同时承担两件事：非 null 即"有刷新在飞"（防并发），
   * 而具体对象身份用于判定"完成的是不是最新那次刷新"（防止旧请求的收尾清掉新锁）。
   */
  private activeRefresh: AbortController | null = null;
  private currentTimeSeconds = 0;
  private inputGeneration = 0;
  private fallbackAttempts = 0;
  private readonly expiryCheckIntervalMs: number;
  private readonly expiryBufferSeconds: number;
  private readonly maxFallbackAttempts: number;
  private onSourceChangeCallbacks: Set<SourceChangeCallback> = new Set();
  private diagnosticCallbacks = new Set<(diagnostic: PlaybackDiagnostic) => void>();
  private preparing: MediaProcessingSession | null = null;
  private localClosures = new Set<Promise<void>>();
  private sourcePreparation: AbortController | null = null;

  public cancelSourcePreparation(): void {
    this.sourcePreparation?.abort(playbackAbortError());
    this.sourcePreparation = null;
  }

  /** 释放未被使用的计划；当前来源仍拥有的会话保持有效。 */
  public releaseUnusedPlan(plan: PlaybackPlan, retained?: PlaybackPlan): void {
    const current = this.getCurrentPlan();
    if (plan.processing?.session !== current?.processing?.session && plan.processing?.session !== retained?.processing?.session) this.releaseLocal(plan.processing?.session);
    if (plan.processing?.sessionEndpoint !== current?.processing?.sessionEndpoint && plan.processing?.sessionEndpoint !== retained?.processing?.sessionEndpoint) this.closeSession(plan.processing?.sessionEndpoint);
  }

  private async preparePlan(resourceId: string, operation: (signal: AbortSignal) => Promise<PlaybackPlan> | PlaybackPlan, timeout?: number): Promise<PlaybackPlan> {
    this.cancelSourcePreparation();
    const controller = new AbortController();
    this.sourcePreparation = controller;
    const ms = timeoutMilliseconds(timeout);
    const timer = ms ? setTimeout(() => controller.abort(new PlaybackTimeoutError('resolve', ms / 1000)), ms) : null;
    try {
      const observed = Promise.resolve().then(() => { controller.signal.throwIfAborted(); return operation(controller.signal); }).then(plan => {
        if (controller.signal.aborted) { this.releaseUnusedPlan(plan); throw controller.signal.reason; }
        try {
          if (plan.resourceId !== resourceId) throw new TypeError('Prepared source must retain resourceId');
          adaptPlayableToSource(plan);
          return plan;
        } catch (error) { this.releaseUnusedPlan(plan); throw error; }
      });
      return await waitWithSignal(observed, controller.signal);
    } finally {
      if (timer) clearTimeout(timer);
      if (this.sourcePreparation === controller) this.sourcePreparation = null;
    }
  }

  public async prepareInput(input: PlayableInput, restart = false): Promise<PlayableInput> {
    let prepared: PlayableInput = input;
    if (isDeferredMediaSource(input)) {
      if (!input.resourceId.trim()) throw new TypeError('Deferred source requires a stable resourceId');
      prepared = await this.preparePlan(input.resourceId, signal => input.prepare({ signal, restart }), input.resolveTimeoutSeconds);
    }
    if (!restart || !isPlaybackPlan(prepared) || !((prepared.timeline?.offsetSeconds ?? 0) > 0)) return prepared;
    const plan = prepared;
    try {
      if (!this.resolverPort?.prepareSource) throw new Error('Restarting an offset delivery requires source preparation');
      const replacement = await this.preparePlan(plan.resourceId, signal => this.resolverPort!.prepareSource!(plan.resourceId, plan, {signal,reason:'seek',positionSeconds:0,paused:true}), plan.timeouts?.resolve);
      if ((replacement.timeline?.offsetSeconds ?? 0) > 0) { this.releaseUnusedPlan(replacement, plan); throw new Error('Restart preparation must include the beginning of the original timeline'); }
      this.releaseUnusedPlan(plan,replacement);return replacement;
    } catch (error) {this.releaseUnusedPlan(plan);throw error;}
  }

  public get canPrepareSource(): boolean { return Boolean(this.getCurrentPlan() && this.resolverPort?.prepareSource); }

  public async prepareReplacement(context: Omit<SourcePreparationContext, 'signal'>): Promise<PlaybackPlan> {
    const plan = this.getCurrentPlan();
    if (!plan || !this.resolverPort?.prepareSource) throw new Error('Source preparation is unavailable');
    this.cancelRefresh();
    return this.preparePlan(plan.resourceId, signal => this.resolverPort!.prepareSource!(plan.resourceId, plan, { ...context, signal }), plan.timeouts?.resolve);
  }

  public get canRecover(): boolean { return Boolean(this.resolverPort?.recoverSource) && !this.isFallbackExhausted(); }

  public async recover(error: unknown, positionSeconds: number, paused: boolean): Promise<PlaybackPlan | null> {
    const plan = this.getCurrentPlan();
    if (!plan || !this.canRecover) return null;
    this.cancelRefresh();
    this.fallbackAttempts++;
    try {
      return await this.preparePlan(plan.resourceId, async signal => {
        const next = await this.resolverPort!.recoverSource!(plan.resourceId, plan, { signal, error, positionSeconds, paused });
        if (!next) throw new Error('No recovery source');
        return next;
      }, plan.timeouts?.resolve);
    } catch (error) { if ((error as Error)?.name === 'AbortError') throw error; return null; }
  }

  private releaseLocal(session?: MediaProcessingSession): void {
    if (!session) return;
    void session.ready.catch(() => {});
    const task = Promise.resolve().then(() => session.release());
    this.localClosures.add(task);
    // Keep cleanup failures observable through flushProcessing, without unhandled rejections.
    void task.catch(() => {});
  }

  private cancelPreparation(): void {
    const session = this.preparing; this.preparing = null;
    if (session) this.releaseLocal(session);
  }

  /** Register explicit preparation against the currently loaded resource. */
  public async prepareProcessing(session: MediaProcessingSession): Promise<PlaybackPlan> {
    if (!this.currentResult || session.resourceId !== this.currentResult.resourceId) {
      this.releaseLocal(session); throw new TypeError('Processing replacement must retain the current resourceId');
    }
    this.cancelPreparation(); this.preparing = session;
    const generation = this.inputGeneration;
    try {
      const plan = await session.ready;
      if (this.preparing !== session || generation !== this.inputGeneration) throw playbackAbortError();
      if (plan.resourceId !== session.resourceId || plan.processing?.session !== session) {
        throw new TypeError('Processing plan must retain its session ownership');
      }
      this.preparing = null; return plan;
    } catch (error) {
      if (this.preparing === session) { this.preparing = null; this.releaseLocal(session); }
      throw error;
    }
  }

  /** Await local processing cleanup; remote endpoint notifications remain best effort. */
  public async flushProcessing(): Promise<void> {
    while (this.localClosures.size) {
      const tasks = [...this.localClosures];
      const results = await Promise.allSettled(tasks);
      for (const task of tasks) this.localClosures.delete(task);
      const failure = results.find(result => result.status === 'rejected');
      if (failure?.status === 'rejected') throw failure.reason;
    }
  }

  public onDiagnostic(callback: (diagnostic: PlaybackDiagnostic) => void): () => void {
    this.diagnosticCallbacks.add(callback);
    return () => this.diagnosticCallbacks.delete(callback);
  }

  private diagnose(value: Omit<PlaybackDiagnostic, 'timestamp'>): void {
    const diagnostic = Object.freeze({ ...value, timestamp: Date.now() });
    for (const callback of this.diagnosticCallbacks) {
      try { callback(diagnostic); } catch { /* 诊断订阅不影响播放。 */ }
    }
  }

  /** 取消仍在进行的解析；保留当前来源，迟到会话仍会释放。 */
  public cancelRefresh(): void {
    const active = this.activeRefresh;
    this.activeRefresh = null;
    active?.abort(playbackAbortError());
  }

  constructor(options: SourceResolverPort | SourceControllerOptions = {}) {
    // 兼容旧签名：直接传入 resolver 端口
    const normalized: SourceControllerOptions = (options as SourceResolverPort)?.resolveUrl
      || (options as SourceResolverPort)?.prepareSource
      || (options as SourceResolverPort)?.recoverSource
      || (options as SourceResolverPort)?.onSessionHeartbeat
      || (options as SourceResolverPort)?.onSessionClose
      ? { resolver: options as SourceResolverPort }
      : (options as SourceControllerOptions);

    this.resolverPort = normalized.resolver;
    this.expiryCheckIntervalMs = normalized.expiryCheckIntervalMs ?? 30000;
    this.expiryBufferSeconds = normalized.expiryBufferSeconds ?? 60;
    this.maxFallbackAttempts = normalized.maxFallbackAttempts ?? 1;
  }

  /**
   * 加载新的媒体输入
   */
  public loadInput(input: PlayableInput): AdaptedSourceResult {
    // 公开加载代表一个新的播放会话。旧的过期刷新即使稍后返回，也会被
    // inputGeneration 丢弃；新的会话不应继承旧会话的刷新锁和回退预算。
    // 置空刷新锁同时让旧请求的收尾无法清掉后续新请求的锁。
    this.cancelRefresh();
    this.cancelPreparation();
    return this.loadInputInternal(input, false);
  }

  /** 同资源的手动交付切换；较早的异步刷新失效，保留资源的回退预算。 */
  public validateReplacement(input: PlayableInput): void {
    if (!this.currentResult || adaptPlayableToSource(input).resourceId !== this.currentResult.resourceId) {
      throw new TypeError('Source replacement must retain the current resourceId; use load for another resource');
    }
  }

  public replaceInput(input: PlayableInput): AdaptedSourceResult {
    this.validateReplacement(input);
    this.cancelRefresh();
    this.cancelPreparation();
    const result = this.loadInputInternal(input, true);
    this.notifySourceChange(result);
    return result;
  }

  /**
   * 执行加载。内部换源需要保留同一资源的回退预算与播放心跳时间，
   * 公开 loadInput 则必须重置它们。
   */
  private loadInputInternal(input: PlayableInput, preserveFallbackAttempts: boolean): AdaptedSourceResult {
    const previousResult = this.currentResult;
    const previousLocalSession = previousResult?.originalPlan?.processing?.session;
    const previousSessionEndpoint = previousResult?.originalPlan?.processing?.sessionEndpoint;
    const previousResourceId = previousResult?.resourceId;
    this.stopHeartbeat();
    const result = adaptPlayableToSource(input);
    timeoutMilliseconds(result.originalPlan?.timeouts?.resolve);

    const nextSessionEndpoint = result.originalPlan?.processing?.sessionEndpoint;
    if (previousLocalSession && previousLocalSession !== result.originalPlan?.processing?.session) this.releaseLocal(previousLocalSession);
    if (previousSessionEndpoint && previousSessionEndpoint !== nextSessionEndpoint) {
      this.closeSession(previousSessionEndpoint);
    }

    this.inputGeneration += 1;
    if (!preserveFallbackAttempts || previousResourceId !== result.resourceId) {
      this.currentTimeSeconds = 0;
      this.fallbackAttempts = 0;
    }
    this.currentResult = result;
    this.startHeartbeatIfNeeded();
    this.startExpiryWatchIfNeeded();
    return result;
  }

  /**
   * 获取当前适配后的中立交付目标
   */
  public getCurrentSource(): DeliveryTarget | null {
    return this.currentResult?.source ?? null;
  }

  /**
   * 获取当前媒体资源 ID
   */
  public getCurrentResourceId(): string | null {
    return this.currentResult?.resourceId ?? null;
  }

  /**
   * 获取当前完整计划对象（若有）
   */
  public getCurrentPlan(): PlaybackPlan | null {
    return this.currentResult?.originalPlan ?? null;
  }

  public getCurrentMetadata(): Readonly<Record<string, unknown>> | null {
    return this.currentResult?.originalPlan?.metadata ?? this.currentResult?.metadata ?? null;
  }

  /**
   * 当前来源的承载方式；用于宿主选择媒体元素
   */
  public carrier(): DeliveryCarrier {
    return this.currentResult?.carrier ?? 'native';
  }

  /** 是否已达到备用源尝试上限（达到后不应再回退） */
  public isFallbackExhausted(): boolean {
    return this.fallbackAttempts >= this.maxFallbackAttempts;
  }

  /** 当前是否还有可尝试的备用源 */
  public canFallback(): boolean {
    const currentResult = this.currentResult;
    const plan = currentResult?.originalPlan;
    if (!plan) return false;
    if (this.isFallbackExhausted()) return false;
    return Boolean(plan.fallback?.playUrl ?? currentResult?.fallbackUrl);
  }

  /**
   * 检查当前链接是否已过期或即将过期（默认预留 60 秒安全缓冲）
   */
  public isNearExpiry(bufferSeconds: number = this.expiryBufferSeconds): boolean {
    if (!this.currentResult?.expiresAt) return false;
    const nowMs = Date.now();
    return (this.currentResult.expiresAt - nowMs) < bufferSeconds * 1000;
  }

  /**
   * 触发重新换源/刷新
   *
   * 换源结果通过 onSourceChange 通知，调用方不应再自行应用一次。
   */
  public async refreshSource(reason: ResolveReason): Promise<AdaptedSourceResult | null> {
    if (this.activeRefresh) return null;

    const initialResult = this.currentResult;
    const initialPlan = initialResult?.originalPlan;
    const resolverPort = this.resolverPort;
    if (!initialPlan || !resolverPort?.resolveUrl) {
      return null;
    }

    const lock = new AbortController();
    this.activeRefresh = lock;
    const generationAtStart = this.inputGeneration;
    const startedAt = Date.now();
    const duration = timeoutMilliseconds(initialPlan.timeouts?.resolve);
    const timer = duration ? setTimeout(() => lock.abort(new PlaybackTimeoutError('resolve', duration / 1000)), duration) : null;
    const stale = () => lock.signal.aborted || this.inputGeneration !== generationAtStart || this.currentResult !== initialResult;
    const releaseAbandoned = (refreshed: string | PlaybackPlan) => {
      const endpoint = typeof refreshed === 'string' ? undefined : refreshed.processing?.sessionEndpoint;
      if (endpoint !== initialPlan.processing?.sessionEndpoint && endpoint !== this.getCurrentPlan()?.processing?.sessionEndpoint) this.closeSession(endpoint);
      const local = typeof refreshed === 'string' ? undefined : refreshed.processing?.session;
      if (local !== initialPlan.processing?.session && local !== this.getCurrentPlan()?.processing?.session) this.releaseLocal(local);
    };
    this.diagnose({ code: 'resolve-start', reason });
    try {
      lock.signal.throwIfAborted();
      const operation = Promise.resolve(resolverPort.resolveUrl(initialPlan.resourceId, initialPlan, reason, { signal: lock.signal }));
      // resolver 可忽略 signal，仍须处理它迟到返回的新远端会话。
      let released = false;
      const observed = operation.then(value => {
        if (stale()) { releaseAbandoned(value); released = true; }
        return value;
      });
      const refreshed = await waitWithSignal(observed, lock.signal);

      // 旧请求不能覆盖已经切换到的新资源或新计划。
      if (stale()) {
        if (!released) releaseAbandoned(refreshed);
        return null;
      }

      let updatedInput: PlayableInput;

      if (typeof refreshed === 'string') {
        // 仅刷新了 URL 时无法证明新的签名有效期；不能沿用旧 expiresAt，
        // 否则下一轮检查会把同一个 URL 刷新请求无限重复下去。
        updatedInput = {
          ...initialPlan,
          playUrl: refreshed,
          expiresAt: undefined,
        };
      } else {
        // 返回了新的完整计划
        updatedInput = refreshed;
      }

      const newResult = this.loadInputInternal(updatedInput, true);
      this.notifySourceChange(newResult);
      this.diagnose({ code: 'resolve-success', reason, elapsedMs: Date.now() - startedAt });
      return newResult;
    } catch (err) {
      const error = lock.signal.aborted ? lock.signal.reason : err;
      this.diagnose({ code: error instanceof PlaybackTimeoutError ? 'resolve-timeout'
        : lock.signal.aborted ? 'resolve-cancelled' : 'resolve-failed', reason,
        elapsedMs: Date.now() - startedAt,
        ...(error instanceof PlaybackTimeoutError ? { timeoutSeconds: error.timeoutSeconds } : {}),
      });
      return null;
    } finally {
      if (timer !== null) clearTimeout(timer);
      // 只有仍是最新那次刷新时才释放锁；被新会话或新刷新取代时保持不动。
      if (this.activeRefresh === lock) {
        this.activeRefresh = null;
      }
    }
  }

  /**
   * 触发降级到备用源（fallback）
   *
   * 受 `maxFallbackAttempts` 限制：同一资源尝试超过上限后返回 null，调用方应进入失败终态。
   * 换源结果通过 onSourceChange 通知，调用方不应再自行应用一次。
   */
  public switchToFallback(): AdaptedSourceResult | null {
    const currentResult = this.currentResult;
    const currentPlan = currentResult?.originalPlan;
    const fallback = currentPlan?.fallback;
    const fallbackUrl = fallback?.playUrl ?? currentResult?.fallbackUrl;
    if (!currentPlan || !fallbackUrl) {
      return null;
    }

    if (this.fallbackAttempts >= this.maxFallbackAttempts) {
      console.warn(
        `[SourceController] Fallback attempt limit (${this.maxFallbackAttempts}) reached for resource:`,
        currentPlan.resourceId
      );
      return null;
    }
    this.fallbackAttempts += 1;
    this.cancelRefresh();

    const fallbackPlan: PlaybackPlan = {
      ...currentPlan,
      strategy: 'fallback',
      playUrl: fallbackUrl,
      transport: fallback?.transport ?? currentPlan.transport,
      mimeType: fallback?.mimeType ?? (fallback ? undefined : currentPlan.mimeType),
      expiresAt: fallback?.expiresAt ?? (fallback ? undefined : currentPlan.expiresAt),
      headers: fallback?.headers ?? (fallback ? undefined : currentPlan.headers),
      processing: fallback?.processing ?? (fallback ? undefined : currentPlan.processing),
      timeline: fallback ? fallback.timeline : currentPlan.timeline,
      fallbackUrl: undefined, // 已经处于 fallback 状态，不再循环回退
      fallback: undefined,
    };

    const newResult = this.loadInputInternal(fallbackPlan, true);
    this.notifySourceChange(newResult);
    return newResult;
  }

  /** 订阅播放源变更事件 */
  public onSourceChange(cb: SourceChangeCallback): () => void {
    this.onSourceChangeCallbacks.add(cb);
    return () => {
      this.onSourceChangeCallbacks.delete(cb);
    };
  }

  private notifySourceChange(result: AdaptedSourceResult) {
    for (const cb of this.onSourceChangeCallbacks) {
      try {
        cb(result.source, result);
      } catch (e) {
        console.error('[SourceController] Error in source change listener:', e);
      }
    }
  }

  /** 启动转码/流控会话心跳保活 */
  private startHeartbeatIfNeeded() {
    const sessionEndpoint = this.currentResult?.originalPlan?.processing?.sessionEndpoint;
    if (!sessionEndpoint || !this.resolverPort?.onSessionHeartbeat) {
      return;
    }

    // 每 15 秒上报一次会话保活
    this.heartbeatTimer = setInterval(() => {
      try {
        Promise.resolve(this.resolverPort?.onSessionHeartbeat?.(sessionEndpoint, this.currentTimeSeconds))
          .catch((error) => {
            console.warn('[SourceController] Session heartbeat failed:', error);
          });
      } catch (error) {
        console.warn('[SourceController] Session heartbeat failed:', error);
      }
    }, 15000);
  }

  /** 链接临近过期时自动换源（防止播放中途签名失效） */
  private startExpiryWatchIfNeeded() {
    this.stopExpiryWatch();
    if (this.expiryCheckIntervalMs <= 0) return;
    if (!this.currentResult?.expiresAt || !this.resolverPort?.resolveUrl) return;

    // 首次加载就已临近过期时不能等满一个检查周期，否则短签名 URL
    // 可能在第一次检查前已经失效。
    this.checkExpiry();
    this.expiryTimer = setInterval(() => this.checkExpiry(), this.expiryCheckIntervalMs);
  }

  private checkExpiry(): void {
    if (this.activeRefresh || this.sourcePreparation || !this.isNearExpiry()) return;
    void this.refreshSource('expired').catch((error) => {
      if (error?.name !== 'AbortError') {
        console.warn('[SourceController] Expiry refresh failed:', error);
      }
    });
  }

  /** 停止心跳 */
  private stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  /** 停止过期检查 */
  private stopExpiryWatch() {
    if (this.expiryTimer) {
      clearInterval(this.expiryTimer);
      this.expiryTimer = null;
    }
  }

  /** 更新当前播放时间，供转码会话心跳使用 */
  public updateCurrentTime(currentTimeSeconds: number): void {
    if (Number.isFinite(currentTimeSeconds) && currentTimeSeconds >= 0) {
      this.currentTimeSeconds = currentTimeSeconds;
    }
  }

  /** 请求释放远端会话，并吞并异步清理错误，避免产生未处理 rejection */
  private closeSession(sessionEndpoint?: string): void {
    if (!sessionEndpoint || !this.resolverPort?.onSessionClose) return;

    try {
      Promise.resolve(this.resolverPort.onSessionClose(sessionEndpoint)).catch((error) => {
        console.warn('[SourceController] Session close failed:', error);
      });
    } catch (error) {
      console.warn('[SourceController] Session close failed:', error);
    }
  }

  /** 释放当前来源与处理会话，保留订阅和配置以支持再次加载。 */
  public unload(): void {
    this.cancelSourcePreparation();
    this.inputGeneration += 1;
    this.stopHeartbeat();
    this.stopExpiryWatch();
    this.cancelRefresh();
    this.cancelPreparation();
    this.releaseLocal(this.currentResult?.originalPlan?.processing?.session);
    const sessionEndpoint = this.currentResult?.originalPlan?.processing?.sessionEndpoint;
    this.currentResult = null;
    this.currentTimeSeconds = 0;
    this.fallbackAttempts = 0;
    this.closeSession(sessionEndpoint);
  }

  /** 销毁释放 */
  public destroy() {
    this.unload();
    this.onSourceChangeCallbacks.clear();
    this.diagnosticCallbacks.clear();
  }
}
