import type {
  AudioDecodeTrack, BrowserMediaDescription, BrowserMediaSupport, MediaDecodeTrack,
  MediaSupportEvidence, MediaSupportReason,
} from '../contracts/media-support.js';
import { playbackAbortError, waitWithSignal } from '../reliability.js';

/** 可注入浏览器 API，测试和非 DOM 环境无需创建媒体元素。 */
export interface BrowserMediaSupportEnvironment {
  canPlayType?: (kind: 'video' | 'audio', contentType: string) => CanPlayTypeResult;
  decodingInfo?: (configuration: MediaDecodingConfiguration) => PromiseLike<MediaCapabilitiesDecodingInfo>;
  isTypeSupported?: (contentType: string) => boolean;
  /** Capability of the actual configured HLS adapter for the input segment container. */
  hlsAdapter?: (segmentMimeType: string | undefined) => boolean | undefined;
}

export interface BrowserMediaSupportOptions {
  signal?: AbortSignal;
  /** 每次评估总等待上限，默认 3000ms；必须为正且不超过 60000ms。 */
  timeoutMs?: number;
  /** 显式提供后不再回落到全局浏览器 API。 */
  environment?: BrowserMediaSupportEnvironment;
}

function browserEnvironment(): BrowserMediaSupportEnvironment {
  return {
    canPlayType: typeof document === 'undefined' ? undefined : (kind, type) => document.createElement(kind).canPlayType(type),
    decodingInfo: typeof navigator === 'undefined' || !navigator.mediaCapabilities?.decodingInfo
      ? undefined : configuration => navigator.mediaCapabilities.decodingInfo(configuration),
    isTypeSupported: typeof MediaSource === 'undefined' ? undefined : type => MediaSource.isTypeSupported(type),
  };
}

function validateTrack(track: MediaDecodeTrack | null | undefined, kind: 'video' | 'audio'): void {
  if (track == null) return;
  if (!new RegExp(`^${kind}/[a-zA-Z0-9.+-]+$`).test(track.mimeType)) throw new TypeError('Expected a track MIME without parameters');
  if (track.codec !== undefined && !/^[a-zA-Z0-9._-]+$/.test(track.codec)) throw new TypeError('Expected one codec identifier');
  const fields = kind === 'video' ? ['bitrate', 'width', 'height', 'framerate'] : ['bitrate', 'samplerate'];
  for (const key of fields) {
    const value = (track as unknown as Record<string, unknown>)[key];
    if (value !== undefined && (typeof value !== 'number' || !Number.isFinite(value) || value <= 0)) {
      throw new TypeError('Media parameters must be finite positive numbers');
    }
  }
  if (kind === 'audio' && (track as AudioDecodeTrack).channels !== undefined
    && !/^[1-9]\d*(?:\.\d+)?$/.test((track as AudioDecodeTrack).channels!)) throw new TypeError('Expected a channel count');
}

function contentType(track: MediaDecodeTrack): string {
  // 原始音频类型已经唯一指明编码；浏览器可拒绝这些类型上的冗余 codecs 参数。
  if ((track.mimeType === 'audio/flac' && track.codec?.toLowerCase() === 'flac')
    || (track.mimeType === 'audio/mpeg' && track.codec === 'mp3')) return track.mimeType;
  return `${track.mimeType}; codecs="${track.codec}"`;
}

function decodingConfiguration(description: BrowserMediaDescription): MediaDecodingConfiguration | undefined {
  // MediaCapabilities has no native HLS configuration; file results are not route evidence.
  if (description.route === 'native-hls') return;
  const { video, audio } = description;
  if (video === undefined || audio === undefined || (!video && !audio)) return;
  if (video && (!video.codec || !video.width || !video.height || !video.bitrate || !video.framerate)) return;
  if (audio && (!audio.codec || !audio.channels || !audio.bitrate || !audio.samplerate)) return;
  return {
    type: description.route === 'mse-hls' ? 'media-source' : 'file',
    ...(video ? { video: { contentType: contentType(video), width: video.width!, height: video.height!, bitrate: video.bitrate!, framerate: video.framerate! } } : {}),
    ...(audio ? { audio: { contentType: contentType(audio), channels: audio.channels!, bitrate: audio.bitrate!, samplerate: audio.samplerate! } } : {}),
  };
}

/**
 * Queries explicit container, selected tracks and route. Never loads or switches a backend.
 * HLS needs an explicit route; MSE additionally needs the actual adapter capability.
 */
export async function assessBrowserMedia(
  description: BrowserMediaDescription,
  options: BrowserMediaSupportOptions = {},
): Promise<BrowserMediaSupport> {
  const timeoutMs = options.timeoutMs ?? 3000;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 60_000) throw new TypeError('timeoutMs must be within (0, 60000]');
  if (options.signal?.aborted) throw playbackAbortError();
  // 固定输入，防止异步等待时宿主修改描述造成判断与证据不一致。
  const media = { ...description,
    container: description.container ? { ...description.container } : undefined,
    mseContainer: description.mseContainer ? { ...description.mseContainer } : undefined,
    video: description.video ? { ...description.video } : description.video,
    audio: description.audio ? { ...description.audio } : description.audio };
  validateTrack(media.video, 'video'); validateTrack(media.audio, 'audio');
  const evidence: MediaSupportEvidence[] = [];
  const checks: BrowserMediaSupport['checks'][number][] = [];
  const finish = (status: BrowserMediaSupport['status'], reason: MediaSupportReason,
    extras: Pick<BrowserMediaSupport, 'smooth' | 'powerEfficient'> = {}): BrowserMediaSupport => Object.freeze({
    status, reason, ...extras, evidence: Object.freeze(evidence.map(item => Object.freeze(item))),
    checks: Object.freeze(checks.map(item => Object.freeze(item))),
    suggestedPath: status === 'expected-supported' ? 'direct' : status === 'unsupported' ? 'compatible-source-or-explicit-host' : 'verify',
  });
  if (!['range', 'hls', 'dash', 'webrtc'].includes(media.transport)
    || media.route && !['file','native-hls','mse-hls'].includes(media.route)) throw new TypeError('Invalid media route');
  if (media.transport !== 'range' && (media.transport !== 'hls' || !media.route || media.route === 'file')) {
    checks.push({ target: 'path', status: 'unknown', reason: 'transport-not-assessed' });
    return finish('unknown', 'transport-not-assessed');
  }
  if (media.transport === 'range' && media.route && media.route !== 'file') throw new TypeError('HLS route needs HLS transport');
  if (media.video === null && media.audio === null) return finish('unsupported', 'no-tracks');
  const environment = options.environment ?? browserEnvironment();
  const mse = media.route === 'mse-hls';
  let pathStatus: BrowserMediaSupport['status'] = 'expected-supported';
  if (media.route === 'native-hls') {
    try {
      const value = environment.canPlayType?.('video', 'application/vnd.apple.mpegurl');
      pathStatus = value === 'probably' ? 'expected-supported' : value === '' ? 'unsupported' : 'unknown';
      evidence.push({ target: 'path', api: 'canPlayType', result: pathStatus === 'expected-supported' ? 'supported' : pathStatus });
    } catch { pathStatus = 'unknown'; evidence.push({ target: 'path', api: 'canPlayType', result: 'error' }); }
  } else if (mse) {
    try {
      const value = environment.hlsAdapter?.(media.container?.mimeType);
      pathStatus = value === true ? 'expected-supported' : value === false ? 'unsupported' : 'unknown';
      evidence.push({ target: 'path', api: 'hlsAdapter', result: pathStatus === 'expected-supported' ? 'supported' : pathStatus });
    } catch { pathStatus = 'unknown'; evidence.push({ target: 'path', api: 'hlsAdapter', result: 'error' }); }
    if (!media.mseContainer) pathStatus = 'unknown';
    else for (const kind of ['video','audio'] as const) {
      if (media[kind]) media[kind] = { ...media[kind], mimeType: `${kind}/${media.mseContainer.mimeType.split('/')[1]}` };
    }
  }
  checks.push({ target: 'path', status: pathStatus, reason: pathStatus === 'expected-supported' ? 'api-supported'
    : pathStatus === 'unsupported' ? 'api-unsupported' : 'path-not-configured' });
  let incomplete = media.video === undefined || media.audio === undefined;
  const queries: { target: 'video' | 'audio' | 'combined'; kind: 'video' | 'audio'; type: string }[] = [];
  for (const kind of ['video', 'audio'] as const) {
    const track = media[kind];
    if (!track) continue;
    if (!track.codec) { incomplete = true; continue; }
    queries.push({ target: kind, kind, type: contentType(track) });
  }
  // canPlayType 单轨成功不能证明容器内的音视频组合可用。
  const { video, audio } = media;
  const container = mse ? media.mseContainer : media.container;
  if (container) {
    if (!/^(video|audio)\/[a-zA-Z0-9.+-]+$/.test(container.mimeType)) throw new TypeError('Expected a container MIME without parameters');
    // Native HLS segment support has no generic browser API for MPEG-TS.
    if (media.route === 'native-hls') {
      evidence.push({ target: 'container', api: 'canPlayType', result: 'unknown' });
    } else if (!mse && environment.canPlayType) {
      try {
        const value = environment.canPlayType(video ? 'video' : 'audio', container.mimeType);
        evidence.push({ target: 'container', api: 'canPlayType', result: value === 'probably' ? 'supported' : value === '' ? 'unsupported' : 'unknown' });
      } catch { evidence.push({ target: 'container', api: 'canPlayType', result: 'error' }); }
    }
  }
  if (video?.codec && audio?.codec && video.mimeType.split('/')[1] === audio.mimeType.split('/')[1]) {
    queries.push({ target: 'combined', kind: 'video', type: `${video.mimeType}; codecs="${video.codec},${audio.codec}"` });
  }
  if (media.route !== 'native-hls' && (mse ? environment.isTypeSupported : environment.canPlayType)) {
    for (const query of queries) {
      try {
        const value = mse ? environment.isTypeSupported!(query.type) : environment.canPlayType!(query.kind, query.type);
        evidence.push({ target: query.target, api: mse ? 'isTypeSupported' : 'canPlayType', result: value === 'probably' || value === true ? 'supported' : value === '' || value === false ? 'unsupported' : 'unknown' });
      } catch { evidence.push({ target: query.target, api: mse ? 'isTypeSupported' : 'canPlayType', result: 'error' }); }
    }
  }
  const configuration = decodingConfiguration(media);
  let info: MediaCapabilitiesDecodingInfo | undefined;
  if (configuration && environment.decodingInfo) {
    const controller = new AbortController();
    const abort = () => controller.abort(playbackAbortError());
    options.signal?.addEventListener('abort', abort, { once: true });
    if (options.signal?.aborted) abort();
    const timedOut = Symbol('media-query-timeout');
    const timer = setTimeout(() => controller.abort(timedOut), timeoutMs);
    try {
      info = await waitWithSignal(Promise.resolve().then(() => {
        if (controller.signal.aborted) throw controller.signal.reason;
        return environment.decodingInfo!(configuration);
      }), controller.signal);
      evidence.push({ target: 'combined', api: 'decodingInfo', result: typeof info?.supported === 'boolean'
        ? info.supported ? 'supported' : 'unsupported' : 'error' });
    } catch {
      if (options.signal?.aborted) throw playbackAbortError();
      evidence.push({ target: 'combined', api: 'decodingInfo', result: controller.signal.reason === timedOut ? 'timeout' : 'error' });
    } finally {
      clearTimeout(timer); options.signal?.removeEventListener('abort', abort);
    }
  }
  if (options.signal?.aborted) throw playbackAbortError();
  const mc = evidence.find(item => item.api === 'decodingInfo');
  const native = evidence.filter(item => ['canPlayType','isTypeSupported'].includes(item.api) && !['container','path'].includes(item.target));
  const nativeUnsupported = native.some(item => item.result === 'unsupported');
  const nativeComplete = native.length > 0 && native.every(item => item.result === 'supported')
    && (!video || !audio || native.some(item => item.target === 'combined'));
  for (const kind of ['video','audio'] as const) {
    if (media[kind] === null) continue;
    const entry = native.find(item => item.target === kind);
    checks.push({ target: kind, status: entry?.result === 'supported' ? 'expected-supported' : entry?.result === 'unsupported' ? 'unsupported' : 'unknown',
      reason: !media[kind]?.codec ? 'metadata-incomplete' : entry?.result === 'supported' ? 'api-supported'
        : entry?.result === 'unsupported' ? 'api-unsupported' : entry?.result === 'error' ? 'api-error' : entry ? 'api-inconclusive' : 'api-unavailable' });
  }
  const containerEntry = evidence.find(item => item.target === 'container');
  const containerStatus = containerEntry?.result === 'unsupported' ? 'unsupported'
    : nativeComplete || mc?.result === 'supported' || containerEntry?.result === 'supported' ? 'expected-supported' : 'unknown';
  checks.push({ target: 'container', status: containerStatus, reason: containerStatus === 'unsupported' ? 'api-unsupported'
    : containerStatus === 'expected-supported' ? 'api-supported' : 'metadata-incomplete' });
  if (video && audio) {
    const combined = native.find(item => item.target === 'combined');
    checks.push({ target: 'combined', status: combined?.result === 'supported' || mc?.result === 'supported' ? 'expected-supported'
      : combined?.result === 'unsupported' || mc?.result === 'unsupported' ? 'unsupported' : 'unknown',
      reason: !combined && !mc ? 'metadata-incomplete' : combined?.result === 'error' || mc?.result === 'error' ? 'api-error'
        : combined?.result === 'supported' || mc?.result === 'supported' ? 'api-supported'
          : combined?.result === 'unsupported' || mc?.result === 'unsupported' ? 'api-unsupported' : 'api-inconclusive' });
  }
  if (pathStatus === 'unsupported' || containerStatus === 'unsupported') return finish('unsupported', 'api-unsupported');
  if ((mc?.result === 'supported' && nativeUnsupported) || (mc?.result === 'unsupported' && nativeComplete)) {
    return finish('unknown', 'api-conflict');
  }
  if (nativeUnsupported || mc?.result === 'unsupported') return finish('unsupported', 'api-unsupported');
  if (pathStatus === 'unknown') return finish('unknown', 'path-not-configured');
  if (incomplete) return finish('unknown', 'metadata-incomplete');
  if (media.route === 'native-hls') return finish('unknown', 'transport-not-assessed');
  if (mc?.result === 'supported') return finish('expected-supported', 'api-supported', {
    ...(typeof info?.smooth === 'boolean' ? { smooth: info.smooth } : {}),
    ...(typeof info?.powerEfficient === 'boolean' ? { powerEfficient: info.powerEfficient } : {}),
  });
  // 超时/异常保留未知，不能用部分 API 的成功掩盖本次未完成评估。
  if (mc?.result === 'timeout') return finish('unknown', 'query-timeout');
  if (evidence.some(item => item.result === 'error')) return finish('unknown', 'api-error');
  if (nativeComplete) return finish('expected-supported', 'api-supported');
  return finish('unknown', evidence.length ? 'api-inconclusive' : 'api-unavailable');
}
