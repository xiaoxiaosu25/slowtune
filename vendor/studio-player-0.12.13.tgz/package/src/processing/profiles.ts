import { MediaProcessingError, type MediaProcessingProfile } from '../contracts/media-processing.js';
import { normalizeFfprobeMedia } from '../source-adapter/probed-media.js';

export interface ProcessingPolicy {
  /** Explicit opt-in; only h264-ac3-to-aac is lossy. */
  allowLossyAudio?: boolean;
  /** AAC LC CBR, per channel; default 96000, allowed 64000..160000. */
  aacBitsPerChannel?: number;
  /** Exact stream indices explicitly approved for omission. All other streams must survive. */
  discardStreams?: readonly number[];
  discardChapters?: boolean;
  /** Allow a reported metadata loss after attempting preservation. Default rejects. */
  allowMetadataLoss?: boolean;
}
export interface ProcessingSelection { readonly video?: number; readonly audio?: number }
export interface ProcessingDegradation {
  readonly kind: 'stream' | 'chapters' | 'metadata' | 'technical-metadata';
  readonly streamIndex?: number;
  readonly fields?: readonly string[];
}
export interface PreparedProfile {
  readonly extension: 'mp4' | 'm4a';
  readonly mimeType: string;
  readonly mediaType: 'audio' | 'video';
  readonly streams: readonly any[];
  readonly args: readonly string[];
  readonly degradations: ProcessingDegradation[];
  readonly lossy: boolean;
  readonly lossless: boolean;
  readonly quality?: { readonly codec: 'aac'; readonly profile: 'LC'; readonly bitrate: number; readonly coder: 'twoloop' };
}
const technical = new Set(['encoder','duration','major_brand','minor_version','compatible_brands','vendor_id']);
const isTechnical = (key: string, value: string) => technical.has(key) || key === 'language' && value === 'und'
  || key === 'handler_name' && ['SoundHandler','VideoHandler'].includes(value);
const tags = (value: any): Record<string, string> => Object.fromEntries(Object.entries(value ?? {})
  .filter((entry): entry is [string,string] => typeof entry[1] === 'string').map(([key,value]) => [key.toLowerCase(), value]));
export function prepareProfile(profile: MediaProcessingProfile, raw: any, header: Uint8Array,
  selection: ProcessingSelection = {}, policy: ProcessingPolicy = {}): PreparedProfile {
  const mismatch = () => { throw new MediaProcessingError('profile-mismatch'); };
  if (!['h264-aac-mkv-to-mp4','alac-to-flac','h264-ac3-to-aac'].includes(profile)) mismatch();
  const media = normalizeFfprobeMedia(raw, false, { header, seekable: true });
  if (!media.tracksComplete || !media.container || !Array.isArray(raw.streams) || raw.streams.length > 64) mismatch();
  const rawStreams = raw.streams;
  const select = (kind: string, index: number | undefined) => index !== undefined
    ? rawStreams.find((stream: any) => stream.index === index && stream.codec_type === kind && !stream.disposition?.attached_pic)
    : rawStreams.find((stream: any) => stream.codec_type === kind && stream.disposition?.default && !stream.disposition?.attached_pic)
      ?? rawStreams.find((stream: any) => stream.codec_type === kind && !stream.disposition?.attached_pic);
  const audio = select('audio', selection.audio), video = select('video', selection.video);
  if (!audio || ![1,2].includes(audio.channels) || !Number.isInteger(Number(audio.sample_rate)) || Number(audio.sample_rate) <= 0) mismatch();
  const lossless = profile === 'alac-to-flac', lossy = profile === 'h264-ac3-to-aac';
  if (lossless) {
    if (video || selection.video !== undefined || !['mp4','mov'].includes(media.container!.kind)
      || audio.codec_name !== 'alac' || ![16,24].includes(Number(audio.bits_per_raw_sample))) mismatch();
  } else {
    const neutral = media.tracks.find(track => track.index === video?.index);
    if (!video || video.codec_name !== 'h264' || !neutral?.decoding?.codec
      || !['yuv420p','yuvj420p'].includes(video.pix_fmt)
      || ['smpte2084','arib-std-b67'].includes(video.color_transfer)) mismatch();
    if (lossy ? !['mp4','mov','matroska'].includes(media.container!.kind) || audio.codec_name !== 'ac3'
      : media.container!.kind !== 'matroska' || audio.codec_name !== 'aac'
        || media.tracks.find(track => track.index === audio.index)?.decoding?.codec !== 'mp4a.40.2') mismatch();
  }
  if (lossy && policy.allowLossyAudio !== true) throw new MediaProcessingError('lossy-not-allowed');
  const perChannel = policy.aacBitsPerChannel ?? 96000;
  if (!Number.isSafeInteger(perChannel) || perChannel < 64000 || perChannel > 160000) throw new MediaProcessingError('invalid-input');
  const discard = policy.discardStreams ?? [];
  if (!Array.isArray(discard) || discard.some(index => !Number.isSafeInteger(index) || !rawStreams.some((stream: any) => stream.index === index))
    || new Set(discard).size !== discard.length || discard.includes(audio.index) || (video && discard.includes(video.index))) throw new MediaProcessingError('invalid-input');
  // The selected audio is first/default; other compatible AAC tracks survive, without conversion.
  const streams: any[] = video && !lossless ? [video, audio] : [audio];
  const degradations: ProcessingDegradation[] = [];
  for (const stream of rawStreams) {
    if (streams.includes(stream)) continue;
    if (discard.includes(stream.index)) { degradations.push({ kind: 'stream', streamIndex: stream.index }); continue; }
    if (!lossless && stream.codec_type === 'audio' && stream.codec_name === 'aac'
      && media.tracks.find(track => track.index === stream.index)?.decoding?.codec === 'mp4a.40.2') streams.push(stream);
    else throw new MediaProcessingError('preservation-required');
  }
  if (raw.chapters?.length && policy.discardChapters) degradations.push({ kind: 'chapters' });
  const args = streams.flatMap(stream => ['-map', `0:${stream.index}`]);
  args.push('-map_metadata','0','-map_chapters',policy.discardChapters ? '-1' : '0');
  if (lossless) {
    args.push('-c:a','flac','-sample_fmt', Number(audio.bits_per_raw_sample) === 24 ? 's32' : 's16', '-compression_level','5');
  }
  else {
    args.push('-c','copy');
    if (lossy) args.push('-c:a:0','aac','-profile:a:0','aac_low','-aac_coder:a:0','twoloop','-b:a:0',String(perChannel * audio.channels),
      '-ar:a:0',String(audio.sample_rate), '-ac:a:0',String(audio.channels));
    for (const [index,stream] of streams.filter(stream => stream.codec_type === 'audio').entries()) {
      args.push(`-disposition:a:${index}`, index === 0 ? '+default' : '-default');
      const title = tags(stream.tags).title;
      if (title) args.push(`-metadata:s:a:${index}`,`handler_name=${title}`);
    }
  }
  // Indexed MP4/M4A also carries FLAC. Raw FLAC tail seeking failed in the verified Edge environment.
  args.push('-movflags','+faststart+use_metadata_tags','-f','mp4');
  for (const [streamIndex, value] of [[undefined, raw.format?.tags], ...streams.map(stream => [stream.index,stream.tags])] as [number | undefined,any][]) {
    const data = tags(value), fields = Object.keys(data).filter(key => isTechnical(key,data[key]));
    if (fields.length) degradations.push({ kind: 'technical-metadata', streamIndex, fields });
  }
  return { extension: lossless ? 'm4a' : 'mp4', mimeType: lossless ? 'audio/mp4' : 'video/mp4', mediaType: lossless ? 'audio' : 'video',
    streams, args, degradations, lossy, lossless,
    ...(lossy ? { quality: { codec: 'aac' as const, profile: 'LC' as const, bitrate: perChannel * audio.channels, coder: 'twoloop' as const } } : {}) };
}

export function verifyProfile(prepared: PreparedProfile, input: any, output: any, policy: ProcessingPolicy): void {
  const fail = () => { throw new MediaProcessingError('verification-failed'); };
  const outputStreams = output.streams?.filter((stream: any) => stream.codec_type === 'audio' || stream.codec_type === 'video');
  if (outputStreams?.length !== prepared.streams.length) fail();
  // A zero exit status can still represent a truncated demux. Allow only bounded
  // timestamp rounding / codec padding, never a percentage of a long recording.
  const seconds = (value: unknown): number | undefined => {
    if (typeof value !== 'string' && typeof value !== 'number' || value === '') return;
    const result = Number(value);
    return Number.isFinite(result) && result >= 0 ? result : undefined;
  };
  const duration = (stream: any): number | undefined => {
    const direct = seconds(stream.duration);
    if (direct !== undefined) return direct;
    const value = tags(stream.tags).duration;
    const match = /^(\d+):(\d{2}):(\d{2}(?:\.\d+)?)$/.exec(value ?? '');
    return match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3])
      - (seconds(stream.start_time) ?? 0) : undefined;
  };
  const verifyDuration = (source: number | undefined, target: number | undefined) => {
    if (source !== undefined && (target === undefined || Math.abs(source - target) > .1)) fail();
  };
  // Explicitly dropped streams may have defined the original container end.
  if (!policy.discardStreams?.length) verifyDuration(seconds(input.format?.duration), seconds(output.format?.duration));
  let audioOrdinal = 0;
  for (const [index,source] of prepared.streams.entries()) {
    const target = outputStreams[index];
    const convertedAudio = source.codec_type === 'audio' && (prepared.lossless || prepared.lossy && audioOrdinal === 0);
    if (source.codec_type === 'audio') audioOrdinal++;
    if (target.codec_type !== source.codec_type || target.codec_name !== (convertedAudio ? prepared.lossless ? 'flac' : 'aac' : source.codec_name)) fail();
    if (source.codec_type === 'video' && ['width','height','pix_fmt','profile','level'].some(key => target[key] !== source[key])) fail();
    if (source.codec_type === 'audio' && (target.channels !== source.channels || target.sample_rate !== source.sample_rate
      || source.channel_layout && target.channel_layout !== source.channel_layout
      || prepared.lossless && Number(target.bits_per_raw_sample) !== Number(source.bits_per_raw_sample))) fail();
    verifyDuration(duration(source), duration(target));
    const flags = Object.keys(source.disposition ?? {}).filter(key => key !== 'default'
      && Boolean(source.disposition[key]) && !target.disposition?.[key]);
    if (flags.length) {
      prepared.degradations.push({ kind: 'metadata', streamIndex: source.index, fields: flags.map(key => `disposition.${key}`) });
      if (!policy.allowMetadataLoss) throw new MediaProcessingError('preservation-required');
    }
    preserveTags(source.tags, target.tags, source.index);
  }
  preserveTags(input.format?.tags, output.format?.tags);
  if (!policy.discardChapters) {
    if ((input.chapters?.length ?? 0) !== (output.chapters?.length ?? 0)) fail();
    for (const [index,chapter] of (input.chapters ?? []).entries()) {
      const target = output.chapters[index];
      if (['start_time','end_time'].some(key => Math.abs(Number(chapter[key])-Number(target[key])) > .002)) fail();
      preserveTags(chapter.tags,target.tags);
    }
  }
  function preserveTags(source: any, target: any, streamIndex?: number) {
    const a = tags(source), b = tags(target);
    const missing = Object.keys(a).filter(key => !isTechnical(key,a[key]) && a[key] !== b[key]
      && !(key === 'title' && streamIndex !== undefined && a[key] === b.handler_name));
    if (!missing.length) return;
    prepared.degradations.push({ kind: 'metadata', streamIndex, fields: missing.filter(key => /^[\w -]{1,64}$/.test(key)) });
    if (!policy.allowMetadataLoss) throw new MediaProcessingError('preservation-required');
  }
}
