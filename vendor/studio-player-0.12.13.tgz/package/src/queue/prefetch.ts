import type { QueueController, QueueItem } from './index.js';
import type { StudioPlayer } from '../player.js';

export interface PrefetchLease { release(): void | Promise<void> }
export interface QueuePrefetchOptions {
  prepare(item: Readonly<QueueItem>, context: { readonly signal: AbortSignal }): Promise<PrefetchLease> | PrefetchLease;
  minimumBufferedSeconds?: number;
  onError?(error: unknown): void;
}

/** 产品预热接口；不创建第二个播放器，至多一个任务。 */
export function mountQueuePrefetch(player: StudioPlayer, queue: QueueController, options: QueuePrefetchOptions): { destroy(): void } {
  const minimum = options.minimumBufferedSeconds ?? 30;
  if (!Number.isFinite(minimum) || minimum < 0) throw new TypeError('Invalid prefetch buffer threshold');
  let disposed = false;
  type Job = { key: string; abort: AbortController; lease?: PrefetchLease };
  let active: Job | null = null;
  const release = (lease: PrefetchLease) => { void Promise.resolve().then(() => lease.release()).catch(error => options.onError?.(error)); };
  const cancel = () => { const previous = active; active = null; previous?.abort.abort(); if (previous?.lease) release(previous.lease); };
  const update = () => {
    const next = queue.peekNext();
    const key = player.currentResourceId && next ? `${player.currentResourceId}\0${next.id}` : null;
    if (active && active.key !== key) cancel();
    if (disposed || active || !key || !next || player.paused || player.failed || queue.snapshot.loading) return;
    const remaining = Math.max(0, player.duration - player.currentTime);
    const buffered = player.buffered.find(range => range.start <= player.currentTime && range.end >= player.currentTime);
    if (!buffered || buffered.end - player.currentTime < Math.min(minimum, remaining)) return;
    const job: Job = { key, abort: new AbortController() };
    active = job;
    void Promise.resolve().then(() => { job.abort.signal.throwIfAborted(); return options.prepare(next, { signal: job.abort.signal }); }).then(lease => {
      if (disposed || active !== job || job.abort.signal.aborted) release(lease);
      else job.lease = lease;
    }, error => { if (!job.abort.signal.aborted) options.onError?.(error); });
  };
  const cleanup = ['timeupdate', 'sourcechange', 'stop', 'detach'].map(event => player.on(event as 'timeupdate', update));
  queue.addEventListener('change', update);
  const destroy = () => { if (disposed) return; disposed = true; cancel(); cleanup.forEach(off => off()); queue.removeEventListener('change', update); player.off('destroy', destroy); queue.removeEventListener('destroy', destroy); };
  player.on('destroy', destroy); queue.addEventListener('destroy', destroy);
  update();
  return { destroy };
}
