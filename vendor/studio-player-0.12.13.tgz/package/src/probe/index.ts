import { MediaProbeError, type ProbedMedia } from '../contracts/media-probe.js';
import { normalizeFfprobeMedia } from '../source-adapter/probed-media.js';
import { createSeekableInput } from './seekable-input.js';

export interface LocalMediaProbeOptions {
  /** Host-provided absolute ffprobe path. The package does not distribute tools. */
  executable: string;
  /** Per-instance limit, default 2. Full capacity rejects immediately. */
  maxConcurrent?: number;
}
export interface LocalMediaProbeRequest {
  signal?: AbortSignal;
  /** Default 5000ms, including open/query; cleanup completes before return. */
  timeoutMs?: number;
  /** Actual source-read total, including repeated ranges. Default 8MiB, max 64MiB. */
  maxReadBytes?: number;
  /** Retained stdout/stderr limit. Exceeding it terminates the process. Default 1MiB. */
  maxOutputBytes?: number;
  /** Default seekable uses an ephemeral loopback Range endpoint; prefix is pipe-only. */
  readMode?: 'seekable' | 'prefix';
}
export interface LocalMediaProbeResult {
  readonly media: ProbedMedia;
  readonly bytesRead: number;
  /** All bytes read at least once; not an integrity guarantee. */
  readonly inputComplete: boolean;
  readonly readMode: 'seekable' | 'prefix';
  readonly readOperations: number;
  readonly ranges: readonly { readonly offset: number; readonly bytes: number }[];
  readonly outputBytes: number;
  readonly elapsedMs: number;
}
function limit(value: number | undefined, fallback: number, max: number): number {
  const number = value ?? fallback;
  if (!Number.isSafeInteger(number) || number <= 0 || number > max) throw new MediaProbeError('invalid-input');
  return number;
}
const builtin = (name: string) => import(/* @vite-ignore */ `node:${name}`);
function coversFile(ranges: readonly { offset: number; bytes: number }[], size: number): boolean {
  let end = 0;
  for (const range of [...ranges].sort((a, b) => a.offset - b.offset)) {
    if (range.offset > end) return false;
    end = Math.max(end, range.offset + range.bytes);
  }
  return end >= size;
}

export class LocalMediaProbe {
  private readonly pending = new Set<AbortController>();
  private readonly tasks = new Set<Promise<unknown>>();
  private readonly maximum: number;
  private readonly executable: string;
  private destroyed = false;
  constructor(options: LocalMediaProbeOptions) {
    this.maximum = limit(options.maxConcurrent, 2, 16); this.executable = options.executable;
  }
  get isDestroyed(): boolean { return this.destroyed; }
  /** Cancel active requests and wait for processes, sockets, and handles to close. */
  async stop(): Promise<void> {
    const tasks = [...this.tasks];
    for (const controller of this.pending) controller.abort(new MediaProbeError('cancelled'));
    await Promise.allSettled(tasks);
  }
  async destroy(): Promise<void> { this.destroyed = true; await this.stop(); }
  inspect(file: string, options: LocalMediaProbeRequest = {}): Promise<LocalMediaProbeResult> {
    const task = this.run(file, { ...options }); this.tasks.add(task);
    void task.then(() => this.tasks.delete(task), () => this.tasks.delete(task));
    return task;
  }
  private async run(file: string, options: LocalMediaProbeRequest): Promise<LocalMediaProbeResult> {
    const timeout = limit(options.timeoutMs, 5000, 60000);
    const budget = limit(options.maxReadBytes, 8 * 1024 * 1024, 64 * 1024 * 1024);
    const outputBudget = limit(options.maxOutputBytes, 1024 * 1024, 8 * 1024 * 1024);
    const readMode = options.readMode ?? 'seekable';
    if (!['prefix', 'seekable'].includes(readMode)) throw new MediaProbeError('invalid-input');
    if (this.destroyed || options.signal?.aborted) throw new MediaProbeError('cancelled');
    if (this.pending.size >= this.maximum) throw new MediaProbeError('busy');
    const started = performance.now(), controller = new AbortController();
    this.pending.add(controller);
    const abort = () => controller.abort(new MediaProbeError('cancelled'));
    options.signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(() => controller.abort(new MediaProbeError('timeout')), timeout);
    const check = () => { if (controller.signal.aborted) throw controller.signal.reason; };
    let handle: any, seekable: Awaited<ReturnType<typeof createSeekableInput>> | undefined;
    let stream: any, bytesRead = 0, outputBytes = 0, readOperations = 0;
    let ranges: { offset: number; bytes: number }[] = [];
    let header: Uint8Array | undefined;
    try {
      const [fs, path, cp, http, processModule] = await Promise.all([builtin('fs/promises'), builtin('path'), builtin('child_process'), builtin('http'), builtin('process')]);
      check();
      if (typeof file !== 'string' || !path.isAbsolute(file) || file.includes('\0') || /^[/\\]{2}/.test(file)
        || typeof this.executable !== 'string' || !path.isAbsolute(this.executable) || this.executable.includes('\0')) throw new MediaProbeError('invalid-input');
      handle = await fs.open(file, fs.constants.O_RDONLY | (fs.constants.O_NONBLOCK ?? 0)); check();
      const stat = await handle.stat(); check();
      if (!stat.isFile() || !Number.isSafeInteger(stat.size)) throw new MediaProbeError('invalid-input');
      if (!stat.size) throw new MediaProbeError('invalid-media');
      if (readMode === 'seekable') seekable = await createSeekableInput(http, handle, stat.size, budget,
        controller.signal, error => controller.abort(error));
      check();
      const json = await new Promise<unknown>((resolve, reject) => {
        let failure: MediaProbeError | undefined, stdout = '';
        const child = cp.spawn(this.executable, [
          '-v', 'error', '-protocol_whitelist', seekable ? 'http,tcp' : 'pipe',
          '-format_whitelist', 'mov,mp3,wav,flac,ogg,matroska,webm,mpegts',
          '-probesize', String(Math.max(32, budget)), '-analyzeduration', '1000000',
          '-show_entries', 'format=format_name,duration:format_tags=major_brand:stream=index,codec_type,codec_name,codec_tag_string,profile,level,pix_fmt,bits_per_raw_sample,extradata,width,height,avg_frame_rate,bit_rate,channels,sample_rate:stream_disposition=default,attached_pic',
          '-show_data', '-of', 'json', '-i', seekable?.url ?? 'pipe:0',
        ], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, shell: false,
          env: { ...processModule.env, http_proxy: '', HTTP_PROXY: '', https_proxy: '', HTTPS_PROXY: '', all_proxy: '', ALL_PROXY: '',
            no_proxy: '127.0.0.1', NO_PROXY: '127.0.0.1' } });
        const fail = (error: MediaProbeError) => {
          if (failure) return;
          failure = error; stream?.destroy(); child.stdin.destroy(); child.kill('SIGKILL');
        };
        const onAbort = () => fail(controller.signal.reason);
        controller.signal.addEventListener('abort', onAbort, { once: true });
        child.on('error', () => fail(new MediaProbeError('unavailable')));
        child.stdin.on('error', () => {}); // Tools can close pipe input early.
        const consume = (chunk: any, collect: boolean) => {
          outputBytes += chunk.byteLength;
          if (outputBytes > outputBudget) { controller.abort(new MediaProbeError('output-limit')); return; }
          if (collect && !failure) stdout += chunk.toString('utf8');
        };
        child.stdout.on('data', (chunk: any) => consume(chunk, true));
        child.stderr.on('data', (chunk: any) => consume(chunk, false));
        child.on('close', (code: number | null) => {
          stream?.destroy(); controller.signal.removeEventListener('abort', onAbort);
          if (failure) { reject(failure); return; }
          if (code !== 0) { reject(new MediaProbeError(stat.size <= budget ? 'invalid-media' : 'probe-limit')); return; }
          try { resolve(JSON.parse(stdout)); } catch { reject(new MediaProbeError('invalid-media')); }
        });
        if (!seekable) {
          stream = handle.createReadStream({ start: 0, end: Math.min(stat.size, budget) - 1, autoClose: false,
            highWaterMark: Math.min(budget, 32768) });
          stream.on('data', (chunk: any) => {
            if (!header) header = new Uint8Array(chunk.subarray(0, 4096));
            bytesRead += chunk.byteLength; readOperations++;
          });
          stream.on('error', () => fail(new MediaProbeError('read-failed')));
        }
        if (controller.signal.aborted) onAbort();
        else if (stream) stream.pipe(child.stdin);
        else child.stdin.end();
      });
      check();
      if (seekable) {
        await seekable.close();
        ({ bytesRead, ranges, readOperations, header } = seekable.snapshot()); seekable = undefined;
      } else ranges = [{ offset: 0, bytes: bytesRead }];
      const after = await fs.stat(file); check();
      if (after.dev !== stat.dev || after.ino !== stat.ino || after.size !== stat.size || after.mtimeMs !== stat.mtimeMs) throw new MediaProbeError('read-failed');
      const inputComplete = coversFile(ranges, stat.size);
      return Object.freeze({ media: normalizeFfprobeMedia(json, inputComplete, { seekable: readMode === 'seekable', header }), bytesRead,
        inputComplete, readMode, readOperations, ranges: Object.freeze(ranges.map(range => Object.freeze(range))),
        outputBytes, elapsedMs: performance.now() - started });
    } catch (error) {
      if (controller.signal.aborted) throw controller.signal.reason;
      if (error instanceof MediaProbeError) throw error;
      throw new MediaProbeError('read-failed');
    } finally {
      await seekable?.close(); stream?.destroy(); await handle?.close().catch(() => {});
      clearTimeout(timer); options.signal?.removeEventListener('abort', abort); this.pending.delete(controller);
    }
  }
}
