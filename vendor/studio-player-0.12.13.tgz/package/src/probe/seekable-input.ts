import { MediaProbeError } from '../contracts/media-probe.js';

/** Repeated ranges are charged too. No path, remote forwarding, or CORS. */
export async function createSeekableInput(http: any, handle: any, size: number, budget: number,
  signal: AbortSignal, fail: (error: MediaProbeError) => void,
  limits: { maxRequests?: number; maxOperations?: number } = {}) {
  let bytesRead = 0, operations = 0, requests = 0, closing = false;
  let header: Uint8Array | undefined;
  const ranges: { offset: number; bytes: number }[] = [];
  const sockets = new Set<any>(), readers = new Set<Promise<void>>();
  const token = globalThis.crypto.randomUUID();
  const server = http.createServer((request: any, response: any) => {
    if (closing || request.url !== `/${token}` || !['GET', 'HEAD'].includes(request.method)) {
      response.writeHead(404).end(); return;
    }
    if (++requests > (limits.maxRequests ?? 64)) {
      fail(new MediaProbeError('probe-limit')); response.destroy(); return;
    }
    const match = /^bytes=(\d+)-(\d*)$/.exec(request.headers.range ?? '');
    const start = match ? Number(match[1]) : 0;
    const end = match?.[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
    if ((request.headers.range && !match) || !Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start > end) {
      response.writeHead(416, { 'Content-Range': `bytes */${size}` }).end(); return;
    }
    response.writeHead(match ? 206 : 200, { 'Content-Type': 'application/octet-stream',
      'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Connection': 'close',
      ...(match ? { 'Content-Range': `bytes ${start}-${end}/${size}` } : {}) });
    if (request.method === 'HEAD') { response.end(); return; }
    const read = async () => {
      let offset = start;
      while (offset <= end && !response.destroyed && !closing && !signal.aborted) {
        if (bytesRead >= budget || ++operations > (limits.maxOperations ?? 2048)) { fail(new MediaProbeError('probe-limit')); return; }
        // Reserve synchronously across concurrent requests, refund a short read.
        const length = Math.min(32768, end - offset + 1, budget - bytesRead);
        bytesRead += length;
        const buffer = new Uint8Array(length);
        const result = await handle.read(buffer, 0, length, offset);
        bytesRead -= length - result.bytesRead;
        if (offset === 0 && !header) header = buffer.slice(0, Math.min(4096, result.bytesRead));
        if (!result.bytesRead) throw new MediaProbeError('read-failed');
        const previous = ranges.at(-1);
        if (previous && previous.offset + previous.bytes === offset) previous.bytes += result.bytesRead;
        else ranges.push({ offset, bytes: result.bytesRead });
        offset += result.bytesRead;
        if (response.destroyed || closing || signal.aborted) return;
        await new Promise<void>(resolve => {
          const done = () => { response.removeListener('close', done); resolve(); };
          response.once('close', done);
          response.write(buffer.subarray(0, result.bytesRead), done);
        });
      }
      if (!response.destroyed) response.end();
    };
    const pending = read().catch(() => { if (!closing && !signal.aborted) fail(new MediaProbeError('read-failed')); })
      .finally(() => { readers.delete(pending); response.destroy(); });
    readers.add(pending);
  });
  server.maxConnections = 4; server.maxHeadersCount = 16;
  server.on('connection', (socket: any) => { sockets.add(socket); socket.once('close', () => sockets.delete(socket)); });
  const stop = () => { closing = true; for (const socket of sockets) socket.destroy(); };
  signal.addEventListener('abort', stop, { once: true });
  try {
    await new Promise<void>((resolve, reject) => {
      server.once('error', reject);
      server.listen(0, '127.0.0.1', () => { server.removeListener('error', reject); resolve(); });
    });
    if (signal.aborted) throw signal.reason;
    return {
      url: `http://127.0.0.1:${server.address().port}/${token}`,
      snapshot: () => ({ bytesRead, header, readOperations: operations, ranges: ranges.map(range => Object.freeze({ ...range })) }),
      async close() {
        stop(); signal.removeEventListener('abort', stop);
        await new Promise<void>(resolve => server.close(() => resolve()));
        await Promise.allSettled([...readers]);
      },
    };
  } catch (error) {
    stop(); signal.removeEventListener('abort', stop);
    await new Promise<void>(resolve => server.close(() => resolve()));
    await Promise.allSettled([...readers]); throw error;
  }
}
