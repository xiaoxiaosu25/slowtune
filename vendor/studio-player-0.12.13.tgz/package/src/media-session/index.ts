import type { StudioPlayer } from '../player.js';
import type { QueueController } from '../queue/index.js';

export interface MediaSessionPort {
  metadata: MediaMetadata | null;
  playbackState: MediaSessionPlaybackState;
  setActionHandler(action: MediaSessionAction, handler: MediaSessionActionHandler | null): void;
  setPositionState?(state?: MediaPositionState): void;
}

export interface MediaSessionOptions {
  /** undefined 使用 navigator.mediaSession；null 明确禁用。 */
  session?: MediaSessionPort | null;
  queue?: QueueController;
  getMetadata?: () => MediaMetadataInit | null;
  createMetadata?: (metadata: MediaMetadataInit) => MediaMetadata | null;
}

// 系统媒体会话是一份宿主资源；每个注入端口只允许一个活动拥有者。
const owners = new WeakMap<MediaSessionPort, MediaSessionController>();

export class MediaSessionController extends EventTarget {
  private readonly session: MediaSessionPort | null;
  private readonly createMetadata: (metadata: MediaMetadataInit) => MediaMetadata | null;
  private queue: QueueController | undefined;
  private destroyed = false;
  private generation = 0;
  private readonly subscriptions: Array<() => void>;
  private readonly installed = new Set<MediaSessionAction>();
  private readonly onQueueChange = () => {
    if (this.active) {
      this.updateQueueActions();
      if (this.queue?.snapshot.loaded) { this.updateMetadata(); this.sync(); }
    }
  };
  private readonly onQueueDestroy = () => {
    this.queue?.removeEventListener('change', this.onQueueChange);
    this.queue?.removeEventListener('destroy', this.onQueueDestroy);
    this.queue = undefined;
    this.onQueueChange();
  };

  constructor(private readonly player: StudioPlayer, private readonly options: MediaSessionOptions = {}) {
    super();
    if (player.isDestroyed) throw new Error('Cannot add a media session to a destroyed player');
    this.session = options.session === undefined
      ? (typeof navigator === 'undefined' ? null : navigator.mediaSession ?? null) : options.session;
    this.createMetadata = options.createMetadata ?? (metadata =>
      typeof MediaMetadata === 'undefined' ? null : new MediaMetadata(metadata));
    this.setQueue(options.queue);
    this.subscriptions = [
      ...(['play', 'pause', 'ended', 'timeupdate', 'durationchange', 'seeked', 'ratechange', 'statechange', 'mediachange'] as const)
        .map(event => player.on(event, () => this.sync())),
      player.on('sourcechange', () => {
        this.updateMetadata();
        this.sync();
      }),
      player.on('loadstart', () => this.clearInfo()),
      player.on('stop', () => this.deactivate()),
      player.on('detach', () => this.deactivate()),
      player.on('destroy', () => this.destroy()),
    ];
  }

  get supported(): boolean {
    return this.session !== null && typeof this.session.setActionHandler === 'function';
  }

  get active(): boolean {
    return this.session !== null && owners.get(this.session) === this;
  }

  get supportedActions(): readonly MediaSessionAction[] {
    return [...this.installed];
  }

  /** 重新连接同一播放会话的队列，不重新接管系统控制或丢失当前媒体信息。 */
  setQueue(queue?: QueueController): void {
    if (this.destroyed) throw new Error('Media session has been destroyed');
    if (this.queue === queue) return;
    this.queue?.removeEventListener('change', this.onQueueChange);
    this.queue?.removeEventListener('destroy', this.onQueueDestroy);
    this.queue = queue;
    this.queue?.addEventListener('change', this.onQueueChange);
    this.queue?.addEventListener('destroy', this.onQueueDestroy);
    this.onQueueChange();
  }

  /** 活动实例由宿主显式选择；接管时释放同端口的前一个实例。 */
  activate(): boolean {
    if (this.destroyed) throw new Error('Media session has been destroyed');
    if (!this.supported || !this.session) return false;
    if (this.active) {
      this.updateMetadata();
      this.sync();
      return true;
    }
    owners.get(this.session)?.deactivate();
    owners.set(this.session, this);
    this.generation += 1;
    this.action('play', () => this.queue?.snapshot.current ? this.queue.play() : this.player.play());
    this.action('pause', () => this.player.pause());
    this.action('seekto', details => {
      if (Number.isFinite(details.seekTime)) this.player.seek(details.seekTime!);
    });
    this.action('seekbackward', details => this.player.seek(this.player.currentTime - (details.seekOffset ?? 10)));
    this.action('seekforward', details => this.player.seek(this.player.currentTime + (details.seekOffset ?? 10)));
    this.updateQueueActions();
    this.updateMetadata();
    this.sync();
    this.dispatchEvent(new Event('change'));
    return true;
  }

  deactivate(): void {
    if (!this.active || !this.session) return;
    this.generation += 1;
    for (const action of this.installed) {
      try { this.session.setActionHandler(action, null); } catch { /* 部分浏览器只支持部分动作 */ }
    }
    this.installed.clear();
    this.clearInfo();
    owners.delete(this.session);
    this.dispatchEvent(new Event('change'));
  }

  /** 宿主元数据变化时主动刷新；默认取当前计划标题/艺术家/专辑/封面。 */
  updateMetadata(): void {
    if (!this.active || !this.session) return;
    try {
      const data = this.options.getMetadata ? this.options.getMetadata() : this.defaultMetadata();
      this.session.metadata = data ? this.createMetadata(data) : null;
    } catch (error) {
      this.session.metadata = null;
      this.reportError(error);
    }
  }

  sync(): void {
    if (!this.active || !this.session) return;
    const available = Boolean(this.player.currentResourceId && !this.player.failed && this.player.state !== 'loading'
      && this.player.state !== 'idle' && this.player.state !== 'stopped');
    this.session.playbackState = available
      ? (this.player.paused || this.player.state === 'ended' ? 'paused' : 'playing')
      : 'none';
    const duration = this.player.duration;
    const position = this.player.currentTime;
    const playbackRate = this.player.playbackRate;
    try {
      if (available && Number.isFinite(duration) && duration > 0 && Number.isFinite(position)
        && Number.isFinite(playbackRate) && playbackRate > 0) {
        this.session.setPositionState?.({ duration, playbackRate, position: Math.min(duration, Math.max(0, position)) });
      } else {
        this.session.setPositionState?.();
      }
    } catch { /* 浏览器可缺少或拒绝位置同步；播放控制仍可用。 */ }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.deactivate();
    for (const unsubscribe of this.subscriptions) unsubscribe();
    this.queue?.removeEventListener('change', this.onQueueChange);
    this.queue?.removeEventListener('destroy', this.onQueueDestroy);
  }

  private updateQueueActions(): void {
    const queue = this.queue;
    this.action('previoustrack', queue?.snapshot.canPrevious ? () => {
      if (this.queue === queue) return queue.previous();
    } : null);
    this.action('nexttrack', queue?.snapshot.canNext ? () => {
      if (this.queue === queue) return queue.next();
    } : null);
  }

  private action(action: MediaSessionAction, run: ((details: MediaSessionActionDetails) => unknown) | null): void {
    if (!this.active || !this.session) return;
    const generation = this.generation;
    const isCurrent = () => this.active && this.generation === generation;
    try {
      this.session.setActionHandler(action, run ? details => {
        if (!isCurrent()) return;
        try {
          Promise.resolve(run(details)).then(
            () => { if (isCurrent()) this.sync(); },
            error => { if (isCurrent()) this.reportError(error); },
          );
        } catch (error) { if (isCurrent()) this.reportError(error); }
      } : null);
      if (run) this.installed.add(action);
      else this.installed.delete(action);
    } catch { this.installed.delete(action); }
  }

  private defaultMetadata(): MediaMetadataInit | null {
    if (!this.player.currentResourceId) return null;
    const data = this.player.currentMetadata ?? {};
    const queue = this.queue?.snapshot;
    const item = queue?.loaded ? queue.current : null;
    return {
      title: typeof data.title === 'string' ? data.title
        : typeof data.name === 'string' ? data.name : item?.title ?? this.player.currentResourceId,
      artist: typeof data.artist === 'string' ? data.artist : item?.artist ?? '',
      album: typeof data.album === 'string' ? data.album : item?.album ?? '',
      artwork: Array.isArray(data.artwork) ? data.artwork : item?.artwork ? [...item.artwork] : [],
    };
  }

  private clearInfo(): void {
    if (!this.active || !this.session) return;
    this.session.metadata = null;
    this.session.playbackState = 'none';
    try { this.session.setPositionState?.(); } catch { /* 可选能力 */ }
  }

  private reportError(error: unknown): void {
    if ((error as { name?: string })?.name !== 'AbortError') {
      this.dispatchEvent(new CustomEvent('error', { detail: error }));
    }
  }
}
