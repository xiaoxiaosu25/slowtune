import type { StudioPlayer } from '../player.js';

/** 消费者创建并注入的产品范围。无全局实例，不接管浏览器 MediaSession。 */
export class MainMediaCoordinator extends EventTarget {
  private participants = new Map<StudioPlayer, MainMediaController>();
  private current: MainMediaController | null = null;
  private disposed = false;
  get active(): MainMediaController | null { return this.current; }
  get size(): number { return this.participants.size; }
  get isDestroyed(): boolean { return this.disposed; }

  register(player: StudioPlayer): MainMediaController {
    if (this.disposed || player.isDestroyed) throw new Error('Cannot join a destroyed media scope or player');
    if (this.participants.has(player)) throw new Error('Player already belongs to this media scope');
    const participant = new MainMediaController(this, player);
    this.participants.set(player, participant);
    // 加入时已有声音的实例也必须立即遵守互斥。
    if (!player.paused || player.playbackRequested) participant.activate();
    return participant;
  }

  /** 请求者同步抢占；pause 取消旧队列与迟到 play，保留旧位置和睡眠。 */
  claim(participant: MainMediaController): boolean {
    if (this.disposed || this.participants.get(participant.player) !== participant || participant.isDestroyed) return false;
    if (this.current === participant) return true;
    const previous = this.current;
    this.current = participant;
    previous?.player.pause();
    // pause 回调可重入并产生更晚请求；不能把归属再写回本次请求者。
    if (this.current !== participant || participant.isDestroyed) return false;
    this.dispatchEvent(new Event('change'));
    return this.current === participant;
  }

  /** 释放不恢复之前的播放器。释放者必须先暂停，不能留下脱离协调的声音。 */
  release(participant: MainMediaController): void {
    if (this.current !== participant) return;
    this.current = null;
    participant.player.pause();
    this.dispatchEvent(new Event('change'));
  }

  unregister(participant: MainMediaController): void {
    if (this.participants.get(participant.player) !== participant) return;
    this.release(participant);
    this.participants.delete(participant.player);
  }

  destroy(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const participant of [...this.participants.values()]) participant.destroy();
    this.dispatchEvent(new Event('destroy'));
  }
}

/** 独立装配入口为 scope.register(player)；销毁仅解绑协调并暂停，不销毁借用的播放器。 */
export class MainMediaController {
  private disposed = false;
  private readonly subscriptions: Array<() => void>;
  constructor(private readonly scope: MainMediaCoordinator, public readonly player: StudioPlayer) {
    this.subscriptions = [
      player.on('playintent', () => { if (!this.activate()) player.pause(); }),
      player.on('pauseintent', () => scope.release(this)),
      player.on('pause', () => {
        if (player.state !== 'ended' && player.paused && !player.playbackRequested) scope.release(this);
      }),
      player.on('stop', () => scope.release(this)),
      player.on('detach', () => scope.release(this)),
      player.on('error', (_error, switched) => { if (!switched) scope.release(this); }),
      player.on('playerror', () => scope.release(this)),
      player.on('ended', () => {
        // 等自然接续/睡眠完成同步决策，装配顺序不影响下一集的抢占。
        queueMicrotask(() => { if (!this.disposed && player.state === 'ended' && !player.playbackRequested) scope.release(this); });
      }),
      player.on('destroy', () => this.destroy()),
    ];
  }
  get active(): boolean { return this.scope.active === this; }
  get isDestroyed(): boolean { return this.disposed; }
  activate(): boolean { return !this.disposed && this.scope.claim(this); }
  release(): void { this.scope.release(this); }
  destroy(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const unsubscribe of this.subscriptions) unsubscribe();
    this.scope.unregister(this);
  }
}
