# 第三方许可与发行材料：播放与本机处理

版本：v1.4 · 更新于 2026-10-05 · 状态：**许可提示已记录；发行材料与授权未确认**

本文件集中维护播放相关第三方组件的使用与分发提示，以及工具取得证据和发行材料草稿。接入、升级、更换工具构建或随产品提供组件前均须阅读；本文件不构成发行授权或法律意见，最终合规结论由发行方与其法律顾问确认。边界见 [`docs/player/03-后端与引擎边界.md`](../../docs/player/03-后端与引擎边界.md) 第 6 节与 [`docs/player/99-未决事项.md`](../../docs/player/99-未决事项.md) 的 P-16。

## 使用与分发提示

下表维护当前集成方式的许可提示，不作为完整依赖清单；实际版本由包及锁文件确定，全部直接与间接依赖仍须按最终交付物核查。默认浏览器组件及图标的许可已核对本机安装包随附文本；工具构建的取得与核验范围见下文。

正式版固定组合的上游清单、完整消费者锁文件及随附 LICENSE/NOTICE 摘要见[兼容证据](evidence/videojs-ga-2026-10-05.md)。本轮没有复制或修改上游核心、增加工具捆绑或改变既有工具发行边界；自托管产品仍需随最终资源提供其实际使用组件的材料。

| 组件 / 当前协议 | 使用与分发时注意 |
| --- | --- |
| Video.js v10、hls.js / Apache-2.0 | 允许商业使用和闭源集成；随发行提供许可证，保留适用版权与 NOTICE，修改文件按要求注明。依据：[Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0)。 |
| Lucide 图标 / ISC，部分源自 Feather 的图标为 MIT | 允许商业使用和闭源集成；保留实际使用图标对应的许可和版权声明。依据：[Lucide LICENSE](https://github.com/lucide-icons/lucide/blob/main/LICENSE)。 |
| P03 FFmpeg/ffprobe / LGPL-3.0-or-later | 当前以宿主提供的独立进程调用，不自动要求公开整个业务仓库。随发工具时，须履行受覆盖组件及修改的对应源码、许可和版权义务；改为库链接时还须满足重新链接/替换及调试修改的逆向工程等条件。依据：[LGPLv3](https://www.gnu.org/licences/lgpl.html)。 |
| 当前 mpv 验证构建 / GPL 路线 | 随发二进制须提供受覆盖组件的对应源码等材料。自有代码是否受到 GPL 组合要求影响须按真实通信与耦合审查，独立进程不构成豁免证明，见第 1、3、4 节。 |
| 已安装 PotPlayer/VLC 的外部调用 | 当前仅启动用户已有应用，不分发播放器本体；用户仍须遵守应用使用条款。捆绑、修改或自行提供下载时另核查实际发行条件；VLC 按实际构建的 GPL 等许可处理，PotPlayer 具体版本 EULA 与再分发许可尚未核验。依据：[VideoLAN legal](https://images.videolan.org/legal.html)，调用边界见[外部调用 README](../external-launcher/README.md)。 |

提供第三方对应源码不要求把整个产品仓库公开上传 GitHub；须让接收者依适用许可证取得与二进制匹配的源码及必要构建材料，包括受覆盖的依赖与修改，任意最新版上游链接不能替代这一义务。第三方组件许可证也不会自动成为平台自有代码的发行许可。

1. **核对实际构建**：下载现成包仍须核对其许可、配置与完整依赖。LGPL/GPL 是构建及授权差异；启用 GPL 组件会改变相应构建许可，FFmpeg 官方将 `--enable-nonfree` 形成的二进制列为不可再分发。换构建、增加编解码器、改用 DLL/libmpv 或增加下载分发渠道时重新核验，依据见第 6 节及[FFmpeg LICENSE](https://github.com/FFmpeg/FFmpeg/blob/ff48edd8b2/LICENSE.md)。
2. **落实发行材料**：按最终集成与发行方式准备许可/版权/NOTICE、对应源码与构建材料、修改说明和适用的替换/重新链接安排；产品协议不得限制开源组件许可证赋予的权利。当前工具未随包分发，完整静态依赖材料、主程序组合判断和最终分发方式仍未确认。
3. **单独确认专利与品牌**：开源许可不等于所有编解码标准专利许可；当前 AC-3 → AAC 实际使用 AAC 编码，复制 H.264 视频也不证明产品整体专利豁免。按具体编码配置、地区、发行/服务形态及已有供应商授权确认是否适用，不按格式名推导一律收费或免费。商标和格式认证另行确认，依据见[编解码授权调研](evidence/codec-upstream-research-2026-09-30.md)；本轮未取得产品商业发行或品牌认证结论。

## 1. 范围

播放后端材料覆盖 **mpv 的 Windows 64 位可执行产物**，由播放后端以**独立进程 + 本地 IPC** 方式调用。本包不复制 mpv 播放核心源码、不链接 `libmpv`、不修改其内部代码；当前按独立程序边界设计。是否构成单纯聚合仍需结合通信方式与耦合语义判断，不能仅凭进程隔离承诺业务源码不受组合分发义务影响，依据见 [GNU FAQ](https://www.gnu.org/licenses/gpl-faq.en.html#MereAggregation)。mpv 内含 FFmpeg 的材料仍属于该范围。独立 FFmpeg/ffprobe 的本机验证材料见第 6 节；它不作播放后端，也不是播放的必经步骤。**独立工具的产品分发目前不进入范围**，若将来随产品分发，须补齐对应发行材料。

## 2. 已验证的取得记录

| 项 | 值 |
| --- | --- |
| 来源 | shinchiro/mpv-winbuild-cmake 发布页，release `20260903` |
| 产物 | `mpv-x86_64-20260903-git-69e63f425a.7z`，33768341 字节 |
| 归档校验 | SHA256 `418DBFB5FEB851CBED33D6C05D8481BA71802621BFD6EFE8974522B28D42AC97` |
| 构建取得方式 | **直接取官方成品，未经过本地构建**，无构建命令 |
| 内含版本 | mpv `v0.41.0-1023-g69e63f425`（构建于 2026-09-03）；FFmpeg `N-126390-g9fc8c785e`；libplacebo `v7.371.0` |
| 文件清单 | 13 个文件，逐文件字节数与 SHA256 见工作区 `local/tools/PLAYER-001/mpv/acquisition.json` |
| 备注 | 该产物**不含**任何许可或版权文本文件 |

## 3. 许可事实（已核对的部分）

- mpv 整体按 **GPLv2 或更新版本**发布，许可证全文见 [mpv 的 `LICENSE.GPL`](https://github.com/mpv-player/mpv/blob/master/LICENSE.GPL)，版权与组件说明见 [mpv 的 `Copyright`](https://github.com/mpv-player/mpv/blob/master/Copyright)。
- 该 Windows 构建**静态链接 FFmpeg 及其他依赖**，因此 mpv.exe 内含第三方组件；[构建脚本](https://github.com/shinchiro/mpv-winbuild-cmake)显示 FFmpeg 会连带拉入 x264、x265、libvpx、aom、dav1d、libbluray、libdvdnav 等 40 余个依赖。
- FFmpeg 的许可取决于构建配置：启用 `--enable-gpl` 类组件时，整个 FFmpeg 构建结果按 GPL 发布（见 [FFmpeg 许可说明](https://ffmpeg.org/legal.html)）。**实测本产物编译进了仅 GPL 构建才有的 `delogo` 与 `nnedi` 滤镜**，与该构建启用 GPL 组件一致。
- **尚未逐项核对**：mpv.exe 内每个组件的名称、版本、许可与可再分发条件。这是分发前的必办项，不能按项目名推断。
- 软件许可不替代编解码专利许可；具体编码、地区与发行方式尚未完成授权判断。官方来源及工程选型结论见[编解码调研](evidence/codec-upstream-research-2026-09-30.md)的“软件许可与编解码授权”。

## 4. 随分发时的义务（要点）

1. 随产品提供 mpv 的 GPL 与版权声明，并附**其余内含组件**各自的许可。
2. 按产物实际适用的 GPL 版本提供**完整对应源码及必要构建材料**，覆盖内含且需提供源码的依赖与修改，并落实许可证允许的源码获取方式。仅链接上游首页或不匹配版本不能替代对应源码；书面要约须符合适用版本的期限与受益人要求，GPLv2 沿用上游要约的例外只适用于非商业分发。
3. 在最终用户协议中说明 mpv 的 GPL 授权和用户权利；将其标为独立组件不能替代第 1 节的真实组合判断。
4. **不得**用加密壳或等效手段限制用户复制、修改、替换 mpv。
5. 使用版本明确、依赖可追溯、**不含不可再分发组件**的构建。

## 5. 当前状态

- **产品尚未随包分发任何第三方工具**，本文件为草稿。最终分发方式（随包 / 宿主安装 / 运行时获取）未定，见 P-16。
- 验证阶段该产物只存在于本机工作区 `local/tools/PLAYER-001/mpv/`，不进仓库、不对内外部发布。

## 6. P03 的独立 FFmpeg/ffprobe 验证构建

P03 使用宿主提供的独立进程工具；公共包只分发调用适配，不分发二进制、DLL 或解码源码。本批取得一个 LGPL 候选，不把此前 GPL 测试工具当作选定的 LGPL 发行工具。上游许可规则依据 [FFmpeg legal](https://ffmpeg.org/legal.html) 和 [对应源码许可说明](https://github.com/FFmpeg/FFmpeg/blob/ff48edd8b2/LICENSE.md)；Windows 产物来自 [BtbN 发布者](https://github.com/BtbN/FFmpeg-Builds/releases/tag/autobuild-2026-09-29-13-10)，FFmpeg 上游文档与该产物的身份分别核对。

| 核查项 | 本批事实 |
| --- | --- |
| 固定取得 | `autobuild-2026-09-29-13-10` 的 `ffmpeg-n8.1.3-6-gff48edd8b2-win64-lgpl-8.1.zip`；直接下载成品，未本地构建 |
| 归档 | 170611331 字节；SHA-256 `114ef46e66e34af204835e18246a8f1475d70d884c361749bb5a7759d4e1e8af`，与发布 API digest 一致 |
| FFmpeg | `n8.1.3-6-gff48edd8b2-20260929`；SHA-256 `b127279ac0eac64d4fed94283df8e69f2898ccbd03383146d6e803fa47fc0b99` |
| ffprobe | 同批版本；SHA-256 `e3a7cbe5e994d5e8f284f77ad38b5bdc674d5a57d4888956ab7eeb116635df40` |
| 许可配置 | 两个工具 `-L` 均声明 LGPLv3 or later；有 `--enable-version3`，未启用 GPL/nonfree，显式禁用 x264/x265/fdk-aac |
| 所需能力 | 实际枚举 AAC、FLAC 编码器和 H.264/AAC/ALAC/AC-3/FLAC 解码器；处理只用原生 AAC/FLAC 与视频流复制，无额外 GPL 编码器 |
| 原始材料 | 工作区 `local/tools/PLAYER-001/ffmpeg-p03/autobuild-2026-09-29-13-10/acquisition.json`，保留版本、完整 configuration、编码/解码列表、工具及许可文本校验；[核查脚本](../../labs/player/processing-check/tool-check.mjs)可复验 |

该构建使用静态链接并启用字体、网络、其他编解码及硬件相关依赖；[发布者构建说明](https://github.com/BtbN/FFmpeg-Builds)将 lgpl 变体定义为排除 GPL-only 依赖。核查了实际配置及本轮所需的原生编解码许可归属，但**未逐项取得所有静态依赖的精确版本、版权/许可文本与对应源码**；发布者的 LGPL 分类不能替代这一发行核查。脚本仓库许可不自动成为二进制的许可。本批只作受控本机验证；最小产品发行构建、静态依赖材料和分发方式继续未确认。

软件许可、编解码专利及商标/认证分别判断。复制 H.264 视频和使用 AAC/AC-3 解码或编码不据此推导专利豁免；适用地区、使用方式和商业发行授权尚未确定。FFmpeg 商标与任何格式认证也没有在本轮申请或取得。不购买、签约、捆绑或发布工具；真实处理及播放结果只证明本批工程行为，见[P03 证据](evidence/media-processing-p03-2026-09-30.md)。
