/**
 * 播放计划到中立交付描述的转换逻辑
 *
 * 约束来源：
 * - 计划结构见 `contracts/plan.ts` 的 `PlaybackPlan`；交付描述见 `contracts/delivery.ts`
 * - HLS 要求无扩展名或带签名地址显式提供 MIME 类型
 *
 * 本模块只做中立推导与结果组装：HLS 判定与 MIME 表归
 * `backends/videojs/source.ts`，Video.js 描述组装（`toVideojsSource`）、等价来源
 * 判定（`isSameVideojsSource`）与 `VideojsSourceDescription` 定义也在那里。
 */

import {
  type PlayableInput,
  type PlaybackPlan,
  type SimpleMediaSource,
  isPlaybackPlan,
  isSimpleMediaSource
} from '../contracts/plan.js';
import { isDeferredMediaSource } from '../contracts/plan.js';
import { validateTimeline } from './timeline.js';
import type { AdaptedSourceResult, DeliveryTarget } from '../contracts/delivery.js';
import { HLS_MIME_TYPE, HLS_MIME_ALIASES, isHlsIndicator, carrierOf } from '../backends/videojs/source.js';

/**
 * 依据 URL 或传输协议推导标准的 MIME 类型
 * 避免因签名参数扰乱扩展名导致播放器走错解码器
 */
export function inferMediaMimeType(url: string, transport?: string, declaredMime?: string): string | undefined {
  if (declaredMime && declaredMime.trim().length > 0) {
    const normalized = declaredMime.split(';', 1)[0].trim().toLowerCase();
    return HLS_MIME_ALIASES.has(normalized) ? HLS_MIME_TYPE : declaredMime.trim();
  }

  const cleanUrl = url.split('?')[0].toLowerCase();

  // HLS 分片清单特征
  if (transport === 'hls' || cleanUrl.endsWith('.m3u8')) {
    return HLS_MIME_TYPE;
  }

  // 常见音视频格式
  if (cleanUrl.endsWith('.mp4') || cleanUrl.endsWith('.m4v')) {
    return 'video/mp4';
  }
  if (cleanUrl.endsWith('.webm')) {
    return 'video/webm';
  }
  if (cleanUrl.endsWith('.mov')) {
    return 'video/quicktime';
  }
  if (cleanUrl.endsWith('.mkv')) {
    return 'video/x-matroska';
  }
  if (cleanUrl.endsWith('.mp3')) {
    return 'audio/mpeg';
  }
  if (cleanUrl.endsWith('.wav')) {
    return 'audio/wav';
  }
  if (cleanUrl.endsWith('.aac') || cleanUrl.endsWith('.m4a')) {
    return 'audio/mp4';
  }
  if (cleanUrl.endsWith('.flac')) {
    return 'audio/flac';
  }
  if (cleanUrl.endsWith('.ogg') || cleanUrl.endsWith('.oga')) {
    return 'audio/ogg';
  }

  return undefined;
}

/**
 * 构造中立交付目标。
 *
 * 规则（对应 P1-4）：
 * - 明确 HLS：`type` 为 HLS 类型、承载方式为 `managed`（走 hls.js 的 MSE 路径）。
 * - 其它且能推导出原生类型：承载方式为 `native`。
 * - 其它且类型未知（无扩展名、无声明）：仍标记 `native`；调用方应提供 `type`
 *   或改用原生媒体元素，因为上游会把未知类型回退成 HLS。
 */
function buildTarget(
  src: string,
  transport: string | undefined,
  mimeType: string | undefined,
  headers?: Record<string, string>
): DeliveryTarget {
  const isHls = isHlsIndicator(src, transport, mimeType);
  const target: DeliveryTarget = { src, type: isHls ? HLS_MIME_TYPE : mimeType };
  if (transport) target.transport = transport as DeliveryTarget['transport'];
  if (headers) target.headers = headers;
  return target;
}

/**
 * 将任意 PlayableInput 适配为中立的交付描述
 */
export function adaptPlayableToSource(input: PlayableInput): AdaptedSourceResult {
  if (isDeferredMediaSource(input)) throw new TypeError('Deferred media must be prepared by StudioPlayer.load');
  // 1. 输入为标准 PlaybackPlan
  if (isPlaybackPlan(input)) {
    validateTimeline(input);
    if (input.fallback) validateTimeline(input.fallback);
    let mimeType = inferMediaMimeType(input.playUrl, input.transport, input.mimeType);
    if (!mimeType) {
      if (input.metadata?.name) {
        mimeType = inferMediaMimeType(String(input.metadata.name), input.transport);
      }
      if (!mimeType && input.resourceId) {
        mimeType = inferMediaMimeType(input.resourceId, input.transport);
      }
      if (!mimeType && (input.playUrl.startsWith('blob:') || input.playUrl.startsWith('data:'))) {
        mimeType = input.mediaType === 'audio' ? 'audio/mpeg' : 'video/mp4';
      }
    }

    const source = buildTarget(input.playUrl, input.transport, mimeType, input.headers);

    return {
      source,
      carrier: carrierOf(source),
      resourceId: input.resourceId,
      originalPlan: input,
      fallbackUrl: input.fallbackUrl,
      expiresAt: input.expiresAt,
    };
  }

  // 2. 输入为 SimpleMediaSource
  if (isSimpleMediaSource(input)) {
    let mimeType = inferMediaMimeType(input.src, undefined, input.type);
    if (!mimeType && input.resourceId) {
      // 本地文件常以 blob:/data: 地址出现，类型只能从文件名提示推导
      mimeType = inferMediaMimeType(input.resourceId);
    }
    if (!mimeType && (input.src.startsWith('blob:') || input.src.startsWith('data:'))) {
      mimeType = 'video/mp4';
    }
    const source = buildTarget(input.src, undefined, mimeType, input.headers);

    return {
      source,
      carrier: carrierOf(source),
      resourceId: input.resourceId || input.src,
      ...(input.title ? { metadata: { title: input.title } } : {}),
    };
  }

  // 3. 输入为纯 URL 字符串
  const urlString = String(input);
  let mimeType = inferMediaMimeType(urlString);
  if (!mimeType && (urlString.startsWith('blob:') || urlString.startsWith('data:'))) {
    mimeType = 'video/mp4';
  }
  const source = buildTarget(urlString, undefined, mimeType);

  return {
    source,
    carrier: carrierOf(source),
    resourceId: urlString,
  };
}
