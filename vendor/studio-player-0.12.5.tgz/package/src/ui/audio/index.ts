import { createPlayerPreset, type PlayerPresetOptions, type PlayerFeatureOptions } from '../../presets/index.js';
import type { StudioPlayer } from '../../player.js';
import type { QueueController, QueueItem, QueueOptions, QueueRepeat } from '../../queue/index.js';
import type { SleepTimerController } from '../../sleep-timer/index.js';
import type { MediaSessionController } from '../../media-session/index.js';
import type { MainMediaController } from '../../main-media/index.js';
import { mountSleepTimerSettings } from '../sleep-settings.js';
import { audioIcon, audioTemplate } from './template.js';
import { createAudioView, type AudioView } from './audio-view.js';

export type AudioPlayerTheme = 'auto' | 'light' | 'dark';
export type AudioPlayerLayout = 'auto' | 'desktop' | 'mobile';
export type AudioPlayerView = 'bar' | 'expanded' | 'mini';
export interface AudioPlayerTokens {
  background?: string;
  surface?: string;
  'surface-alt'?: string;
  text?: string;
  'text-muted'?: string;
  border?: string;
  accent?: string;
  'on-accent'?: string;
  focus?: string;
  error?: string;
  radius?: string;
  font?: string;
  shadow?: string;
}
export interface AudioPlayerActionContext {
  readonly player: StudioPlayer;
  readonly queue: QueueController;
  readonly current: Readonly<QueueItem> | null;
}
export interface AudioPlayerAction {
  id: string;
  label: string;
  run(context: AudioPlayerActionContext): unknown | Promise<unknown>;
}
export interface AudioPlayerOptions extends Omit<PlayerPresetOptions, 'features' | 'nativeElementTag'> {
  /** 单条媒体同样以一个 QueueItem 传入，默认不加载或自动播放。 */
  items?: readonly QueueItem[];
  queue?: QueueOptions;
  features?: Omit<PlayerFeatureOptions, 'queue'>;
  theme?: AudioPlayerTheme;
  tokens?: AudioPlayerTokens;
  layout?: AudioPlayerLayout;
  view?: AudioPlayerView;
  /** 默认创建原生 audio；HLS 等可注入已经注册的 Video.js 媒体元素。套件拥有并释放它。 */
  createMediaElement?: (document: Document) => HTMLElement;
  onClose?: () => void;
  onError?: (error: unknown) => void;
  onRequestItems?: () => unknown | Promise<unknown>;
  /** 最多三个产品操作，只接宿主行为，不替换播放器规则。 */
  actions?: readonly AudioPlayerAction[];
}
export interface AudioPlayerUI {
  readonly element: HTMLElement;
  readonly player: StudioPlayer;
  readonly queue: QueueController;
  readonly sleepTimer: SleepTimerController | null;
  readonly mediaSession: MediaSessionController | null;
  readonly mainMedia: MainMediaController | null;
  readonly isClosed: boolean;
  readonly isDestroyed: boolean;
  setTheme(theme: AudioPlayerTheme): void;
  /** 替换本实例通过此 API 设置的变量；传 {} 回到继承/默认值。 */
  setTokens(tokens: AudioPlayerTokens): void;
  setLayout(layout: AudioPlayerLayout): void;
  setView(view: AudioPlayerView): void;
  /** 先停止保存，再替换列表；不会自动播放。 */
  setItems(items: readonly QueueItem[]): Promise<boolean>;
  open(): void;
  close(): Promise<void>;
  destroy(): void;
}

const tokenNames: readonly (keyof AudioPlayerTokens)[] = [
  'background', 'surface', 'surface-alt', 'text', 'text-muted', 'border', 'accent', 'on-accent', 'focus', 'error', 'radius', 'font', 'shadow',
];
const repeatLabels: Record<QueueRepeat, string> = { off: '循环关闭', all: '列表循环', one: '单曲循环' };
let registration: Promise<unknown> | undefined;
function registerElements(): Promise<unknown> {
  // DOM 仅在挂载时需要；无头入口不导入这些控件，UI 入口自身也可在 Node 中导入。
  return registration ??= Promise.all([
    import('@videojs/html/audio/player'), import('@videojs/html/ui/container'),
    import('@videojs/html/ui/time-slider'), import('@videojs/html/ui/slider-track'),
    import('@videojs/html/ui/slider-thumb'), import('@videojs/html/ui/slider-fill'), import('@videojs/html/ui/slider-buffer'),
    import('@videojs/html/ui/volume-slider'), import('@videojs/html/ui/mute-button'),
    import('@videojs/html/i18n/locales/zh/register'),
  ]).catch(error => { registration = undefined; throw error; });
}
function choice<T extends string>(value: T, values: readonly T[], label: string): void {
  if (!values.includes(value)) throw new TypeError(`Unknown audio ${label}: ${value}`);
}
function time(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const total = Math.floor(seconds);
  return total >= 3600 ? `${Math.floor(total / 3600)}:${String(Math.floor(total / 60) % 60).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
    : `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}
function metadata(item: Readonly<QueueItem> | null, actual?: Readonly<Record<string, unknown>> | null) {
  const source = item?.source;
  const data = actual ?? (source && typeof source === 'object' && 'metadata' in source ? source.metadata : {}) ?? {};
  const value = (key: string, fallback = '') => typeof data[key] === 'string' && data[key] ? data[key] as string : fallback;
  const artwork = Array.isArray(data.artwork) ? data.artwork : item?.artwork;
  return {
    title: value('title', value('name', item?.title || (source && typeof source === 'object' && 'title' in source ? source.title : '') || '未命名音频')),
    artist: value('artist', item?.artist ?? '未知艺术家'), album: value('album', item?.album ?? ''),
    cover: typeof artwork?.[0]?.src === 'string' ? artwork[0].src as string : '',
  };
}

/** 可直接挂载的音频套件，拥有一个 audio 预设；所有形态共享同一媒体、队列与睡眠状态。 */
export async function mountAudioPlayer(root: HTMLElement, options: AudioPlayerOptions = {}): Promise<AudioPlayerUI> {
  if (!root?.ownerDocument || typeof root.append !== 'function') throw new TypeError('An audio UI mount element is required');
  choice(options.theme ?? 'auto', ['auto', 'light', 'dark'], 'theme');
  choice(options.layout ?? 'auto', ['auto', 'desktop', 'mobile'], 'layout');
  choice(options.view ?? 'bar', ['bar', 'expanded', 'mini'], 'view');
  const actions = options.actions ?? [];
  if (actions.length > 3 || new Set(actions.map(action => action.id)).size !== actions.length
    || actions.some(action => !action.id || !action.label || typeof action.run !== 'function')) throw new TypeError('Provide at most three unique labeled audio actions');
  await registerElements();
  const { items = [], queue: queueOptions, features, theme: initialTheme = 'auto', tokens = {}, layout: initialLayout = 'auto', view: initialView,
    createMediaElement, onClose, onError, onRequestItems, actions: _actions, ...playerOptions } = options;
  const preset = createPlayerPreset('audio', { ...playerOptions, features: { ...features, queue: queueOptions ?? true } });
  const { player } = preset;
  const queue = preset.features.queue!;
  const { sleepTimer, mediaSession, mainMedia } = preset.features;
  const document = root.ownerDocument;
  const element = document.createElement('div');
  element.dataset.studioAudio = '';
  element.dataset.theme = initialTheme;
  const shadow = element.attachShadow({ mode: 'open' });
  shadow.innerHTML = audioTemplate;
  // 浮层核必须先建：面板内容来自模板里的 `<template data-panel=…>`，核把它们搬进容器后，
  // 下面的 `[data-queue-list]` / `[data-sleep-settings]` 这些查询才拿得到节点。
  const audioView: AudioView = createAudioView({ shadow });
  const get = <T extends Element = HTMLElement>(selector: string) => shadow.querySelector<T>(selector)!;
  const all = <T extends Element = HTMLElement>(selector: string) => [...shadow.querySelectorAll<T>(selector)];
  const surface = get('[data-surface]');
  const presentation = get('.root');
  const title = get('[data-title]');
  const subtitle = get('[data-subtitle]');
  const cover = get<HTMLImageElement>('[data-cover]');
  const playButton = get<HTMLButtonElement>('[data-action=play]');
  const slider = get<HTMLElement & { disabled: boolean }>('media-time-slider');
  const queueList = get('[data-queue-list]');
  const unsubscribes: Array<() => void> = [];
  const abort = new AbortController();
  let mediaAbort = new AbortController();
  let closeAbort: AbortController | null = null;
  let disposed = false;
  let closed = false;
  let buffering = false;
  let lastError: unknown = null;
  let commandRevision = 0;
  let layout = initialLayout;
  let view: AudioPlayerView = initialView ?? 'bar';
  let automaticView = initialView === undefined;
  let theme = initialTheme;
  let appliedTokens: (keyof AudioPlayerTokens)[] = [];
  let queueRenderKey = '';
  let historyRenderKey = '';
  let coverSource = '';
  let lastPlayIcon = '';
  let settings: ReturnType<typeof mountSleepTimerSettings> | null = null;
  let observer: ResizeObserver | null = null;
  let api: AudioPlayerUI;

  function assertLive() { if (disposed) throw new Error('Audio UI has been destroyed'); }
  function text(selector: string, value: string) {
    const target = get(selector);
    if (target.textContent !== value) target.textContent = value;
  }
  function report(error: unknown) {
    if (disposed || (error as Error)?.name === 'AbortError') return;
    if (lastError !== error) { lastError = error; onError?.(error); }
    render();
  }
  async function perform(action: () => unknown | Promise<unknown>): Promise<void> {
    const revision = ++commandRevision;
    lastError = null;
    try { await action(); }
    catch (error) { if (revision === commandRevision) report(error); }
    render();
  }
  function focusFallback() {
    if (disposed) return;
    if (closed) get<HTMLButtonElement>('[data-action=reopen]').focus();
    else if (!playButton.disabled) playButton.focus();
    else get<HTMLButtonElement>('[data-action=queue]').focus();
  }
  function setTab(name: string) {
    for (const tab of all<HTMLButtonElement>('[data-tab]')) {
      const selected = tab.dataset.tab === name;
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
    }
    for (const panel of all('[data-tab-panel]')) panel.hidden = panel.dataset.tabPanel !== name;
  }
  function applyLayout() {
    if (disposed) return;
    const resolved = layout === 'auto' ? (element.getBoundingClientRect().width < 740 ? 'mobile' : 'desktop') : layout;
    presentation.dataset.layout = resolved;
    if (automaticView) view = resolved === 'mobile' ? 'mini' : 'bar';
    presentation.dataset.view = view;
    get<HTMLSelectElement>('[data-setting=view]').value = view;
  }
  function setView(next: AudioPlayerView) {
    assertLive(); choice(next, ['bar', 'expanded', 'mini'], 'view');
    automaticView = false; view = next; applyLayout();
  }
  function setTheme(next: AudioPlayerTheme) {
    assertLive(); choice(next, ['auto', 'light', 'dark'], 'theme');
    theme = next; element.dataset.theme = next;
    get<HTMLSelectElement>('[data-setting=theme]').value = next;
  }
  function setTokens(next: AudioPlayerTokens) {
    assertLive();
    for (const [key, value] of Object.entries(next)) {
      if (!tokenNames.includes(key as keyof AudioPlayerTokens) || typeof value !== 'string') throw new TypeError(`Unknown or invalid audio token: ${key}`);
    }
    for (const key of appliedTokens) element.style.removeProperty(`--studio-audio-${key}`);
    appliedTokens = Object.keys(next) as (keyof AudioPlayerTokens)[];
    for (const key of appliedTokens) element.style.setProperty(`--studio-audio-${key}`, next[key]!);
  }
  function renderQueue() {
    const snapshot = queue.snapshot;
    const key = JSON.stringify([snapshot.items, snapshot.current?.id, snapshot.upNext]);
    if (key !== queueRenderKey) {
      queueRenderKey = key;
      const focused = shadow.activeElement as HTMLElement | null;
      const focusId = focused?.dataset.itemId;
      const focusAction = focused?.dataset.queueAction;
      const focusIndex = focused?.closest<HTMLElement>('.queue-row')?.dataset.index;
      const rows = snapshot.items.map((item, index) => {
        const data = metadata(item);
        const row = document.createElement('li');
        row.className = 'queue-row'; row.dataset.current = String(item.id === snapshot.current?.id); row.dataset.index = String(index);
        const choose = document.createElement('button');
        choose.type = 'button'; choose.className = 'queue-track'; choose.dataset.queueAction = 'select'; choose.dataset.itemId = item.id;
        choose.setAttribute('aria-label', `播放 ${data.title}`);
        if (item.id === snapshot.current?.id) choose.setAttribute('aria-current', 'true');
        const number = document.createElement('span'); number.className = 'queue-number';
        if (item.id === snapshot.current?.id) {
          number.innerHTML = audioIcon('note');
          number.setAttribute('aria-label', '正在播放');
        } else number.textContent = String(index + 1).padStart(2, '0');
        const copy = document.createElement('span'); copy.className = 'queue-copy';
        const name = document.createElement('strong'); name.textContent = data.title;
        const artist = document.createElement('small'); artist.textContent = `${data.artist}${snapshot.upNext.includes(item.id) ? ' · 下一首播放' : ''}`;
        copy.append(name, artist); choose.append(number, copy);
        const menu = document.createElement('details'); menu.className = 'row-menu';
        const summary = document.createElement('summary'); summary.className = 'icon'; summary.dataset.itemId = item.id; summary.dataset.queueAction = 'menu';
        summary.setAttribute('aria-label', `${data.title} 的队列操作`); summary.innerHTML = audioIcon('more');
        const operations = document.createElement('div'); operations.className = 'row-actions';
        for (const [action, label] of [['enqueue', '下一首播放'], ['up', '向上移动'], ['down', '向下移动'], ['remove', '移出队列']]) {
          const control = document.createElement('button'); control.type = 'button'; control.textContent = label;
          control.dataset.queueAction = action; control.dataset.itemId = item.id;
          control.disabled = (action === 'up' && index === 0) || (action === 'down' && index === snapshot.items.length - 1) || (action === 'enqueue' && item.id === snapshot.current?.id);
          operations.append(control);
        }
        menu.append(summary, operations); row.append(choose, menu); return row;
      });
      queueList.replaceChildren(...rows);
      if (focusId) {
        const replacement = all<HTMLElement>('[data-item-id]').find(control => control.dataset.itemId === focusId
          && control.dataset.queueAction === (focusAction === 'select' ? 'select' : 'menu'));
        const fallback = rows[Math.min(Number(focusIndex ?? 0), rows.length - 1)]?.querySelector<HTMLElement>('button');
        (replacement ?? fallback ?? get<HTMLButtonElement>('[data-action=queue]')).focus();
      }
    }
    const historyKey = JSON.stringify([snapshot.history, snapshot.historyIndex, snapshot.items]);
    if (historyKey !== historyRenderKey) {
      historyRenderKey = historyKey;
      const rows = snapshot.history.map((id, index) => {
        const row = document.createElement('li');
        if (index === snapshot.historyIndex) row.setAttribute('aria-current', 'true');
        const number = document.createElement('span'); number.textContent = String(index + 1).padStart(2, '0');
        const name = document.createElement('span'); name.textContent = metadata(snapshot.items.find(item => item.id === id) ?? null).title;
        row.append(number, name); return row;
      });
      if (!rows.length) { const row = document.createElement('li'); row.textContent = '播放后，历史会出现在这里。'; rows.push(row); }
      get('[data-history-list]').replaceChildren(...rows);
    }
    text('[data-queue-count]', String(snapshot.items.length));
    text('[data-queue-description]', `${snapshot.items.length} 首音频 · ${snapshot.order === 'shuffle' ? '随机播放' : '顺序播放'} · ${repeatLabels[snapshot.repeat]}`);
    get('[data-queue-empty]').hidden = snapshot.items.length > 0;
    get<HTMLButtonElement>('[data-action=clear]').disabled = snapshot.items.length === 0;
    get<HTMLButtonElement>('[data-action=back]').disabled = !snapshot.canBack;
    get<HTMLButtonElement>('[data-action=forward]').disabled = !snapshot.canForward;
  }
  function render() {
    if (disposed) return;
    const snapshot = queue.snapshot;
    const displayed = snapshot.current ?? snapshot.items[0] ?? null;
    const data = metadata(displayed, snapshot.loaded ? player.currentMetadata : null);
    const error = snapshot.error ?? lastError;
    const state = player.state;
    const busy = snapshot.loading || state === 'loading' || buffering;
    const playing = !player.paused && !player.failed && state !== 'stopped';
    presentation.dataset.state = state;
    presentation.dataset.busy = String(busy);
    surface.hidden = closed;
    get('[data-closed]').hidden = !closed;
    title.textContent = displayed ? data.title : '准备好，开始听';
    title.title = title.textContent;
    subtitle.textContent = displayed ? [data.artist, data.album].filter(Boolean).join(' · ') : '选择一首音频';
    if (data.cover !== coverSource) {
      coverSource = data.cover;
      cover.hidden = !coverSource;
      if (coverSource) cover.src = coverSource; else cover.removeAttribute('src');
    }
    get('[data-empty]').hidden = snapshot.items.length > 0;
    playButton.disabled = snapshot.items.length === 0;
    const pause = playing || snapshot.autoplayPending;
    const icon = pause ? 'pause' : 'play';
    if (lastPlayIcon !== icon) { playButton.innerHTML = audioIcon(icon); lastPlayIcon = icon; }
    playButton.setAttribute('aria-label', pause ? '暂停' : state === 'stopped' ? '重新播放' : '播放');
    playButton.title = playButton.getAttribute('aria-label')!;
    get<HTMLButtonElement>('[data-action=previous]').disabled = !snapshot.canPrevious;
    get<HTMLButtonElement>('[data-action=next]').disabled = !snapshot.canNext;
    get('[data-action=shuffle]').setAttribute('aria-pressed', String(snapshot.order === 'shuffle'));
    const repeat = get('[data-action=repeat]');
    repeat.setAttribute('aria-label', repeatLabels[snapshot.repeat]); repeat.title = repeatLabels[snapshot.repeat];
    repeat.setAttribute('aria-pressed', String(snapshot.repeat !== 'off'));
    get('[data-repeat-one]').hidden = snapshot.repeat !== 'one';
    slider.disabled = !snapshot.loaded || state === 'stopped' || player.failed || !Number.isFinite(player.duration) || player.duration <= 0;
    text('[data-current-time]', time(snapshot.loaded ? player.currentTime : 0));
    text('[data-duration]', player.duration === Infinity ? '直播' : time(snapshot.loaded ? player.duration : 0));
    get<HTMLSelectElement>('[data-setting=rate]').value = String(player.playbackRate);
    get('[data-volume-unavailable]').hidden = !get('media-volume-slider').hidden;
    const timer = sleepTimer?.snapshot;
    get('[data-sleep-active]').hidden = timer?.status !== 'running';
    const sleepText = timer?.status === 'running' ? timer.trigger?.type === 'duration'
      ? `${time(Math.ceil(timer.remainingMs / 1000))} 后${timer.action === 'pause' ? '暂停' : timer.action === 'stop' ? '停止' : '关闭'}`
      : `再播完 ${timer.remainingItems} 首后${timer.action === 'pause' ? '暂停' : timer.action === 'stop' ? '停止' : '关闭'}` : '';
    const status = error ? '播放遇到问题，可以重试或选择其他曲目。' : busy ? buffering && !snapshot.loading ? '正在缓冲…' : '正在加载…'
      : state === 'stopped' ? '已停止 · 队列已保留' : state === 'ended' ? '播放完毕' : playing ? '正在播放'
        : state === 'paused' ? '已暂停' : '选择一首，开始收听';
    text('[data-status]', sleepText ? `${status} · ${sleepText}` : status);
    get('[data-action=sleep]').title = sleepText || '睡眠设置';
    get('[data-error]').hidden = !error;
    const retry = get<HTMLButtonElement>('[data-action=retry]');
    retry.textContent = state === 'stopped' ? '重新播放' : '重试播放';
    retry.disabled = snapshot.items.length === 0;
    if (error) text('[data-error-text]', (error as Error)?.name === 'NotAllowedError' ? '浏览器暂停了自动播放，请点击重试。'
      : state === 'stopped' ? '播放资源已停止，但进度保存未完成。' : '这首音频暂时无法播放。请重试，或选择其他曲目。');
  }
  function onQueueChange() { if (!disposed) { renderQueue(); render(); } }
  function bindMedia() {
    mediaAbort.abort(); mediaAbort = new AbortController(); buffering = false;
    const media = player.element;
    for (const event of ['waiting', 'stalled']) media?.addEventListener(event, () => { buffering = !player.paused; render(); }, { signal: mediaAbort.signal });
    for (const event of ['playing', 'canplay', 'pause', 'emptied']) media?.addEventListener(event, () => { buffering = false; render(); }, { signal: mediaAbort.signal });
  }
  function togglePlay() {
    if ((!player.paused && !player.failed) || queue.snapshot.autoplayPending) player.pause();
    else return queue.play();
  }
  async function close() {
    assertLive();
    closeAbort?.abort(); closeAbort = new AbortController();
    audioView.dismiss();
    try { await player.close({ signal: closeAbort.signal }); }
    catch (error) { report(error); throw error; }
  }
  function open() {
    assertLive(); closeAbort?.abort(); closeAbort = null;
    if (sleepTimer?.snapshot.actionPending && sleepTimer.snapshot.action === 'close') sleepTimer.cancel();
    closed = false; render(); focusFallback();
  }
  function destroy() {
    if (disposed) return;
    disposed = true; commandRevision += 1;
    closeAbort?.abort(); abort.abort(); mediaAbort.abort(); observer?.disconnect();
    for (const unsubscribe of unsubscribes) unsubscribe();
    queue.removeEventListener('change', onQueueChange);
    queue.removeEventListener('error', queueError);
    sleepTimer?.removeEventListener('change', render);
    mediaSession?.removeEventListener('error', queueError);
    settings?.destroy(); audioView.dismiss(); preset.destroy(); element.remove();
  }
  const queueError = (event: Event) => report((event as CustomEvent).detail);

  try {
    queue.setItems(items);
    setTokens(tokens);
    const media = createMediaElement?.(document) ?? document.createElement('audio');
    media.dataset.mediaHost = ''; media.setAttribute('preload', 'metadata'); media.setAttribute('playsinline', '');
    get('audio-player').prepend(media);
    root.append(element);
    player.attach(media);
    audioView.bind(abort.signal);
    if (sleepTimer) settings = mountSleepTimerSettings(get('[data-sleep-settings]'), sleepTimer);
    else get('[data-action=sleep]').hidden = true;
    for (const control of all('[data-action=add]')) control.hidden = !onRequestItems;
    for (const action of actions) {
      const control = document.createElement('button'); control.type = 'button'; control.textContent = action.label;
      control.addEventListener('click', () => { void perform(() => action.run({ player, queue, current: queue.snapshot.current })); }, { signal: abort.signal });
      get('[data-host-actions]').append(control);
    }
    shadow.addEventListener('click', event => {
      const target = (event.target as Element)?.closest<HTMLElement>('[data-action],[data-queue-action],[data-tab]');
      if (!target || (target as HTMLButtonElement).disabled) return;
      if (target.dataset.tab) { setTab(target.dataset.tab); return; }
      const id = target.dataset.itemId;
      const operation = target.dataset.queueAction;
      if (id && operation) {
        if (operation === 'menu') return;
        target.closest('details')?.removeAttribute('open');
        void perform(() => {
          if (operation === 'select') return queue.selectId(id);
          if (operation === 'remove') return queue.remove(id);
          if (operation === 'enqueue') return queue.enqueueNext(id);
          const index = queue.snapshot.items.findIndex(item => item.id === id);
          queue.move(id, index + (operation === 'up' ? -1 : 1));
        });
        return;
      }
      const action = target.dataset.action;
      // 三个浮层入口都交给核的音频视图（方案 P5）；其余动作走这里。
      if (action === 'dismiss') { audioView.dismiss(); return; }
      if (audioView.handleAction(action, target)) return;
      if (action === 'expand') { setView('expanded'); get<HTMLButtonElement>('[data-action=collapse]').focus(); return; }
      if (action === 'collapse') { setView(presentation.dataset.layout === 'mobile' ? 'mini' : 'bar'); get<HTMLButtonElement>('.toolbar [data-action=expand]').focus(); return; }
      if (action === 'reopen') { open(); return; }
      void perform(() => {
        if (action === 'play') return togglePlay();
        if (action === 'previous') return queue.previous();
        if (action === 'next') return queue.next();
        if (action === 'retry') return player.state === 'stopped' ? queue.play() : queue.retry();
        if (action === 'shuffle') return queue.setOrder(queue.snapshot.order === 'shuffle' ? 'sequential' : 'shuffle');
        if (action === 'repeat') return queue.setRepeat(({ off: 'all', all: 'one', one: 'off' } as const)[queue.snapshot.repeat]);
        if (action === 'back') return queue.back();
        if (action === 'forward') return queue.forward();
        if (action === 'stop') { audioView.dismiss(); return player.stop(); }
        if (action === 'close') return close();
        if (action === 'clear') return queue.clear();
        if (action === 'add') return onRequestItems?.();
      });
    }, { signal: abort.signal });
    shadow.addEventListener('change', event => {
      const control = event.target as HTMLSelectElement;
      if (control.dataset.setting === 'theme') setTheme(control.value as AudioPlayerTheme);
      if (control.dataset.setting === 'view') setView(control.value as AudioPlayerView);
      if (control.dataset.setting === 'rate') void perform(() => player.setPlaybackRate(Number(control.value)));
    }, { signal: abort.signal });
    shadow.addEventListener('keydown', event => {
      const key = event as KeyboardEvent;
      const target = event.target as HTMLElement;
      // 浮层的 Tab / Escape / 方向键由核在 document 捕获阶段统一处理（方案 S3/S4）。
      if (target.dataset.tab && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(key.key)) {
        key.preventDefault();
        const name = key.key === 'Home' ? 'queue' : key.key === 'End' ? 'history' : target.dataset.tab === 'queue' ? 'history' : 'queue';
        setTab(name); get<HTMLButtonElement>(`[data-tab=${name}]`).focus();
      // `!key.defaultPrevented`：核已在捕获阶段处理过这次 Escape（关掉了面板），这里不要重复反应，
      // 否则同一次按键既关面板又把 expanded 折成 mini（实测焦点会跑到播放键、collapse 按钮随之消失）。
      } else if (key.key === 'Escape' && !key.defaultPrevented && view === 'expanded') {
        key.preventDefault(); setView(presentation.dataset.layout === 'mobile' ? 'mini' : 'bar'); focusFallback();
      }
    }, { signal: abort.signal });
    cover.addEventListener('error', () => { cover.hidden = true; }, { signal: abort.signal });
    queue.addEventListener('change', onQueueChange); queue.addEventListener('error', queueError);
    sleepTimer?.addEventListener('change', render); mediaSession?.addEventListener('error', queueError);
    for (const event of ['statechange', 'timeupdate', 'durationchange', 'pause', 'ended', 'sourcechange', 'ratechange', 'volumechange', 'seeked'] as const) unsubscribes.push(player.on(event, render));
    unsubscribes.push(player.on('playing', () => {
      // 睡眠可能已在 play 阶段停止；确认实际起播后才接管系统控制。
      if (!closed && !player.paused && player.state === 'playing' && player.currentResourceId) mediaSession?.activate();
      render();
    }));
    unsubscribes.push(player.on('playerror', report));
    unsubscribes.push(player.on('loadstart', () => { lastError = null; buffering = false; closed = false; render(); }));
    unsubscribes.push(player.on('mediachange', bindMedia));
    unsubscribes.push(player.on('closerequest', () => {
      if (disposed) return;
      closed = true; audioView.dismiss(); render(); focusFallback(); onClose?.();
    }));
    unsubscribes.push(player.on('destroy', destroy));
    bindMedia();
    const ResizeObserverClass = document.defaultView?.ResizeObserver;
    if (ResizeObserverClass) { observer = new ResizeObserverClass(applyLayout); observer.observe(element); }
    else document.defaultView?.addEventListener('resize', applyLayout, { signal: abort.signal });
    setTheme(theme); applyLayout(); renderQueue(); render();
    api = {
      element, player, queue, sleepTimer, mediaSession, mainMedia,
      get isClosed() { return closed; }, get isDestroyed() { return disposed; },
      setTheme, setTokens, setView,
      setLayout(next) { assertLive(); choice(next, ['auto', 'desktop', 'mobile'], 'layout'); layout = next; applyLayout(); },
      async setItems(next) { assertLive(); return queue.replaceItems(next); }, open, close, destroy,
    };
    return api;
  } catch (error) { destroy(); throw error; }
}
