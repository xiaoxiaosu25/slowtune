/**
 * 中立交付描述契约
 *
 * 层次边界：见 packages/player/README.md 的"契约层边界"。
 * 公共核心只认这里的字段：目标地址、MIME 类型、传输协议、请求头与承载方式。
 * 任何具体引擎（Video.js、mpv、浏览器原生通路）的来源描述结构都不属于本层，
 * 由各后端在自己的模块内组装。
 */

import type { PlaybackPlan, PlaybackTransport } from './plan.js';

/** 中立交付目标：核心只认这些字段，不认任何引擎描述。 */
export interface DeliveryTarget {
  src: string;
  type?: string;
  transport?: PlaybackTransport;
  headers?: Record<string, string>;
}

/** 承载方式：managed = 需要后端自己的承载元素；native = 可直接用原生媒体元素。 */
export type DeliveryCarrier = 'native' | 'managed';

export interface AdaptedSourceResult {
  source: DeliveryTarget;
  carrier: DeliveryCarrier;
  resourceId: string;
  originalPlan?: PlaybackPlan;
  metadata?: Record<string, unknown>;
  fallbackUrl?: string;
  expiresAt?: number;
}
