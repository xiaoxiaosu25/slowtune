# 构建与依赖边界

版本：v1.2 · 2026-10-05

[返回包入口](../README.md)。公开签名以包声明为准，真实支持以入口和证据所述环境为准。

## 构建与入口

MediaDock UI 见[界面指南](ui.md)，异步来源与原始时间轴见[来源指南](sources.md)；公共候选见[整合证据](../evidence/mediadock-integration-2026-09-30.md)。其隔离记录保留，真实 MediaDock 音频浏览器/服务端结果见[消费者证据](../evidence/mediadock-real-2026-10-01.md)，实体 Android 尚未验收。

在本目录执行 `npm.cmd run build`、`npm.cmd test`、`npm.cmd run test:types`。最后一项通过包的公开导出编译消费者代码及非法参数用例。干净环境先 `npm.cmd ci`；缓存放在当前工作区 local/runtime 下。
构建生成 `dist` 与类型声明；版本和完整依赖以 [package.json](../package.json) 为准。

公开入口清单**以 [package.json](../package.json) 的 `exports` 为准**，不在此誊抄。按粒度分三种用法：

| 粒度 | 入口 | 何时用 |
| --- | --- | --- |
| 整个库 | 根入口、`presets` | 要核心加默认功能组合 |
| 按功能组 | `ui/audio`、`ui/video`、`ui/mediadock`、`ui/preview`、`ui/sleep-settings` | 直接用现成套件 |
| 按单个模块 | `core`、`contracts`、`source-adapter`、`progress`、`queue`、`sleep-timer`、`media-session`、`main-media`、`video-tracks` | 自绘界面，只取需要的控制器或契约 |

构建由 TypeScript 保留 ES 模块依赖图。根入口和功能子入口共享同一模块实例，避免把系统媒体端口的活动拥有者重复打包成多份。导入功能不自动创建任务、访问存储或注册系统操作。

仅导入 `core` 的浏览器 bundle 已检查不包含队列、睡眠、系统媒体、主媒体协调、轨道、预设和 UI 模块。`presets` 为支持运行时开关引用五个功能模块；关闭功能阻止初始化与副作用，不承诺所有关闭的功能都从 bundle 中消失。要求最小依赖的消费者直接使用 `core` 和所需子入口。各 UI 入口导入时均不访问 DOM；视频 UI 挂载时只注册 Video.js 的播放器/容器与本地化模块，普通播放按钮、`input[type=range]`、状态反馈和能力降级由套件自身绑定。样式随模块封装，无需复制示例 CSS。

两个上游 peer 都是**可选** peer：只取 `core` 与 `contracts` 的消费者不要求安装上游包；使用 `ui/audio`、`ui/video`、`ui/mediadock`、`ui/preview` 时才需要 HTML peer，HLS 另装其适配 peer，均固定为包清单声明的确切版本。视频套件不要求上游的 `media-*` UI 控件模块；`hlsjs-video` 元素来自 `@videojs/html/media/hlsjs-video`。图标运行依赖由 npm 随包安装，消费者无需额外处理。产品只依赖公开入口，不导入 `src` 内部文件。
示例联调见[示例 A](../../../examples/player/example-a/README.md)和[示例 B](../../../examples/player/example-b/README.md)。本轮隔离制品安装、公开类型与固定样本浏览器播放已验收；这不代表 U5 的 mpv 真实产品阶段完成。

正式版组合与独立安装基线见[正式版证据](../evidence/videojs-ga-2026-10-05.md)，0.12.3 恢复修复、MediaDock 固定制品和回退见[消费者升级证据](../evidence/mediadock-ga-2026-10-05.md)；此前[列表滚动](../evidence/mobile-scroll-2026-10-02.md)、[MediaDock 制品](../evidence/mediadock-integration-2026-09-30.md)与[可靠性制品](../evidence/reliability-2026-09-30.md)保留为历史版本。使用 UI/HLS 时安装候选 tgz 和清单指定的对应 peer；仅使用核心时只安装候选包。具体产品仍需验证自己的来源、凭据、自托管资源及宿主，旧产品制品不会随平台主线更新。
