# 来源、轨道与本机处理

版本：v1.0 · 2026-10-04

[返回包入口](../README.md)。公开签名以包声明为准，真实支持以入口和证据所述环境为准。

## 视频轨道与同资源换源

`new VideoTracksController(player)` 可独立装配，也可在测试/宿主边界注入一个后端中立 `TrackPort`；`selectSubtitle(id | 'off')`、`selectAudioTrack(id)`、`selectQuality(id | 'auto')`、`snapshot/destroy/isDestroyed` 是公开操作，`change` 通知能力或选择更新。公共控制器不读取 `player.element`。

| 能力 | 实际实现与降级 |
| --- | --- |
| 字幕 | `TrackPort` 提供中立快照与选择；Video.js 适配器将计划 WebVTT 接到真实 `<track>`/TextTrack，由浏览器绘制并报告加载、可用、失败、不支持；对 `hlsjs-video` 等自定义承载，默认模式同步到其真实 target；mpv 适配器读取 `track-list`。SRT/ASS/SSA 需宿主转换为 WebVTT |
| 音轨 | `TrackPort` 提供中立快照与选择；Video.js 适配器读取公开 `audioTracks` 并修改实际 enabled 轨道，mpv 适配器写入会话的音轨选择。至少两轨才提供切换；无列表时明确降级 |
| 清晰度 | 仍是 Video.js 兼容扩展，不进入窄 `TrackPort`：至少两档真实 `videoRenditions` 才显示菜单，经公开 selectedIndex 请求自动或手动档位。mpv 不伪造 HLS 自适应画质列表 |

快照含资源 ID、只读轨道/画质列表、当前选择与三种 `Available/Reason`。非法/不可用选择抛 `NotSupportedError`；菜单 ID 必须取实际快照。当前音轨按请求 ID 选择，语言/名称相同也能区分；旧轨被替换后才按语言/名称回退。异步列表变化重用最新选择；同资源字幕按 ID、清晰度按尺寸/码率匹配，换为其他资源时重置。销毁移除自己添加的字幕、事件和待执行工作。

`player.replaceSource(input)` 同步替换当前资源的交付来源，必须保留相同 `resourceId`；未加载/已停止或跨资源替换拒绝且不破坏当前会话。位置、音量、倍速、暂停/播放意图、Queue 和 SleepTimer 保留，较旧 URL 刷新结果失效。手动定位至 0 也优先于存储中的旧断点；新来源元数据就绪后恢复位置。新资源使用 `load` 或 Queue；重试使用队列原始来源，需刷新的地址由消费者 resolver 提供。

等待换源元数据时，后续静音、音量和倍速命令优先于换源快照。此时停止、关闭或睡眠停止保存待恢复位置；有较新的手动定位则保存该位置，包括 0 秒。

锁定 rc.2 的两处兼容处理有真实浏览器回归：公开 rendition 桥接可能在 nextLevel 相同时遗漏手动锁定，因此实际档位偏离最新选择时限频重发列表 change；公开 PiP 状态未处理 Shadow DOM 重定向，因此 UI 用标准 `getRootNode().pictureInPictureElement` 补齐拥有媒体的公开状态属性。都不访问私有引擎、不复制/修改上游源码；显式升级上游时须复验并评估移除。

## 浏览器格式能力预检

`source-adapter` 的 `assessBrowserMedia` 接收封装及所选音视频编码描述，分别评估容器、轨道、组合和实际文件/HLS 通路。类型由 `contracts` 维护。调用方先评估，再通过已有 `load` 加载；评估自身没有读取、取址、播放或换后端副作用。

```js
import { assessBrowserMedia } from '@studio/player/source-adapter';

const abortController = new AbortController();
const support = await assessBrowserMedia({
  transport: 'range',
  video: null, // 明确为纯音频；省略表示视频信息未知
  audio: { mimeType: 'audio/mp4', codec: 'mp4a.40.2',
    channels: '2', samplerate: 48000, bitrate: 128000 },
}, { signal: abortController.signal });
// support.status: expected-supported / unsupported / unknown
// reason、checks、evidence 解释总体、各维度及 API 查询；不含 URL 或原始错误。
```

输入中的 MIME 不带参数，编码使用准确标识；不从扩展名推断编码。`null` 明确没有该轨道，省略或编码缺失保持未知。检查所选音视频及可表达的组合，音频否定结果不会被视频支持掩盖。视频和音频均无轨道时返回 `no-tracks`。

参数完整时查询 `MediaCapabilities`；否则可使用 `canPlayType` 的明确结果。`maybe`、API 缺失、异常及相互冲突保持未知。原始 FLAC/MP3 使用对应 MIME，避免冗余 `codecs` 参数造成误判。可选 `environment` 显式注入查询端口；导入时不访问 DOM，非浏览器缺少 API 时返回未知。

异步查询默认等待上限为 3000ms，可用 `timeoutMs` 在 (0, 60000] 内设置；超时返回未知，取消以 `AbortError` 拒绝，迟到结果不改变已返回判断。浏览器底层查询没有取消接口，本函数只取消等待并观察迟到拒绝。

HLS 须显式声明 `route: 'native-hls'` 或 `'mse-hls'`。原生通路只查询 HLS 清单类型；`maybe` 保持未知，缺少原生 HLS 轨道及容器证据时保持未知，不使用文件 `canPlayType` 或 `MediaCapabilities` 的结果否定此通路。MSE 通路还须由宿主通过 `environment.hlsAdapter` 提供实际适配器能力，并以 `mseContainer` 声明适配后容器；编码保持原值，查询 `MediaSource.isTypeSupported` 和 `MediaCapabilities` 的 `media-source` 配置。框架可加载 HLS 不能替代所选音频或视频的解码判断；未声明通路的 HLS、DASH/WebRTC 保持 `transport-not-assessed`。

这是预测：不证明文件完整、实际解码成功、实体声音输出、硬件加速或播放流畅。`smooth/powerEfficient` 仅保留浏览器估计；`suggestedPath` 给出直接播放、继续验证或寻找兼容来源/显式宿主的建议，不启动转换或隐式切换。媒体信息可由外部提供，或通过下述可选 Node 入口取得；缓存与处理服务未实现。格式样本与结果见[格式检查](../../../labs/player/format-check/README.md)及[P01 证据](../evidence/format-compatibility-p01-2026-09-30.md)。

### 可选本地文件探测

`@studio/player/probe` 提供 `LocalMediaProbe`，只供 Node 宿主或服务端显式调用；根入口、核心和浏览器来源适配不导入该运行时。ffprobe 可执行文件由宿主提供，不随包安装或分发。首批实际工具环境为 Windows x64，其他系统未验收。

```js
// Node 宿主：路径由宿主配置和授权的文件选择结果提供。
import { LocalMediaProbe } from '@studio/player/probe';
import { describeProbedMedia } from '@studio/player/source-adapter';

const probe = new LocalMediaProbe({ executable: ffprobeAbsolutePath });
const result = await probe.inspect(selectedAbsolutePath, {
  signal: abortController.signal, maxReadBytes: 8 * 1024 * 1024,
});
const description = describeProbedMedia(result.media);
// 把 description 传给浏览器，再调用 assessBrowserMedia(description)。
await probe.destroy(); // 取消未完成请求，等待进程、文件和临时服务释放。
```

接受本地普通文件的绝对路径，拒绝 URL、相对路径及 UNC 路径；文件授权由宿主负责。默认 `seekable` 模式通过随机令牌的临时 loopback Range 服务提供有界定位读取，ffprobe 接收该端点，限定协议与容器探测器，不接收原文件路径或任意命令参数。保留显式 `prefix` 管道模式；预算不足不扩大范围。

读取预算累计实际源读取量，重复区间也计费；`bytesRead`、`ranges` 和 `readOperations` 提供本次证据。`inputComplete` 只表示所有字节至少读过一次；可定位探测取得完整索引轨道时，`tracksComplete` 可以为真而无需读完整文件，两者均不证明媒体完整可解码。前缀或缺失配置中的未知项保留未知。

读取、保留的 stdout/stderr、等待和每实例并发均有上限；输出超过预算的块触发失败并终止进程，不保留该块。并发满额立即返回 `busy`。取消、超时和预算失败在返回前结束子进程并释放文件、socket、服务和监听；`stop()` 取消现有请求并等待释放，实例仍可复用，`destroy()` 还拒绝后续请求且可重复调用。

探测结果保留中立事实，不携带原始路径、tags、stderr 或系统异常。`describeProbedMedia` 按默认轨或显式索引生成描述并忽略封面图，不改变播放器选轨。MP4/MOV 品牌及 MKV/WebM 的 EBML DocType 用于识别实际容器；H.264、HEVC、AV1 从配置记录生成标识，VP9 须有真实 profile/level/位深，DTS 按真实 profile 区分，AAC 按可确认的配置映射。缺少 sample entry、level 或配置时保持未知，不根据扩展名或常见默认值补齐。

失败通过 `MediaProbeError.code` 区分取消、超时、并发占满、读取/输出预算、无效媒体及工具不可用。该入口没有远程下载、缓存、转封装、转码或播放副作用。扩展样本及真实进程资源检查见[P01 证据](../evidence/format-compatibility-p01-2026-09-30.md)，[前一批证据](../evidence/media-probe-2026-09-30.md)保留历史结果。AC-3/DTS 可出现有画面无声音，不能以 `playing` 或画面解码替代整段音视频可用结论；其他系统与实体输出仍未验收。

### 可选本机媒体处理

`@studio/player/processing` 的 `LocalMediaProcessor` 由 Node 宿主显式提供 FFmpeg/ffprobe 路径、SHA-256、取得记录标识和已授权输出目录。浏览器核心、根入口和来源适配不导入该运行时，不自动安装工具、转换媒体或切换后端。契约由 `contracts/media-processing.ts` 维护；最小消费者及复验命令见[处理检查](../../../labs/player/processing-check/README.md)。

三种 profile 的输出均采用带索引的 MP4 系列封装：H.264/AAC MKV 复制音视频到 MP4；ALAC 转为 FLAC 编码并用 M4A 承载；H.264/AC-3 复制视频并转为 AAC LC。ALAC 的 FLAC 输出仍为无损音频，M4A 扩展名不表示 AAC；原始 FLAC 在本机 Edge 的末尾定位失败，索引封装通过。适配接受明确配置的 H.264 8 位 4:2:0、单/双声道音频和 16/24 位 ALAC；本批实测视频音频为单声道，ALAC 为 48kHz/24 位/双声道。其他组合及设备未验证，DTS、HDR、多声道和全视频转码不进入本轮支持。

```js
// Node 宿主；浏览器须由宿主提供 publishOutput 和会话代理。
import { LocalMediaProcessor } from '@studio/player/processing';
const processor = new LocalMediaProcessor({ ffmpeg: approvedFfmpeg,
  ffprobe: approvedFfprobe, outputRoot: authorizedDirectory });
const session = processor.start({ file: selectedAbsolutePath, resourceId: 'episode-1',
  profile: 'h264-ac3-to-aac', policy: { allowLossyAudio: true } });
await player.load(await session.ready); // 初次加载；计划持有成功输出。
await player.replaceProcessedSource(nextSession); // 同资源：注册准备并沿用换源规则。
await player.stop(); // 等待本机处理及输出释放。
await player.destroyAsync(); // 同步 destroy 仍可用；宿主需要等待时使用此入口。
await processor.destroy();
```

`session` 表达 preparing/ready/failed/cancelled/released；取消与释放等待进程和临时资源终止，重复释放安全。SourceController 持有显式准备过程，换源、停止、销毁及 resolver 迟到结果均释放不再使用的本机会话。输出 ready 后交回既有加载通路。替换成功后的旧会话清理失败仍向调用者报告，但不会释放已接管播放的新会话。同资源位置、暂停/播放意图、音量、静音和倍速沿用核心规则；所选音轨映射到输出默认轨，其他兼容 AAC 轨保留，`evidence.trackMapping` 反馈实际索引变化。宿主依据映射更新来源选择；浏览器没有实际音轨列表时，仍不能承诺运行中切轨。已有外挂 WebVTT 清单保留，嵌入字幕不会自动转换。

有损转换默认拒绝，显式允许后使用原生 AAC LC/twoloop，默认每声道 96kbps，允许每声道 64–160kbps；不改变采样率或声道，关闭 AC-3 解码 DRC，不混音或转换 HDR。未知编码/配置和不能保留的轨道、章节、必要元数据默认拒绝。只有宿主的精确 `discardStreams`、章节丢弃或元数据损失策略可以批准降级，结果报告损失；编码器标识、占位语言等技术元数据的重写也有报告。保留检查比较真实输出，允许策略不把丢失写成已保留。设置默认音轨仅增删 default，其他 disposition 标志必须保留，丢失按必要元数据策略拒绝或报告。已知容器及保留轨道时长在输出复核时比较，固定允许 100ms 封装取整/编码填充误差；缺少对应输出时长或超差均拒绝，显式丢弃轨道时不比较容器总时长。此检查不证明未知时间线或误差范围内的内容完整性。

只接受授权本地普通文件的绝对路径，拒绝 URL、相对路径和 UNC；来源不提供命令参数。FFmpeg 直接使用固定参数数组、无 shell，通过有界 loopback Range 读取，原文件只读。源读取累计包含探测、处理和重复区间，默认 256MiB；输出复核另有最多 64MiB 预算。默认 30 秒、每实例一个任务、日志总量 2MiB、单输出 128MiB、保留空间预留 512MiB，并要求额外 64MiB 空闲；上限和校验以公开类型及实现为准。会话使用独占临时目录和 `-n`，已有输出不覆盖；失败/取消删除残留，成功输出直到释放才删除。默认返回 file URL，普通网页须由宿主提供受控 URL；`publishOutput` 的释放必须关闭宿主拥有的读取服务。

源预算按实际 read 执行；输出使用 `-fs`、20ms 大小监控与最终拒绝，**允许瞬时写入超出预算**，没有 OS 磁盘配额、严格 CPU/内存上限或跨实例空间仲裁。截止时间终止进程后等待 read、关闭和删除；清理耗时可超过截止时间。工具校验读取每个不超过 256MiB 的二进制；宿主负责工具不被并发替换、文件授权、进程崩溃后的孤立目录清理，以及 URL 端口的取消和释放。没有持久缓存复用、处理过程中播放或定位，也没有后台服务。

错误只报告 `MediaProcessingError.code`，不携带路径、stderr 或凭据；Node 的 `outputFile` 只供授权宿主读取。本次修复复验见[评审修复记录](../evidence/processing-review-2026-09-30.md)。工具、质量、音画、同步和资源证据见[P03 记录](../evidence/media-processing-p03-2026-09-30.md)；工具不随包或产品分发，静态依赖的精确发行材料与编解码专利未确认，见[第三方材料](../THIRD-PARTY.md)。

## 可靠性与诊断

仅显式配置超时的计划启用对应截止时间；省略或 `0` 禁用。单位为秒，支持项拒绝负数、非有限数或超出计时器范围的值。`resolve` 限制一次 resolver 等待，超时保留当前来源并通知诊断；`initial` 在 Video.js 路径有播放意图后等待 `playing`，不代表首帧渲染；`stall` 从已起播媒体的 `waiting/stalled` 开始，时间推进、`playing`、暂停或结束会取消。重复缓冲事件不延长同一次等待。暂停后再次播放重新等待起播；加载但未播放不启动起播计时。

起播/卡顿超时复用既有备用源预算和错误出口，保留换源位置及播放意图；没有可用备用源时进入失败状态并释放媒体来源。等待中的 `play()` 在失败终态以 `PlaybackTimeoutError` 拒绝；已进入备用源的旧请求按 `AbortError` 取消，避免队列把恢复标为失败。不会自动无限重试，也不会从一个后端切到另一个。`connect/read` 仍未消费；mpv 不启用 `initial/stall`。

```js
const source = {
  resourceId: 'episode-1', mediaType: 'video', strategy: 'direct', transport: 'hls',
  playUrl: '/video/master.m3u8',
  timeouts: { resolve: 10, initial: 15, stall: 20 }, // 示例策略，由产品按来源调整
};
const unsubscribe = player.on('diagnostic', diagnostic => {
  // 由产品选择记录方式；不自动上传或持久化。
  console.debug(diagnostic);
});
await player.load(source);
// 用户播放操作中：await player.play()，并处理拒绝。
```

`diagnostic` 是现有播放器事件通道的一部分，负载类型由 `contracts/diagnostics.ts` 维护，包含原因代码与时间信息，不包含 URL、请求头、资源 ID 或原始错误文本。来源控制器可独立订阅 `onDiagnostic`；诊断监听失败不改变播放。原有 `error/playerror` 契约保留，未承诺对它们的原始错误做脱敏。

resolver 的可选第四参数提供 `{ signal }`，原三参数实现保持兼容。宿主可将 signal 交给 fetch。新加载、同资源替换、停止、卸载、销毁和解析超时会取消旧解析等待；忽略 signal 的 resolver 迟到返回新远端会话时仍会释放该会话。暂停只取消播放等待，不取消仍可服务当前资源的地址刷新；迟到刷新不得恢复已暂停媒体。没有隐式取址服务：首次 `load` 仍接收已取得的 URL/计划。

## 集成限制

- 明确 HLS 才走 MSE；无扩展名地址须给 MIME 或 `transport: 'hls'`。非 MP4、非 HLS 类型优先使用原生 video/audio，固定承载元素尚待实验。这一判定以交付结果的 `carrier` 表达（见[交付结果契约](core.md#交付结果契约中立字段)）。
- 原生媒体不能注入任意 headers；HLS 可经 Video.js 描述的 `engine.hlsJs.xhrSetup` 透传（由 `toVideojsSource` 组装，只在 `carrier === 'managed'` 且 headers 非空时出现）。上游锁 hls.js 1.6.7，产品对齐版本需单独验证。
- 自托管运行产物；中文采用静态 locale 注册。产品 CSP、Worker、字幕渲染与上游默认配置兼容性按真实接入验证。
- `tracks.subtitles` 已由视频功能消费，音轨/画质取实际公开媒体列表；外置音频声明、非 WebVTT 字幕和未暴露轨道的宿主有明确降级。`timeouts` 的支持范围见“可靠性与诊断”；`processing.recommendedMode/unavailableReason` 仍未驱动行为；`sessionEndpoint` 已用于心跳和释放。
- 起播位置读取 `PlaybackPlan.resumePositionSeconds`。
- 公共包不依赖旧项目、labs、examples 或产品内部文件；不维护上游核心源码分叉。支持边界与未验证项见 [BASELINE](../../../standards/BASELINE.md) 的“验证边界”。
