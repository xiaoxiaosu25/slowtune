# 核心与宿主接入

版本：v1.0 · 2026-10-04

[返回包入口](../README.md)。公开签名以包声明为准，真实支持以入口和证据所述环境为准。

## 最小用法

```js
import { StudioPlayer } from '@studio/player/core';

const player = new StudioPlayer(); // 注入 progressStorage 后才启用进度记忆
player.attach(document.querySelector('video'));
await player.load({ src: '/media.mp4', type: 'video/mp4', resourceId: 'demo' });
// 在用户播放操作中调用，并处理 play() 的拒绝：
await player.play();
// 离开宿主时：
player.destroy();
```

`load` 接受 URL、`SimpleMediaSource`、可取消的 `DeferredMediaSource` 或完整 `PlaybackPlan`。计划需有 `resourceId/mediaType/strategy/transport/playUrl`；
不同传输的备用源用 `fallback: { playUrl, transport, mimeType }`，`fallbackUrl` 只作同传输类型简写。
资源标识和存储由宿主提供，公共包不使用产品账号或数据库。

`load(input, { restart: true })` 明确从头播放，忽略该次加载的计划起播位置和存储断点；不会通过人工 `seek(0)` 伪造一次定位。Queue 自然循环复用此入口。开始新加载时先暂停旧媒体，再等待旧资源进度写入。

`play({ signal })` 可取消本次仍在等待数据的播放请求；已触发 `playing`、已成功起播或已由较新请求接替后，取消不再暂停媒体。Queue 用此机制在卸载时撤销自己尚未起播的请求，借用播放器的基础播放继续保留。

上游的结构化 `source` 赋值会去重；显式加载同一个 URL/引擎配置时，底座补一次公开 `load()`，保证重复条目重新加载且不遗留 `loading`。已变化的来源仍仅由 setter 加载一次。

### 交付结果契约（中立字段）

`load()`、`replaceSource()` 返回 `AdaptedSourceResult`，`SourceController.getCurrentSource()` 返回它的 `source`。**核心只认这些中立字段**，不暴露任何引擎描述：

| 字段 | 含义 |
| --- | --- |
| `source.src` | 实际交付地址，与 `PlaybackPlan.playUrl`（或简单来源的 `src`）逐字相同 |
| `source.type` | MIME 类型。明确 HLS 一律为 `application/vnd.apple.mpegurl`，其它为按扩展名/声明推导的值，推导不出时省略 |
| `source.transport` | 计划声明的传输协议，仅在计划输入时出现 |
| `source.headers` | 计划/简单来源声明的请求头，原样带出；是否真的能注入取决于承载方式 |
| `carrier` | `native` = 可直接用原生媒体元素；`managed` = 需要后端自己的承载元素（当前即 hls.js 的 MSE 路径） |
| `resourceId`、`originalPlan`、`metadata`、`fallbackUrl`、`expiresAt` | 与计划输入一致，语义不变 |

`carrier` 就是"是否需要 MSE"这一步的公开表达：明确 HLS 的来源为 `managed`，其余为 `native`（无扩展名且无类型提示时也按 `native` 处理，此时调用方应补 `type`）。`attach()` 与内部重绑按 `carrier` 选择承载元素。

Video.js 的 source 描述属于后端描述，不在中立契约里：它在 Video.js 后端模块（`src/backends/videojs/source.ts`）组装，并仍从 `source-adapter` 入口导出 `toVideojsSource(target, carrier)` 与 `isSameVideojsSource(previous, next)`，由底座在应用来源时调用。`carrier === 'managed'` 时组装出 `preferPlayback: 'mse'`，否则 `'native'`；只有 `managed` 且 `source.headers` 非空时才注入 `engine.hlsJs.xhrSetup`。消费者不需要手写 `media.source`。

### 第二后端：mpv（独立进程；实例端口可选 native surface）

**当前状态：已接入、可在本机复跑后端级通路；已在 `platform/local` 的最小 Electron/Windows 64 位宿主及 link-studio 开发期 smoke harness 完成 `load → ready → playing`、独立窗口与真实输出取证；U5-4B 又在隔离 Electron 宿主完成显式实例、`stream` UI、native child surface 及窗口/surface/键盘/renderer 文档生命周期自动化链路；P03 通过双实例 Electron 实测确认独立的 `--wid`、命名管道、暂停/播放、时间和音量事实。U5-5 已在 link-studio 工作树落入本地 main/preload/renderer 接线，但本轮 Electron 启动时本地 FastAPI 后端因 SQLite 缺少 `updated_count` 退出，产品播放器页未运行，未取得产品级播放或人工确认**。实际 100%/125%/150% DPI、应用页 reload 后重挂载、React unmount、实体交互与完整用户确认仍未验证；不据此声明 U5-4B 阶段门或产品支持通过。

U2 的后端选择、可执行文件和附加参数环境变量只服务无参数 smoke/诊断构造，**不供显式实例或混合产品 UI 读取**。U5 的构造要求每个 mpv 实例显式绑定 `PlayerInstance`、`PlaybackPort`、`SurfacePort` 和 main 生成的启动配置，不新增第二套状态总线（接缝签名已在 U1 定稿）：

| 环境变量 | 作用 |
| --- | --- |
| `STUDIO_PLAYER_BACKEND=mpv` | 仅在无参数 U2 smoke/诊断构造中选择 mpv；显式选择 `backend` 或 `PlayerInstance` 时忽略 |
| `STUDIO_PLAYER_MPV_BIN` | 仅供无参数 U2 smoke/诊断构造选择 mpv 可执行文件 |
| `STUDIO_PLAYER_MPV_ARGS` | 仅供无参数 U2 smoke/诊断构造传入附加参数；显式实例启动不读取该值 |

```js
// U2 smoke/诊断兼容路径；生产实例应显式绑定 main 生成的配置。
process.env.STUDIO_PLAYER_BACKEND = 'mpv';
process.env.STUDIO_PLAYER_MPV_BIN = 'D:/tools/mpv/mpv.exe';

const player = new StudioPlayer();   // 不需要 attach()
await player.load({ src: 'D:/media/episode.mp4', type: 'video/mp4' });
await player.play();
player.pause(); player.seek(30); player.setPlaybackRate(1.5);
await player.stop();                 // 释放当前来源，保留会话进程
player.destroy();                    // 结束会话进程
```

**不需要也不接受 `attach()`**：mpv 是非 DOM 媒体面；`load()`/`play()` 直接作用在会话上，宿主如需产品播放区域则注入 `SurfacePort` 管理 native surface。选择 mpv 后调用 `attach()` 抛 `TypeError`（`[StudioPlayer] 已选择 mpv 后端，它没有可挂载的承载元素：不需要也不接受 attach()，请直接使用 load()/play()。`），而不是静默忽略——静默忽略会让调用方以为传入的元素在承载播放。`detach()`/`destroy()` 的语义不变，并额外结束会话进程。

`carrier` 与后端选择是两件事：`carrier` 仍只表达"来源怎么交付"（明确 HLS → `managed`，其余 → `native`），mpv 不占其中任何一个取值，也不新增引擎专属取值；`SourceController.carrier()` 未改。

**mpv 缺失或版本不兼容时会拒绝加载，不会降级到 Video.js。** 显式实例必须有 main 生成的有效启动配置；缺少配置或不匹配的 surface/IPC 绑定会在构造时拒绝。U2 无参数兼容路径缺少 `STUDIO_PLAYER_MPV_BIN` 时，加载来源同步拒绝；可执行文件不存在或会话结束不了时启动失败。运行失败继续使用核心既有的错误通道——`state === 'error'`、`failed === true`，`error` 事件带 `code`（通常 `no-fallback`；有可用备用源时先按既有规则尝试备用源），错误文案前缀 `[StudioPlayer] mpv …`。低于声明下限 `v0.36.0` 的版本按不兼容拒绝（**只实测过 `v0.41.0-1023-g69e63f425`**）。

行为差异与降级（相对 Video.js 一路）：

| 项 | mpv 后端的行为 |
| --- | --- |
| `element` | **`null`**：不把引擎会话句柄当成媒体元素暴露。位置、时长、暂停、倍速、音量、静音与状态仍从 `currentTime/duration/paused/playbackRate/volume/muted/state` 读到，取值来自真实 mpv 的推送 |
| 事件 | `loadstart/statechange/sourcechange/play/playing/pause/timeupdate/durationchange/ended/error/stop/seeked/volumechange/ratechange` 照常；`timeupdate` 的密度由 mpv 推送决定 |
| 轨道 | 后端按 mpv 的 `track-list` 列举并选择音轨/字幕轨/视频轨；公共 `VideoTracksController` 只消费窄 `TrackPort`，因此音轨/字幕通路已可接 mpv。Video.js 的 DOM 列表和 mpv 的 `track-list` 仍分别留在各自适配器 |
| 画质档位 | mpv 不列举 HLS 自适应档位（只报当前视频轨），与 hls.js 的手动档位能力不同 |
| 请求头 | 经 mpv 的 `http-header-fields` 注入；**未用鉴权端点验证** |
| 功能层 | Queue、MainMedia、MediaSession 和轨道控制器读 `StudioPlayer` 中立事实/事件或 `TrackPort`，不以 `player.element` 作为 mpv 可用性的前置条件 |
| 页面生命周期 | 选择 mpv 后端时注册与承载元素路径同一组刷盘钩子（`pagehide`/`beforeunload`/`visibilitychange`）。这条路径没有 `attach()`，钩子改由后端选择处注册 |
| 会话面校验 | 会话按核心真正驱动的“媒体面”被使用（位置、时长、暂停、结束、定位、音量、静音、倍速、错误、播放/暂停/释放与事件订阅），由核心内的 `BackendMediaFace` 做**编译期**断言：会话侧改名或漏实现会构建失败，而不是运行时静默失效 |
| 运行环境 | Node 内建模块（`child_process`、`net`）按需动态载入；只实现 Windows 命名管道 |
| 产物范围 | `core` 的构建产物静态引用本后端（`dist/player.js` → `backends/mpv/index.js`），只取 `core` 的消费者会加载该模块但**拿不到它的符号**；“不从任何公开入口导出”指符号不可达，不指产物里没有这段代码 |

**当前不承诺**：三套套件与 `presets` 在未注入宿主端口时直接改用 mpv 画面、link-studio 的产品级 mpv 支持、非 Windows 平台的 IPC、字幕渲染、随包分发 mpv、浏览器内使用 mpv。link-studio 的本地 U5-5 接线已开始，但真实播放器页仍被应用后端启动失败阻断，不作为消费者验收结果。U5-3 已收口 `element === null` 下的公共功能控制器与窄轨道接线；真实 mpv 的功能层回归仍需带官方 mpv 与媒体样本的专项执行，不能由确定性端口夹具替代。

U5-4B 的平台宿主用法是按实例注入端口；`surfacePort` 由 Electron 宿主实现，公共包不导入 `electron`，也没有新增 `@studio/player/electron` 空入口：

显式 mpv 实例的启动配置由 Electron main 创建并校验；配置按实例包含可执行文件、native window ID、IPC 名和固定的 `gpu-next`/`wasapi` 输出。构造器会拒绝未知字段、错误实例 ID、非法 surface target 和非白名单输出。renderer 只拿到播放与 surface 白名单代理。

```js
import { StudioPlayer } from '@studio/player/core';
import { createPlayerInstance } from '@studio/player/contracts';

const instance = createPlayerInstance('host-player-1', 'mpv');
// Electron main only. The HWND and launch configuration stay out of renderer/preload.
const player = new StudioPlayer({ backend: 'mpv', instance, surfacePort, mpv: {
  instanceId: instance.instanceId,
  executable: approvedMpvPath,
  ipcName: uniquePipeName,
  surfaceTarget: { type: 'native-window', windowId: surfaceHwndDecimal },
  videoOutput: 'gpu-next',
  audioOutput: 'wasapi',
  logFile: instanceLogPath,
} });
```

`surfacePort` 和 `mpv.instanceId` 必须与 `instance` 属于同一宿主所有权；surface 代理只负责 `create/resize/show/hide/focus/requestFullscreen/destroy`，不把 native handle、IPC 端点或任意 mpv 命令暴露给 UI。Video.js 默认路径仍使用省略 `backend`/`instance`/`surfacePort`/`mpv` 的既有构造方式。

真实 mpv 的可复现检查在 `tests/mpv-backend.test.mjs`：**不设置下列环境变量时跳过**（跳过不等于通过）；设置后覆盖能力声明、会话操作、事实反馈、输出面与轨道，以及经核心驱动的完整通路：

```powershell
$env:STUDIO_PLAYER_MPV_BIN='D:/tools/mpv/mpv.exe'
$env:STUDIO_PLAYER_MPV_MEDIA='D:/media/episode.mp4'
$env:STUDIO_PLAYER_MPV_HLS='D:/media/master.m3u8'   # 多轨 HLS 样本，用于轨道用例
npm.cmd --prefix packages/player run test
```

环境变量只影响无参数 U2 smoke/诊断构造；显式 Video.js/mpv 实例相互独立，显式 mpv 配置不会读取进程环境。受限沙箱下 Windows 命名管道不可连接（`EPERM`），真实专项需要能创建命名管道的环境。

P03 的双实例真实 Electron 验证记录见[实例隔离证据](../evidence/u5-4b-mpv-instance-isolation.md)。该结果证明启动隔离与事实隔离，不覆盖应用页重新挂载、独立安装升级回退、真实 DPI 或产品消费者验收。U5-5 最小 link-studio 接线及启动阻塞见[消费者证据](../evidence/u5-5-link-studio-consumer.md)；产品验收仍待完成。

### U5-2 宿主端口与实例契约

`@studio/player/contracts` 的 `src/contracts/ports.ts` 是端口定义的唯一位置。公开类型包括 `PlayerInstance`、`PlayerPorts`、`PlaybackPort`、`TrackPort`、`SurfacePort`、`PlayerInstanceId`、`SurfaceGeometry`、播放/呈现白名单请求和 `PlayerLifecycleState`；实现或宿主不得在其它模块复制这些定义。

`PlayerInstance` 必须显式选择 `videojs` 或 `mpv`。`PlaybackPort` 只承接 `StudioPlayer` 已有的播放操作、事实和事件；`TrackPort` 只承接音轨/字幕快照、选择和变更订阅，不承接画质或整播放器状态；`Queue`、`MediaSession`、`MainMedia` 和 `VideoTracksController` 继续消费这些已有事实，不创建包揽全部状态的新总线。mpv 实例必须注入 `SurfacePort`，Video.js 默认路径不接受 native surface 端口。当前 `StudioPlayer` 的默认构造、`mountVideoPlayer()` 入口和 Video.js 行为保持不变；U5-3 已完成 TrackPort 的运行时接线，U5-4B 已在平台最小 Electron 宿主完成 native surface 接线，公共宿主入口仍未创建。link-studio 的本地宿主接线在 U5-5 中实现，但其产品运行仍未通过验收。

`SurfacePort` 只有 `create/resize/show/hide/focus/requestFullscreen/destroy`。renderer/preload/main 之间只允许 `PLAYER_SURFACE_CHANNEL` 和 `SURFACE_OPERATIONS` 中的请求；每个请求带实例标识，main 侧用 `SurfaceCommandGate` 校验 sender 所有权、实例匹配、调用顺序和销毁后的拒绝规则。矩形与 `devicePixelRatio` 由 `validateSurfaceGeometry()` 校验。请求不返回 HWND、命名管道、子进程、文件写入或任意命令能力。

所有 UI 卸载、renderer 重载、BrowserWindow 关闭、IPC 断开、mpv 退出和 helper 退出都复用 `PLAYER_CLEANUP_ORDER`：停止播放、销毁播放、释放 IPC、销毁 surface、清除 renderer 监听。`destroy` 可重复调用；真实 native 资源释放后才由 main 调用 gate 的 `release()` 清除所有权记录。

U5 首期路线是 Windows Electron dedicated native child surface + mpv `--wid`；Overlay 只作诊断/回退，libmpv/宿主另行渲染延后。首期支持结论只覆盖已验证的 Windows 64 位 + Electron。宿主适配长期归属为现有包的可选 `@studio/player/electron` 子路径，本阶段不创建空导出；macOS、Linux、Tauri 和移动端没有预留或支持声明。

`stream` 的 mpv 首期功能范围是播放/暂停、定位、音量/静音、倍速、时间/时长/状态/错误、队列/结束控制、睡眠、音轨和可用字幕。没有真实来源的画质档位与 PiP 隐藏并说明原因；它们不能通过请求伪造为可用能力。

## 行为约定

| 行为 | 约定 |
| --- | --- |
| 挂载 | 传媒体元素或包含媒体的容器；找不到时抛 TypeError，不查询其他页面元素。标签识别不等于该引擎已验证 |
| 加载与失败 | 最后一次 `load` 生效，被替代/销毁的请求拒绝为 AbortError；不支持的新源停止旧媒体，尝试备用源，失败后进入 `error` / `failed` |
| 来源变化 | 刷新、回退各应用一次；同源默认仅一次备用尝试。换源事件不是实际播放成功证明 |
| 到期刷新 | 有 `expiresAt` 和 resolver 才启用；默认每 30 秒检查、提前 60 秒刷新；仅返回 URL 时丢弃旧过期时间 |
| 换源续播 | 保留有效位置与播放意图；仅初次位置尚未建立时可读保存断点，手动定位至 0 优先；显式暂停取消续播，`autoResume: false` 不禁止位置延续 |
| 自动恢复 | 每个来源仅一次；API 或原生控件定位取消迟到的自动位置写入 |
| 暂停/停止/关闭 | `pause()` 保留位置与来源；`stop()` 保存断点并释放来源，保留挂载元素和队列；`close()` 停止完成后发出界面关闭请求，详细见下节 |
| 进度 | 连续跨越完播边界或 ended 清除；尾部/暂停上报不重建记录，显式定位或重播可以重新保存 |
| 清理 | `detach` 停止媒体、清除元素来源、使等待中的 load 失效、解绑媒体/页面事件并刷新进度；`destroy` 还通知可选功能释放任务并关闭远端会话；内部媒体路径重绑不等于 detach |
| 错误通道 | `error` 附 `attempted-fallback/no-fallback/fallback-limit`；当前媒体 play 拒绝统一发一次 `playerror` 并释放主媒体归属；调用方仍处理 Promise，取消 AbortError 不作为播放失败通知 |
| 状态 | `statechange` / `state` 提供 idle/loading/ready/playing/paused/stopped/ended/error；实际位置、时长、暂停状态读取媒体属性 |

新增事件：`loadstart(input)` 表示开始一次公开加载，`pauseintent` 表示显式暂停请求（已暂停时也发出），`mediachange` 表示承载元素变化，`detach` / `destroy` 用于功能清理。`volumechange/ratechange/seeked/playing` 转发当前媒体事件；`play` 可在数据就绪前发出，实际起播使用 `playing` 或成功完成的 `play()`。原生控件/预设皮肤的暂停也取消换源续播意图。`currentMetadata` 返回计划元数据或简单来源的标题。

## 契约层边界

`contracts` 入口用在这些场景：你要自己实现一个端口（进度存储、来源 resolver、系统媒体），或要按类型写自己的控制器。

- 契约层维护类型、端口及无宿主依赖的运行时校验，不依赖具体引擎、Electron 或 Node。
- 除计划类型保护和默认进度策略外，`contracts/ports.ts` 已包含实例绑定、请求解析、几何校验与有状态的 `SurfaceCommandGate`。Gate 只验证命令所有权和生命周期，不创建窗口或启动进程；真实 sender 身份仍由宿主校验。
- 契约不反向引用核心、功能模块、UI 或预设；类型使用 `import type`，需要执行校验时按值导入。公开符号以代码为准。
