# @studio/music-sources

版本：v0.13 · 2026-10-20 · 匿名目录及点播；登录分支待本人验收；未发布

无界面来源库，提供 B 站音乐栏目、搜索、分 P、只读收藏夹/合集与独立音轨，以及 YouTube 视频搜索、歌单、元信息和音频准备。新增 B 站扫码会话、两家账号/个人只读列表及 YouTube 登录态工具交付；实现与真实账号验收分别记录。主实现 TypeScript，输出 ESM 与声明；首期解析和媒体交付运行在 Node。来源核心不依赖界面、数据库、账号存储、player 或 Sources。

完整签名、导出与固定依赖由[源码契约](src/contracts.ts)、[包清单](package.json)维护。YouTube.js 包装视频目录，播放使用宿主显式提供的 yt-dlp；Music 首页/搜索与 YouTube.js 播放解析留在[实验](../../../labs/audio-video/music-sources/README.md)。正式 Music 搜索返回 `unsupported`；视频推荐要求验证宿主会话，真实内容未验收。协议版本随账号/栏目操作升级，旧 HTTP 客户端必须一起更新。

## 直接调用

在本目录执行 `npm.cmd ci`、`npm.cmd run check`。可通过本地 tarball 安装；从[最小样例](../../../examples/audio-video/music-sources/README.md)开始。导入任何入口均不联网、不监听、不读取凭据。

```js
import { MusicSources, identify } from '@studio/music-sources';
import { BilibiliProvider } from '@studio/music-sources/bilibili';
import { createNodeHost } from '@studio/music-sources/node';

const host = createNodeHost({ fetch });
const music = new MusicSources(host, { bilibili: new BilibiliProvider() });
try {
  const shelves = await music.discover('bilibili');
  const page = await music.search('bilibili', { query: '原创音乐', limit: 20 });
  const entry = await music.metadata(identify('BV1NPtC6qEeA'));
  const playback = await music.prepare({ ref: entry.ref, codecs: ['mp4a'] });
  // playback.delivery contains host-only URL/headers; persist entry.ref instead.
} finally { await music.dispose(); }
```

`identify` 识别视频/BV、YouTube 歌单、B站 space 收藏夹 fid 与 collectiondetail sid 链接，不自动请求短链。`normalizeMusicInput(api, input, options)` 返回规范来源引用，视频按元信息解析，B站链接中的 p 转为真实 cid；越界序号明确失败。视频元信息默认选择第一分 P，并返回完整分 P。搜索尚无 cid 时只保存视频身份，准备前完成规范化；player 桥接会先规范化再创建延迟来源。

分 P 的单个/勾选/全部/从某 P 开始由公开选择函数处理。选择真实 cid，勾选结果保留元信息快照中的原顺序；未知 cid、重复选择或错误身份明确拒绝。`selectMusicParts` 为纯函数，`resolveMusicParts` 查询一次元信息，`resolveMusicEntries` 每个视频读取一次元信息并保留输入顺序及重复。YouTube 视频仍是单项，来源库不写收藏或播放队列。行为与产品接入见[分 P 证据](evidence/parts-2026-10-07.md)。

栏目各自携带页或错误。B站视频搜索先排除明确标记为课程、直播等非视频类型的混入卡片，再解析投稿；保留视频原顺序与上游分页，视频字段损坏仍明确失败。两家分页游标只公开临时不透明句柄，绑定操作、查询、页长与凭据版本，有数量和期限限制，销毁后失效。需要去重跨页结果时由产品按 `resourceId` 处理来源实时变动。来源错误与成功的空结果分开，风控 voucher、HTTP 412、403、429 等不会转换为空页。混合卡片修复见[搜索证据](evidence/search-cards-2026-10-18.md)。

网络、时钟、凭据引用及可选元信息缓存显式注入。缓存不保存音频 URL；宿主凭据端口提供递增/变更的 revision 和可选来源绑定，使旧游标与媒体租约失效。宿主端口应响应取消信号，返回时不得继续保留未计账工作。`dispose()` 取消工作并等待释放。B 站搜索使用平台显式签发的匿名访客 Cookie，仅在内存短期保存；不建立账号，真实 412/voucher 仍明确失败。

同身份/凭据版本的在途元信息以及 B站访客/WBI 初始化合并，各调用者独立取消并取得独立副本；最后一个调用者退出等待物理清理。HTTP 429 的有效 Retry-After 转为有界等待信息，来源不自行重放请求。可选 `MusicHost.onDiagnostic` 提供阶段、状态、耗时和媒体尝试关联，不包含资源身份、媒体地址或凭据；观察者不拥有业务操作。

## 登录会话

可选 `./discovery` 提供有界 B站目录协议客户端、真实字段投影、官方周榜期次，以及 YouTube 音乐区公开歌单／电台解析与显式加载器。签名复用 B站同一 WBI 算法，同作用域初始化合并且调用者取消隔离；单响应沿现有 JSON 字节上限。B站投影只带实际取得的分区、分类、标签和发布时间，缺少字段保持未知。官方榜单保留最新／历史期次及原始曲目顺序，缺少可播放视频不生成条目；YouTube 仅返回公开目录事实，不断言曲目语言。入口导入不联网；只有调用 YouTube 加载器才加载其可选 peer。

榜单返回的当前期次、期次列表与曲目均为独立副本，调用者修改结果不会改变后续查询的缓存。受控回归与本地隔离消费见[缓存修复证据](evidence/discovery-cache-fix-2026-10-12.md)。

音乐范围、中文地区华语／粤语歌单优先、栏目数量、候选缓存、分页和有效展示由产品装配；公共入口不持有推荐或听歌历史，不扩展账号或媒体行为。慢听抽取见[阶段 5 证据](evidence/stage5-2026-10-11.md)，两产品各自固定组合及最终独立交付见[阶段 6 证据](evidence/stage6-2026-10-11.md)；本阶段没有公共来源变更，不统一升级枕边声或 Player。

B 站扫码由 `beginLogin` 申请、`pollLogin` 查询、`cancelLogin` 取消。宿主提供 `credentials.write`，库在成功后验证账号再交付 Cookie，返回值只包含中立状态和账号信息；同一凭据引用的挑战有期限与轮询间隔，取消会终止在途请求。二维码内容由宿主展示，没有登录 UI 或密码收集。最小调用见[扫码样例](../../../examples/audio-video/music-sources/login-bilibili.mjs)；本轮用户选择暂不登录，真实成功分支和私人列表保持未验收。

两家通过 `account` 检查显式会话，`library` 获取个人只读列表，再沿原 `list` 读取条目。YouTube 的视频推荐通过 `discover` 和 `shelf` 分页消费。会话获取、保存及重新登录由宿主负责；YouTube 不提供 Google 登录 UI，也不把受限 TV OAuth 当作通用认证。上游依据见 [YouTube.js 认证](https://ytjs.dev/guide/authentication)和 [yt-dlp 会话说明](https://github.com/yt-dlp/yt-dlp/wiki/Extractors#exporting-youtube-cookies)。

`disconnect` 移除宿主为该来源保存的会话并清理适配器缓存，HTTP 服务同时撤销关联媒体租约、等待读取取消。直接宿主另外调用 `delivery.revoke(credentialRef)`。这项操作只移除本库使用的会话引用，不承诺撤销平台所有设备的登录。凭据端口没有持久化实现，默认匿名；同一引用应固定绑定一个来源。HTTP 由宿主依据调用者与来源选择引用，客户端不能传入平台 Cookie 或凭据引用；鉴权/媒体请求所需的会话 Cookie 由宿主提供。

## 媒体与 HTTP

准备结果区分稳定身份、真实格式与临时交付，保留 MIME、codec、container、有效期及备用地址。默认仍准备独立音轨；显式 `media: 'video'` 接入点播画面与声音。B站使用单段 AVC/AAC MP4，拒绝多段和仅画面 DASH；YouTube 选择带音轨的 HTTP 文件，或将提取器实际列出的 VOD HLS 视频与音频列表配对。没有音轨、直播、DRM、SABR/OTF 和不符合编码约束的结果不算可播。不自动转码或安装工具。

B站搜索指定 `mode: 'video'` 时覆盖普通投稿分区，原默认／music 模式继续限音乐区。搜索实际返回的标签及 YouTube 元信息 keywords 作为可选 `tags`，缺少时保持未知。标题／作者／标签筛选、候选范围与缓存、ASMR 策略归产品。公共能力以 `video-search`／`video-prepare` 表明增量支持。

`formats` 只查询可用音轨事实，不提供地址或发布租约。准备时可显式选择最高/最低码率、无损或指定格式；编码约束始终优先，缺少符合条件的音轨明确拒绝。省略政策保持原选择，B站默认 AAC；无损是显式请求，FLAC 不等同于 Hi-Res。HTTP 扩展沿用原协议封装，客户端依据 capabilities 判断新能力，旧服务不支持音质政策时明确拒绝。

浏览器媒体元素无法注入来源所需请求头。使用 `MediaDelivery` 发布受控短期租约，`createMusicService` 将统一操作和媒体流挂到已有服务。独立 Node 示例使用 Hono；监听、服务身份、允许的 Origin、账户上下文和网络出口由宿主配置。服务不接受客户端直接提交平台 Cookie 或任意媒体 URL，前端只获得临时媒体地址。

客户端先握手，协议不匹配明确失败；服务和客户端共用 `MUSIC_PROTOCOL`。直接调用与 HTTP 的条目/错误/分页语义一致，HTTP 准备另外创建媒体租约。Python/Go 可以按[HTTP 调用样例](../../../examples/audio-video/music-sources/consume_http.py)消费同一操作封装，无额外语言取源实现。

流按需读取，单范围 `Range`、HEAD、取消和背压沿 Web Streams 转发；不缓存整曲。验证来源返回的 Content-Range；B 站的精确范围 200 响应规范化为 206，无证据的忽略 Range 仍失败。仅允许来源 CDN 域名内有限重定向，跨域移除认证头；Cookie 不随 B 站媒体交付转发。截断与读取失败保持失败。租约关闭与宿主销毁等待已拥有的读取结束，具备有界并发、数量和期限。

0.2.8 的 `MediaDelivery.read` 第五参数可显式区分 `connectMs`、`firstByteMs`、`idleMs` 与可选 `totalMs`，各值为 1–3600000 的整数。连接预算覆盖凭据核对与响应头前的全部候选；首次非空正文、后续等待读取分别计时。下游背压不算上游空闲；HLS 清单也按进度更新空闲预算。省略该参数保持原 `readTimeoutMs`／默认 120 秒总寿命，既有消费者不会自动改变策略。慢听仅在桌面租约启用分段政策，受控证据见[慢读与工具复用](evidence/desktop-read-reuse-2026-10-20.md)。

HLS 发布结果只含租约 URL 和 `transport: 'hls'`；选定音视频、初始化片段、密钥与媒体段由服务端不透明子资源映射交付，不暴露上游签名地址，不接受客户端任意 URL。每列表最多 4 MiB、每租约最多 8192 个资源，只接受 HTTPS googlevideo 域名及有 ENDLIST 的点播列表；不支持变量替换、内容转向或直播。清单自身不接受 Range，媒体段沿用 Range／HEAD／取消。宿主为浏览器装配可播放 HLS 的元素；桥接仍保留同一稳定资源身份及租约生命周期。

媒体响应提交前可在同音轨的备用 CDN 中有界尝试，所有尝试共享取消与总时间预算。连接、可恢复媒体状态或范围协议失败可以换地址；权限/风控、429 与不允许的主机不盲目重试。开始交付后的截断和超时明确失败，不拼接不同地址的媒体字节。地址过期重新准备与播放状态仍由既有消费契约处理。

YouTube 使用 `YtDlpResolver` 的规范视频 URL JSON 提取，不执行下载；宿主显式给出路径、前置参数、JS runtime 和可选代理。禁用工具配置、缓存及隐式浏览器凭据/代理。登录态交付要求显式 `cookieDirectory`，宿主保证该目录的访问权限；库把提供的 Cookie 写为短期工具输入，成功、失败、取消和销毁均等待删除，不将值放进进程参数或结果。进程输出、等待和并发有界，取消终止其进程树。工具和 EJS 不随包分发，安装/升级由宿主维护；依赖材料见[第三方说明](THIRD-PARTY.md)。

宿主可显式设置 `reuseMs`（0–10000，默认 0）复用同身份的已完成格式提取，最多 8 份，仅内存保存；按来源、视频、media、scope、凭据引用／修订及实际 Cookie 隔离，有效期不超过签名地址到期前一秒，缺少到期证据不复用。失败不保留，不共享在途取消信号，返回独立副本；销毁清空，来源代次由宿主以 resolver 生命周期隔离。缓存不写盘，不对外返回内部地址或凭据；移动／未启用的宿主仍每次提取。

## player 桥接与边界

同级 [music-app](../../../../music-app/README.md) 通过固定制品接入匿名目录、Hono 媒体交付与 player 薄桥接，并消费本轮分 P 处理与前批来源完善；产品界面、播放及存储结果见[产品验收](../../../../music-app/docs/验收.md)。产品宿主、身份与 UI 留在产品，本页的账号、地区、工具及设备限制继续适用。

同级[枕边声](../../../../zhenbiansheng/docs/进度与交接.md) 通过固定导出消费匿名普通视频搜索、实际标签、分 P 和带声音 MP4／配对 VOD HLS，受控与真实边界见[点播证据](evidence/video-vod-2026-10-09.md)。人工规则、候选缓存、资料和页面由产品维护；直播与账号未随此接入。

`MusicPlayerBridge` 提供规范化后的 `DeferredMediaSource` 和已有 `SourceResolverPort`。首次播放按需准备，过期/恢复重新取源；换源位置、暂停意图、队列和重试预算由现有 player 维护。桥接选项 `media: 'video'` 在初次准备与刷新时保持，HLS 按实际 transport 交付。桥接只映射计划和租约生命周期，不增加播放状态核心。

来源包自有桥接会在初次准备及刷新时保持音质和指定格式政策，不增加播放器状态契约。原来源完善与设备/播放验收分别记录于[完善证据](evidence/public-improvements-2026-10-07.md)；枕边声所需的公共 HLS 展示／释放修正另由[Player 证据](../player/evidence/hls-release-2026-10-09.md)维护。

```js
import { MusicPlayerBridge } from '@studio/music-sources/player';
import { StudioPlayer } from '@studio/player/core';

const bridge = new MusicPlayerBridge(httpClient, { codecs: ['mp4a'] });
const player = new StudioPlayer({ sourceResolver: bridge.resolver });
player.attach(existingAudioElement);
await player.load(await bridge.source(entry.ref));
await player.play();
// Shutdown order: player, bridge, client, host delivery, source library.
await player.destroyAsync();
await bridge.dispose();
```

桥接的 JavaScript 导入可缺席 Player peer；严格 TypeScript 消费需要其公开声明，实际播放仍须显式装配播放器。选择该桥接入口的最小 bundle 与根入口、Node 或 UI 的依赖范围分别验证，不能互相推导。独立正负类型消费、装配及所选 bundle 见[桥接交付核对](../music-library/evidence/dependency-delivery-2026-10-05.md)。

使用直接库时，宿主给桥接提供 `publish/release/touch` 端口；缺少请求头交付能力会明确拒绝。每个桥接实例固定一个凭据引用，首次准备和刷新保留来源调用选项；切换账号时销毁旧实例及其租约。真实匿名网络刷新已验证；测试用短租约触发自动到期检查，CDN 原地址的小时级自然到期、网络出口切换和长时间稳定性未验收。

首版匿名结果见[原验收证据](evidence/acceptance-2026-10-03.md)，新增分支、网络限制及实测见[完善证据](evidence/improvements-2026-10-03.md)。Windows x64 Node 与 Edge 已有匿名来源、解码、WebAudio 信号、完整曲目与生命周期证据；实体扬声器/人工听感、Electron/Tauri、实体移动端、真实登录、地区受限内容和高码率/FLAC/Dolby 未验证。这些公共库示例与夹具的结论限定原批次；产品接线与页面验收由前述产品说明独立维护。
