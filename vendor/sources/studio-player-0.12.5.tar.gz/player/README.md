# @studio/player 0.12.5

这是慢听固定依赖的公开源码快照，正式维护来源为 Studio platform。

固定安装制品内随附的 src 原始源码；补充独立 TypeScript 构建配置和开发依赖锁。历史 Player 测试未保存在该制品中，本归档仅提供源码构建入口。

## 构建

使用 Node.js >=24.15.0 和 npm。将三份公共包源码解压到同一目录，保留同级的 player、music-sources 和 recommendation 目录。先构建 player，再构建其他包；在对应包目录执行：

```powershell
npm ci
npm run build
```

公开类型和实现位于 src/。使用入口由 package.json 的 exports 定义。本归档用于源码阅读和修改；构建命令没有在本次规范整理中执行，不保证与历史制品逐字节相同。

## 授权与维护

本交付原创代码按 AGPL-3.0-only 提供，见 LICENSE 和 NOTICE；第三方材料保留各自声明。本次仅补授权、构建材料和说明，未改写运行源码或升级慢听的固定依赖。公共修复由维护者同步回 platform，再生成新版本，不在此快照长期维护分叉。
