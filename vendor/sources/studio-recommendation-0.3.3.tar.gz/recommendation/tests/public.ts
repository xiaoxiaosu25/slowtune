import { RecommendationSession, DEFAULT_CONFIG, resolveSettings, execute, saveSettings, type CandidatePort, type SettingsDocument, type AccessContext, type RevisionPort } from '@studio/recommendation';
const document: SettingsDocument = { schema: 1, revision: '1', preset: { id: 'file', revision: '1', config: DEFAULT_CONFIG }, overrides: { batchSize: 2 } };
const access: AccessContext = { user: 'u', authorizationRevision: '1', sourceRevision: '1', grants: [{ source: 'files', roots: ['/'] }] };
const port: CandidatePort = { source: 'files', revision: '1', async read({ signal, limit, access }) { signal.throwIfAborted(); void limit; void access; return { items: [] }; } };
const store: RevisionPort = { async compareAndSet({ next }) { return { status: 'saved', document: next }; } };
const session = new RecommendationSession(); session.activate({ settings: document, access, ports: [port], seed: '1' });
const config = resolveSettings(document).config;
execute({ candidates: [], config, access, seed: 'x' });
void saveSettings(store, { user: 'u', expectedRevision: '0', next: document, signal: new AbortController().signal });
// @ts-expect-error temporary player instances are not stable candidate identities
const badPort: CandidatePort = { source: 'files', revision: '1', async read() { return { items: [{ queueId: '1' }] }; } };
// @ts-expect-error schema version is fixed and must be explicitly migrated
const unsupported: SettingsDocument = { ...document, schema: 2 };
void badPort; void unsupported;
