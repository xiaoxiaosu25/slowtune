import { DEFAULT_CONFIG } from '../dist/index.js';
export const config = (override = {}) => ({ ...structuredClone(DEFAULT_CONFIG), ...override });
export const access = { user: 'fixture-user', authorizationRevision: 'auth-1', sourceRevision: 'sources-1', grants: [{ source: 'files', roots: ['/music'] }, { source: 'other', roots: ['/music'] }] };
export const row = (id, overrides = {}) => ({ identity: { namespace: 'file', id: String(id) }, source: 'files', authorized: true, available: true, title: '轻语 music', path: '/music/album/' + id, directory: '/music/album', media: 'audio', tags: [], categories: ['music'], author: 'A', provenance: 'index:fixture-1', ...overrides });
export const group = (id, terms, fields = ['title'], mode = 'any') => ({ id, terms, fields, mode });
export const settings = (overrides = {}, revision = '1') => ({ schema: 1, revision, preset: { id: 'fixture', revision: 'preset-1', config: config(overrides) }, overrides: {} });
export const port = (rows, source = 'files') => ({ source, revision: 'index-1', async read({ cursor, limit, signal }) { signal.throwIfAborted(); const start = Number(cursor ?? 0); return { items: rows.slice(start, start + limit), ...(start + limit < rows.length ? { nextCursor: String(start + limit) } : {}) }; } });
