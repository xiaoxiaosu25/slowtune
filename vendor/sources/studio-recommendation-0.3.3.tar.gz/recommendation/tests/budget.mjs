import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { execute, LIMITS, RecommendationSession } from '../dist/index.js';
import { row, config, access, settings, group } from './fixture.mjs';
const mode = process.argv[2];
if (!mode) {
  // Measure both workloads in fresh default-runtime processes, including peak RSS.
  const reports = [];
  for (const workload of ['direct', 'index-session','large-batch']) {
    const result = spawnSync(process.execPath, [fileURLToPath(import.meta.url), workload], { encoding: 'utf8', windowsHide: true });
    if (result.status !== 0) { console.log(result.stdout); console.error(result.stderr); process.exit(result.status ?? 1); }
    reports.push(JSON.parse(result.stdout));
  }
  const report = { node: process.version, platform: process.platform, reports, limits: LIMITS, status: 'passed', scope: 'Synthetic facts; fresh default-runtime processes; no production or product benchmark' };
  if (process.env.RECOMMENDATION_BUDGET_REPORT) await writeFile(process.env.RECOMMENDATION_BUDGET_REPORT, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
} else {
  const rssBefore = process.memoryUsage().rss, peakBefore = process.resourceUsage().maxRSS * 1024, started = performance.now();
  const create = i => row(i, { title: `music ${i}`, author: String(i % 100), directory: '/music/' + i % 100 });
  const budget = { candidates: LIMITS.candidates, bytes: LIMITS.bytes, timeoutMs: LIMITS.timeoutMs };
  const preferences = Array.from({ length: 10 }, (_, i) => ({ ...group(`rule-${i}`, ['music']), weight: 1 }));
  let executionMs, requestMs;
  if (mode === 'direct'||mode==='large-batch') {
    const rows = Array.from({ length: LIMITS.candidates }, (_, i) => create(i));
    const size=mode==='large-batch'?500:12;
    const start = performance.now(), result = execute({ candidates: rows, config: config({ budget, preferences, order: 'random',batchSize:size }), access, seed: 'budget-1' });
    executionMs = performance.now() - start; assert.equal(result.diagnostics.read, LIMITS.candidates); assert.equal(result.items.length, size); assert(executionMs <= LIMITS.executionMs);
  } else {
    const port = { source: 'files', revision: 'fixture-1', async read({ cursor, limit, signal }) { signal.throwIfAborted(); const start = Number(cursor ?? 0), size = Math.min(limit, LIMITS.candidates - start); return { items: Array.from({ length: size }, (_, i) => create(start + i)), ...(start + size < LIMITS.candidates ? { nextCursor: String(start + size) } : {}) }; } };
    const session = new RecommendationSession(); session.activate({ settings: settings({ budget, preferences, order: 'random' }), access, ports: [port], seed: 'budget-1' });
    const start = performance.now(), batch = await session.preview(); requestMs = performance.now() - start;
    assert.equal(batch.diagnostics.read, LIMITS.candidates); assert.equal(batch.complete, true); assert.equal(session.diagnostics().history, 0); assert(requestMs <= LIMITS.timeoutMs);
    session.dispose(); assert.equal(session.diagnostics().activeReads, 0);
  }
  const rssAfter = process.memoryUsage().rss, peakAfter = process.resourceUsage().maxRSS * 1024, rssDelta = Math.max(rssAfter, peakAfter) - rssBefore;
  const report = { mode, candidates: LIMITS.candidates, rules: preferences.length, executionMs, requestMs, totalMs: performance.now() - started, rssBefore, rssAfter, peakBefore, peakAfter, rssDelta, rssLimit: 128 * 1024 * 1024 };
  console.log(JSON.stringify(report)); assert(rssDelta <= report.rssLimit, `RSS delta ${rssDelta} >128MiB`);
}
