import test from 'node:test';
import assert from 'node:assert/strict';
import { RecommendationSession, saveSettings } from '../dist/index.js';
import { access, row, settings, port } from './fixture.mjs';
const activation = (ports, overrides = {}) => ({ settings: settings(overrides), access, ports, seed: 'fixed' });
const tick = () => new Promise(resolve => setTimeout(resolve, 5));

test('preview uses same executor and seed; only confirmed display mutates history and batch', async () => {
  const session = new RecommendationSession(); session.activate(activation([port([row(1), row(2), row(3)])], { batchSize: 2, order: 'random' }));
  const preview = await session.preview(); assert.equal(session.confirm(preview.token).accepted, false); assert.equal(session.diagnostics().history, 0);
  const first = await session.nextBatch(); assert.deepEqual(first.items, preview.items); assert.equal(first.batch, 0);
  const confirmation = session.confirm(first.token); assert.equal(confirmation.accepted, true); assert.equal(confirmation.recent.length, 2); assert.equal(session.confirm(first.token).accepted, false);
  const second = await session.nextBatch(); assert.equal(second.batch, 1); assert.equal(second.items.length, 1); assert(second.items.every(i => !confirmation.recent.includes(i.key)));
  session.dispose(); assert.deepEqual(session.diagnostics(), { activeReads: 0, pending: 0, history: 0, disposed: true });
});
test('cancel releases cooperative host reads; failure/cancellation do not consume history', async () => {
  let active = 0, released = 0;
  const slow = { source: 'files', revision: '1', read({ signal }) { active++; return new Promise((resolve, reject) => { const timer = setTimeout(() => { active--; resolve({ items: [row(1)] }); }, 1000); signal.addEventListener('abort', () => { clearTimeout(timer); active--; released++; reject(new Error('cancelled')); }, { once: true }); }); } };
  const session = new RecommendationSession(); session.activate(activation([slow]));
  const ctrl = new AbortController(), work = session.nextBatch(ctrl.signal); await tick(); ctrl.abort();
  await assert.rejects(work, e => e.code === 'cancelled'); await tick();
  assert.equal(active, 0); assert.equal(released, 1); assert.equal(session.diagnostics().activeReads, 0); assert.equal(session.diagnostics().history, 0);
  session.dispose();
});
test('timeout aborts host and releases timer/read slots', async () => {
  let released = false;
  const slow = { source: 'files', revision: '1', read({ signal }) { return new Promise((_, reject) => signal.addEventListener('abort', () => { released = true; reject(new Error('aborted')); }, { once: true })); } };
  const session = new RecommendationSession(); session.activate(activation([slow], { budget: { candidates: 10, bytes: 4096, timeoutMs: 20 } }));
  await assert.rejects(session.nextBatch(), e => e.code === 'timeout'); await tick(); assert(released); assert.equal(session.diagnostics().activeReads, 0); session.dispose();
});
test('late response cannot overwrite configuration/source; uncooperative read retains concurrency slot', async () => {
  let resolveOld;
  const old = { source: 'files', revision: 'old', read() { return new Promise(resolve => { resolveOld = resolve; }); } };
  const session = new RecommendationSession(); session.activate(activation([old]));
  const pending = session.nextBatch(); const rejection = assert.rejects(pending, e => e.code === 'stale'); await tick();
  const next = activation([port([row(2)], 'files')]); next.access = { ...access, sourceRevision: 'new' }; next.settings.revision = 'new';
  session.activate(next); await rejection;
  assert.equal(session.diagnostics().activeReads, 1); await assert.rejects(session.nextBatch(), e => e.code === 'busy');
  resolveOld({ items: [row(1)] }); await tick();
  const result = await session.nextBatch(); assert.deepEqual(result.items.map(i => i.candidate.identity.id), ['2']); assert(session.confirm(result.token).accepted); session.dispose();
});
test('host page count, memory, malformed source and cursor budgets are enforced', async () => {
  const session = new RecommendationSession(); session.activate(activation([port(Array.from({ length: 1200 }, (_, i) => row(i)))], { budget: { candidates: 700, bytes: 1024 * 1024, timeoutMs: 30000 } }));
  const result = await session.nextBatch(); assert.equal(result.diagnostics.read, 700); assert.equal(result.complete, false); assert(result.truncatedBy.includes('candidates'));
  session.activate(activation([port([row(1), row(2)])], { budget: { candidates: 10, bytes: 400, timeoutMs: 30000 } }));
  const small = await session.preview(); assert.equal(small.complete, false); assert(small.truncatedBy.includes('bytes')); assert(small.diagnostics.read <= 1);
  session.activate(activation([{ source: 'files', revision: '1', async read() { return { items: [row(1, { source: 'other' })] }; } }]));
  await assert.rejects(session.nextBatch(), e => e.code === 'port');
  session.activate(activation([{ source: 'files', revision: '1', async read() { return { items: [], nextCursor: 'loop' }; } }]));
  await assert.rejects(session.nextBatch(), e => e.code === 'port'); session.dispose();
});
test('read concurrency <=2, deterministic page order despite reversed latency, inputs frozen', async () => {
  let active = 0, peak = 0;
  const ports = ['files', 'other'].map((source, index) => ({ source, revision: '1', async read({ signal, config: c }) { assert(Object.isFrozen(c.scope)); active++; peak = Math.max(peak, active); await new Promise(resolve => setTimeout(resolve, index ? 1 : 15)); active--; signal.throwIfAborted(); return { items: [row(index, { source })] }; } }));
  const input = activation(ports), session = new RecommendationSession(); session.activate(input); input.settings.preset.config.scope.sources.push('other');
  const result = await session.nextBatch(); assert.equal(peak, 2); assert.equal(active, 0); assert.deepEqual(result.items.map(i => i.candidate.identity.id), ['0', '1']); session.dispose();
});
test('dispose invalidates late batches and old host-confirmation tokens', async () => {
  const a = new RecommendationSession(), b = new RecommendationSession(); for (const s of [a, b]) s.activate(activation([port([row(1)])]));
  const first = await a.nextBatch(), second = await b.nextBatch(); assert.notEqual(first.token, second.token); assert.equal(b.confirm(first.token).accepted, false);
  a.dispose(); assert.equal(a.confirm(first.token).accepted, false); await assert.rejects(a.preview(), e => e.code === 'disposed'); b.dispose();
});
test('atomic revision save validates, returns conflicts and retains prior revision in host', async () => {
  let stored = settings(), old = [];
  const store = { async compareAndSet({ expectedRevision, next }) { if (stored.revision !== expectedRevision) return { status: 'conflict', currentRevision: stored.revision }; old.push(stored); stored = structuredClone(next); return { status: 'saved', document: stored }; } };
  const request = { user: access.user, expectedRevision: '1', next: settings({ batchSize: 2 }, '2'), signal: new AbortController().signal };
  assert.equal((await saveSettings(store, request)).status, 'saved'); assert.equal(old[0].revision, '1'); assert.equal((await saveSettings(store, request)).status, 'conflict');
  await assert.rejects(saveSettings(store, { ...request, next: settings({}, '1') }), e => e.code === 'invalid-config');
});
test('global read slots remain bounded across separate sessions', async () => {
  let releaseA, releaseB;
  const delayed = set => ({ source: 'files', revision: '1', read() { return new Promise(resolve => set(() => resolve({ items: [] }))); } });
  const a = new RecommendationSession(), b = new RecommendationSession(), c = new RecommendationSession();
  a.activate(activation([delayed(release => { releaseA = release; })])); b.activate(activation([delayed(release => { releaseB = release; })])); c.activate(activation([port([])]));
  const pa = a.preview(), pb = b.preview(); await tick(); await assert.rejects(c.preview(), e => e.code === 'busy');
  releaseA(); releaseB(); await Promise.all([pa, pb]); assert.equal(a.diagnostics().activeReads + b.diagnostics().activeReads, 0); a.dispose(); b.dispose(); c.dispose();
});
test('pre-aborted request performs no host reads; changing user invalidates pending confirmation', async () => {
  let calls = 0;
  const p = { source: 'files', revision: '1', async read() { calls++; return { items: [row(1)] }; } };
  const s = new RecommendationSession(); s.activate(activation([p])); const ctrl = new AbortController(); ctrl.abort();
  await assert.rejects(s.nextBatch(ctrl.signal), e => e.code === 'cancelled'); assert.equal(calls, 0);
  const batch = await s.nextBatch(), next = activation([p]); next.access = { ...access, user: 'different', authorizationRevision: 'auth-2' }; s.activate(next);
  assert.equal(s.confirm(batch.token).accepted, false); assert.equal(s.diagnostics().history, 0); assert.notEqual((await s.preview()).contextKey, batch.contextKey); s.dispose();
});
test('host cannot exceed requested page size and missing selected ports are explicit', async () => {
  const s = new RecommendationSession(); s.activate(activation([{ source: 'files', revision: '1', async read() { return { items: [row(1), row(2)] }; } }], { budget: { candidates: 1, bytes: 4096, timeoutMs: 30000 } }));
  await assert.rejects(s.preview(), e => e.code === 'port');
  s.activate(activation([], { scope: { sources: ['files'], roots: [], media: [], boards: [], categories: [] } }));
  const empty = await s.preview(); assert.equal(empty.complete, false); assert(empty.truncatedBy.includes('missing-port-or-grant')); s.dispose();
});
