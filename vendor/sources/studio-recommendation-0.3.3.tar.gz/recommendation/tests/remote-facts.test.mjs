import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CONFIG,execute,executeSnapshot,evaluateCandidate,matchGroup} from '../dist/index.js';
const access={user:'test',authorizationRevision:'anonymous',sourceRevision:'fixed',grants:[{source:'s'}]};
const candidate=id=>({identity:{namespace:'native',id},source:'s',authorized:true,available:true,media:'video',title:'ASMR',texts:['ASMR'],provenance:'real supplied fields'});
test('harvested texts do not fabricate author/tags or cross-field hits',()=>{
 const c={...candidate('1'),texts:['ear','care']},group={id:'g',fields:['texts'],mode:'any',terms:['earcare']};
 assert.equal(matchGroup(c,group),'no');assert.equal(matchGroup(c,{...group,fields:['tags']}),'unknown');
 const config={...structuredClone(DEFAULT_CONFIG),exclude:[{...group,terms:['loud']}]};assert.equal(evaluateCandidate(c,config,access).truth,'yes');
 config.exclude[0].fields=['author'];assert.equal(evaluateCandidate(c,config,access).truth,'unknown');
});
test('explicit unknown author policy preserves facts and default shared bucket',()=>{
 const cs=['1','2','3'].map(candidate),config={...structuredClone(DEFAULT_CONFIG),diversity:{author:1,directory:0}};
 assert.equal(execute({candidates:cs,config,access,seed:'s'}).items.length,1);
 config.diversity.unknownAuthor='distinct';
 for(const items of [execute({candidates:cs,config,access,seed:'s'}).items,executeSnapshot({pages:[cs],base:[config],selections:[{id:'s',config,seed:'s'}],access}).selections[0].items]){
  assert.equal(items.length,3);assert(items.every(i=>i.candidate.author===undefined&&i.candidate.authorId===undefined));
 }
});
