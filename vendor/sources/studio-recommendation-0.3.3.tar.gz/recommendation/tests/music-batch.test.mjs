import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CONFIG,execute,validateConfig} from '../dist/index.js';
test('36 and 500 item bounded pools preserve all/custom consumers and seeded order',()=>{
 const access={user:'u',authorizationRevision:'a',sourceRevision:'s',grants:[{source:'youtube'}]};
 const candidates=Array.from({length:500},(_,n)=>({identity:{namespace:'youtube',id:String(n)},source:'youtube',authorized:true,available:true,title:'Music '+n,provenance:'public playlist'}));
 for(const size of [36,500]){const config={...structuredClone(DEFAULT_CONFIG),batchSize:size,repeat:'after-fresh'};const input={candidates:candidates.slice(0,size),config,access,seed:'fixed'};assert.equal(execute(input).items.length,size);assert.deepEqual(execute(input),execute(input));}
 assert.throws(()=>validateConfig({...DEFAULT_CONFIG,batchSize:501}),{code:'invalid-config'});
 const larger=Array.from({length:1000},(_,n)=>({...candidates[n%500],identity:{namespace:'youtube',id:String(n)}}));
 const all=execute({candidates:larger,config:{...DEFAULT_CONFIG,batchSize:500},access,seed:'all',all:true});assert.equal(all.items.length,1000,'explicit all keeps the actual bounded pool beyond custom-count cap');
});
