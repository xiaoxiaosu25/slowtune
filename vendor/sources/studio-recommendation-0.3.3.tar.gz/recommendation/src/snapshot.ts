import { LIMITS, validateConfig } from './config.js';
import { authorGroup, candidateBytes, compileEvaluator, compilePhraseRules, compileRuleTree, identityKey, projectCandidate, seededScore, type PhraseRules, type RuleTree } from './executor.js';
import { RecommendationError, type AccessContext, type Candidate, type ContentIdentity, type ExecutionResult, type RecommendationConfig } from './contracts.js';

export interface SnapshotSelection {
  id: string; config: RecommendationConfig; seed: string;
  /** Additional hard rules are ANDed without merging or losing individual any/all groups. */
  constraints?: RecommendationConfig[];
  /** Search window, independently bounded from recommendation card batch size. */
  window?: { offset:number; limit:number };
  rules?:PhraseRules;
  tree?:RuleTree;
}
const natural = new Intl.Collator('zh-CN', { numeric: true });
type Ranked = { candidate: Candidate; key: string; rank: number; score: number; bytes: number; partition: string; repeated: boolean; ordinal: number };
const lexical = (a: string, b: string) => a < b ? -1 : a > b ? 1 : 0;
/** Complete host snapshot, one bounded page at a time. No database, async I/O or host state.
 * Keeps only the sufficient ranked prefix per source; partitions are directory OR author.
 * Both simultaneous partition caps require the existing pool executor, and are rejected here.
 * Sequential selections share an unbounded-within-request page identity set, independent of recent.
 */
export function executeSnapshot(input: {
  pages: Iterable<readonly Candidate[]>; base: RecommendationConfig[]; selections: SnapshotSelection[];
  access: AccessContext; recent?: readonly string[]; signal?: AbortSignal;
  accept?: (candidate: Candidate) => boolean;
  sampleReasons?: readonly string[];
  rules?:PhraseRules;
  tree?:RuleTree;
  /** Explicit same-snapshot lookup for compact search windows; never loaded implicitly. */
  resolve?: (identities:ContentIdentity[]) => readonly Candidate[];
}) {
  if (!input.base.length || input.base.length > 8 || !input.selections.length || input.selections.length > 8)
    throw new RecommendationError('invalid-config', 'snapshot requires 1..8 base rules and selections');
  if ((input.recent?.length ?? 0) > LIMITS.history) throw new RecommendationError('budget', 'recent history exceeded');
  const configs: RecommendationConfig[] = [];
  const parse = (value: RecommendationConfig) => {
    const config = validateConfig(value); configs.push(config); return config;
  };
  const treeCheck = (tree: RuleTree) => {
    const check = compileRuleTree(tree, input.access);
    // Compile first to enforce the tree's depth/node bounds before walking its leaves.
    const collect = (node: RuleTree): void => {
      if ('children' in node) node.children.forEach(collect); else parse(node);
    };
    collect(tree); return check;
  };
  const base = input.base.map(parse), checks = base.map(c => compileEvaluator(c, input.access));
  if(input.rules)checks.push(compilePhraseRules(input.rules));
  if(input.tree)checks.push(treeCheck(input.tree));
  const prepared = input.selections.map(selection => {
    if ((selection.constraints?.length ?? 0) > 8) throw new RecommendationError('invalid-config', 'invalid snapshot selection');
    return { selection, config: parse(selection.config), constraints: (selection.constraints ?? []).map(parse),
      tree: selection.tree ? treeCheck(selection.tree) : undefined };
  });
  // One complete snapshot shares the strictest budget from every participating configuration.
  const budget = { candidates: Math.min(...configs.map(c => c.budget.candidates)), bytes: Math.min(...configs.map(c => c.budget.bytes)), timeoutMs: Math.min(...configs.map(c => c.budget.timeoutMs)) };
  const recent = new Set(input.recent), identities = new Map<string,Set<string>>();
  let prefix = 0;
  const states = prepared.map(({ selection, config, constraints, tree }) => {
    if (config.diversity.author && config.diversity.directory) throw new RecommendationError('invalid-config', 'snapshot supports one partition cap per selection');
    if (!selection.seed || selection.seed.length > 512 || !selection.id || (selection.constraints?.length ?? 0) > 8)
      throw new RecommendationError('invalid-config', 'invalid snapshot selection');
    const window=selection.window;
    if(window && (!Number.isSafeInteger(window.offset)||window.offset<0||window.offset>LIMITS.candidates||!Number.isSafeInteger(window.limit)||window.limit<1||window.limit>100))
      throw new RecommendationError('invalid-config','invalid search window');
    const desired=window?window.offset+window.limit:config.batchSize;
    const prior = prefix; prefix += desired;
    const compact=!!(input.resolve && window && input.selections.length===1 && !config.mix.length && !config.diversity.author && !config.diversity.directory && config.order==='name' && !input.recent?.length);
    const tail=compact && budget.candidates-window!.offset < desired;
    const limit = compact ? Math.max(0,tail?budget.candidates-window!.offset:desired) : prefix, partitionLimit = config.diversity.directory || config.diversity.author;
    const compare = (a: Ranked, b: Ranked) => Number(a.repeated) - Number(b.repeated) || (
      config.order === 'random' ? a.rank - b.rank : config.order === 'score' ? b.score - a.score :
      config.order === 'time' ? (b.candidate.timestamp ?? -Infinity) - (a.candidate.timestamp ?? -Infinity) :
      config.order === 'time-zero-v1' ? (b.candidate.timestamp ?? 0)-(a.candidate.timestamp ?? 0) :
      config.order === 'name' ? natural.compare(a.candidate.originalTitle ?? a.candidate.title ?? '', b.candidate.originalTitle ?? b.candidate.title ?? '') : a.ordinal - b.ordinal
    ) || (config.order === 'name'||config.order==='time-zero-v1' ? (a.key || identityKey(a.candidate.identity)).localeCompare(b.key || identityKey(b.candidate.identity)) : lexical(a.key,b.key));
    return { selection, config, limit, prior, desired, partitionLimit, compare,compact,tail,
      checks: [...[config, ...constraints].map(c => compileEvaluator(c, input.access)),...(selection.rules?[compilePhraseRules(selection.rules)]:[]),...(tree?[tree]:[])],
      groups: new Map<string, Ranked[]>(), eligible: 0, repeats: 0 };
  });
  if (new Set(states.map(s => s.selection.id)).size !== states.length) throw new RecommendationError('invalid-config', 'duplicate selection');
  const started = performance.now(); let coreMs = 0, count = 0, pages = 0, retained = 0, peak = 0, keyBytes = 0, eligible = 0;
  const encoder = new TextEncoder();
  const strings=new Map<string,string>();
  const intern=(value:string)=>{const stored=strings.get(value);if(stored!==undefined)return stored;strings.set(value,value);keyBytes+=encoder.encode(value).length;return value;};
  const rejected: Record<string, number> = {}, samples: ExecutionResult['diagnostics']['samples'] = [];
  const ensureBudget = () => {
    if (input.signal?.aborted) throw new RecommendationError('cancelled', 'snapshot cancelled');
    if (performance.now() - started > budget.timeoutMs || coreMs > LIMITS.executionMs) throw new RecommendationError('timeout', 'snapshot exceeded frozen time budget');
    peak = Math.max(peak, retained + keyBytes);
    if (peak > budget.bytes) throw new RecommendationError('budget', 'snapshot retained bytes exceeded');
  };
  for (const page of input.pages) {
    ensureBudget(); const tick = performance.now();
    if (++pages > LIMITS.pages || page.length > LIMITS.page) throw new RecommendationError('budget', 'snapshot page budget exceeded');
    for (const value of page) {
      if (++count > budget.candidates) throw new RecommendationError('budget', 'snapshot candidate budget exceeded');
      const candidate = projectCandidate(value, false, false), bytes = candidateBytes(candidate);
      if (bytes > LIMITS.candidateBytes) throw new RecommendationError('invalid-candidate', 'projection exceeds 16 KiB');
      const failures = checks.map(check => check(candidate)).find(result => result.truth !== 'yes') ?? (input.accept && !input.accept(candidate) ? {reason:'filter:no'} : undefined);
      if (failures) {
        rejected[failures.reason] = (rejected[failures.reason] ?? 0) + 1;
        if (samples.length < LIMITS.samples && (!input.sampleReasons || input.sampleReasons.some(prefix=>failures.reason.startsWith(prefix)))) samples.push({ key:identityKey(candidate.identity), reasons: [failures.reason] });
        continue;
      }
      const namespace=JSON.stringify([candidate.identity.namespace,candidate.identity.part ?? null]);
      let seen=identities.get(namespace);
      if(!seen){seen=new Set();identities.set(namespace,seen);keyBytes+=encoder.encode(namespace).length;}
      if(seen.has(candidate.identity.id))continue;
      seen.add(candidate.identity.id);keyBytes+=encoder.encode(candidate.identity.id).length;
      const key=identityKey(candidate.identity);
      eligible++;
      for (const state of states) {
        const results = state.checks.map(check => check(candidate));
        if (results.some(result => result.truth !== 'yes')) continue;
        state.eligible++;
        const repeated = recent.has(key); if (repeated) { state.repeats++; if (state.config.repeat === 'never') continue; }
        const partition = state.config.diversity.author ? authorGroup(candidate, state.config.diversity)
          : JSON.stringify([candidate.source, candidate.directoryId ?? candidate.directory ?? null]);
        const row: Ranked = { candidate, key, bytes, partition, repeated, ordinal: count,
          score: results[0].score, rank: seededScore(state.selection.seed, key) };
        const source = state.config.mix.length ? candidate.source : '*';
        const pool = state.groups.get(source) ?? []; state.groups.set(source, pool);
        if(state.compact){
          if(!state.limit)continue;
          row.key='';row.bytes=encoder.encode(candidate.originalTitle ?? candidate.title ?? '').length+48;
          row.candidate={identity:{...candidate.identity},source:candidate.source,authorized:candidate.authorized,available:candidate.available,
            provenance:candidate.provenance,...(candidate.originalTitle===undefined?{title:candidate.title}:{originalTitle:candidate.originalTitle})};
          const compare=(a:Ranked,b:Ranked)=>state.tail?-state.compare(a,b):state.compare(a,b);
          if(pool.length>=state.limit && compare(row,pool[0])>=0)continue;
          row.candidate.identity.namespace=intern(candidate.identity.namespace);row.candidate.source=intern(candidate.source);row.candidate.provenance=intern(candidate.provenance);
          if(row.candidate.identity.part!==undefined)row.candidate.identity.part=intern(row.candidate.identity.part);
          if(pool.length<state.limit){pool.push(row);retained+=row.bytes;let at=pool.length-1;
            while(at){const parent=(at-1)>>>1;if(compare(pool[at],pool[parent])<=0)break;[pool[at],pool[parent]]=[pool[parent],pool[at]];at=parent;}
          }else{retained+=row.bytes-pool[0].bytes;pool[0]=row;let at=0;
            for(;;){const left=at*2+1,right=left+1;if(left>=pool.length)break;const next=right<pool.length&&compare(pool[right],pool[left])>0?right:left;
              if(compare(pool[next],pool[at])<=0)break;[pool[at],pool[next]]=[pool[next],pool[at]];at=next;}
          }
          continue;
        }
        if (pool.length >= state.limit && state.compare(row,pool[pool.length-1]) >= 0) continue;
        // A partition cap plus all prior possible removals is a sufficient prefix.
        let remove = -1;
        if (state.partitionLimit) {
          let same = 0;
          for (let i=0;i<pool.length;i++) if (pool[i].partition === partition) { same++; remove=i; }
          if (same < state.partitionLimit + state.prior) remove = -1;
        }
        if (remove < 0 && pool.length >= state.limit) remove = pool.length-1;
        if (remove >= 0) {
          if (state.compare(row,pool[remove]) >= 0) continue;
          retained -= pool[remove].bytes; pool.splice(remove,1);
        }
        let low=0,high=pool.length;
        while (low<high) { const mid=(low+high)>>>1; if (state.compare(row,pool[mid])<0) high=mid; else low=mid+1; }
        // Copy only retained values: hosts may reuse page objects after yielding.
        row.candidate = projectCandidate(candidate); pool.splice(low,0,row); retained+=bytes;
      }
    }
    coreMs += performance.now()-tick; ensureBudget();
  }
  const tick = performance.now(), selected = new Set<string>();
  const selections = states.map(state => {
    if(state.compact){
      const pool=state.groups.get('*') ?? [];pool.sort(state.compare);
      const offset=state.selection.window!.offset-(state.tail?state.eligible-pool.length:0);
      const picked=state.selection.window!.offset>=state.eligible?[]:pool.slice(offset,offset+state.selection.window!.limit);
      const facts=input.resolve!(picked.map(r=>r.candidate.identity));
      if(facts.length!==picked.length)throw new RecommendationError('port','snapshot resolve returned wrong count');
      const items=picked.map((row,index)=>{const candidate=projectCandidate(facts[index]);
        if(identityKey(candidate.identity)!==identityKey(row.candidate.identity)||candidate.source!==row.candidate.source||candidate.originalTitle!==row.candidate.originalTitle||candidate.title!==row.candidate.title
          ||checks.some(check=>check(candidate).truth!=='yes')||state.checks.some(check=>check(candidate).truth!=='yes')||(input.accept&&!input.accept(candidate)))throw new RecommendationError('port','snapshot facts changed during resolve');
        const key=identityKey(candidate.identity);return {candidate,key,score:row.score,reasons:['scope:yes'],repeated:false};});
      retained+=items.reduce((sum,i)=>sum+candidateBytes(i.candidate),0);
      return {id:state.selection.id,items,diagnostics:{read:count,eligible:state.eligible,duplicates:0,recent:0,diversity:0,rejected:{},samples:[]},shortage:[]};
    }
    const groups = [...state.groups].map(([source,pool]) => ({source,pool,index:0,selected:0,weight:state.config.mix.find(m=>m.source===source)?.weight ?? 1}));
    const items: ExecutionResult['items'] = [], partitions = new Map<string,number>(); let diversity=0, samePage=0;
    while (items.length<state.desired) {
      const group=groups.filter(g=>g.index<g.pool.length).sort((a,b)=>
        Number(a.pool[a.index].repeated)-Number(b.pool[b.index].repeated) || (a.selected+1)/a.weight-(b.selected+1)/b.weight
        || (state.config.order==='random'?seededScore(state.selection.seed,a.source)-seededScore(state.selection.seed,b.source):0) || lexical(a.source,b.source))[0];
      if (!group) break;
      const row=group.pool[group.index++];
      if (selected.has(row.key)) { samePage++; continue; }
      const used=partitions.get(row.partition) ?? 0;
      if (state.partitionLimit && used>=state.partitionLimit) { diversity++; continue; }
      partitions.set(row.partition,used+1); selected.add(row.key); group.selected++;
      items.push({candidate:row.candidate,key:row.key,score:row.score,reasons:['scope:yes'],repeated:row.repeated});
    }
    return { id:state.selection.id, items:state.selection.window?items.slice(state.selection.window.offset):items, diagnostics:{ read:count, eligible:state.eligible,duplicates:samePage,recent:state.repeats,diversity,rejected:{},samples:[] },
      shortage:items.length===state.desired?[]:['candidate-pool',...(diversity?['diversity']:[]),...(samePage?['same-page']:[]),...(state.repeats?['recent-history']:[])] };
  });
  coreMs+=performance.now()-tick; ensureBudget();
  return { selections, diagnostics:{read:count,eligible,rejected,samples}, complete:true as const,
    resources:{pages,read:count,retainedBytes:peak,coreMs,elapsedMs:performance.now()-started} };
}
