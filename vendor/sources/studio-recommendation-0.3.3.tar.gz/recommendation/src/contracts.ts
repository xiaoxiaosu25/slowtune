/** Native stable identity. part keeps cid/segment distinct; never use a queue instance ID. */
export interface ContentIdentity { namespace: string; id: string; part?: string }
export type TextField = 'title' | 'originalTitle' | 'displayTitle' | 'author' | 'tags' | 'categories' | 'path' | 'texts';
export type Truth = 'yes' | 'no' | 'unknown';
export interface Candidate {
  identity: ContentIdentity;
  source: string;
  /** Host asserts actual authorization and availability, not a default inferred by the core. */
  authorized: boolean;
  available: boolean;
  media?: 'audio' | 'video' | 'live';
  live?: boolean;
  title?: string;
  originalTitle?: string;
  displayTitle?: string;
  /** Actual host listening history. Display history cannot supply this fact. */
  listened?: boolean;
  author?: string;
  authorId?: string;
  tags?: string[];
  /** Explicit collection of actually harvested text facts. Does not assert missing fields exist. */
  texts?: string[];
  categories?: string[];
  board?: string;
  /** Canonical host logical path, slash-separated; no filesystem access by the core. */
  path?: string;
  directory?: string;
  /** Host's stable directory grouping key; separate from the canonical display path. */
  directoryId?: string;
  timestamp?: number;
  /** Explicit source evidence, such as a local index revision or original shelf. */
  provenance: string;
}
export interface PhraseGroup { id: string; fields: TextField[]; mode: 'any' | 'all'; terms: string[] }
export interface HardScope {
  sources: string[];
  roots: { source: string; path: string }[];
  media: ('audio' | 'video' | 'live')[];
  boards: string[];
  categories: string[];
  live?: boolean;
  unheard?: boolean;
}
export interface RecommendationConfig {
  schema: 1;
  algorithm: 'literal-v1' | 'literal-case-v1';
  scope: HardScope;
  include: { mode: 'any' | 'all'; groups: PhraseGroup[] };
  exclude: PhraseGroup[];
  preferences: (PhraseGroup & { weight: number })[];
  order: 'upstream' | 'score' | 'time' | 'time-zero-v1' | 'random' | 'name';
  /** Weighted fair interleave, not an exact quota or a promise of enough candidates. */
  mix: { source: string; weight: number }[];
  diversity: { author: number; directory: number; unknownAuthor?: 'shared' | 'distinct' };
  batchSize: number;
  repeat: 'never' | 'after-fresh';
  budget: { candidates: number; bytes: number; timeoutMs: number };
}
export type ConfigOverrides = Partial<Pick<RecommendationConfig, 'scope' | 'include' | 'exclude' | 'preferences' | 'order' | 'mix' | 'diversity' | 'batchSize' | 'repeat' | 'budget'>>;
export interface SettingsDocument {
  schema: 1;
  revision: string;
  preset: { id: string; revision: string; config: RecommendationConfig };
  /** Explicit complete section replacements; absent sections inherit the current preset. */
  overrides: ConfigOverrides;
}
export interface AccessContext {
  user: string;
  authorizationRevision: string;
  sourceRevision: string;
  grants: { source: string; roots?: string[] }[];
}
export interface ReadRequest {
  cursor?: string;
  limit: number;
  signal: AbortSignal;
  access: AccessContext;
  config: RecommendationConfig;
}
export interface CandidatePage { items: Candidate[]; nextCursor?: string }
/** Reads an existing index only. It MUST honor limit/signal and settle after releasing I/O. */
export interface CandidatePort {
  source: string;
  revision: string;
  read(request: ReadRequest): Promise<CandidatePage>;
}
export interface RevisionPort {
  /** The host atomically compares revision, archives the previous document and saves next. */
  compareAndSet(request: { user: string; expectedRevision: string; next: SettingsDocument; signal: AbortSignal }): Promise<
    { status: 'saved'; document: SettingsDocument } | { status: 'conflict'; currentRevision: string }
  >;
}
export interface Evaluation { pass: boolean; truth: Truth; score: number; reasons: string[] }
export interface PickedCandidate { candidate: Candidate; key: string; score: number; reasons: string[]; repeated: boolean }
export interface ExecutionResult {
  items: PickedCandidate[];
  diagnostics: { read: number; eligible: number; duplicates: number; recent: number; diversity: number; rejected: Record<string, number>; samples: { key: string; reasons: string[] }[] };
  shortage: string[];
}
export interface RecommendationBatch extends ExecutionResult {
  token: string;
  contextKey: string;
  mode: 'preview' | 'display';
  batch: number;
  nextBatch: number;
  complete: boolean;
  truncatedBy: string[];
}
export class RecommendationError extends Error {
  constructor(public readonly code: 'invalid-config' | 'invalid-candidate' | 'budget' | 'cancelled' | 'timeout' | 'stale' | 'disposed' | 'busy' | 'port', message: string) { super(message); this.name = 'RecommendationError'; }
}
