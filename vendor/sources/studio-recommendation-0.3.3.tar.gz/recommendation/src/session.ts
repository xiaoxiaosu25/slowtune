import { LIMITS, resolveSettings, text, validateSettings } from './config.js';
import { executeIndexed, identityKey, projectCandidate, validateAccess } from './executor.js';
import { CandidateBuffer } from './pool.js';
import { RecommendationError, type AccessContext, type Candidate, type CandidatePage, type CandidatePort, type RecommendationBatch, type RecommendationConfig, type RevisionPort, type SettingsDocument } from './contracts.js';

function freeze<T>(value: T): T {
  if (value && typeof value === 'object') { Object.freeze(value); for (const item of Object.values(value)) freeze(item); }
  return value;
}
interface Snapshot { document: SettingsDocument; config: RecommendationConfig; access: AccessContext; ports: CandidatePort[]; seed: string; key: string }
let sessionSequence = 0;
let outstandingReads = 0;
export class RecommendationSession {
  private readonly instance = ++sessionSequence;
  private snapshot?: Snapshot;
  private generation = 0;
  private request = 0;
  private ordinal = 0;
  private history: string[] = [];
  private pending?: { token: string; keys: string[]; key: string };
  private controller?: AbortController;
  private activeReads = 0;
  private disposed = false;

  /** Explicit reconfiguration invalidates pending batches and all prior async work. No cache. */
  activate(input: { settings: SettingsDocument; access: AccessContext; ports: CandidatePort[]; seed: string; recent?: string[] }): string {
    if (this.disposed) throw new RecommendationError('disposed', 'session disposed');
    const { document, config } = resolveSettings(input.settings), access = validateAccess(input.access);
    text(input.seed, 'seed', 400);
    if (!Array.isArray(input.ports) || input.ports.length > LIMITS.ports) throw new RecommendationError('invalid-config', 'at most 8 explicit ports');
    const ports = input.ports.map(port => {
      text(port.source, 'port.source'); text(port.revision, 'port.revision');
      if (typeof port.read !== 'function') throw new RecommendationError('invalid-config', 'port.read required');
      return Object.freeze({ source: port.source, revision: port.revision, read: port.read.bind(port) });
    });
    if (new Set(ports.map(p => p.source)).size !== ports.length) throw new RecommendationError('invalid-config', 'duplicate port source');
    if ((input.recent?.length ?? 0) > LIMITS.history || input.recent?.some(k => typeof k !== 'string' || k.length > 9000)) throw new RecommendationError('invalid-config', 'invalid bounded recent identity history');
    this.cancel(); this.generation++; this.ordinal = 0;
    this.history = [...new Set(input.recent ?? [])];
    const key = JSON.stringify([access.user, access.authorizationRevision, access.sourceRevision, document.revision, document.preset.id, document.preset.revision, config, access.grants, ports.map(p => [p.source, p.revision])]);
    this.snapshot = freeze({ document, config, access, ports, seed: input.seed, key });
    return key;
  }
  cancel(): void { this.controller?.abort(); this.controller = undefined; this.pending = undefined; this.request++; }
  dispose(): void { if (!this.disposed) { this.cancel(); this.disposed = true; this.snapshot = undefined; this.history = []; } }
  diagnostics() { return { activeReads: this.activeReads, pending: this.pending ? 1 : 0, history: this.history.length, disposed: this.disposed }; }
  /** Only host-confirmed valid display batches consume recent history and advance the seed. */
  confirm(token: string): { accepted: boolean; recent: string[] } {
    const pending = this.pending;
    if (this.disposed || !pending || pending.token !== token || this.snapshot?.key !== pending.key) return { accepted: false, recent: [...this.history] };
    this.history = [...this.history.filter(k => !pending.keys.includes(k)), ...pending.keys].slice(-LIMITS.history);
    this.pending = undefined; this.ordinal++;
    return { accepted: true, recent: [...this.history] };
  }
  preview(signal?: AbortSignal) { return this.run('preview', signal); }
  nextBatch(signal?: AbortSignal) { return this.run('display', signal); }

  private read(port: CandidatePort, cursor: string | undefined, limit: number, snapshot: Snapshot, signal: AbortSignal): Promise<CandidatePage> {
    if (signal.aborted) return Promise.reject(new RecommendationError('cancelled', 'request cancelled'));
    if (outstandingReads >= LIMITS.concurrency) return Promise.reject(new RecommendationError('busy', 'two host requests still active across sessions'));
    this.activeReads++; outstandingReads++;
    // Slot lives until the underlying host request settles, including after cancellation.
    const work = Promise.resolve().then(() => { if (signal.aborted) throw new RecommendationError('cancelled', 'request cancelled'); return port.read({ cursor, limit, signal, access: snapshot.access, config: snapshot.config }); });
    const released = work.finally(() => { this.activeReads--; outstandingReads--; });
    return new Promise((resolve, reject) => {
      const aborted = () => { signal.removeEventListener('abort', aborted); reject(new RecommendationError('cancelled', 'host read aborted')); };
      signal.addEventListener('abort', aborted, { once: true });
      released.then(page => { signal.removeEventListener('abort', aborted); if (signal.aborted) aborted(); else resolve(page); }, error => { signal.removeEventListener('abort', aborted); reject(error); });
      if (signal.aborted) aborted();
    });
  }
  private async run(mode: 'preview' | 'display', external?: AbortSignal): Promise<RecommendationBatch> {
    if (this.disposed) throw new RecommendationError('disposed', 'session disposed');
    if (!this.snapshot) throw new RecommendationError('invalid-config', 'activate first');
    this.cancel();
    const snapshot = this.snapshot, generation = this.generation, request = this.request, batch = this.ordinal;
    if (this.activeReads) throw new RecommendationError('busy', 'cancelled host reads have not released');
    const controller = new AbortController(); this.controller = controller;
    let timeout = false;
    const abort = () => controller.abort();
    external?.addEventListener('abort', abort, { once: true });
    if (external?.aborted) abort();
    const timer = setTimeout(() => { timeout = true; controller.abort(); }, snapshot.config.budget.timeoutMs);
    const started = performance.now();
    const current = () => {
      if (this.disposed) throw new RecommendationError('disposed', 'session disposed');
      if (generation !== this.generation || request !== this.request || snapshot !== this.snapshot) throw new RecommendationError('stale', 'configuration/source/request superseded');
      if (timeout || performance.now() - started >= snapshot.config.budget.timeoutMs) throw new RecommendationError('timeout', 'request exceeded budget');
      if (controller.signal.aborted) throw new RecommendationError('cancelled', 'request cancelled');
    };
    try {
      current();
      const states = snapshot.ports.filter(p => snapshot.access.grants.some(g => g.source === p.source) && (!snapshot.config.scope.sources.length || snapshot.config.scope.sources.includes(p.source)))
        .map(port => ({ port, cursor: undefined as string | undefined, cursors: new Set<string>(), done: false, rows: [] as number[] }));
      const buffer = new CandidateBuffer(snapshot.config.budget.candidates);
      const encoder = new TextEncoder();
      let pages = 0, reserved = 0, bytes = 0, stop = false, offset = 0;
      const truncatedBy: string[] = [];
      if (snapshot.config.scope.sources.some(source => !states.some(s => s.port.source === source))) truncatedBy.push('missing-port-or-grant');
      while (states.some(s => !s.done) && !stop) {
        current();
        const jobs: { state: typeof states[number]; limit: number }[] = [];
        // Fair reads across sources, but result order is fixed by port and native page order.
        for (let visited = 0; visited < states.length && jobs.length < LIMITS.concurrency; visited++) {
          const state = states[(offset + visited) % states.length];
          if (state.done) continue;
          const remaining = snapshot.config.budget.candidates - reserved;
          if (!remaining || pages >= LIMITS.pages) break;
          const limit = Math.min(LIMITS.page, remaining); reserved += limit; pages++; jobs.push({ state, limit });
        }
        offset = (offset + jobs.length) % Math.max(1, states.length);
        if (!jobs.length) { truncatedBy.push(pages >= LIMITS.pages ? 'pages' : 'candidates'); break; }
        const responses = await Promise.all(jobs.map(job => this.read(job.state.port, job.state.cursor, job.limit, snapshot, controller.signal)));
        current();
        for (let i = 0; i < responses.length; i++) {
          const page = responses[i], { state, limit } = jobs[i];
          if (!page || !Array.isArray(page.items) || page.items.length > limit) throw new RecommendationError('port', 'host exceeded page limit or returned invalid page');
          reserved -= limit - page.items.length;
          for (const item of page.items) {
            const candidate = projectCandidate(item, true, false);
            if (candidate.source !== state.port.source) throw new RecommendationError('port', 'candidate source differs from bound port');
            const encoded = encoder.encode(JSON.stringify(candidate)), size = encoded.length;
            if (size > LIMITS.candidateBytes) throw new RecommendationError('invalid-candidate', 'projection exceeds 16 KiB');
            if (bytes + size > snapshot.config.budget.bytes) { stop = true; truncatedBy.push('bytes'); break; }
            bytes += size; state.rows.push(buffer.append(encoded));
          }
          if (stop) break;
          if (page.nextCursor !== undefined) {
            try { text(page.nextCursor, 'cursor', 4096); } catch { throw new RecommendationError('port', 'invalid host cursor'); }
            if (state.cursors.has(page.nextCursor)) throw new RecommendationError('port', 'repeated host cursor');
            state.cursors.add(page.nextCursor); state.cursor = page.nextCursor;
          } else state.done = true;
        }
        // Let abort events and host control run between bounded pages.
        await new Promise<void>(resolve => setTimeout(resolve, 0));
      }
      current();
      const complete = states.every(s => s.done) && !truncatedBy.length;
      const indices = states.flatMap(s => s.rows);
      const result = executeIndexed({ count: indices.length, at: index => buffer.at(indices[index]), config: snapshot.config, access: snapshot.access, seed: `${snapshot.seed}:${batch}`, recent: this.history, signal: controller.signal });
      current();
      const token = JSON.stringify([this.instance, generation, request, batch]);
      const output: RecommendationBatch = { ...result, token, contextKey: snapshot.key, mode, batch, nextBatch: batch + 1, complete, truncatedBy: [...new Set(truncatedBy)] };
      if (!complete && output.items.length < snapshot.config.batchSize) output.shortage.push('read-budget');
      if (mode === 'display') this.pending = { token, keys: output.items.map(item => identityKey(item.candidate.identity)), key: snapshot.key };
      return output;
    } catch (error) {
      current();
      if (error instanceof RecommendationError) throw error;
      throw new RecommendationError('port', error instanceof Error ? error.message : 'host read failed');
    } finally {
      controller.abort(); clearTimeout(timer); external?.removeEventListener('abort', abort);
      if (this.controller === controller) this.controller = undefined;
    }
  }
}
/** Validation is shared with preview. History and atomic revision storage remain host-owned. */
export async function saveSettings(port: RevisionPort, input: { user: string; expectedRevision: string; next: SettingsDocument; signal: AbortSignal }) {
  const next = validateSettings(input.next);
  text(input.user, 'user'); text(input.expectedRevision, 'expectedRevision');
  if (next.revision === input.expectedRevision) throw new RecommendationError('invalid-config', 'new revision must differ from expected revision');
  if (input.signal.aborted) throw new RecommendationError('cancelled', 'save cancelled before dispatch');
  const result = await port.compareAndSet({ ...input, next: freeze(next) });
  if (input.signal.aborted) throw new RecommendationError('cancelled', 'save response cancelled; host must reconcile its atomic write outcome');
  if (result.status === 'saved') {
    const stored = validateSettings(result.document);
    if (JSON.stringify(stored) !== JSON.stringify(next)) throw new RecommendationError('port', 'host saved a different document');
    return { status: 'saved' as const, document: stored };
  }
  if (result.status !== 'conflict') throw new RecommendationError('port', 'invalid conditional write response');
  text(result.currentRevision, 'currentRevision'); return result;
}
