export * from './contracts.js';
export { DEFAULT_CONFIG, LIMITS, validateConfig, validateSettings, resolveSettings } from './config.js';
export { identityKey, normalizeText, combineTruth, matchGroup, evaluateCandidate, compileEvaluator, compilePhraseRules, type PhraseRules, compileRuleTree, type RuleTree, execute } from './executor.js';
export { executeSnapshot, type SnapshotSelection } from './snapshot.js';
export { RecommendationSession, saveSettings } from './session.js';
