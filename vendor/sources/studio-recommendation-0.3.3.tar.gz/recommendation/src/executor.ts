import { DEFAULT_CONFIG, LIMITS, logicalPath, text, validateConfig, withinRoot } from './config.js';
import { RecommendationError, type AccessContext, type Candidate, type ContentIdentity, type Evaluation, type ExecutionResult, type PhraseGroup, type PickedCandidate, type RecommendationConfig, type Truth, type TextField } from './contracts.js';

export const identityKey = (identity: ContentIdentity): string => JSON.stringify([identity.namespace, identity.id, identity.part ?? null]);
/** literal-v1: NFKC, locale-independent lower case, collapse whitespace, trim. */
export const normalizeText = (value: string): string => value.normalize('NFKC').toLowerCase().replace(/\s+/gu, ' ').trim();
export function combineTruth(values: Truth[], mode: 'any' | 'all'): Truth {
  if (!values.length) return mode === 'all' ? 'yes' : 'no';
  if (mode === 'any') return values.includes('yes') ? 'yes' : values.includes('unknown') ? 'unknown' : 'no';
  return values.includes('no') ? 'no' : values.includes('unknown') ? 'unknown' : 'yes';
}
export function matchGroup(candidate: Candidate, group: PhraseGroup, algorithm: RecommendationConfig['algorithm'] = 'literal-v1'): Truth {
  const normalize = algorithm === 'literal-case-v1' ? (value: string) => value.toLocaleLowerCase() : normalizeText;
  const facts = group.fields.map(field => candidate[field]);
  const unknown = facts.some(value => value === undefined);
  const known = facts.flatMap(value => value === undefined ? [] : Array.isArray(value) ? value : [value]).map(normalize);
  return combineTruth(group.terms.map(term => known.some(value => value.includes(normalize(term))) ? 'yes' : unknown ? 'unknown' : 'no'), group.mode);
}

const candidateFields = ['identity', 'source', 'authorized', 'available', 'media', 'live', 'listened', 'title', 'originalTitle', 'displayTitle', 'author', 'authorId', 'tags', 'texts', 'categories', 'board', 'path', 'directory', 'directoryId', 'timestamp', 'provenance'];
const candidateFieldSet = new Set(candidateFields);
export function projectCandidate(value: unknown, copy = true, measure = true): Candidate {
  try {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('expected object');
    const row = value as Record<string, unknown>;
    for (const key in row) if (!candidateFieldSet.has(key)) throw new Error('unsupported/private candidate field');
    if (!row.identity || typeof row.identity !== 'object' || Array.isArray(row.identity)) throw new Error('stable identity required');
    const ident = row.identity as Record<string, unknown>;
    for (const key in ident) if (key !== 'namespace' && key !== 'id' && key !== 'part') throw new Error('unsupported identity field');
    const namespace = text(ident.namespace, 'identity.namespace'), id = text(ident.id, 'identity.id', 4096), part = ident.part === undefined ? undefined : text(ident.part, 'identity.part');
    if (typeof row.authorized !== 'boolean' || typeof row.available !== 'boolean') throw new Error('authorization and availability facts required');
    const source = text(row.source, 'source'), provenance = text(row.provenance, 'provenance', 512);
    const result: Candidate = copy ? { identity: { namespace, id, ...(part === undefined ? {} : { part }) }, source, authorized: row.authorized, available: row.available, provenance } : value as Candidate;
    for (const key of ['title', 'originalTitle', 'displayTitle', 'author', 'authorId', 'board'] as const) if (row[key] !== undefined) { const parsed = text(row[key], key, ['title','originalTitle','displayTitle'].includes(key) ? 1024 : 200); if (copy) result[key] = parsed; }
    for (const key of ['path', 'directory'] as const) if (row[key] !== undefined) { const parsed = logicalPath(row[key], key); if (copy) result[key] = parsed; }
    if(row.directoryId!==undefined){const parsed=text(row.directoryId,'directoryId',8192);if(copy)result.directoryId=parsed;}
    for (const key of ['tags', 'categories', 'texts'] as const) if (row[key] !== undefined) {
      const max = key === 'texts' ? 1102 : key === 'tags' ? 1100 : 48;
      if (!Array.isArray(row[key]) || row[key].length > max) throw new Error(`${key}: expected list <=${max}`);
      if (copy) result[key] = row[key].map((item: unknown) => text(item, key, key==='texts'?1024:200));
      else for (const item of row[key]) text(item, key, key==='texts'?1024:200);
    }
    if (row.media !== undefined) {
      if (!['audio', 'video', 'live'].includes(row.media as string)) throw new Error('invalid media');
      if (copy) result.media = row.media as Candidate['media'];
    }
    if (row.live !== undefined) { if (typeof row.live !== 'boolean') throw new Error('invalid live fact'); if (copy) result.live = row.live; }
    if (row.listened !== undefined) { if (typeof row.listened !== 'boolean') throw new Error('invalid listening fact'); if (copy) result.listened = row.listened; }
    if (row.timestamp !== undefined) { if (typeof row.timestamp !== 'number' || !Number.isFinite(row.timestamp) || row.timestamp < 0) throw new Error('invalid timestamp'); if (copy) result.timestamp = row.timestamp; }
    if (measure && candidateBytes(result) > LIMITS.candidateBytes) throw new Error('projection exceeds 16 KiB');
    return result;
  } catch (error) { throw new RecommendationError('invalid-candidate', error instanceof Error ? error.message : 'invalid facts'); }
}
const encoder = new TextEncoder();
export const candidateBytes = (candidate: Candidate): number => encoder.encode(JSON.stringify(candidate)).length;
export function validateAccess(value: AccessContext): AccessContext {
  const user = text(value.user, 'access.user'), authorizationRevision = text(value.authorizationRevision, 'access.authorizationRevision'), sourceRevision = text(value.sourceRevision, 'access.sourceRevision');
  if (!Array.isArray(value.grants) || value.grants.length > 100) throw new RecommendationError('invalid-config', 'access.grants: expected <=100 grants');
  const grants = value.grants.map(g => {
    const source = text(g.source, 'grant.source');
    if (g.roots !== undefined && (!Array.isArray(g.roots) || g.roots.length > 32)) throw new RecommendationError('invalid-config', 'grant.roots: expected <=32 roots');
    return { source, ...(g.roots === undefined ? {} : { roots: g.roots.map(p => logicalPath(p, 'grant.root')) }) };
  });
  if (new Set(grants.map(g => g.source)).size !== grants.length) throw new RecommendationError('invalid-config', 'duplicate access grant');
  return { user, authorizationRevision, sourceRevision, grants };
}
function evaluate(candidate: Candidate, config: RecommendationConfig, access: AccessContext): Evaluation {
  const reasons: string[] = [], hard: Truth[] = [];
  const check = (truth: Truth, reason: string) => { hard.push(truth); if (truth !== 'yes') reasons.push(`${reason}:${truth}`); };
  const grant = access.grants.find(g => g.source === candidate.source);
  check(grant && candidate.authorized ? 'yes' : 'no', 'authorization');
  check(candidate.available ? 'yes' : 'no', 'availability');
  if (grant?.roots !== undefined) check(candidate.path === undefined ? 'unknown' : grant.roots.some(r => withinRoot(candidate.path!, r)) ? 'yes' : 'no', 'authorization-root');
  const scope = config.scope;
  if (scope.unheard) check(candidate.listened === undefined ? 'unknown' : candidate.listened ? 'no' : 'yes', 'listening-history');
  if (scope.sources.length) check(scope.sources.includes(candidate.source) ? 'yes' : 'no', 'source');
  if (scope.roots.length) check(candidate.path === undefined ? 'unknown' : scope.roots.some(r => r.source === candidate.source && withinRoot(candidate.path!, r.path)) ? 'yes' : 'no', 'directory');
  if (scope.media.length) check(candidate.media === undefined ? 'unknown' : scope.media.includes(candidate.media) ? 'yes' : 'no', 'media');
  if (scope.boards.length) check(candidate.board === undefined ? 'unknown' : scope.boards.includes(candidate.board) ? 'yes' : 'no', 'board');
  if (scope.categories.length) check(candidate.categories === undefined ? 'unknown' : candidate.categories.some(c => scope.categories.includes(c)) ? 'yes' : 'no', 'category');
  if (scope.live !== undefined || candidate.media === 'live') {
    const wanted = candidate.media === 'live' ? true : scope.live;
    check(candidate.live === undefined ? 'unknown' : candidate.live === wanted && (scope.live === undefined || candidate.live === scope.live) ? 'yes' : 'no', 'live');
  }
  // Evaluate exclusions before includes: definite exclusion wins even if includes are unknown.
  const excludes = config.exclude.map(g => ({ g, truth: matchGroup(candidate, g, config.algorithm) }));
  const exclusion = combineTruth(excludes.map(e => e.truth), 'any');
  for (const e of excludes) if (e.truth !== 'no') reasons.push(`exclude:${e.g.id}:${e.truth}`);
  if (exclusion === 'yes') return { pass: false, truth: 'no', score: 0, reasons };
  const includes = config.include.groups.map(g => ({ g, truth: matchGroup(candidate, g, config.algorithm) }));
  const inclusion = includes.length ? combineTruth(includes.map(e => e.truth), config.include.mode) : 'yes';
  for (const e of includes) reasons.push(`include:${e.g.id}:${e.truth}`);
  const truth = combineTruth([...hard, inclusion, exclusion === 'unknown' ? 'unknown' : 'yes'], 'all');
  if (truth !== 'yes') return { pass: false, truth, score: 0, reasons: reasons.length ? reasons : [`include:${inclusion}`] };
  let score = 0;
  for (const preference of config.preferences) {
    const matched = matchGroup(candidate, preference, config.algorithm);
    if (matched === 'yes') score += preference.weight;
    reasons.push(`preference:${preference.id}:${matched}`);
  }
  return { pass: true, truth, score, reasons: reasons.length ? reasons : ['scope:yes'] };
}
export function evaluateCandidate(value: Candidate, config: RecommendationConfig, access: AccessContext): Evaluation {
  return evaluate(projectCandidate(value), validateConfig(config), validateAccess(access));
}
export function seededScore(seed: string, key: string): number {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) { hash ^= seed.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  hash = Math.imul(hash, 16777619);
  for (let i = 0; i < key.length; i++) { hash ^= key.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  hash ^= hash >>> 16; hash = Math.imul(hash, 0x7feb352d); hash ^= hash >>> 15; hash = Math.imul(hash, 0x846ca68b); hash ^= hash >>> 16;
  return hash >>> 0;
}
type CompiledGroup = PhraseGroup & { weight?: number; normalize?: (value: string) => string };
function compileGroup(group: CompiledGroup, algorithm: RecommendationConfig['algorithm']): CompiledGroup {
  const normalize = algorithm === 'literal-case-v1' ? (value: string) => value.toLocaleLowerCase() : normalizeText;
  return { ...group, normalize, terms: group.terms.map(normalize) };
}
function compiledMatch(candidate: Candidate, group: CompiledGroup, cache: Partial<Record<TextField, string[] | null>>): Truth {
  let unknown = false;
  for (const term of group.terms) {
    let hit = false, missing = false;
    for (const field of group.fields) {
      if (!Object.hasOwn(cache, field)) {
        const fact = candidate[field]; cache[field] = fact === undefined ? null : (Array.isArray(fact) ? fact : [fact]).map(group.normalize!);
      }
      const facts = cache[field];
      if (facts === null) missing = true;
      else if (facts!.some(value => value.includes(term))) { hit = true; break; }
    }
    if (group.mode === 'any' && hit) return 'yes';
    if (group.mode === 'all' && !hit && !missing) return 'no';
    if (!hit && missing) unknown = true;
  }
  return unknown ? 'unknown' : group.mode === 'all' ? 'yes' : 'no';
}
/** Allocation-bounded pool assessment; full reasons are built only for selected/diagnostic rows. */
function assess(candidate: Candidate, config: RecommendationConfig, grants: Map<string, AccessContext['grants'][number]>, groups: { include: CompiledGroup[]; exclude: CompiledGroup[]; preferences: CompiledGroup[] }): { truth: Truth; score: number; reason: string } {
  let missing = '';
  const grant = grants.get(candidate.source), scope = config.scope;
  if (!grant || !candidate.authorized) return { truth: 'no', score: 0, reason: 'authorization:no' };
  if (!candidate.available) return { truth: 'no', score: 0, reason: 'availability:no' };
  if (scope.unheard) {
    if (candidate.listened === undefined) missing = 'listening-history:unknown';
    else if (candidate.listened) return { truth: 'no', score: 0, reason: 'listening-history:no' };
  }
  if (scope.sources.length && !scope.sources.includes(candidate.source)) return { truth: 'no', score: 0, reason: 'source:no' };
  if (grant.roots !== undefined) {
    if (candidate.path === undefined) missing = 'authorization-root:unknown';
    else if (!grant.roots.some(root => withinRoot(candidate.path!, root))) return { truth: 'no', score: 0, reason: 'authorization-root:no' };
  }
  if (scope.roots.length) {
    if (candidate.path === undefined) missing ||= 'directory:unknown';
    else if (!scope.roots.some(r => r.source === candidate.source && withinRoot(candidate.path!, r.path))) return { truth: 'no', score: 0, reason: 'directory:no' };
  }
  if (scope.media.length) {
    if (candidate.media === undefined) missing ||= 'media:unknown';
    else if (!scope.media.includes(candidate.media)) return { truth: 'no', score: 0, reason: 'media:no' };
  }
  if (scope.boards.length) {
    if (candidate.board === undefined) missing ||= 'board:unknown';
    else if (!scope.boards.includes(candidate.board)) return { truth: 'no', score: 0, reason: 'board:no' };
  }
  if (scope.categories.length) {
    if (candidate.categories === undefined) missing ||= 'category:unknown';
    else if (!candidate.categories.some(c => scope.categories.includes(c))) return { truth: 'no', score: 0, reason: 'category:no' };
  }
  if (scope.live !== undefined || candidate.media === 'live') {
    if (candidate.live === undefined) missing ||= 'live:unknown';
    else if (candidate.live !== (candidate.media === 'live' ? true : scope.live) || (scope.live !== undefined && candidate.live !== scope.live)) return { truth: 'no', score: 0, reason: 'live:no' };
  }
  const cache: Partial<Record<TextField, string[] | null>> = {};
  for (const group of groups.exclude) {
    const truth = compiledMatch(candidate, group, cache);
    if (truth === 'yes') return { truth: 'no', score: 0, reason: `exclude:${group.id}:yes` };
    if (truth === 'unknown') missing ||= `exclude:${group.id}:unknown`;
  }
  let yes = false, no = false, unknown = false;
  for (const group of groups.include) {
    const truth = compiledMatch(candidate, group, cache); yes ||= truth === 'yes'; no ||= truth === 'no'; unknown ||= truth === 'unknown';
  }
  const inclusion: Truth = !groups.include.length ? 'yes' : config.include.mode === 'any' ? yes ? 'yes' : unknown ? 'unknown' : 'no' : no ? 'no' : unknown ? 'unknown' : 'yes';
  if (inclusion === 'no') return { truth: 'no', score: 0, reason: 'include:no' };
  if (inclusion === 'unknown') missing ||= 'include:unknown';
  if (missing) return { truth: 'unknown', score: 0, reason: missing };
  let score = 0;
  for (const group of groups.preferences) if (compiledMatch(candidate, group, cache) === 'yes') score += group.weight!;
  return { truth: 'yes', score, reason: 'scope:yes' };
}
const lexical = (a: string, b: string) => a < b ? -1 : a > b ? 1 : 0;
const natural = new Intl.Collator('zh-CN', { numeric: true });
/** Shared author partition semantics for pool and complete snapshot execution. */
export function authorGroup(candidate: Candidate, diversity: RecommendationConfig['diversity']): string {
  const author = candidate.authorId ?? (candidate.author === undefined
    ? diversity.unknownAuthor === 'distinct' ? identityKey(candidate.identity) : null
    : normalizeText(candidate.author));
  return JSON.stringify([candidate.source, author]);
}
/** Pure compiled rules, for host classification and snapshot execution. No reads or history. */
export function compileEvaluator(value: RecommendationConfig, permissions: AccessContext) {
  const config = validateConfig(value), access = validateAccess(permissions), grants = new Map(access.grants.map(g => [g.source, g]));
  const groups = { include: config.include.groups.map(g => compileGroup(g, config.algorithm)), exclude: config.exclude.map(g => compileGroup(g, config.algorithm)), preferences: config.preferences.map(g => compileGroup(g, config.algorithm)) };
  return (candidate: Candidate) => assess(candidate, config, grants, groups);
}
export interface PhraseRules { algorithm:RecommendationConfig['algorithm'];include:{mode:'any'|'all';groups:PhraseGroup[]};exclude:PhraseGroup[] }
/** Composes separately validated phrase leaves without losing any/all or exclusion priority.
 * The host retains its own full settings/request byte limit; each public leaf keeps 64 KiB.
 */
export function compilePhraseRules(rules:PhraseRules){
  const base=validateConfig({...DEFAULT_CONFIG,algorithm:rules.algorithm,include:{mode:rules.include.mode,groups:[]}});
  const parse=(values:PhraseGroup[])=>{
    if(!Array.isArray(values)||values.length>16||new Set(values.map(g=>g.id)).size!==values.length)throw new RecommendationError('invalid-config','invalid phrase group collection');
    return values.map(g=>compileGroup(validateConfig({...base,include:{mode:'any',groups:[g]}}).include.groups[0],rules.algorithm));
  };
  const include=parse(rules.include.groups),exclude=parse(rules.exclude);
  return (candidate:Candidate)=>{
    const cache:Partial<Record<TextField,string[]|null>>={};
    const exclusion=combineTruth(exclude.map(g=>compiledMatch(candidate,g,cache)),'any');
    if(exclusion==='yes')return {truth:'no' as Truth,score:0,reason:'exclude:phrases:yes'};
    const inclusion=include.length?combineTruth(include.map(g=>compiledMatch(candidate,g,cache)),rules.include.mode):'yes';
    const truth=combineTruth([inclusion,exclusion==='unknown'?'unknown':'yes'],'all');
    return {truth,score:0,reason:exclusion==='unknown'?'exclude:phrases:unknown':truth==='yes'?'scope:yes':`include:${truth}`};
  };
}
export type RuleTree = RecommendationConfig | {mode:'any'|'all';children:RuleTree[]};
/** Bounded composition of existing configurations. Every leaf retains the original config cap. */
export function compileRuleTree(tree:RuleTree,access:AccessContext){
  let leaves=0,nodes=0;
  const compile=(node:RuleTree,depth:number):ReturnType<typeof compileEvaluator>=>{
    if(!node||typeof node!=='object'||Array.isArray(node))throw new RecommendationError('invalid-config','invalid rule node');
    if(++nodes>32||depth>3)throw new RecommendationError('invalid-config','rule composition exceeds bounds');
    if('children' in node){
      if(Object.keys(node).some(k=>k!=='mode'&&k!=='children'))throw new RecommendationError('invalid-config','unsupported rule node field');
      if(!['any','all'].includes(node.mode)||!Array.isArray(node.children)||!node.children.length||node.children.length>16)throw new RecommendationError('invalid-config','invalid rule composition');
      const children=node.children.map(child=>compile(child,depth+1));
      return candidate=>{const results=children.map(check=>check(candidate)),truth=combineTruth(results.map(r=>r.truth),node.mode);
        const rejected=results.find(r=>r.truth!=='yes'&&r.reason.startsWith('exclude:')) ?? results.find(r=>r.truth!=='yes');
        return {truth,score:truth==='yes'?(node.mode==='all'?results.reduce((sum,r)=>sum+r.score,0):Math.max(...results.filter(r=>r.truth==='yes').map(r=>r.score))):0,reason:truth==='yes'?'scope:yes':rejected?.reason ?? `composition:${truth}`};};
    }
    if(++leaves>16)throw new RecommendationError('invalid-config','too many rule leaves');
    return compileEvaluator(node,access);
  };
  return compile(tree,0);
}
/** Same executor for preview and display; does not read or mutate any history. */
export function execute(input: { candidates: readonly Candidate[]; config: RecommendationConfig; access: AccessContext; seed: string; recent?: readonly string[]; signal?: AbortSignal; all?:boolean }): ExecutionResult {
  return executePrepared(input, false);
}
/** Internal: session has already validated and accounted for each immutable projection. */
export function executePrepared(input: { candidates: readonly Candidate[]; config: RecommendationConfig; access: AccessContext; seed: string; recent?: readonly string[]; signal?: AbortSignal; all?:boolean }, prepared = true): ExecutionResult {
  return executePool({ ...input, count: input.candidates.length, at: index => input.candidates[index] }, prepared);
}
export function executeIndexed(input: { count: number; at: (index: number) => Candidate; config: RecommendationConfig; access: AccessContext; seed: string; recent?: readonly string[]; signal?: AbortSignal }): ExecutionResult { return executePool(input, true); }
function executePool(input: { count: number; at: (index: number) => Candidate; config: RecommendationConfig; access: AccessContext; seed: string; recent?: readonly string[]; signal?: AbortSignal; all?:boolean }, prepared: boolean): ExecutionResult {
  const config = validateConfig(input.config), access = validateAccess(input.access), started = performance.now();
  if(input.all!==undefined&&typeof input.all!=='boolean')throw new RecommendationError('invalid-config','all must be an explicit boolean');
  const target=input.all?input.count:config.batchSize;
  text(input.seed, 'seed', 512);
  if (input.count > config.budget.candidates) throw new RecommendationError('budget', 'candidate count exceeded');
  if ((input.recent?.length ?? 0) > LIMITS.history) throw new RecommendationError('budget', 'history exceeded');
  const recent = new Set(input.recent), used = new Set<string>();
  const grants = new Map(access.grants.map(g => [g.source, g]));
  const compiled = { include: config.include.groups.map(g => compileGroup(g, config.algorithm)), exclude: config.exclude.map(g => compileGroup(g, config.algorithm)), preferences: config.preferences.map(g => compileGroup(g, config.algorithm)) };
  const diagnostics: ExecutionResult['diagnostics'] = { read: input.count, eligible: 0, duplicates: 0, recent: 0, diversity: 0, rejected: {}, samples: [] };
  const eligible: number[] = [], keys: string[] = new Array(input.count);
  const scores = new Uint16Array(input.count), random = new Uint32Array(input.count), repeats = new Uint8Array(input.count), times = new Float64Array(config.order === 'time' || config.order==='time-zero-v1' ? input.count : 0);
  times.fill(NaN);
  const sourceNames = new Map<string, string>(), sources: string[] = [];
  let bytes = 0;
  const budget = () => {
    if (input.signal?.aborted) throw new RecommendationError('cancelled', 'execution cancelled');
    if (performance.now() - started > LIMITS.executionMs) throw new RecommendationError('timeout', 'execution exceeded 5 seconds');
  };
  for (let i = 0; i < input.count; i++) {
    if (i % LIMITS.page === 0) budget();
    const candidate = prepared ? input.at(i) : projectCandidate(input.at(i), false, false);
    if (!prepared) { const size = candidateBytes(candidate); if (size > LIMITS.candidateBytes) throw new RecommendationError('invalid-candidate', 'projection exceeds 16 KiB'); bytes += size; }
    if (bytes > config.budget.bytes) throw new RecommendationError('budget', 'candidate memory exceeded');
    const key = identityKey(candidate.identity), result = assess(candidate, config, grants, compiled);
    if (result.truth !== 'yes') {
      const reason = result.reason;
      diagnostics.rejected[reason] = (diagnostics.rejected[reason] ?? 0) + 1;
      if (diagnostics.samples.length < LIMITS.samples) diagnostics.samples.push({ key, reasons: evaluate(candidate, config, access).reasons });
      continue;
    }
    if (used.has(key)) { diagnostics.duplicates++; continue; }
    used.add(key); diagnostics.eligible++;
    const repeated = recent.has(key);
    if (repeated) { diagnostics.recent++; if (config.repeat === 'never') continue; }
    keys[i] = key; scores[i] = result.score; random[i] = seededScore(input.seed, key); repeats[i] = Number(repeated);
    if (config.order === 'time' || config.order==='time-zero-v1') times[i] = candidate.timestamp ?? (config.order==='time-zero-v1'?0:NaN);
    if (config.mix.length) { if (!sourceNames.has(candidate.source)) sourceNames.set(candidate.source, candidate.source); sources[i] = sourceNames.get(candidate.source)!; }
    eligible.push(i);
  }
  eligible.sort((a, b) => repeats[a] - repeats[b] || (
    config.order === 'score' ? scores[b] - scores[a] :
    config.order === 'time' ? (Number.isNaN(times[a]) && Number.isNaN(times[b]) ? 0 : Number.isNaN(times[a]) ? 1 : Number.isNaN(times[b]) ? -1 : times[b] - times[a]) :
    config.order === 'time-zero-v1' ? times[b]-times[a] :
    config.order === 'name' ? natural.compare(input.at(a).originalTitle ?? input.at(a).title ?? '', input.at(b).originalTitle ?? input.at(b).title ?? '') :
    config.order === 'random' ? random[a] - random[b] : a - b
  ) || (config.order==='name'||config.order==='time-zero-v1'?keys[a].localeCompare(keys[b]):lexical(keys[a], keys[b])));
  budget();
  const items: PickedCandidate[] = [], authors = new Map<string, number>(), directories = new Map<string, number>();
  const select = (index: number) => {
    const candidate = input.at(index);
    const author = authorGroup(candidate, config.diversity);
    const directory = JSON.stringify([candidate.source, candidate.directoryId ?? candidate.directory ?? null]);
    if ((config.diversity.author && (authors.get(author) ?? 0) >= config.diversity.author) || (config.diversity.directory && (directories.get(directory) ?? 0) >= config.diversity.directory)) { diagnostics.diversity++; return false; }
    authors.set(author, (authors.get(author) ?? 0) + 1); directories.set(directory, (directories.get(directory) ?? 0) + 1);
    items.push({ candidate: projectCandidate(candidate), key: keys[index], score: scores[index], reasons: evaluate(candidate, config, access).reasons, repeated: Boolean(repeats[index]) }); return true;
  };
  // Fresh candidates always exhaust before explicitly permitted repeats, including with mixing.
  for (const repeated of [false, true]) {
    if (items.length >= target) break;
    const pool = eligible.filter(e => Boolean(repeats[e]) === repeated);
    if (!config.mix.length) { for (const e of pool) { select(e); if (items.length >= target) break; } }
    else {
      const groups = new Map<string, { pool: typeof pool; index: number; selected: number; weight: number }>();
      for (const e of pool) {
        const source = sources[e];
        let g = groups.get(source);
        if (!g) { g = { pool: [], index: 0, selected: 0, weight: config.mix.find(m => m.source === source)?.weight ?? 1 }; groups.set(source, g); }
        g.pool.push(e);
      }
      while (items.length < target) {
        const next = [...groups.entries()].filter(([, g]) => g.index < g.pool.length).sort(([sa, a], [sb, b]) => (a.selected + 1) / a.weight - (b.selected + 1) / b.weight
          || (config.algorithm==='literal-case-v1' && config.order==='random'?seededScore(input.seed,sa)-seededScore(input.seed,sb):0) || lexical(sa, sb))[0];
        if (!next) break;
        const g = next[1]; if (select(g.pool[g.index++])) g.selected++;
      }
    }
  }
  budget();
  const shortage = items.length >= target ? [] : [
    ...(Object.keys(diagnostics.rejected).length ? ['rules-or-scope'] : []), ...(diagnostics.duplicates ? ['duplicates'] : []),
    ...(diagnostics.recent ? ['recent-history'] : []), ...(diagnostics.diversity ? ['diversity'] : []), 'candidate-pool',
  ];
  return { items, diagnostics, shortage };
}
