import { LIMITS } from './config.js';
import { RecommendationError, type Candidate } from './contracts.js';
/** Compact immutable snapshots. Bounded off-heap chunks avoid retaining JSON/object graphs. */
export class CandidateBuffer {
  private readonly chunkSize = 1024 * 1024;
  private readonly chunks: Uint8Array[] = [];
  private readonly positions: Uint32Array;
  private readonly lengths: Uint16Array;
  private count = 0;
  private position = 0;
  private readonly decoder = new TextDecoder();
  constructor(capacity: number) { this.positions = new Uint32Array(capacity); this.lengths = new Uint16Array(capacity); }
  append(bytes: Uint8Array): number {
    if (bytes.length > LIMITS.candidateBytes || this.count >= this.positions.length) throw new RecommendationError('budget', 'candidate buffer exceeded');
    if (this.position % this.chunkSize + bytes.length > this.chunkSize) this.position = Math.ceil(this.position / this.chunkSize) * this.chunkSize;
    const chunk = Math.floor(this.position / this.chunkSize);
    if (!this.chunks[chunk]) this.chunks[chunk] = new Uint8Array(this.chunkSize);
    this.chunks[chunk].set(bytes, this.position % this.chunkSize);
    const index = this.count++; this.positions[index] = this.position; this.lengths[index] = bytes.length; this.position += bytes.length;
    return index;
  }
  at(index: number): Candidate {
    const position = this.positions[index], chunk = Math.floor(position / this.chunkSize), offset = position % this.chunkSize;
    return JSON.parse(this.decoder.decode(this.chunks[chunk].subarray(offset, offset + this.lengths[index]))) as Candidate;
  }
}
