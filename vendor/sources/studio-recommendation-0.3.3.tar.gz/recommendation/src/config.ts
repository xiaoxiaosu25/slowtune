import { RecommendationError, type RecommendationConfig, type SettingsDocument, type PhraseGroup, type HardScope, type TextField } from './contracts.js';

export const LIMITS = Object.freeze({ batch: 500, candidates: 100000, page: 500, pages: 200, concurrency: 2, ports: 8, timeoutMs: 30000, executionMs: 5000, bytes: 32 * 1024 * 1024, candidateBytes: 16 * 1024, configBytes: 64 * 1024, history: 100, samples: 8 });
function freezeDefault<T>(value: T): T { if (value && typeof value === 'object') { Object.freeze(value); for (const child of Object.values(value)) freezeDefault(child); } return value; }
export const DEFAULT_CONFIG: RecommendationConfig = freezeDefault({
  schema: 1, algorithm: 'literal-v1', scope: { sources: [], roots: [], media: [], boards: [], categories: [] },
  include: { mode: 'any', groups: [] }, exclude: [], preferences: [], order: 'upstream', mix: [],
  diversity: { author: 0, directory: 0 }, batchSize: 12, repeat: 'never',
  budget: { candidates: 10000, bytes: LIMITS.bytes, timeoutMs: LIMITS.timeoutMs },
});
export function fail(path: string, message: string): never { throw new RecommendationError('invalid-config', `${path}: ${message}`); }
export function record(value: unknown, path: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail(path, 'expected object');
  return value as Record<string, unknown>;
}
function keys(row: Record<string, unknown>, allowed: string[], path: string) {
  for (const key of Object.keys(row)) if (!allowed.includes(key)) fail(`${path}.${key}`, 'unsupported field');
}
export function text(value: unknown, path: string, max = 200): string {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u001f]/.test(value)) fail(path, 'expected nonempty bounded text');
  return value;
}
function integer(value: unknown, min: number, max: number, path: string): number {
  if (!Number.isSafeInteger(value) || Number(value) < min || Number(value) > max) fail(path, `expected integer ${min}..${max}`);
  return value as number;
}
function choice<T extends string>(value: unknown, values: T[], path: string): T {
  if (!values.includes(value as T)) fail(path, `expected ${values.join('|')}`);
  return value as T;
}
function list<T>(value: unknown, max: number, path: string, parse: (v: unknown, p: string) => T): T[] {
  if (!Array.isArray(value) || value.length > max) fail(path, `expected list <=${max}`);
  return value.map((v, i) => parse(v, `${path}[${i}]`));
}
function strings(value: unknown, max: number, path: string, length = 200): string[] {
  const result = list(value, max, path, (v, p) => text(v, p, length));
  if (new Set(result).size !== result.length) fail(path, 'duplicate values');
  return result;
}
export function logicalPath(value: unknown, path: string): string {
  const result = text(value, path, 4096);
  if (!result.startsWith('/') || result.includes('\\') || result.includes('//') || (result !== '/' && result.endsWith('/')) || /\/(?:\.|\.\.)(?:\/|$)/.test(result)) fail(path, 'expected canonical logical path');
  return result;
}
export function withinRoot(value: string, root: string): boolean { return root === '/' || value === root || value.startsWith(root + '/'); }
function group(value: unknown, path: string, preference = false): PhraseGroup & { weight?: number } {
  const row = record(value, path); keys(row, ['id', 'fields', 'mode', 'terms', ...(preference ? ['weight'] : [])], path);
  const fields = list(row.fields, 8, `${path}.fields`, (v, p) => choice<TextField>(v, ['title', 'originalTitle', 'displayTitle', 'author', 'tags', 'categories', 'path', 'texts'], p));
  if (!fields.length || new Set(fields).size !== fields.length) fail(`${path}.fields`, 'one or more distinct fields required');
  const terms = strings(row.terms, 24, `${path}.terms`, 120);
  if (!terms.length) fail(`${path}.terms`, 'empty group; use an empty group list for no restriction');
  return { id: text(row.id, `${path}.id`, 80), fields, mode: choice(row.mode, ['any', 'all'], `${path}.mode`), terms, ...(preference ? { weight: integer(row.weight, 1, 100, `${path}.weight`) } : {}) };
}
function groups(value: unknown, path: string, preference = false) {
  const result = list(value, 16, path, (v, p) => group(v, p, preference));
  if (new Set(result.map(g => g.id)).size !== result.length) fail(path, 'duplicate group id');
  return result;
}
function byteCheck(value: unknown) {
  let encoded: string;
  try { encoded = JSON.stringify(value); } catch { fail('config', 'not JSON'); }
  if (!encoded! || new TextEncoder().encode(encoded!).length > LIMITS.configBytes) fail('config', 'JSON exceeds 64 KiB');
}
export function validateConfig(value: unknown): RecommendationConfig {
  byteCheck(value);
  const row = record(value, 'config');
  keys(row, Object.keys(DEFAULT_CONFIG), 'config');
  if (row.schema !== 1 || !['literal-v1', 'literal-case-v1'].includes(String(row.algorithm))) fail('config', 'unsupported schema/algorithm');
  const scope = record(row.scope, 'scope'); keys(scope, ['sources', 'roots', 'media', 'boards', 'categories', 'live', 'unheard'], 'scope');
  if (scope.live !== undefined && typeof scope.live !== 'boolean') fail('scope.live', 'expected boolean');
  if (scope.unheard !== undefined && typeof scope.unheard !== 'boolean') fail('scope.unheard', 'expected boolean');
  const hard: HardScope = {
    sources: strings(scope.sources, 100, 'scope.sources'),
    roots: list(scope.roots, 32, 'scope.roots', (v, p) => { const r = record(v, p); keys(r, ['source', 'path'], p); return { source: text(r.source, `${p}.source`), path: logicalPath(r.path, `${p}.path`) }; }),
    media: list(scope.media, 3, 'scope.media', (v, p) => choice(v, ['audio', 'video', 'live'], p)),
    boards: strings(scope.boards, 100, 'scope.boards'), categories: strings(scope.categories, 48, 'scope.categories'),
    ...(scope.live === undefined ? {} : { live: scope.live as boolean }),
    ...(scope.unheard === undefined ? {} : { unheard: scope.unheard as boolean }),
  };
  if (new Set(hard.media).size !== hard.media.length) fail('scope.media', 'duplicate values');
  const include = record(row.include, 'include'); keys(include, ['mode', 'groups'], 'include');
  const diversity = record(row.diversity, 'diversity'); keys(diversity, ['author', 'directory', 'unknownAuthor'], 'diversity');
  const budget = record(row.budget, 'budget'); keys(budget, ['candidates', 'bytes', 'timeoutMs'], 'budget');
  const mix = list(row.mix, LIMITS.ports, 'mix', (v, p) => { const r = record(v, p); keys(r, ['source', 'weight'], p); return { source: text(r.source, `${p}.source`), weight: integer(r.weight, 1, 100, `${p}.weight`) }; });
  if (new Set(mix.map(m => m.source)).size !== mix.length) fail('mix', 'duplicate source');
  return {
    schema: 1, algorithm: row.algorithm as RecommendationConfig['algorithm'], scope: hard,
    include: { mode: choice(include.mode, ['any', 'all'], 'include.mode'), groups: groups(include.groups, 'include.groups') },
    exclude: groups(row.exclude, 'exclude'), preferences: groups(row.preferences, 'preferences', true) as RecommendationConfig['preferences'],
    order: choice(row.order, ['upstream', 'score', 'time', 'time-zero-v1', 'random', 'name'], 'order'), mix,
    diversity: { author: integer(diversity.author, 0, 100, 'diversity.author'), directory: integer(diversity.directory, 0, 100, 'diversity.directory'), ...(diversity.unknownAuthor===undefined?{}:{unknownAuthor:choice<'shared'|'distinct'>(diversity.unknownAuthor,['shared','distinct'],'diversity.unknownAuthor')}) },
    batchSize: integer(row.batchSize, 1, LIMITS.batch, 'batchSize'), repeat: choice(row.repeat, ['never', 'after-fresh'], 'repeat'),
    budget: { candidates: integer(budget.candidates, 1, LIMITS.candidates, 'budget.candidates'), bytes: integer(budget.bytes, 1, LIMITS.bytes, 'budget.bytes'), timeoutMs: integer(budget.timeoutMs, 1, LIMITS.timeoutMs, 'budget.timeoutMs') },
  };
}
export function validateSettings(value: unknown): SettingsDocument {
  byteCheck(value);
  const row = record(value, 'settings'); keys(row, ['schema', 'revision', 'preset', 'overrides'], 'settings');
  if (row.schema !== 1) fail('settings.schema', 'unsupported version');
  const preset = record(row.preset, 'preset'); keys(preset, ['id', 'revision', 'config'], 'preset');
  const config = validateConfig(preset.config), overrides = record(row.overrides, 'overrides');
  keys(overrides, Object.keys(DEFAULT_CONFIG).filter(k => k !== 'schema' && k !== 'algorithm'), 'overrides');
  const effective = validateConfig({ ...config, ...overrides });
  const clean: Record<string, unknown> = {};
  for (const key of Object.keys(overrides)) clean[key] = effective[key as keyof RecommendationConfig];
  return { schema: 1, revision: text(row.revision, 'revision'), preset: { id: text(preset.id, 'preset.id'), revision: text(preset.revision, 'preset.revision'), config }, overrides: clean };
}
export function resolveSettings(value: unknown) {
  const document = validateSettings(value), config = validateConfig({ ...document.preset.config, ...document.overrides });
  const origins = Object.fromEntries(Object.keys(config).map(k => [k, Object.hasOwn(document.overrides, k) ? 'personal' : 'preset']));
  return { document, config, origins };
}
