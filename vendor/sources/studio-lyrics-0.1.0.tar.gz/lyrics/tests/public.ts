import { parseLyrics, activeLyricLine, lyricFill, type LyricDocumentCache } from '@studio/lyrics';
import { LyricProviders } from '@studio/lyrics/providers';
declare const cache: LyricDocumentCache;
const lines = parseLyrics('[00:01]text');
void activeLyricLine(lines, 1, 0); void lyricFill(lines, 0, 1000);
const providers = new LyricProviders(cache); void providers.dispose();
// @ts-expect-error A document lookup requires an explicit signal.
void providers.document({ provider: 'lrclib', id: '1' });
