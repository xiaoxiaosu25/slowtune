import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseLyrics,activeLyricLine,automaticLyricCandidates,lyricQuery,lyricFill,lyricWords} from '../dist/index.js';
import {LyricProviders} from '../dist/providers.js';
const signal=()=>new AbortController().signal;
const tick=()=>new Promise(resolve=>setImmediate(resolve));
const row={id:123,trackName:'歌曲',artistName:'歌手',duration:60,syncedLyrics:'[00:01]第一行\n[00:03]第二行'};
function cache(){const docs=new Map();return {cached:id=>docs.get(id),cache:document=>docs.set(document.provider+':'+document.id,document),docs};}

test('LRC parsing preserves offsets, repeated stamps, translations and untimed text without fabricating word times',()=>{
  const lines=parseLyrics('[offset:500]\n[00:03.25][00:09.250]重复\n[00:01.00]开始\n[00:05] \n[00:01.000]合唱','[offset:500]\n[00:03.25]翻译');
  assert.deepEqual(lines,[{startMs:500,text:'开始\n合唱'},{startMs:2750,text:'重复',translation:'翻译'},{startMs:4500,text:''},{startMs:8750,text:'重复'}]);
  assert.equal(activeLyricLine(lines,3,500),0);assert.deepEqual(parseLyrics('plain\ntext'),[{startMs:null,text:'plain'},{startMs:null,text:'text'}]);
  for(const body of ['a'.repeat(128*1024+1),'x\n'.repeat(4001),'x'.repeat(2001)])assert.throws(()=>parseLyrics(body),{code:'invalid-input'});
});
test('matching requires exact title, version and corroborating metadata, and never uses an uploader as a singer',()=>{
  const candidate={provider:'lrclib',id:'123',title:'歌曲',artists:['歌手'],durationSeconds:60};
  assert.equal(automaticLyricCandidates([candidate],{title:'歌曲',artist:'歌手',durationSeconds:61}).length,1);
  for(const query of [{title:'歌曲 Live',artist:'歌手'},{title:'歌曲',artist:'其他'},{title:'歌曲',artist:'歌手',durationSeconds:90}])assert.equal(automaticLyricCandidates([candidate],query).length,0);
  assert.equal(lyricQuery('《歌曲》').artist,'');assert.equal(lyricFill([{startMs:1000,text:'句'}],0,1500,2000),.5);
  assert.equal(lyricWords({startMs:0,text:'词',words:[{startMs:0,endMs:0,text:'词'}]}),undefined);
});
test('provider partial failure is not cached; search and document snapshots do not share mutable cache data',async()=>{
  let fail=true,calls=0;const store=cache(),providers=new LyricProviders(store,async input=>{
    calls++;const url=new URL(input);if(url.hostname==='music.163.com')return fail?new Response('',{status:503}):Response.json({code:200,result:{songCount:0}});
    return Response.json(url.pathname==='/api/search'?[row]:row);
  });
  try{
    const first=await providers.search({title:'歌曲'},signal());assert.equal(first.issues.length,1);
    fail=false;const second=await providers.search({title:'歌曲'},signal());assert.equal(second.issues.length,0);const before=calls;second.candidates.length=0;
    assert.equal((await providers.search({title:'歌曲'},signal())).candidates.length,1);assert.equal(calls,before);
    const doc=await providers.document({provider:'lrclib',id:'123'},signal());doc.lines[0].text='mutated';
    assert.equal((await providers.document({provider:'lrclib',id:'123'},signal())).lines[0].text,'第一行');
  }finally{await providers.dispose();}
});
test('shared consumers cancel independently and disposal waits for stalled body cancellation before the cache closes',async()=>{
  let release,calls=0;const store=cache(),providers=new LyricProviders(store,async()=>{calls++;await new Promise(resolve=>release=resolve);return Response.json(row);});
  const controller=new AbortController(),a=providers.document({provider:'lrclib',id:'123'},controller.signal,true),b=providers.document({provider:'lrclib',id:'123'},signal(),true);
  await tick();controller.abort();await assert.rejects(a,{code:'cancelled'});release();await b;assert.equal(calls,1);await providers.dispose();
  let cancelled=0;const stalled=new LyricProviders(cache(),async()=>new Response(new ReadableStream({cancel(){cancelled++;}})));
  const pending=stalled.document({provider:'lrclib',id:'123'},signal());const rejected=assert.rejects(pending,{code:'cancelled'});
  await tick();await stalled.dispose();await rejected;assert.equal(cancelled,1);await assert.rejects(stalled.document({provider:'lrclib',id:'123'},signal()),{code:'disposed'});
});
