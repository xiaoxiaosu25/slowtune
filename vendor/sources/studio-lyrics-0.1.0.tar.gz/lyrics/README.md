# 无界面歌词

版本：v1.1 · 2026-10-27 · 状态：可用，慢听固定消费；未公开发布

独立的 LRC／纯文本解析、翻译对齐、偏移和实际媒体时钟计算；可选提供方入口查询网易云与 LRCLIB。没有 UI、播放器、数据库、来源账号或隐式任务。根入口运行依赖为空，提供方由宿主显式传入 fetch、时钟及正文缓存端口。

歌词选择、CAS 修订、用户隔离、自动采用决策及持久化属于宿主。匹配只返回候选，不自动覆盖人工选择；上传者不作为歌手。别名由调用方显式提供。普通 LRC 不制造逐字时间，纯文本不制造同步信息。

上游读取、缓存及取消有界；部分失败不进入完整搜索缓存。调用者独立取消，最后等待者等待共享请求清理。销毁取消请求并等待结束，宿主随后关闭缓存。正文与时间边界由源码契约维护；通过固定制品接入慢听。当前证据尚不形成广泛复用或设备支持声明。

```js
import { parseLyrics, activeLyricLine } from '@studio/lyrics';
const lines = parseLyrics('[00:01.00]歌词');
const index = activeLyricLine(lines, hostMediaPositionSeconds, hostSavedOffsetMs);
```

根入口可在浏览器使用，无 Node 或播放器依赖；可选 `./providers` 首批在 Node 使用，宿主提供同步正文缓存接口，库不创建文件或监听。调用 search／document 才访问网络；查询参数中的桌面优化选择只控制在途共享和预算，不决定宿主类型或自动采用。独立检查运行 `npm ci`、`npm run check`。维护与证据见[能力入口](../../../docs/audio-video/lyrics/README.md)。
