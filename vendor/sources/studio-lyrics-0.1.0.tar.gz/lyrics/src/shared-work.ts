import { LyricsError } from './contracts.js';
/** Only in-flight requests are shared; the last consumer waits for owned cleanup. */
export class SharedWork {
  private jobs = new Map<string, { controller: AbortController; promise: Promise<unknown>; users: number }>();
  private pending = new Set<Promise<unknown>>();
  run<T>(_owner: string, key: string, signal: AbortSignal, task: (signal: AbortSignal) => Promise<T>): Promise<T> {
    signal.throwIfAborted();
    let job = this.jobs.get(key);
    if (!job || job.controller.signal.aborted) {
      if (this.pending.size >= 64) return Promise.reject(new LyricsError('busy'));
      const controller = new AbortController(), promise = Promise.resolve().then(() => { controller.signal.throwIfAborted(); return task(controller.signal); });
      job = { controller, promise, users: 0 }; this.jobs.set(key, job); this.pending.add(promise);
      const current = job;
      const finish = () => { this.pending.delete(promise); if (this.jobs.get(key) === current) this.jobs.delete(key); };
      promise.then(finish, finish);
    }
    const current = job; current.users++;
    return new Promise<T>((resolve, reject) => {
      let done = false;
      const leave = () => { done = true; current.users--; signal.removeEventListener('abort', abort); };
      const abort = () => {
        if (done) return; leave();
        if (current.users) reject(signal.reason);
        else { current.controller.abort(signal.reason); current.promise.then(() => reject(signal.reason), () => reject(signal.reason)); }
      };
      signal.addEventListener('abort', abort, { once: true });
      current.promise.then(value => { if (!done) { leave(); resolve(structuredClone(value) as T); } }, error => { if (!done) { leave(); reject(error); } });
      if (signal.aborted) abort();
    });
  }
  async dispose() { for (const job of this.jobs.values()) job.controller.abort(); await Promise.allSettled(this.pending); this.jobs.clear(); }
}
