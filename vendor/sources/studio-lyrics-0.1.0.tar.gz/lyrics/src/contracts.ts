export type LyricProvider = 'netease' | 'lrclib';
export interface LyricCandidate {
  provider: LyricProvider | 'local'; id: string; title: string; artists: string[];
  album?: string; durationSeconds?: number; synced?: boolean; instrumental?: boolean;
}
export interface LyricLine {
  startMs: number | null; text: string; translation?: string;
  words?: { startMs: number; endMs: number; text: string }[];
}
export interface LyricDocument extends LyricCandidate { lines: LyricLine[] }
export interface LyricSearch { candidates: LyricCandidate[]; issues: { provider: LyricProvider; code: string }[] }
/** Host-owned cache only; source choice and revisioned persistence belong to the application. */
export interface LyricDocumentCache {
  cached(id: string, now: number): LyricDocument | undefined;
  cache(document: LyricDocument, now: number): void;
}
export const lyricTextBytes = 128 * 1024;
export class LyricsError extends Error {
  constructor(readonly code: string, readonly currentRevision?: string | null) { super(code); }
}
