import {test} from 'node:test';
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {MediaDelivery} from '../dist/service.js';
import {verifyAudioPlayback} from '../dist/audio-probe.js';
const ref={provider:'bilibili',kind:'video',id:'BV0000000001',part:'1'},format={id:'aac',codec:'mp4a.40.2',mimeType:'audio/mp4',container:'mp4'};
const playback={entry:{ref,title:'fixture'},resourceId:'fixture',format,delivery:{url:'https://first.bilivideo.com/audio?signature=exact%2Bvalue',alternatives:['https://second.bilivideo.com/audio'],requiresHost:true}};
const policy={candidateMs:50,selectionMs:300,maxFirstChunkBytes:262144};
const bytes=()=>{const value=new Uint8Array(1024);value[3]=24;value.set(new TextEncoder().encode('ftypM4A '),4);return value;};
const good=()=>new Response(bytes(),{status:206,headers:{'Content-Range':'bytes 0-1023/2048','Content-Length':'1024'}});
const request=lease=>new Request(lease.delivery.url,{headers:{Range:'bytes=0-1023'}});
test('candidate deadlines cover headers and first nonempty body; surviving prefix is delivered exactly once',async()=>{
  for(const phase of ['headers','body']){
    const calls=[];let cancelled=0;
    let closed=false;const close=()=>{if(!closed){closed=true;cancelled++;}};
    const host={now:Date.now,fetch:async(url,{signal})=>{calls.push(url);if(calls.length>1)return good();if(phase==='headers'){await delay(1000,undefined,{signal});return good();}return new Response(new ReadableStream({start(c){signal.addEventListener('abort',()=>{close();c.error(signal.reason);},{once:true});},cancel(){close();}}),{status:206,headers:{'Content-Range':'bytes 0-1023/2048'}});}};
    const delivery=new MediaDelivery(host),lease=await delivery.publish(playback,'http://localhost');
    try{const response=await delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,policy);assert.deepEqual(new Uint8Array(await response.arrayBuffer()),bytes());assert.equal(calls.length,2);assert.equal(calls[0],playback.delivery.url);if(phase==='body')assert.equal(cancelled,1);}finally{await delivery.dispose();}
    assert.equal(delivery.diagnostics().activeReads,0);
  }
});
test('permissions and rate limits do not rotate; HEAD skips the first-block requirement',async()=>{
  for(const status of [403,412,429]){
    let calls=0;const delivery=new MediaDelivery({now:Date.now,fetch:async()=>{calls++;return new Response(null,{status,headers:{'Retry-After':'2'}});}}),lease=await delivery.publish(playback,'http://localhost');
    try{await assert.rejects(delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,policy),error=>error.code===(status===429?'rate-limited':'restricted')&&(status!==429||error.retryAfterMs===2000));assert.equal(calls,1);}finally{await delivery.dispose();}
  }
  const delivery=new MediaDelivery({now:Date.now,fetch:async()=>new Response(null,{status:200})}),lease=await delivery.publish(playback,'http://localhost');
  try{assert.equal((await delivery.read(lease.leaseId,new Request(lease.delivery.url,{method:'HEAD'}),undefined,undefined,undefined,policy)).status,200);}finally{await delivery.dispose();}
});
test('cancel and selection expiry stop all candidates; an oversize first block is rejected using its actual size',async()=>{
  let calls=0;const delivery=new MediaDelivery({now:Date.now,fetch:async(_url,{signal})=>{calls++;await delay(1000,undefined,{signal});return good();}}),lease=await delivery.publish(playback,'http://localhost');
  try{
    const stop=new AbortController(),read=delivery.read(lease.leaseId,new Request(lease.delivery.url,{signal:stop.signal}),undefined,undefined,undefined,policy);stop.abort();await assert.rejects(read,{code:'cancelled'});assert(calls<=1);
    calls=0;await assert.rejects(delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,{...policy,selectionMs:20}),{code:'timeout'});assert.equal(calls,1);
  }finally{await delivery.dispose();}
  const large=new MediaDelivery({now:Date.now,fetch:async()=>new Response(new Uint8Array(262145))}),published=await large.publish({...playback,delivery:{...playback.delivery,alternatives:[]}},'http://localhost');
  try{await assert.rejects(large.read(published.leaseId,new Request(published.delivery.url),undefined,undefined,undefined,policy),{code:'protocol'});}finally{await large.dispose();}
});
test('ranking accepts only a permutation of validated candidates, and credentials retain their original origin',async()=>{
  const calls=[],delivery=new MediaDelivery({now:Date.now,fetch:async(url,init)=>{calls.push({url,headers:new Headers(init.headers)});return good();}}),lease=await delivery.publish({...playback,delivery:{...playback.delivery,headers:{Authorization:'original-only'}}},'http://localhost');
  try{await (await delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,{...policy,order:()=>[1,0]})).arrayBuffer();assert(calls[0].url.includes('second.'));assert.equal(calls[0].headers.get('Authorization'),null);
    await assert.rejects(delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,{...policy,order:()=>[0,0]}),{code:'invalid-input'});
  }finally{await delivery.dispose();}
  const denied=new MediaDelivery({now:Date.now,fetch:async()=>assert.fail('Untrusted URL reached fetch')}),bad=await denied.publish({...playback,delivery:{...playback.delivery,url:'https://127.0.0.1/private',alternatives:[]}},'http://localhost');
  try{await assert.rejects(denied.read(bad.leaseId,request(bad),undefined,undefined,undefined,policy),{code:'restricted'});}finally{await denied.dispose();}
});
test('untrusted primary or unused backups are excluded before ranking without suppressing a trusted sibling',async()=>{
  for(const urls of [[playback.delivery.url,'https://127.0.0.1/private'],['https://first.bilivideo.com:4483/media','https://untrusted.example:4483/media',playback.delivery.url]]){
    let calls=0,ranked;const delivery=new MediaDelivery({now:Date.now,fetch:async(url,options)=>{calls++;assert.equal(url,playback.delivery.url);assert.equal(new Headers(options.headers).get('Authorization'),urls[0]===playback.delivery.url?'original-only':null);return good();}}),lease=await delivery.publish({...playback,delivery:{...playback.delivery,url:urls[0],alternatives:urls.slice(1),headers:{Authorization:'original-only'}}},'http://localhost');
    try{const response=await delivery.read(lease.leaseId,request(lease),undefined,undefined,undefined,{...policy,order:items=>{ranked=items;return [0];}});assert.deepEqual(new Uint8Array(await response.arrayBuffer()),bytes());assert.equal(calls,1);assert.deepEqual(ranked,[{index:0,hostname:'first.bilivideo.com'}]);}finally{await delivery.dispose();}
  }
});
test('probe opts into the same first-block policy and strict rendition permissions without changing legacy defaults',async()=>{
  const flac={...format,id:'flac',codec:'fLaC'},prepared=[];
  const api={capabilities:()=>({operations:['formats']}),formats:async()=>[flac,format],prepare:async input=>{prepared.push(input.formatId);return {...playback,format:input.formatId==='flac'?flac:format};}};
  await assert.rejects(verifyAudioPlayback(api,{now:Date.now,fetch:async()=>new Response(null,{status:403})},ref,{signal:new AbortController().signal,playable:()=>true,deliveryPolicy:policy,stopOnRestricted:true}),{code:'restricted'});assert.deepEqual(prepared,['flac']);
});
