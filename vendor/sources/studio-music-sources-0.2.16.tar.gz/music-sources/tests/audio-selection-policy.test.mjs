import {test} from 'node:test';
import assert from 'node:assert/strict';
import {MusicSources} from '../dist/index.js';
import {BilibiliProvider} from '../dist/bilibili.js';
import {createNodeHost} from '../dist/node.js';
import {prepareBestAudio} from '../dist/audio.js';
import {verifyAudioPlayback} from '../dist/audio-probe.js';
import {MusicClient} from '../dist/client.js';
import {MediaDelivery,createMusicService} from '../dist/service.js';
const ref={provider:'bilibili',kind:'video',id:'BV0000000001',part:'7'},aac={id:'aac',codec:'mp4a.40.2',mimeType:'audio/mp4',container:'mp4'},flac={...aac,id:'flac',codec:'fLaC'};
test('Bilibili projects only supplied audio specifications and HTTP clients retain bit depth without delivery facts',async()=>{
  let extra={audioSamplingRate:'96000',channels:2,bitDepth:24};
  const host=createNodeHost({fetch:async input=>{const path=new URL(input).pathname;return Response.json({code:0,data:path.endsWith('/view')?{bvid:ref.id,cid:7,title:'fixture',duration:3,pages:[{cid:7,part:'fixture',duration:3}]}:path.endsWith('/nav')?{wbi_img:{img_url:'https://fixture/0123456789abcdef0123456789abcdef.png',sub_url:'https://fixture/abcdef0123456789abcdef0123456789.png'}}:path.includes('playurl')?{dash:{audio:[{id:30280,codecs:'mp4a.40.2',mimeType:'audio/mp4',bandwidth:128000,baseUrl:'https://fixture.bilivideo.com/audio',...extra}]}}:{b_3:'fixture',b_4:'fixture'}});}});
  const api=new MusicSources(host,{bilibili:new BilibiliProvider()}),delivery=new MediaDelivery(host),service=createMusicService(api,delivery,{baseUrl:'http://localhost',providers:['bilibili']}),client=await MusicClient.connect('http://localhost',{fetch:(input,init)=>service.fetch(new Request(input,init))});
  try{const [format]=await client.formats(ref);assert.equal(format.sampleRate,96000);assert.equal(format.channels,2);assert.equal(format.bitDepth,24);assert(!JSON.stringify(format).includes('bilivideo'));
    extra={};const [unknown]=await client.formats(ref);for(const key of ['sampleRate','channels','bitDepth'])assert.equal(unknown[key],undefined);
    extra={sample_rate:48000,audio_channels:'1',bit_depth:'16'};const [snake]=await client.formats(ref);assert.equal(snake.sampleRate,48000);assert.equal(snake.channels,1);assert.equal(snake.bitDepth,16);
    extra={audioSamplingRate:0,channels:-1,bitDepth:192};const [invalid]=await client.formats(ref);assert.equal(invalid.sampleRate,undefined);assert.equal(invalid.channels,undefined);assert.equal(invalid.bitDepth,undefined);
  }finally{client.dispose();await delivery.dispose();await api.dispose();}
});
test('host format selection is bounded by compatible facts and exact format requests',async()=>{
  const prepared=[],api={capabilities:()=>({operations:['formats']}),formats:async()=>[flac,aac],prepare:async request=>{prepared.push(request);return request;}};
  assert.equal((await prepareBestAudio(api,{ref},undefined,()=>true,formats=>formats.find(format=>format.id==='aac')?.id)).formatId,'aac');
  await assert.rejects(prepareBestAudio(api,{ref},undefined,format=>format.id==='aac',()=> 'flac'),{code:'invalid-input'});
  await assert.rejects(prepareBestAudio(api,{ref,formatId:'flac'},undefined,format=>format.id==='aac',formats=>formats[0]?.id),{code:'unsupported'});
  assert.equal(prepared.length,1);
});
test('a host-pinned probe never silently prepares a different rendition after rejection',async()=>{
  const prepared=[],api={capabilities:()=>({operations:['formats']}),formats:async()=>[flac,aac],prepare:async request=>{prepared.push(request.formatId);return {resourceId:'fixture',entry:{ref,title:'fixture'},format:request.formatId==='flac'?flac:aac,delivery:{url:'https://fixture.bilivideo.com/audio',requiresHost:true}};}};
  await assert.rejects(verifyAudioPlayback(api,{now:Date.now,fetch:async()=>new Response(null,{status:404})},ref,{signal:new AbortController().signal,playable:()=>true,selectFormat:formats=>formats.find(format=>format.id==='aac')?.id}));
  assert.deepEqual(prepared,['aac']);
});
