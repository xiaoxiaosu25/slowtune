import { MusicSources, normalizeMusicInput, resolveMusicParts, resolveMusicEntries, type MusicApi, type MusicHost, type EntryRef, type PrepareRequest } from '@studio/music-sources';
import { MusicClient } from '@studio/music-sources/client';
import { prepareBestAudio, audioMime,type AudioFormatSelector } from '@studio/music-sources/audio';
import { verifyAudioPlayback } from '@studio/music-sources/audio-probe';
import { BilibiliResponseReuse } from '@studio/music-sources/bilibili';
import { CreatorSources, type CreatorRef } from '@studio/music-sources/creators';
import { VideoComments } from '@studio/music-sources/comments';
import { MusicCharts } from '@studio/music-sources/charts';
import { NeteaseSongCatalog } from '@studio/music-sources/catalog';
import { songIdentityReasons } from '@studio/music-sources/song-match';
declare const host: MusicHost, api: MusicApi, ref: EntryRef;
const request: PrepareRequest = { ref, quality: 'lowest', codecs: ['mp4a'] };
void new MusicSources(host, {}); void api.formats?.(ref); void normalizeMusicInput(api, 'BV1NPtC6qEeA'); void MusicClient; void request;
void resolveMusicParts(api,ref,{mode:'selected',parts:['123']});void resolveMusicEntries(api,[ref]);
// @ts-expect-error Quality policy must be a known value.
const bad: PrepareRequest = { ref, quality: 'invented' };
void bad;
const video: PrepareRequest = { ref, media: 'video', codecs: ['avc1'] };
void api.prepare(video);
// @ts-expect-error Media selection is explicit and closed.
const badMedia: PrepareRequest = { ref, media: 'live' };
void badMedia;
void prepareBestAudio(api, { ref }, undefined, format => !!audioMime(format));
const selector:AudioFormatSelector=formats=>formats.find(format=>format.bitDepth===24)?.id;
void prepareBestAudio(api,{ref},undefined,()=>true,selector);
void verifyAudioPlayback(api,host,ref,{signal:new AbortController().signal,playable:()=>true,selectFormat:selector});
void verifyAudioPlayback(api, host, ref, { signal: new AbortController().signal });
void new BilibiliResponseReuse(host.fetch, new AbortController().signal);
const creator:CreatorRef={provider:'bilibili',id:'101'};
void new CreatorSources(host).profile(creator,new AbortController().signal);
void api.search('bilibili',{query:'歌曲',order:'favorites'});
void new CreatorSources(host).search({provider:'bilibili',query:'作者',page:1,pageSize:20,order:'followers'},new AbortController().signal);
// @ts-expect-error Search order is a closed source contract.
void api.search('bilibili',{query:'歌曲',order:'random'});
// @ts-expect-error User search never accepts platform relation changes.
void new CreatorSources(host).search({provider:'bilibili',query:'作者',follow:true},new AbortController().signal);
void new VideoComments(host);void new MusicCharts(host);void new NeteaseSongCatalog(host.fetch);
void songIdentityReasons({title:'song'},{title:'song'});
// @ts-expect-error The probe requires an explicit cancellation signal.
void verifyAudioPlayback(api, host, ref, {});
