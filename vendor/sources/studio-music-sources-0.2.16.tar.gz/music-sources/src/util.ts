import { fail, MusicSourceError, type ProviderContext, type MusicEntry, type AudioQuality, type MusicHost, type SourceDiagnostic, type AudioFormat } from './contracts.js';
export function obj(value: unknown): Record<string, any> { if (!value || typeof value !== 'object' || Array.isArray(value)) fail('upstream'); return value as Record<string, any>; }
export function array(value: unknown): any[] { if (!Array.isArray(value)) fail('upstream'); return value; }
export function str(value: unknown): string { if (typeof value !== 'string' || !value) fail('upstream'); return value; }
export function number(value: unknown): number { const n = typeof value === 'number' ? value : Number(value); if (!Number.isFinite(n) || n < 0) fail('upstream'); return n; }
export function limit(n = 20): number { if (!Number.isInteger(n) || n < 1 || n > 50) fail('invalid-input'); return n; }
export function text(value: unknown): string { return str(value).replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>'); }
export function imageUrl(value: unknown): string | undefined { if (typeof value !== 'string') return; try { const u = new URL(value.startsWith('//') ? 'https:' + value : value); if (['https:','http:'].includes(u.protocol)) { u.protocol = 'https:'; return u.href; } } catch {} }
export function dedupe(entries: MusicEntry[]): MusicEntry[] { return [...new Map(entries.map(e => [e.resourceId, e])).values()]; }
export function normalizeError(error: unknown, context?: ProviderContext): MusicSourceError {
  if (error instanceof MusicSourceError) return error;
  if (context?.signal.aborted) return new MusicSourceError({ code: context.signal.reason?.name === 'TimeoutError' ? 'timeout' : 'cancelled', retryable: false });
  return new MusicSourceError({ code: 'network', retryable: true });
}
export async function boundedJson(response: Response, maxBytes = 4 * 1024 * 1024): Promise<any> {
  if (!response.ok) { await response.body?.cancel(); const code = response.status === 401 ? 'authentication' : [403,412].includes(response.status) ? 'restricted' : response.status === 429 ? 'rate-limited' : response.status === 404 ? 'not-found' : 'upstream'; throw new MusicSourceError({ code, retryable: code === 'rate-limited', upstreamCode: String(response.status), ...(response.status === 429 ? { retryAfterMs: retryAfter(response.headers) } : {}) }); }
  if (!response.body) fail('upstream');
  const reader = response.body.getReader(); let size = 0; const chunks: Uint8Array[] = [];
  try { for (;;) { const { value, done } = await reader.read(); if (done) break; size += value.length; if (size > maxBytes) fail('upstream'); chunks.push(value); } }
  finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
  const bytes = new Uint8Array(size); let offset = 0; for (const c of chunks) { bytes.set(c, offset); offset += c.length; }
  try { return JSON.parse(new TextDecoder().decode(bytes)); } catch { return fail('upstream'); }
}
export function cursorEncode(data: object): string { return btoa(unescape(encodeURIComponent(JSON.stringify(data)))); }
export function cursorDecode(token: string): any { if (typeof token !== 'string' || token.length > 16384) fail('stale-cursor'); try { return JSON.parse(decodeURIComponent(escape(atob(token)))); } catch { return fail('stale-cursor'); } }
export function expires(url: string): number | undefined { try { const u = new URL(url); const value = u.searchParams.get('deadline') ?? u.searchParams.get('expire') ?? u.pathname.match(/\/expire\/(\d+)(?:\/|$)/)?.[1]; if (value && /^\d+$/.test(value)) return Number(value) * 1000; } catch {} }
export function selectFormat<T extends { format: { id: string; codec: string; bitrate?: number } }>(formats: T[], codecs?: string[], formatId?: string, quality: AudioQuality = 'highest'): T {
  const candidates = formats.filter(v => (!formatId || v.format.id === formatId) && (!codecs || codecs.some(c => v.format.codec.toLowerCase().startsWith(c.toLowerCase()))) && (quality !== 'lossless' || /^(flac|alac)(?:\.|$)/i.test(v.format.codec)));
  if (!candidates.length) fail('unsupported');
  return candidates.sort((a,b) => quality === 'lowest' ? (a.format.bitrate ?? Infinity) - (b.format.bitrate ?? Infinity) : (b.format.bitrate ?? 0) - (a.format.bitrate ?? 0))[0];
}
export function retryAfter(headers: Headers, now = Date.now()): number | undefined {
  const value = headers.get('retry-after'); if (!value) return;
  const milliseconds = /^\d+$/.test(value) ? Number(value) * 1000 : Date.parse(value) - now;
  if (Number.isFinite(milliseconds) && milliseconds >= 0) return Math.min(milliseconds, 3600000);
}
export function emitDiagnostic(host: MusicHost, event: SourceDiagnostic): void {
  try { host.onDiagnostic?.(Object.freeze({ ...event })); } catch { /* Observers do not own operations. */ }
}
export function formatFacts(value: unknown): AudioFormat {
  const raw = obj(value); const result: AudioFormat = { id: str(raw.id), mimeType: str(raw.mimeType), codec: str(raw.codec), container: str(raw.container) };
  for (const key of ['bitrate', 'byteLength', 'sampleRate', 'channels', 'bitDepth'] as const) if (raw[key] !== undefined) { if (typeof raw[key] !== 'number' || !Number.isFinite(raw[key]) || raw[key] < 0 || key==='bitDepth'&&(!Number.isInteger(raw[key])||raw[key]<1||raw[key]>64)) fail('upstream'); result[key] = raw[key]; }
  return result;
}
