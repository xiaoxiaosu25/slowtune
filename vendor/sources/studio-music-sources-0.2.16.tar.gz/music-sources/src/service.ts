import { Hono } from 'hono';
import { MUSIC_PROTOCOL, MusicSourceError, fail, type MusicApi, type CallOptions, type ProviderId } from './contracts.js';
import { boundedJson, obj } from './util.js';
import { MediaDelivery } from './delivery.js';
export { MediaDelivery } from './delivery.js';
export type {DeliveryReadPolicy} from './delivery.js';
export { MUSIC_PROTOCOL } from './contracts.js';
/** Mount into an existing host. Authentication, allowed origins and listening belong to the host. */
export function createMusicService(api:MusicApi,delivery:MediaDelivery,options:{baseUrl:string;providers:ProviderId[];context?:(request:Request,provider?:ProviderId)=>Promise<Omit<CallOptions,'signal'>>;authorize?:(request:Request)=>Promise<void>}):Hono {
  const app=new Hono();
  app.onError((error,c)=>{
    const e=error instanceof MusicSourceError ? error : new MusicSourceError({code:c.req.raw.signal.aborted?'cancelled':'upstream',retryable:false});
    const code=e.code;return c.json({protocol:MUSIC_PROTOCOL,error:e.toJSON()},code==='authentication'?401:code==='not-found'||code==='expired'?404:code==='rate-limited'||code==='busy'?429:code==='invalid-input'||code==='stale-cursor'?400:code==='restricted'?403:code==='cancelled'?408:502);
  });
  app.use('/v1/*',async(c,next)=>{await options.authorize?.(c.req.raw);await next();});
  app.get('/v1/handshake',c=>c.json({protocol:MUSIC_PROTOCOL,capabilities:options.providers.map(p=>api.capabilities(p))}));
  app.post('/v1/call/:operation',async c=>{
    const input=obj(await boundedJson(new Response(c.req.raw.body),65536));
    if(input.protocol!==MUSIC_PROTOCOL)fail('protocol');
    const operation=c.req.param('operation');
    const provider=['metadata','formats'].includes(operation)?input.ref?.provider:['list','prepare'].includes(operation)?input.request?.ref?.provider:input.provider;
    if(!['bilibili','youtube'].includes(provider)||(input.provider!==undefined&&input.provider!==provider))fail('invalid-input');
    if(!options.providers.includes(provider))fail('unsupported',provider);
    const context={...await options.context?.(c.req.raw,provider),signal:c.req.raw.signal};
    let result:unknown;
    switch(operation){
      case 'metadata':result=await api.metadata(input.ref,context);break;
      case 'formats':if(!api.formats)fail('unsupported',provider);result=await api.formats(input.ref,context);break;
      case 'discover':result=await api.discover(input.provider,context);break;
      case 'search':result=await api.search(input.provider,input.request,context);break;
      case 'list':result=await api.list(input.request,context);break;
      case 'account':if(!api.account)fail('unsupported');result=await api.account(input.provider,context);break;
      case 'library':if(!api.library)fail('unsupported');result=await api.library(input.provider,input.request,context);break;
      case 'shelf':if(!api.shelf)fail('unsupported');result=await api.shelf(input.provider,input.request,context);break;
      case 'begin-login':if(!api.beginLogin)fail('unsupported');result=await api.beginLogin(input.provider,context);break;
      case 'poll-login':if(!api.pollLogin)fail('unsupported');result=await api.pollLogin(input.provider,input.id,context);break;
      case 'cancel-login':if(!api.cancelLogin)fail('unsupported');await api.cancelLogin(input.provider,input.id,context);result=null;break;
      case 'disconnect':if(!api.disconnect)fail('unsupported');await api.disconnect(input.provider,context);if(context.credentialRef)await delivery.revoke(context.credentialRef);result=null;break;
      case 'prepare':{
        const prepared=await api.prepare(input.request,context);context.signal.throwIfAborted();
        const published=await delivery.publish(prepared,options.baseUrl,context);
        if(context.signal.aborted){await delivery.release(published.leaseId!);context.signal.throwIfAborted();}
        result=published;break;
      }
      default:fail('invalid-input');
    }
    return c.json({protocol:MUSIC_PROTOCOL,result});
  });
  app.get('/v1/media/:id',async c=>{const id=c.req.param('id');return delivery.read(id,c.req.raw,await options.context?.(c.req.raw,delivery.provider(id)));});
  app.get('/v1/media/:id/:resource',async c=>{const id=c.req.param('id');return delivery.read(id,c.req.raw,await options.context?.(c.req.raw,delivery.provider(id)),c.req.param('resource'));});
  app.on('HEAD','/v1/media/:id/:resource',async c=>{const id=c.req.param('id');return delivery.read(id,c.req.raw,await options.context?.(c.req.raw,delivery.provider(id)),c.req.param('resource'));});
  app.on('HEAD','/v1/media/:id',async c=>{const id=c.req.param('id');return delivery.read(id,c.req.raw,await options.context?.(c.req.raw,delivery.provider(id)));});
  app.delete('/v1/leases/:id',async c=>{const id=c.req.param('id');await delivery.release(id,options.context?await options.context(c.req.raw,delivery.provider(id)):undefined);return c.body(null,204);});
  app.post('/v1/leases/:id',async c=>{const id=c.req.param('id');await delivery.touch(id,await options.context?.(c.req.raw,delivery.provider(id)));return c.body(null,204);});
  return app;
}
