import { MUSIC_PROTOCOL, fail, MusicSourceError, type MusicApi, type ProviderId, type Capabilities, type CallOptions, type EntryRef, type SearchRequest, type ListRequest, type LibraryRequest, type ShelfRequest, type Account, type LoginChallenge, type LoginStatus, type PrepareRequest, type MusicEntry, type Shelf, type Page, type PreparedPlayback, type AudioFormat } from './contracts.js';
import { boundedJson, obj } from './util.js';
/** Small fetch-only browser/client entry; no Node, Hono, SDK or player imports. */
export class MusicClient implements MusicApi {
  private disposed=new AbortController(); private caps=new Map<ProviderId,Capabilities>();
  private constructor(private baseUrl:string,private fetcher:typeof fetch,private headers:Record<string,string>) {const port=fetcher;this.fetcher=(input,init)=>port(input,init);}
  static async connect(baseUrl:string,options:{fetch:typeof fetch;headers?:Record<string,string>;signal?:AbortSignal}):Promise<MusicClient> {
    const client=new MusicClient(baseUrl,options.fetch,options.headers??{});
    const response=await client.fetcher(new URL('/v1/handshake',baseUrl),{headers:client.headers,signal:options.signal});const r=obj(await boundedJson(response));
    if(r.protocol!==MUSIC_PROTOCOL || !Array.isArray(r.capabilities))fail('protocol');for(const c of r.capabilities){if(!['youtube','bilibili'].includes(c.provider)||!Array.isArray(c.operations)||!Array.isArray(c.limitations)||typeof c.anonymous!=='boolean')fail('protocol');client.caps.set(c.provider,c);}
    return client;
  }
  capabilities(provider:ProviderId) {const c=this.caps.get(provider);if(!c)fail('unsupported',provider);return c;}
  private async call<T>(operation:string,input:object,options:CallOptions={}):Promise<T> {
    if(this.disposed.signal.aborted)fail('disposed');if(options.credentialRef)fail('unsupported');
    const signal=AbortSignal.any([this.disposed.signal,...(options.signal?[options.signal]:[])]);
    try {
      const response=await this.fetcher(new URL(`/v1/call/${operation}`,this.baseUrl),{method:'POST',headers:{...this.headers,'Content-Type':'application/json'},body:JSON.stringify({protocol:MUSIC_PROTOCOL,...input}),signal});
      // Error envelopes have non-2xx statuses; parse them before the generic HTTP checker.
      const data=obj(await boundedJson(new Response(response.body,{status:200})));if(data.protocol!==MUSIC_PROTOCOL)fail('protocol');
      if(data.error){if(typeof data.error.code!=='string'||typeof data.error.retryable!=='boolean'||(data.error.retryAfterMs!==undefined&&(!Number.isFinite(data.error.retryAfterMs)||data.error.retryAfterMs<0||data.error.retryAfterMs>3600000)))fail('protocol');throw new MusicSourceError(data.error);}if(!response.ok || !Object.hasOwn(data,'result'))fail('protocol');
      validateResult(operation,data.result);return data.result as T;
    }catch(e){if(e instanceof MusicSourceError)throw e;if(signal.aborted)fail('cancelled');fail('network');}
  }
  metadata(ref:EntryRef,options?:CallOptions){return this.call<MusicEntry>('metadata',{ref},options);}
  discover(provider:ProviderId,options?:CallOptions){return this.call<Shelf[]>('discover',{provider},options);}
  search(provider:ProviderId,request:SearchRequest,options?:CallOptions){return this.call<Page<MusicEntry>>('search',{provider,request},options);}
  list(request:ListRequest,options?:CallOptions){return this.call<Page<MusicEntry>>('list',{request},options);}
  prepare(request:PrepareRequest,options?:CallOptions){if(request.media==='video'&&!this.capabilities(request.ref.provider).operations.includes('video-prepare'))fail('unsupported',request.ref.provider);if(request.quality!==undefined&&!this.capabilities(request.ref.provider).operations.includes('formats'))fail('unsupported',request.ref.provider);return this.call<PreparedPlayback>('prepare',{request},options);}
  formats(ref:EntryRef,options?:CallOptions){if(!this.capabilities(ref.provider).operations.includes('formats'))fail('unsupported',ref.provider);return this.call<AudioFormat[]>('formats',{ref},options);}
  account(provider:ProviderId,options?:CallOptions){return this.call<Account>('account',{provider},options);}
  library(provider:ProviderId,request:LibraryRequest={},options?:CallOptions){return this.call<Page<MusicEntry>>('library',{provider,request},options);}
  shelf(provider:ProviderId,request:ShelfRequest,options?:CallOptions){return this.call<Page<MusicEntry>>('shelf',{provider,request},options);}
  beginLogin(provider:ProviderId,options?:CallOptions){return this.call<LoginChallenge>('begin-login',{provider},options);}
  pollLogin(provider:ProviderId,id:string,options?:CallOptions){return this.call<LoginStatus>('poll-login',{provider,id},options);}
  async cancelLogin(provider:ProviderId,id:string,options?:CallOptions){await this.call('cancel-login',{provider,id},options);}
  async disconnect(provider:ProviderId,options?:CallOptions){await this.call('disconnect',{provider},options);}
  private async lease(id:string,method:'POST'|'DELETE'){if(!/^[\w-]{32}$/.test(id))fail('invalid-input');const r=await this.fetcher(new URL(`/v1/leases/${id}`,this.baseUrl),{method,headers:this.headers});await r.body?.cancel();if(!r.ok)fail('expired');}
  release(id:string){return this.lease(id,'DELETE');}
  touch(id:string){return this.lease(id,'POST');}
  dispose(){this.disposed.abort();}
}
function validateResult(operation:string,value:any):void{
  const entry=(e:any)=>{if(!e||typeof e.resourceId!=='string'||typeof e.title!=='string'||typeof e.url!=='string'||!e.ref||!['youtube','bilibili'].includes(e.ref.provider)||!['video','playlist'].includes(e.ref.kind)||typeof e.ref.id!=='string')fail('protocol');if(e.parts){if(!Array.isArray(e.parts))fail('protocol');e.parts.forEach(entry);}};
  const page=(p:any)=>{if(!p||!Array.isArray(p.items)||(p.nextCursor!==undefined&&typeof p.nextCursor!=='string'))fail('protocol');p.items.forEach(entry);};
  if(operation==='metadata')entry(value);
  else if(operation==='formats'){
    if(!Array.isArray(value)||value.length>200)fail('protocol');
    const keys=['id','mimeType','codec','container','bitrate','byteLength','sampleRate','channels','bitDepth'];
    for(const format of value){if(!format||typeof format!=='object'||Object.keys(format).some(key=>!keys.includes(key)))fail('protocol');for(const key of ['id','mimeType','codec','container'])if(typeof format[key]!=='string'||!format[key]||format[key].length>200)fail('protocol');for(const key of ['bitrate','byteLength','sampleRate','channels','bitDepth'])if(format[key]!==undefined&&(!Number.isFinite(format[key])||format[key]<0||key==='bitDepth'&&(!Number.isInteger(format[key])||format[key]<1||format[key]>64)))fail('protocol');}
  }
  else if(['list','search','library','shelf'].includes(operation))page(value);
  else if(operation==='account'){if(!value||!['bilibili','youtube'].includes(value.provider)||typeof value.id!=='string'||typeof value.name!=='string')fail('protocol');}
  else if(operation==='begin-login'){if(!value||typeof value.id!=='string'||! /^[\w-]{32}$/.test(value.id)||value.method!=='qr'||typeof value.url!=='string'||!Number.isFinite(value.expiresAt)||!Number.isFinite(value.intervalMs)||value.intervalMs<1000)fail('protocol');try{const url=new URL(value.url);if(url.protocol!=='https:'||!['passport.bilibili.com','account.bilibili.com'].includes(url.hostname))fail('protocol');}catch{fail('protocol');}}
  else if(operation==='poll-login'){if(!value||!['pending','scanned','expired','authenticated'].includes(value.state)||(value.state==='authenticated'&&!value.account))fail('protocol');if(value.account)validateResult('account',value.account);}
  else if(['cancel-login','disconnect'].includes(operation)){if(value!==null)fail('protocol');}
  else if(operation==='discover'){if(!Array.isArray(value))fail('protocol');for(const s of value){if(!s||typeof s.id!=='string'||typeof s.title!=='string'||(!s.page&&!s.error))fail('protocol');if(s.page)page(s.page);if(s.error&&typeof s.error.code!=='string')fail('protocol');}}
  else if(operation==='prepare'){entry(value?.entry);if(typeof value.resourceId!=='string'||typeof value.format?.codec!=='string'||typeof value.format.mimeType!=='string'||typeof value.format.container!=='string'||typeof value.delivery?.url!=='string'||typeof value.delivery.requiresHost!=='boolean')fail('protocol');try{const u=new URL(value.delivery.url);if(!['http:','https:'].includes(u.protocol))fail('protocol');}catch{fail('protocol');}}
}
