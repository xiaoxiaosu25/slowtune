import { MusicSourceError, type AudioFormat, type MusicApi, type PrepareRequest, type CallOptions } from './contracts.js';

const fallbackFormats: AudioFormat[] = [
  { id: 'flac', codec: 'fLaC', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'alac', codec: 'alac', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'mp4a', codec: 'mp4a.40.2', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'opus', codec: 'opus', mimeType: 'audio/webm', container: 'webm' },
  { id: 'vorbis', codec: 'vorbis', mimeType: 'audio/webm', container: 'webm' },
];
export const audioSupportFormats: readonly Readonly<AudioFormat>[] = Object.freeze([...fallbackFormats,
  { id: 'ec-3', codec: 'ec-3', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'ac-3', codec: 'ac-3', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'opus-mp4', codec: 'opus', mimeType: 'audio/mp4', container: 'mp4' },
  { id: 'mp3', codec: 'mp3', mimeType: 'audio/mpeg', container: 'mp3' },
  { id: 'wav', codec: 'pcm', mimeType: 'audio/wav', container: 'wav' },
].map(format => Object.freeze(format)));
export function audioMime(format: Pick<AudioFormat, 'codec' | 'mimeType'>) {
  const codec = /^flac$/i.test(format.codec) && format.mimeType === 'audio/mp4' ? 'fLaC' : format.codec;
  return `${format.mimeType}; codecs="${codec}"`;
}
export const losslessAudio = (format: Pick<AudioFormat, 'codec'>) => /^(flac|alac)(?:\.|$)/i.test(format.codec);
export const supportsAudioType = (types: readonly string[], format: AudioFormat) => types.some(type => type.toLowerCase() === audioMime(format).toLowerCase());
export const supportedAudioTypes = (playable: (format: AudioFormat) => boolean) => audioSupportFormats.filter(playable).map(audioMime);
/** Host policy selects an ID from already compatible, neutral format facts. */
export type AudioFormatSelector=(formats:readonly AudioFormat[])=>string|undefined;
export function selectAudioFormat(formats:readonly AudioFormat[],playable:(format:AudioFormat)=>boolean,select?:AudioFormatSelector){
  const usable=formats.filter(format=>format.mimeType.startsWith('audio/')&&playable(format));
  if(!select)return bestAudioFormat(usable,playable);
  const id=select(usable.map(format=>Object.freeze({...format})));
  if(id===undefined)return undefined;
  const selected=usable.find(format=>format.id===id);
  if(!selected)throw new MusicSourceError({code:'invalid-input',retryable:false});
  return selected;
}
/** Lossless first, then rendition bitrate. Never infer master quality from bitrate. */
export function bestAudioFormat(formats: readonly AudioFormat[], playable: (format: AudioFormat) => boolean) {
  return formats.filter(format => format.mimeType.startsWith('audio/') && playable(format))
    .sort((a, b) => Number(losslessAudio(b)) - Number(losslessAudio(a)) || (b.bitrate ?? 0) - (a.bitrate ?? 0) || a.id.localeCompare(b.id))[0];
}
/** Browser-safe composition of public format facts and explicit preparation. */
export async function prepareBestAudio(api: MusicApi, request: PrepareRequest, options: CallOptions | undefined, playable: (format: AudioFormat) => boolean,select?:AudioFormatSelector) {
  options?.signal?.throwIfAborted();
  if (request.media === 'video' || !select&&(request.formatId || request.quality === 'lowest' || request.quality === 'lossless')) return api.prepare(request, options);
  if (!api.formats || !api.capabilities(request.ref.provider).operations.includes('formats')) {
    if(select)throw new MusicSourceError({code:'unsupported',provider:request.ref.provider,retryable:false});
    const codecs = request.codecs ?? fallbackFormats.filter(playable).map(format => format.id);
    if (!codecs.length) throw new MusicSourceError({ code: 'unsupported', provider: request.ref.provider, retryable: false });
    return api.prepare({ ...request, codecs }, options);
  }
  const formats = await api.formats(request.ref, options);
  options?.signal?.throwIfAborted();
  const selected = selectAudioFormat(formats.filter(format => (!request.formatId||format.id===request.formatId)&&(!request.codecs || request.codecs.some(codec => format.codec.toLowerCase().startsWith(codec.toLowerCase())))), playable,select);
  if (!selected) throw new MusicSourceError({ code: 'unsupported', provider: request.ref.provider, retryable: false });
  return api.prepare({ ...request, codecs: [selected.codec], formatId: selected.id, quality: 'highest' }, options);
}
