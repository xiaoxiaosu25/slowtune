import { fail, MusicSourceError, type PreparedPlayback, type MusicHost, type SourceDiagnostic } from './contracts.js';
import { emitDiagnostic, retryAfter } from './util.js';

export function deliveryStatus(response: Response, range: string | null): number {
  const status = response.status, contentRange = response.headers.get('content-range');
  if (![200, 206, 416].includes(status)) {
    const code = status === 401 ? 'authentication' : [403, 412].includes(status) ? 'restricted' : status === 429 ? 'rate-limited' : [404, 410].includes(status) ? 'not-found' : 'upstream';
    throw new MusicSourceError({ code, retryable: status === 429 || status >= 500, upstreamCode: String(status), ...(status === 429 ? { retryAfterMs: retryAfter(response.headers) } : {}) });
  }
  if (range && [200, 206].includes(status)) {
    const match = contentRange?.match(/^bytes (\d+)-(\d+)\/(\d+)$/); if (!match) fail('protocol');
    const start = Number(match[1]), end = Number(match[2]), total = Number(match[3]);
    const requested = range.slice(6).split('-');
    const expectedStart = requested[0] ? Number(requested[0]) : Math.max(0, total - Number(requested[1]));
    const expectedEnd = requested[0] && requested[1] ? Math.min(Number(requested[1]), total - 1) : total - 1;
    if (![start, end, total, expectedStart, expectedEnd].every(Number.isSafeInteger) || start !== expectedStart || end !== expectedEnd || end < start || end >= total) fail('protocol');
    const length = response.headers.get('content-length');
    if (length !== null && (!/^\d+$/.test(length) || Number(length) !== end - start + 1)) fail('protocol');
    return 206;
  }
  if (status === 206 && (!contentRange || !/^bytes \d+-\d+\/(\d+|\*)$/.test(contentRange))) fail('protocol');
  return status;
}
function allowed(url: URL, provider: string): boolean {
  return url.protocol === 'https:' && !url.username && !url.password && !url.port && (provider === 'youtube' ? url.hostname.endsWith('.googlevideo.com') : ['.bilivideo.com', '.bilivideo.cn', '.bilivideo.net'].some(s => url.hostname.endsWith(s)));
}
export interface DeliveryReadPolicy {
  candidateMs:number;
  selectionMs:number;
  maxFirstChunkBytes?:number;
  /** Host-only indexes into validated candidates; URLs never cross this port. */
  order?:(candidates:readonly {index:number;hostname:string}[])=>readonly number[];
  observe?:(fact:{hostname:string;ready:boolean;elapsedMs:number;errorCode?:string})=>void;
}
export function validateDeliveryPolicy(policy?:DeliveryReadPolicy){
  if(!policy)return;
  for(const value of [policy.candidateMs,policy.selectionMs])if(!Number.isInteger(value)||value<1||value>3600000)fail('invalid-input');
  if(policy.maxFirstChunkBytes!==undefined&&(!Number.isInteger(policy.maxFirstChunkBytes)||policy.maxFirstChunkBytes<1||policy.maxFirstChunkBytes>262144))fail('invalid-input');
}
/** Only retry before a Response is handed to the consumer. Never splice media bytes. */
export async function readDelivery(host: MusicHost, playback: PreparedPlayback, request: Request, signal: AbortSignal, maxCandidates: number, diagnostic: Pick<SourceDiagnostic, 'requestId' | 'timestamp'>,policy?:DeliveryReadPolicy) {
  validateDeliveryPolicy(policy);
  const range = request.headers.get('range'), primary = new URL(playback.delivery.url);
  let candidates = [...new Set([playback.delivery.url, ...(playback.delivery.alternatives ?? [])])].slice(0, maxCandidates);
  if(policy){
    candidates=candidates.filter(value=>{try{return allowed(new URL(value),playback.entry.ref.provider);}catch{return false;}});
    if(!candidates.length)fail('restricted');
    const facts=candidates.map((value,index)=>({index,hostname:new URL(value).hostname}));
    const order=policy.order?.(facts)??facts.map(value=>value.index);
    if(order.length!==facts.length||new Set(order).size!==facts.length||order.some(index=>!Number.isInteger(index)||index<0||index>=facts.length))fail('invalid-input');
    candidates=order.map(index=>candidates[index]);
  }
  const selection=new AbortController(),selectionTimer=policy?setTimeout(()=>selection.abort(new DOMException('Candidate selection timed out','TimeoutError')),policy.selectionMs):undefined;
  try{
  for (let index = 0; index < candidates.length; index++) {
    let url:URL;try{url=new URL(candidates[index]);}catch{return fail('protocol');}
    const report = (code: SourceDiagnostic['code'], extra: Partial<SourceDiagnostic> = {}) => emitDiagnostic(host, { requestId: diagnostic.requestId, timestamp: host.now(), elapsedMs: host.now() - diagnostic.timestamp, operation: 'media', provider: playback.entry.ref.provider, code, attempt: index + 1, upstreamHost: url.hostname, ...(range ? { range } : {}), ...extra });
    if (index && !allowed(url, playback.entry.ref.provider)) fail('restricted');
    const headers: Record<string, string> = { ...playback.delivery.headers, ...(range ? { Range: range } : {}), 'Accept-Encoding': 'identity' };
    const removeCredentials = () => { for (const key of Object.keys(headers)) if (['cookie', 'authorization'].includes(key.toLowerCase())) delete headers[key]; };
    if (url.origin !== primary.origin) removeCredentials();
    report(index ? 'fallback' : 'start');
    let response: Response | undefined,reader:ReadableStreamDefaultReader<Uint8Array>|undefined;
    const candidate=new AbortController(),started=host.now(),timer=policy?setTimeout(()=>candidate.abort(new DOMException('Candidate timed out','TimeoutError')),policy.candidateMs):undefined;
    const attemptSignal=policy?AbortSignal.any([signal,selection.signal,candidate.signal]):signal;
    const observe=(ready:boolean,errorCode?:string)=>{try{policy?.observe?.({hostname:url.hostname,ready,elapsedMs:host.now()-started,...(errorCode?{errorCode}:{})});}catch{/* Observation cannot own delivery. */}};
    try {
      for (let redirects = 0; ; redirects++) {
        attemptSignal.throwIfAborted();
        response = await host.fetch(url.href, { method: request.method, headers, signal:attemptSignal, redirect: 'manual' });
        if (attemptSignal.aborted) { await response.body?.cancel(); attemptSignal.throwIfAborted(); }
        if (![301, 302, 303, 307, 308].includes(response.status)) break;
        const location = response.headers.get('location'); await response.body?.cancel(); response = undefined;
        if (!location || redirects >= 3) fail('protocol');
        const next = new URL(location, url); if (!allowed(next, playback.entry.ref.provider)) fail('restricted');
        if (next.origin !== url.origin) removeCredentials(); url = next;
      }
      const status = deliveryStatus(response!, range); report('headers', { status });
      let firstChunk:Uint8Array|undefined;
      if(policy&&request.method!=='HEAD'&&status!==416){
        if(!response!.body)fail('protocol');reader=response!.body!.getReader();
        for(let empty=0;;empty++){
          const chunk=await reader.read();attemptSignal.throwIfAborted();
          if(chunk.done)fail('protocol');
          if(chunk.value.byteLength){firstChunk=chunk.value;break;}
          if(empty>=15)fail('protocol');
        }
        const length=response!.headers.get('content-length');
        const declaredRange=response!.headers.get('content-range')?.match(/^bytes (\d+)-(\d+)\/\d+$/),rangeLength=declaredRange?Number(declaredRange[2])-Number(declaredRange[1])+1:undefined;
        if(firstChunk.byteLength>(policy.maxFirstChunkBytes??262144)||length!==null&&/^\d+$/.test(length)&&firstChunk.byteLength>Number(length)||rangeLength!==undefined&&firstChunk.byteLength>rangeLength)fail('protocol');
      }
      observe(true);
      return { response: response!, status, attempt: index + 1, upstreamHost: url.hostname,reader,firstChunk };
    } catch (error) {
      const timedOut=selection.signal.aborted||candidate.signal.aborted;
      candidate.abort();if(reader)await reader.cancel().catch(()=>{});else await response?.body?.cancel().catch(()=>{});
      if(signal.aborted)throw error;
      const actual=timedOut?new MusicSourceError({code:'timeout',retryable:true}):error instanceof MusicSourceError?error:new MusicSourceError({code:'network',retryable:true});
      observe(false,actual.code);
      report('failure', { errorCode: actual.code, ...(actual.upstreamCode && /^\d{3}$/.test(actual.upstreamCode) ? { status: Number(actual.upstreamCode) } : {}) });
      const recoverable = ['network', 'protocol', 'not-found',...(policy?['timeout']:[])].includes(actual.code) || (actual.code === 'upstream' && ['500', '502', '503', '504'].includes(actual.upstreamCode ?? ''));
      if(selection.signal.aborted)throw new MusicSourceError({code:'timeout',retryable:true});
      if (!recoverable || index + 1 >= candidates.length) throw actual;
    }finally{clearTimeout(timer);}
  }
  return fail('upstream');
  }finally{clearTimeout(selectionTimer);}
}
