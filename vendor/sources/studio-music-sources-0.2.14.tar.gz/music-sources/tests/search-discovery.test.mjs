import {test} from 'node:test';
import assert from 'node:assert/strict';
import {MusicSources} from '../dist/core.js';
import {BilibiliProvider} from '../dist/bilibili.js';
import {CreatorSources} from '../dist/creators.js';
import {createNodeHost} from '../dist/node.js';

const signal=()=>new AbortController().signal;
const images={img_url:'https://i.example/abcdefghijklmnopqrstuvwxyz012345.png',sub_url:'https://i.example/012345abcdefghijklmnopqrstuvwxyz.png'};
test('video order reaches the platform and cursor identity includes normalized order',async()=>{
  const calls=[];
  const api=new MusicSources(createNodeHost({fetch:async(input)=>{
    const url=new URL(String(input));calls.push(url);
    if(url.pathname.endsWith('/spi'))return Response.json({code:0,data:{b_3:'visitor',b_4:'fixture'}});
    return Response.json({code:0,data:{numPages:2,result:[{type:'video',bvid:'BV1234567890',title:'歌曲',author:'作者',mid:101}]}});
  }}),{bilibili:new BilibiliProvider()});
  try{
    for(const [order,source] of [['relevance','totalrank'],['plays','click'],['favorites','stow'],['newest','pubdate']]){
      const first=await api.search('bilibili',{query:'歌曲',mode:'video',order,limit:20});
      assert.equal(calls.at(-1).searchParams.get('order'),source);assert.equal(calls.at(-1).searchParams.get('page'),'1');
      await api.search('bilibili',{query:'歌曲',mode:'video',order,limit:20,cursor:first.nextCursor});
      assert.equal(calls.at(-1).searchParams.get('page'),'2');
      await assert.rejects(api.search('bilibili',{query:'歌曲',mode:'video',order:order==='plays'?'newest':'plays',limit:20,cursor:first.nextCursor}),{code:'stale-cursor'});
    }
    const first=await api.search('bilibili',{query:'默认',mode:'video'});
    await api.search('bilibili',{query:'默认',mode:'video',order:'relevance',cursor:first.nextCursor});
    const count=calls.length;
    assert.throws(()=>api.search('bilibili',{query:'歌曲',order:'unknown'}),{code:'invalid-input'});
    assert.equal(calls.length,count);
  }finally{await api.dispose();}
});

test('creator search signs bounded requests, returns actual identity and never writes account relations',async()=>{
  const calls=[];
  const sources=new CreatorSources(createNodeHost({fetch:async(input,options)=>{
    const url=new URL(String(input));calls.push({url,options});
    if(url.pathname.endsWith('/nav'))return Response.json({code:0,data:{wbi_img:images}});
    assert.equal(url.pathname,'/x/web-interface/wbi/search/type');
    return Response.json({code:0,data:{page:2,pagesize:20,numPages:3,numResults:61,result:[{type:'bili_user',mid:101,uname:'<em class="keyword">许嵩</em>',upic:'//i0.hdslb.com/avatar.jpg',usign:'音乐 &amp; 日常',fans:12345,official_verify:{type:0,desc:'音乐人'}}]}});
  }}),async()=>'buvid3=fixture');
  try{
    const result=await sources.search({provider:'bilibili',query:'许嵩',page:2,pageSize:30,order:'followers'},signal());
    assert.equal(result.page,2);assert.equal(result.pageSize,20);assert.equal(result.hasMore,true);assert.equal(result.total,60,'total cannot exceed the accessible platform pages');
    assert.deepEqual(result.items[0],{provider:'bilibili',id:'101',name:'许嵩',url:'https://space.bilibili.com/101',artwork:'https://i0.hdslb.com/avatar.jpg',description:'音乐 & 日常',followers:12345,verification:'音乐人'});
    const {url,options}=calls.at(-1);assert.equal(url.searchParams.get('search_type'),'bili_user');assert.equal(url.searchParams.get('order'),'fans');assert.equal(url.searchParams.get('page'),'2');assert(url.searchParams.has('w_rid'));assert.equal(options.method,undefined);
    const count=calls.length;
    for(const invalid of [{provider:'bilibili',query:''},{provider:'bilibili',query:'x',page:0},{provider:'bilibili',query:'x',pageSize:999},{provider:'bilibili',query:'x',order:'level'}])await assert.rejects(sources.search(invalid,signal()),{code:'invalid-input'});
    await assert.rejects(sources.search({provider:'youtube',query:'x'},signal()),{code:'unsupported'});assert.equal(calls.length,count);
  }finally{await sources.dispose();}
});

test('creator search keeps source errors distinct from empty results and cancels owned body reads',async()=>{
  let response={code:0,data:{numPages:0,numResults:0,result:[]}};
  const sources=new CreatorSources(createNodeHost({fetch:async input=>Response.json(String(input).includes('/nav')?{code:0,data:{wbi_img:images}}:response)}),async()=>'buvid3=fixture');
  try{
    assert.deepEqual((await sources.search({provider:'bilibili',query:'空'},signal())).items,[]);
    response={code:0,data:{v_voucher:'restricted'}};await assert.rejects(sources.search({provider:'bilibili',query:'风控'},signal()),{code:'restricted'});
    response={code:0,data:{numPages:1,result:[{mid:'invalid',uname:'用户'}]}};await assert.rejects(sources.search({provider:'bilibili',query:'损坏'},signal()),{code:'upstream'});
  }finally{await sources.dispose();}
  let cancelled=0,ready;const entered=new Promise(resolve=>ready=resolve);
  const slow=new CreatorSources(createNodeHost({fetch:async input=>String(input).includes('/nav')?Response.json({code:0,data:{wbi_img:images}}):new Response(new ReadableStream({start(){ready();},cancel(){cancelled++;}}))}),async()=>'buvid3=fixture');
  const pending=slow.search({provider:'bilibili',query:'取消'},signal()),rejected=assert.rejects(pending,{code:'cancelled'});
  await entered;await slow.dispose();await rejected;assert.equal(cancelled,1);
});
