import {test} from 'node:test';
import assert from 'node:assert/strict';
import {CreatorSources,parseYoutubeUpdates} from '../dist/creators.js';
import {NeteaseSongCatalog} from '../dist/catalog.js';
import {songIdentityReasons} from '../dist/song-match.js';
import {createNodeHost} from '../dist/node.js';
import {directoryResponse} from '../dist/directory-work.js';
const signal=()=>new AbortController().signal,tick=()=>new Promise(resolve=>setImmediate(resolve));

test('creator directory validates ownership, preserves source facts and never follows unsupported URLs',async()=>{
  const calls=[],creator={provider:'bilibili',id:'101',name:'作者',url:'https://space.bilibili.com/101'};
  const host=createNodeHost({fetch:async input=>{const url=new URL(String(input));calls.push(url);let data;
    if(url.pathname.endsWith('/nav'))data={wbi_img:{img_url:'https://i.example/abcdefghijklmnopqrstuvwxyz012345.png',sub_url:'https://i.example/012345abcdefghijklmnopqrstuvwxyz.png'}};
    else if(url.pathname.endsWith('/acc/info'))data={mid:101,name:'作者',face:'http://i0.hdslb.com/face.jpg'};
    else if(url.pathname.endsWith('/arc/search'))data={page:{count:61},list:{vlist:[{bvid:'BV1234567890',title:'视频',created:1700000000,length:'3:20'}]}};
    else if(url.pathname.endsWith('/seasons_archives_list'))data={meta:{mid:101},page:{total:31},archives:[{bvid:'BV1234567890',title:'视频'}]};
    else throw Error('unexpected source');return Response.json({code:0,data});}});
  const sources=new CreatorSources(host,async()=>'buvid3=fixture');
  try{
    assert.equal((await sources.profile(creator,signal())).artwork,'https://i0.hdslb.com/face.jpg');
    const page=await sources.videos(creator,signal(),'2');assert.equal(page.cursor,'3');assert.equal(page.items[0].durationSeconds,200);assert(calls.at(-1).searchParams.has('w_rid'));
    assert.equal((await sources.collectionVideos(creator,'season:101:1',signal())).cursor,'2');
    await assert.rejects(sources.collectionVideos(creator,'season:999:1',signal()),{code:'invalid-input'});
    const count=calls.length;await assert.rejects(sources.profile('http://127.0.0.1/101',signal()),{code:'invalid-input'});assert.equal(calls.length,count);
  }finally{await sources.dispose();}
});
test('creator feeds retain missing dates and native author identity; disposal cancels an owned response body',async()=>{
  const creator={provider:'youtube',id:'UC'+'a'.repeat(22),name:'作者',url:'https://youtube.com'};
  const feed=`<feed><entry><yt:videoId>abcdefghijk</yt:videoId><yt:channelId>${creator.id}</yt:channelId><title>标题</title></entry></feed>`;
  const page=parseYoutubeUpdates(feed,creator);assert.equal(page.length,1);assert.equal(page[0].publishedAt,undefined);
  let cancelled=0;const sources=new CreatorSources(createNodeHost({fetch:async()=>new Response(new ReadableStream({cancel(){cancelled++;}}))}));
  const pending=sources.videos(creator,signal()),rejected=assert.rejects(pending,{code:'cancelled'});await tick();await sources.dispose();await rejected;assert.equal(cancelled,1);
});
test('catalogue queries contain facts only, return detached cache results and await cancellation cleanup',async()=>{
  let calls=0;const source=new NeteaseSongCatalog(async input=>{calls++;return Response.json(new URL(input).pathname.includes('search')?{code:200,result:{songs:[{id:1}]}}:{code:200,songs:[{id:1,name:'歌曲',artists:[{name:'歌手'}],album:{picUrl:'http://p1.music.126.net/cover.jpg'},duration:60000}]});});
  try{const rows=await source.search('歌曲',signal());assert.equal(rows[0].artwork,'https://p1.music.126.net/cover.jpg');rows[0].title='changed';assert.equal((await source.search('歌曲',signal()))[0].title,'歌曲');assert.equal(calls,2);assert.equal(rows[0].ref,undefined);}finally{await source.dispose();}
  let cancelled=0;const slow=new NeteaseSongCatalog(async()=>new Response(new ReadableStream({cancel(){cancelled++;}})));
  const pending=slow.records(['1'],signal()),rejected=assert.rejects(pending,{code:'cancelled'});await tick();await slow.dispose();await rejected;assert.equal(cancelled,1);
});
test('song evidence checks short-name boundaries, all requested artists and known duration without choosing a result',()=>{
  assert(songIdentityReasons({title:'大晴天 周杰伦'},{title:'晴天',artists:['周杰伦']}).includes('short-title-boundary'));
  assert(songIdentityReasons({title:'甲《歌曲》',artists:['甲'],durationSeconds:200},{title:'歌曲',artists:['甲','乙'],durationSeconds:60}).includes('incomplete-artists'));
  assert.deepEqual(songIdentityReasons({title:'甲《歌曲》',artists:['甲'],durationSeconds:60},{title:'歌曲',artists:['甲'],durationSeconds:60}),[]);
});
test('SDK bodies have an explicit byte bound and retain response metadata',async()=>{
  const response=Response.json({value:true});Object.defineProperty(response,'url',{value:'https://www.youtube.com/fixture'});
  const result=await directoryResponse(response,signal());assert.equal(result.url,response.url);assert.deepEqual(await result.json(),{value:true});
  let cancelled=0;const oversized=new Response(new ReadableStream({start(c){c.enqueue(new Uint8Array(8*1024*1024+1));},cancel(){cancelled++;}}));
  await assert.rejects(directoryResponse(oversized,signal()),{code:'upstream'});assert.equal(cancelled,1);
});
