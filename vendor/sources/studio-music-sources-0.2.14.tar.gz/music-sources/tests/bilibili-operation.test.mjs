import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BilibiliResponseReuse } from '../dist/bilibili.js';

const endpoint = 'https://api.bilibili.com/x/player/wbi/playurl?cid=901';
const create = (fetcher, signal = new AbortController().signal, observe) => new BilibiliResponseReuse(fetcher, signal, observe);
const json = async response => (await response).json();

test('operation reuse normalizes signatures only, isolates headers and parts and returns independent bodies', async () => {
  let calls = 0;
  const op = create(async () => Response.json({ value: ++calls }), undefined, () => { throw Error('observer'); });
  try {
    const a = await op.fetch(endpoint + '&wts=1&w_rid=a', { headers: { Cookie: 'one' } });
    const b = await op.fetch(new Request(endpoint + '&w_rid=b&wts=2', { headers: { Cookie: 'one' } }));
    // Request defaults form part of the identity; equivalent Request inputs still reuse.
    const c = await op.fetch(new Request(endpoint + '&w_rid=c&wts=3', { headers: { Cookie: 'one' } }));
    assert.deepEqual(await b.json(), await c.json()); await a.json();
    await op.fetch(endpoint + '&wts=4', { headers: { Cookie: 'one' } }); assert.equal(calls, 2);
    await op.fetch(endpoint.replace('901', '902'), { headers: { Cookie: 'one' } });
    await op.fetch(endpoint, { headers: { Cookie: 'two' } }); assert.equal(calls, 4);
    await op.fetch('https://api.bilibili.com/x/web-interface/nav'); await op.fetch('https://api.bilibili.com/x/web-interface/nav'); assert.equal(calls, 6);
  } finally { await op.dispose(); }
});

test('one cancelled consumer preserves its peer; final cancellation waits for physical cleanup and allows retry', async () => {
  let release, cancelled = 0, calls = 0;
  const op = create(async (_url, { signal }) => { calls++; return new Response(new ReadableStream({ start(c) { release = () => { c.enqueue(new TextEncoder().encode('{}')); c.close(); }; }, cancel() { cancelled++; } })); });
  const first = new AbortController(), second = new AbortController();
  const a = op.fetch(endpoint, { signal: first.signal }), b = op.fetch(endpoint, { signal: second.signal });
  await new Promise(r => setImmediate(r)); first.abort(); await assert.rejects(a); assert.equal(cancelled, 0);
  release(); assert.deepEqual(await json(b), {}); assert.equal(calls, 1);
  const final = new AbortController(), pending = op.fetch(endpoint + '&new=1', { signal: final.signal });
  await new Promise(r => setImmediate(r)); final.abort(); await assert.rejects(pending); assert.equal(cancelled, 1);
  const retry = op.fetch(endpoint + '&new=1'); await new Promise(r => setImmediate(r)); release(); await retry; assert.equal(calls, 3);
  await op.dispose(); await assert.rejects(op.fetch(endpoint));
});

test('failed responses and operation boundaries never retain media preparation responses', async () => {
  let calls = 0; const fetcher = async () => new Response('{}', { status: ++calls === 1 ? 503 : 200 });
  const one = create(fetcher), two = create(fetcher);
  assert.equal((await one.fetch(endpoint)).status, 503); await one.fetch(endpoint); await one.fetch(endpoint); assert.equal(calls, 2);
  await two.fetch(endpoint); assert.equal(calls, 3); await one.dispose(); await two.dispose();
});

test('an immediate replacement never joins an abandoned producer or loses its own cache', async () => {
  let calls = 0, cancelled = 0;
  const op = create(async () => ++calls === 1 ? new Response(new ReadableStream({ cancel() { cancelled++; } })) : Response.json({ fresh: true }));
  const controller = new AbortController();
  const old = op.fetch(endpoint, { signal: controller.signal }); const rejected = assert.rejects(old);
  await new Promise(r => setImmediate(r)); controller.abort();
  assert.deepEqual(await json(op.fetch(endpoint)), { fresh: true }); await rejected;
  assert.deepEqual(await json(op.fetch(endpoint)), { fresh: true }); assert.equal(calls, 2); assert.equal(cancelled, 1);
  await op.dispose();
});

test('response and aggregate operation budgets reject oversized work and dispose cancels owned streams', async () => {
  const op = create(async () => new Response(new Uint8Array(4 * 1024 * 1024 + 1)));
  await assert.rejects(op.fetch(endpoint), { code: 'upstream' }); await op.dispose();
  let cancelled = 0;
  const stopped = create(async () => new Response(new ReadableStream({ cancel() { cancelled++; } })));
  const pending = stopped.fetch(endpoint); const rejected = assert.rejects(pending);
  await new Promise(r => setImmediate(r)); await stopped.dispose(); await rejected; assert.equal(cancelled, 1);
  const bulk = create(async () => new Response(new Uint8Array(4 * 1024 * 1024)));
  const results = await Promise.allSettled([1, 2, 3].map(n => bulk.fetch(endpoint + '&n=' + n)));
  assert(results.some(r => r.status === 'rejected' && r.reason.code === 'busy'));
  await bulk.dispose();
});
