import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MusicSourceError } from '../dist/contracts.js';
import { prepareBestAudio, bestAudioFormat, audioMime, supportsAudioType } from '../dist/audio.js';
import { verifyAudioPlayback, audioPrefixRecognized } from '../dist/audio-probe.js';

const ref = { provider: 'bilibili', kind: 'video', id: 'BV1000000001', part: '901' };
const aac = { id: 'aac', codec: 'mp4a.40.2', mimeType: 'audio/mp4', container: 'mp4', bitrate: 128000 };
const flac = { id: 'flac', codec: 'fLaC', mimeType: 'audio/mp4', container: 'mp4' };
const prepared = format => ({ ref, resourceId: 'song', entry: { ref, resourceId: 'song', title: 'Song', url: 'https://www.bilibili.com/video/' + ref.id }, format,
  delivery: { url: 'https://fixture.bilivideo.com/' + format.id, headers: { Referer: 'https://www.bilibili.com/' }, requiresHost: true } });
const signal = () => new AbortController().signal;
const prefix = () => { const bytes = new Uint8Array(1024); bytes.set([0, 0, 0, 24, 102, 116, 121, 112]); return bytes; };

test('audio selection uses actual container/codec support, preserves inputs and pins the selected format', async () => {
  const formats = [aac, flac], before = structuredClone(formats), requests = [];
  assert.equal(bestAudioFormat(formats, () => true), flac);
  assert.equal(bestAudioFormat(formats, f => f.id === 'aac'), aac);
  assert(supportsAudioType([audioMime(flac)], flac));
  const api = { capabilities: () => ({ operations: ['formats'] }), formats: async () => formats, prepare: async (r, o) => { requests.push([r, o]); return prepared(formats.find(f => f.id === r.formatId) ?? aac); } };
  const options = { signal: signal(), credentialRef: 'owner' };
  await prepareBestAudio(api, { ref }, options, () => true);
  assert.equal(requests[0][0].formatId, 'flac'); assert.equal(requests[0][1], options);
  assert.deepEqual(formats, before);
  for (const request of [{ ref, formatId: 'aac' }, { ref, quality: 'lowest' }, { ref, quality: 'lossless' }, { ref, media: 'video' }]) {
    await prepareBestAudio(api, request, options, () => true);
    assert.equal(requests.at(-1)[0], request);
  }
});

test('unsupported formats and cancelled format queries cannot prepare; old APIs receive compatible codecs', async () => {
  let calls = 0; const controller = new AbortController();
  const api = { capabilities: () => ({ operations: ['formats'] }), formats: async () => { controller.abort(); return [aac]; }, prepare: async () => { calls++; } };
  await assert.rejects(prepareBestAudio(api, { ref }, { signal: controller.signal }, () => true)); assert.equal(calls, 0);
  const old = { capabilities: () => ({ operations: [] }), prepare: async r => { calls++; assert.deepEqual(r.codecs, ['mp4a']); return prepared(aac); } };
  await prepareBestAudio(old, { ref }, undefined, f => f.codec.startsWith('mp4a'));
  await assert.rejects(prepareBestAudio(old, { ref }, undefined, () => false), { code: 'unsupported' }); assert.equal(calls, 1);
});

test('probe accumulates a bounded prefix, retains credentials and releases reads before returning facts', async () => {
  let cancelled = 0, handed = 0; const options = { signal: signal(), credentialRef: 'account' };
  const api = { prepare: async (request, call) => { assert.equal(call.credentialRef, 'account'); const p = prepared(aac); p.delivery.credentialRevision = 'one'; return p; } };
  const host = { now: Date.now, credentials: { read: async () => ({ revision: 'one' }) }, fetch: async (url, init) => {
    assert.equal(new Headers(init.headers).get('range'), 'bytes=0-1023'); assert.equal(new Headers(init.headers).get('referer'), 'https://www.bilibili.com/');
    let at = 0; const body = prefix();
    return new Response(new ReadableStream({ pull(c) { if (at < body.length) { c.enqueue(body.slice(at, at += 256)); } }, cancel() { cancelled++; } }), { status: 206, headers: { 'Content-Range': 'bytes 0-1023/2048' } });
  } };
  const checked = await verifyAudioPlayback(api, host, ref, { ...options, onPrepared(p) { assert.equal(p.format, aac); handed++; } });
  assert.deepEqual(checked, { ref, format: aac }); assert.equal(handed, 1); assert.equal(cancelled, 1);
  assert(!JSON.stringify(checked).includes('fixture.bilivideo.com'));
});

test('probe falls back only across rejected renditions and stops on network, authentication, rate limits or cancellation', async () => {
  for (const code of ['unsupported', 'not-found', 'expired', 'network', 'authentication', 'rate-limited']) {
    const calls = [], api = { capabilities: () => ({ operations: ['formats'] }), formats: async () => [aac, flac], prepare: async r => {
      calls.push(r.formatId); if (r.formatId === 'flac') throw new MusicSourceError({ code, retryable: true }); return prepared(aac);
    } };
    const task = verifyAudioPlayback(api, { now: Date.now, fetch: async () => new Response(prefix(), { status: 206, headers: { 'Content-Range': 'bytes 0-1023/2048' } }) }, ref, { signal: signal(), playable: () => true });
    if (['unsupported', 'not-found', 'expired'].includes(code)) { await task; assert.deepEqual(calls, ['flac', 'aac']); }
    else { await assert.rejects(task, { code }); assert.deepEqual(calls, ['flac']); }
  }
  const controller = new AbortController(); controller.abort();
  await assert.rejects(verifyAudioPlayback({ prepare: () => assert.fail('no preparation') }, { now: Date.now, fetch }, ref, { signal: controller.signal }));
});

test('probe rejects garbage, truncation and host policy rejection without handing off a preparation', async () => {
  for (const bytes of [new Uint8Array(1024).fill(1), prefix().slice(0, 12)]) {
    await assert.rejects(verifyAudioPlayback({ prepare: async () => prepared(aac) }, { now: Date.now, fetch: async () => new Response(bytes, { status: 206, headers: { 'Content-Range': 'bytes 0-1023/2048' } }) }, ref, { signal: signal(), onPrepared() { assert.fail('no handoff'); } }));
  }
  await assert.rejects(verifyAudioPlayback({ prepare: async () => prepared(aac) }, { now: Date.now, fetch: () => assert.fail('no media request') }, ref, { signal: signal(), validateEntry() { throw Error('policy'); } }), /policy/);
  assert(audioPrefixRecognized(prefix().subarray(0, 16), aac));
});
