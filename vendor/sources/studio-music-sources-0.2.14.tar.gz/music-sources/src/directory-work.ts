import { MusicSourceError } from './contracts.js';

/** Bounded source reads, including bodies whose host fetch ignores cancellation. */
export async function sourceText(response: Response, signal: AbortSignal, maxBytes = 2 * 1024 * 1024): Promise<string> {
  if (!response.ok) { await response.body?.cancel(); throw new MusicSourceError({ code: response.status === 429 ? 'rate-limited' : [403, 412].includes(response.status) ? 'restricted' : response.status === 404 ? 'not-found' : 'upstream', retryable: true }); }
  return new TextDecoder('utf-8', { fatal: true }).decode(await sourceBytes(response, signal, maxBytes));
}
async function sourceBytes(response: Response, signal: AbortSignal, maxBytes: number): Promise<Uint8Array> {
  const reader = response.body?.getReader(); if (!reader) throw new MusicSourceError({ code: 'upstream', retryable: true });
  const cancel = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', cancel, { once: true });
  const chunks: Uint8Array[] = []; let size = 0;
  try {
    signal.throwIfAborted();
    for (;;) { const row = await reader.read(); signal.throwIfAborted(); if (row.done) break; size += row.value.byteLength; if (size > maxBytes) throw new MusicSourceError({ code: 'upstream', retryable: true }); chunks.push(row.value); }
    return new Uint8Array(Buffer.concat(chunks));
  } finally { signal.removeEventListener('abort', cancel); await reader.cancel().catch(() => {}); reader.releaseLock(); }
}

/** Preserve SDK response metadata while bounding the body it will parse. */
export async function directoryResponse(response: Response, signal: AbortSignal): Promise<Response> {
  if (!response.body) { signal.throwIfAborted(); return response; }
  const bytes = await sourceBytes(response, signal, 8 * 1024 * 1024);
  const result = new Response(bytes, { status: response.status, statusText: response.statusText, headers: response.headers });
  for (const key of ['url','redirected','type'] as const) Object.defineProperty(result,key,{value:response[key]});
  return result;
}

export class DirectoryWork {
  private stop = new AbortController();
  private pending = new Map<Promise<unknown>, { owner: string; controller: AbortController }>();
  run<T>(owner: string, signal: AbortSignal, task: (signal: AbortSignal) => Promise<T>): Promise<T> {
    if (this.stop.signal.aborted) return Promise.reject(new MusicSourceError({ code: 'disposed', retryable: false }));
    if (this.pending.size >= 4) return Promise.reject(new MusicSourceError({ code: 'busy', retryable: true }));
    const controller = new AbortController(), combined = AbortSignal.any([signal, controller.signal, this.stop.signal, AbortSignal.timeout(25000)]);
    const promise = Promise.resolve().then(async () => { combined.throwIfAborted(); const value = await task(combined); combined.throwIfAborted(); return structuredClone(value); }).catch(error => {
      if (combined.aborted) throw new MusicSourceError({ code: combined.reason?.name === 'TimeoutError' ? 'timeout' : 'cancelled', retryable: true });
      if (error instanceof MusicSourceError) throw error;
      throw new MusicSourceError({ code: error instanceof SyntaxError ? 'upstream' : 'network', retryable: true });
    });
    this.pending.set(promise, { owner, controller });
    const finish = () => this.pending.delete(promise); promise.then(finish, finish); return promise;
  }
  cancelOwner(owner?: string) { for (const row of this.pending.values()) if (owner === undefined || row.owner === owner) row.controller.abort(); }
  async dispose() { this.stop.abort(); await Promise.allSettled(this.pending.keys()); }
}
