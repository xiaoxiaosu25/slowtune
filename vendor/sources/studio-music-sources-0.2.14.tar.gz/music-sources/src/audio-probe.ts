import { MediaDelivery } from './delivery.js';
import { MusicSourceError, type AudioFormat, type MusicApi, type MusicHost, type MusicEntry, type EntryRef, type CallOptions, type PreparedPlayback } from './contracts.js';
import { bestAudioFormat, audioSupportFormats } from './audio.js';

export function audioPrefixRecognized(bytes: Uint8Array, format: AudioFormat): boolean {
  const ascii = (start: number, end: number) => new TextDecoder().decode(bytes.subarray(start, end));
  if (bytes.length < 12) return false;
  if (format.container === 'mp4' || format.mimeType === 'audio/mp4') return ascii(4, 8) === 'ftyp' && new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(0) >= 8;
  if (format.container === 'webm') return bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3;
  if (format.container === 'ogg') return ascii(0, 4) === 'OggS';
  if (format.container === 'flac') return ascii(0, 4) === 'fLaC';
  if (format.container === 'wav') return ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WAVE';
  if (format.container === 'mp3' || format.mimeType === 'audio/mpeg') return ascii(0, 3) === 'ID3' || bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0;
  return false;
}
export interface AudioProbeOptions extends CallOptions {
  signal: AbortSignal;
  playable?: (format: AudioFormat) => boolean;
  /** Host policy may reject source facts before any media read. */
  validateEntry?: (entry: MusicEntry) => void;
  /** Host-only preparation handoff; called after the bounded read succeeds. */
  onPrepared?: (playback: PreparedPlayback) => void;
}
/** Checks at most 1024 bytes in ten seconds, not complete playback or decoding. */
export async function verifyAudioPlayback(api: Pick<MusicApi, 'prepare'> & Partial<Pick<MusicApi, 'formats' | 'capabilities'>>, host: MusicHost, ref: EntryRef, options: AudioProbeOptions): Promise<{ ref: EntryRef; format: AudioFormat }> {
  const signal = AbortSignal.any([options.signal, AbortSignal.timeout(10000)]);
  const call: CallOptions & { signal: AbortSignal } = { signal, credentialRef: options.credentialRef };
  const delivery = new MediaDelivery(host, { maxLeases: 1, maxReads: 1, readTimeoutMs: 10000 });
  try {
    signal.throwIfAborted();
    const playable = options.playable ?? (() => true);
    const formats = options.playable && api.formats && api.capabilities?.(ref.provider).operations.includes('formats') ? await api.formats(ref, call) : undefined;
    signal.throwIfAborted();
    const remaining = formats?.filter(format => format.mimeType.startsWith('audio/') && playable(format));
    const codecs = options.playable ? audioSupportFormats.filter(playable).map(format => format.codec) : undefined;
    if ((!remaining && codecs && !codecs.length) || remaining && !remaining.length) throw new MusicSourceError({ code: 'unsupported', provider: ref.provider, retryable: false });
    for (;;) {
      signal.throwIfAborted();
      const selected = remaining ? bestAudioFormat(remaining, playable) : undefined;
      let leaseId: string | undefined, reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
      try {
        const playback = await api.prepare({ ref, media: 'audio', quality: 'highest', ...(selected ? { formatId: selected.id, codecs: [selected.codec] } : codecs ? { codecs } : {}) }, call);
        signal.throwIfAborted(); options.validateEntry?.(playback.entry);
        if (!playable(playback.format)) throw new MusicSourceError({ code: 'unsupported', provider: ref.provider, retryable: false });
        const published = await delivery.publish(playback, 'http://localhost', call);
        leaseId = published.leaseId;
        if (!leaseId) throw new MusicSourceError({ code: 'unsupported', provider: ref.provider, retryable: false });
        const response = await delivery.read(leaseId, new Request(published.delivery.url, { headers: { Range: 'bytes=0-1023' }, signal }), call);
        reader = response.body?.getReader();
        const range = response.headers.get('content-range')?.match(/^bytes 0-(\d+)\/(\d+)$/);
        const expected = range ? Number(range[1]) + 1 : 0;
        if (!reader || !expected || expected > 1024) throw new MusicSourceError({ code: 'protocol', provider: ref.provider, retryable: false });
        const prefix = new Uint8Array(expected); let received = 0;
        while (received < expected) {
          const chunk = await reader.read(); signal.throwIfAborted();
          if (chunk.done || !chunk.value?.length || chunk.value.length > expected - received) throw new MusicSourceError({ code: 'protocol', provider: ref.provider, retryable: false });
          prefix.set(chunk.value, received); received += chunk.value.length;
        }
        if (!audioPrefixRecognized(prefix, playback.format)) throw new MusicSourceError({ code: 'unsupported', provider: ref.provider, retryable: false });
        signal.throwIfAborted(); options.onPrepared?.(playback);
        return { ref: playback.entry.ref, format: playback.format };
      } catch (error) {
        signal.throwIfAborted();
        if (!selected || !(error instanceof MusicSourceError) || !['not-found', 'restricted', 'unsupported', 'expired'].includes(error.code)) throw error;
        remaining!.splice(remaining!.indexOf(selected), 1);
        if (!remaining!.length) throw error;
      } finally {
        await reader?.cancel().catch(() => {});
        if (leaseId) await delivery.release(leaseId, call);
      }
    }
  } catch (error) {
    if (signal.aborted && signal.reason?.name === 'TimeoutError') throw new MusicSourceError({ code: 'timeout', provider: ref.provider, retryable: true });
    throw error;
  } finally { await delivery.dispose(); }
}
