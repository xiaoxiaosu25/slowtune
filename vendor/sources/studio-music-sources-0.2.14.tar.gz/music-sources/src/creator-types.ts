import { MusicSourceError, type EntryRef, type MusicEntry, type ProviderId } from './contracts.js';
export interface CreatorRef { provider: ProviderId; id: string }
export interface CreatorProfile extends CreatorRef { name: string; url: string; artwork?: string }
export interface CreatorSearchItem extends CreatorProfile { description?: string; followers?: number; verification?: string }
export interface CreatorSearchRequest { provider: ProviderId; query: string; page?: number; pageSize?: number; order?: 'relevance' | 'followers' }
export interface CreatorSearchPage { items: CreatorSearchItem[]; page: number; pageSize: number; total?: number; hasMore: boolean }
export interface CreatorCollection { id: string; kind: 'season' | 'series' | 'playlist'; title: string; url: string; artwork?: string; count?: number; ref?: EntryRef }
export interface CreatorCollections { items: CreatorCollection[]; cursor?: string }
export interface CreatorVideos { items: MusicEntry[]; cursor?: string; total?: number; page?: number; pageSize?: number }
export const creatorKey = (creator: CreatorRef) => `${creator.provider}:${creator.id}`;
export function validateCreator(value: unknown): CreatorRef {
  const creator = value as CreatorRef;
  if (!creator || !['bilibili', 'youtube'].includes(creator.provider) || typeof creator.id !== 'string' || !(creator.provider === 'bilibili' ? /^[1-9]\d{0,19}$/ : /^UC[\w-]{22}$/).test(creator.id)) throw new MusicSourceError({ code: 'invalid-input', retryable: false });
  return { provider: creator.provider, id: creator.id };
}
