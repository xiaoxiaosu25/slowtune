import { MusicSourceError } from './contracts.js';
import { artworkUrl } from './artwork.js';
import { sourceText } from './directory-work.js';

export interface SongCatalogRecord {
  provider: 'netease'; id: string; title: string; artists: string[]; album?: string;
  artwork?: string; durationSeconds?: number; url: string;
}
export class SongCatalogError extends Error {
  constructor(readonly code: 'network' | 'timeout' | 'upstream' | 'rate-limited') { super(code); }
}
const validId = (id: unknown): id is string => typeof id === 'string' && /^[1-9]\d{0,15}$/u.test(id) && Number.isSafeInteger(Number(id));
const invalid = () => new MusicSourceError({code:'invalid-input',retryable:false});

/** Directory facts only. It never resolves playable media or writes a song library. */
export class NeteaseSongCatalog {
  private stop = new AbortController();
  private active = 0;
  private pending = new Set<Promise<unknown>>();
  private searches = new Map<string, {until:number;records:SongCatalogRecord[]}>();
  constructor(private fetcher: typeof fetch = fetch, private now = Date.now) {}
  private own<T>(task:()=>Promise<T>):Promise<T>{
    if(this.stop.signal.aborted)return Promise.reject(new MusicSourceError({code:'disposed',retryable:false}));
    if(this.pending.size>=8)return Promise.reject(new MusicSourceError({code:'busy',retryable:true}));
    const result=Promise.resolve().then(task);this.pending.add(result);const done=()=>this.pending.delete(result);result.then(done,done);return result;
  }
  private async json(path:string,params:Record<string,string>,requestSignal:AbortSignal){
    requestSignal.throwIfAborted();
    if(this.active>=4)throw new MusicSourceError({code:'busy',retryable:true});
    const url=new URL(path,'https://music.163.com');for(const [key,value]of Object.entries(params))url.searchParams.set(key,value);
    const signal=AbortSignal.any([requestSignal,this.stop.signal,AbortSignal.timeout(12000)]);this.active++;
    try{
      const response=await this.fetcher(url,{signal,redirect:'error',headers:{'User-Agent':'Mozilla/5.0',Referer:'https://music.163.com/'}});
      if(!response.ok){await response.body?.cancel();throw new SongCatalogError(response.status===429?'rate-limited':'upstream');}
      const data=JSON.parse(await sourceText(response,signal));
      if(data?.code!==200)throw new SongCatalogError(data?.code===429?'rate-limited':'upstream');return data;
    }catch(error){
      if(requestSignal.aborted||this.stop.signal.aborted)throw new MusicSourceError({code:'cancelled',retryable:false});
      if(signal.aborted)throw new SongCatalogError('timeout');
      if(error instanceof SongCatalogError||error instanceof MusicSourceError)throw error;
      throw new SongCatalogError(error instanceof SyntaxError?'upstream':'network');
    }finally{this.active--;}
  }
  records(ids:string[],signal:AbortSignal):Promise<SongCatalogRecord[]>{return this.own(()=>this.readRecords(ids,signal));}
  private async readRecords(ids:string[],signal:AbortSignal):Promise<SongCatalogRecord[]>{
    if(!ids.length||ids.length>12||ids.some(id=>!validId(id)))throw invalid();
    const data=await this.json('/api/song/detail',{ids:'['+ids.join(',')+']'},signal);
    if(!Array.isArray(data.songs))throw new SongCatalogError('upstream');
    return data.songs.slice(0,12).flatMap((row:any)=>{
      const id=String(row?.id),title=row?.name,album=row?.album??row?.al,rawArtists=row?.artists??row?.ar;
      const artists=Array.isArray(rawArtists)?rawArtists.map((artist:any)=>artist?.name):undefined;
      if(!validId(id)||!ids.includes(id)||typeof title!=='string'||!title.trim()||title.length>1000||!Array.isArray(artists)||!artists.length||artists.length>100||artists.some((v:unknown)=>typeof v!=='string'||!v.trim()||v.length>1000||/[\u0000-\u001f\u007f]/u.test(v))||/[\u0000-\u001f\u007f]/u.test(title))return [];
      const artwork=artworkUrl(album?.picUrl),duration=(row.duration??row.dt)/1000;
      return [{provider:'netease' as const,id,title:title.trim(),artists,url:'https://music.163.com/song?id='+id,
        ...(typeof album?.name==='string'&&album.name.trim()&&album.name.length<=1000&&!/[\u0000-\u001f\u007f]/u.test(album.name)?{album:album.name}:{}),
        ...(artwork?{artwork}:{}),...(Number.isFinite(duration)&&duration>0&&duration<=86400?{durationSeconds:duration}:{})}];
    });
  }
  search(query:string,signal:AbortSignal):Promise<SongCatalogRecord[]>{return this.own(async()=>{
    signal.throwIfAborted();
    if(typeof query!=='string'||!query.trim()||query.length>500||/[\u0000-\u001f\u007f]/u.test(query))throw invalid();
    const key=query.trim(),cached=this.searches.get(key);if(cached&&cached.until>this.now())return structuredClone(cached.records);
    const data=await this.json('/api/search/get/web',{s:key,type:'1',limit:'12',offset:'0'},signal);
    const rows=data?.result?.songs??(data?.result?.songCount===0?[]:undefined);if(!Array.isArray(rows))throw new SongCatalogError('upstream');
    const ids=[...new Set<string>(rows.slice(0,12).map((row:any)=>String(row?.id)).filter(validId))];
    const records=ids.length?await this.readRecords(ids,signal):[];signal.throwIfAborted();this.stop.signal.throwIfAborted();
    this.searches.set(key,{records:structuredClone(records),until:this.now()+600000});while(this.searches.size>64)this.searches.delete(this.searches.keys().next().value!);return records;
  });}
  async dispose(){this.stop.abort();await Promise.allSettled(this.pending);this.searches.clear();}
}
