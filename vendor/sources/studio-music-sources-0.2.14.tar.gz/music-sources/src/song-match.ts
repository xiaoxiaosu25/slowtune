/** Normalization never strips version words or invents artist aliases. */
export const normalizeSongText = (text: string) => text.normalize('NFKC').toLocaleLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
export interface SongIdentity { title: string; artists?: readonly string[]; durationSeconds?: number }
export type SongIdentityReason = 'title' | 'artist' | 'short-title-artist' | 'ambiguous-title' | 'short-title-boundary' | 'incomplete-artists' | 'performer' | 'duration';
/** Evidence only. Host rules still decide whether a candidate should be selected. */
export function songIdentityReasons(entry: SongIdentity, song: SongIdentity, options: { performerTitle?: string; detailed?: boolean } = {}): SongIdentityReason[] {
  const reasons: SongIdentityReason[] = [], contains = (a: string, b: string) => normalizeSongText(a).includes(normalizeSongText(b));
  const wanted = normalizeSongText(song.title), artists = (song.artists ?? []).map(normalizeSongText).filter(Boolean);
  if (!contains(entry.title, song.title)) reasons.push('title');
  if (artists.length) { const facts = [entry.title, ...entry.artists ?? []].join(' '); if (!artists.some(name => contains(facts, name))) reasons.push('artist'); }
  else if (wanted.length <= 3) reasons.push('short-title-artist');
  if (options.detailed === false) return reasons;
  const title = entry.title.normalize('NFKC'), quoted = [...title.matchAll(/《([^《》]+)》/gu)].map(match => normalizeSongText(match[1]));
  if (quoted.length && (!quoted.includes(wanted) || new Set(quoted).size > 1)) reasons.push('ambiguous-title');
  if (!quoted.length && wanted.length <= 3) {
    const escaped = song.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (!new RegExp('(?:^|[\\s\\p{P}\\p{S}])' + escaped + '(?=$|[\\s\\p{P}\\p{S}])', 'iu').test(title)) reasons.push('short-title-boundary');
  }
  const facts = [options.performerTitle ?? title, ...entry.artists ?? []].join(' ');
  if (artists.some(name => !normalizeSongText(facts).includes(name))) reasons.push('incomplete-artists');
  if (entry.artists?.length && artists.some(name => !entry.artists!.some(value => normalizeSongText(value) === name))) reasons.push('performer');
  if (song.durationSeconds !== undefined && entry.durationSeconds !== undefined && Math.abs(song.durationSeconds - entry.durationSeconds) > Math.max(12, song.durationSeconds * .08)) reasons.push('duration');
  return reasons;
}
