import { Innertube } from 'youtubei.js';
import { fail, MusicSourceError, resourceId, type MusicProvider, type MusicEntry, type EntryRef, type ProviderContext, type SearchRequest, type ListRequest, type LibraryRequest, type ShelfRequest, type Account, type PrepareRequest, type PreparedPlayback } from './contracts.js';
import { str, imageUrl, dedupe, limit } from './util.js';
import { opaqueToken, type YtDlpResolver } from './node.js';
import { AsyncLocalStorage } from 'node:async_hooks';
const youtubeContext=new AsyncLocalStorage<ProviderContext>();

export interface YoutubeOptions { resolver: 'yt-dlp'; tool: YtDlpResolver; language?: string; location?: string }
function entry(node: any): MusicEntry | undefined {
  const type = node.type;
  let id = node.content_id ?? node.video_id ?? node.id;
  const kind = ['playlist'].includes(node.item_type) || node.content_type === 'PLAYLIST' || ['Playlist','GridPlaylist'].includes(type) ? 'playlist' : 'video';
  if(kind==='playlist'&&typeof id==='string'&&id.startsWith('VL'))id=id.slice(2);
  if (typeof id !== 'string' || (kind === 'video' && !/^[\w-]{11}$/.test(id))) return;
  if (!['MusicTwoRowItem','MusicResponsiveListItem','Video','CompactVideo','GridVideo','PlaylistVideo','PlaylistPanelVideo','Playlist','GridPlaylist','LockupView'].includes(type)) return;
  if (type === 'LockupView' && !['VIDEO','PLAYLIST'].includes(node.content_type)) return;
  const title = String(node.title ?? node.metadata?.title ?? ''); if (!title || title === 'undefined') fail('upstream','youtube');
  const ref: EntryRef = { provider:'youtube',kind,id };
  const thumbnails = node.thumbnails ?? node.content_image?.image;
  const duration = node.duration?.seconds;
  return {ref,resourceId:resourceId(ref),title,url:kind === 'video' ? `https://www.youtube.com/watch?v=${id}` : `https://music.youtube.com/playlist?list=${encodeURIComponent(id)}`,
    artwork:imageUrl(thumbnails?.at(-1)?.url),...(typeof duration === 'number' && duration > 0 ? {durationSeconds:duration} : {}),
    ...(node.author?.name ? {uploader:{name:node.author.name,id:node.author.id ?? node.author.channel_id}} : {}),
    ...(node.artists ? {artists:node.artists.map((a: any) => str(a.name))} : {})};
}
function mapItems(items: any[]): MusicEntry[] { return dedupe(items.map(entry).filter((v): v is MusicEntry => !!v)); }
function playbackStatus(info: any) {
  const status = info.playability_status?.status;
  if (status && status !== 'OK') fail(status === 'LOGIN_REQUIRED' ? 'authentication' : status === 'UNPLAYABLE' ? 'restricted' : 'not-found','youtube',status);
}
export class YoutubeProvider implements MusicProvider {
  readonly capabilities = {provider:'youtube' as const,operations:['metadata','video-search','playlist','prepare','video-prepare','formats','account','library','recommendation','shelf','disconnect'],anonymous:true,
    limitations:['YouTube Music home and search remain in the separate lab candidate; current test egress reports region unavailability.','Account, private lists and login playback need real user acceptance; recommendations require a verified host session.','Video requires progressive audio/video or paired VOD HLS video and audio renditions; SABR/OTF/live and unpaired silent tracks are rejected. HLS requires host delivery and an HLS-capable player.','This adapter requires the optional youtubei.js peer and a host-provided yt-dlp tool.']};
  private sessions = new Map<string, {client: Innertube; until:number;ref?:string;account?:Account}>();
  private cursors = new Map<string,{scope:string;binding:string;until:number;feed:any;remaining:MusicEntry[]}>();
  constructor(private options: YoutubeOptions) {
    if (options.resolver !== 'yt-dlp' || !options.tool) fail('invalid-input','youtube');
  }
  private prune(now: number) { for (const [k,v] of this.cursors) if (v.until <= now) this.cursors.delete(k); for (const [k,v] of this.sessions) if (v.until <= now) this.sessions.delete(k); }
  protected async run<T>(c: ProviderContext, fn:(client: Innertube)=>Promise<T>): Promise<T> {
    return youtubeContext.run(c, async () => {
      this.prune(c.host.now());
      try {
        let session = this.sessions.get(c.scope);
        if (!session) {
          if (this.sessions.size >= 4) this.sessions.delete(this.sessions.keys().next().value!);
          const client = await Innertube.create({retrieve_player:false,enable_session_cache:false,generate_session_locally:false,
            lang:this.options.language ?? 'en',location:this.options.location ?? 'US',cookie:c.credential?.cookie,
            fetch: (input,init) => { const active = youtubeContext.getStore(); if (!active) fail('disposed','youtube'); return active.host.fetch(input,{...init,signal:active.signal}); }});
          const account=c.credential?.cookie?await this.readAccount(client):undefined;
          session = {client,until:c.host.now()+900000,ref:c.credentialRef,account}; this.sessions.set(c.scope,session);
        }
        return await fn(session.client);
      } catch(e) {
        if (e instanceof MusicSourceError || c.signal.aborted) throw e;
        const name = e instanceof Error ? e.message : '';
        fail(/fetch|network|connect|timed out/i.test(name) ? 'network' : /sign(?:ed)? in|login|401|unauthenticated/i.test(name) ? 'authentication' : /not available|country|403/i.test(name) ? 'restricted' : 'upstream','youtube');
      }
    });
  }
  private async readAccount(client:Innertube):Promise<Account>{
    const accounts=await client.account.getInfo(true);
    const selected=accounts.find(a=>a.is_selected&&!a.is_disabled);if(!selected)fail('authentication','youtube');
    const id=String(selected.channel_handle??'')||String(selected.account_byline??'');
    const name=String(selected.account_name??'');if(!id||!name)fail('upstream','youtube');
    return{provider:'youtube',id,name,artwork:imageUrl(selected.account_photo?.at(-1)?.url)};
  }
  account(c:ProviderContext){if(!c.credential?.cookie)fail('authentication','youtube');return this.run(c,client=>this.readAccount(client));}
  library(request:LibraryRequest,c:ProviderContext){
    if(!c.credential?.cookie)fail('authentication','youtube');
    const size=limit(request.limit),binding=JSON.stringify(['library',size]);
    const extract=(feed:any)=>mapItems(feed.playlists??[]).filter(e=>e.ref.kind==='playlist');
    return this.run(c,async client=>{if(request.cursor)return this.continuation(request.cursor,binding,size,c,extract);const feed=await client.getPlaylists();return this.page(feed,extract(feed),size,binding,c);});
  }
  forgetCredentials(ref:string){
    const scopes=new Set<string>();for(const[key,s]of this.sessions)if(s.ref===ref){scopes.add(key);this.sessions.delete(key);}
    for(const[key,c]of this.cursors)if(scopes.has(c.scope)||c.scope.startsWith(JSON.stringify([ref]).slice(0,-1)+','))this.cursors.delete(key);
  }
  async metadata(ref: EntryRef, c: ProviderContext): Promise<MusicEntry> {
    if (ref.kind !== 'video') fail('unsupported','youtube');
    return this.run(c,async client => { const info = await client.getBasicInfo(ref.id); const b = info.basic_info;
      if(!b.title)playbackStatus(info);
      return {ref,resourceId:resourceId(ref),title:str(b.title),url:`https://www.youtube.com/watch?v=${ref.id}`,artwork:imageUrl(b.thumbnail?.at(-1)?.url),durationSeconds:typeof b.duration === 'number' ? b.duration : undefined,
        ...(Array.isArray(b.keywords) ? { tags: b.keywords.filter((tag): tag is string => typeof tag === 'string') } : {}),
        ...(b.author ? {uploader:{name:b.author,id:b.channel_id ?? undefined}} : {})}; });
  }
  async discover(c: ProviderContext) {
    return[{id:'youtube-home',title:'YouTube 推荐',kind:'recommendation' as const,page:await this.shelf({id:'youtube-home',limit:20},c)}];
  }
  shelf(request:ShelfRequest,c:ProviderContext){
    if(!c.credential?.cookie)fail('authentication','youtube');if(request.id!=='youtube-home')fail('unsupported','youtube');
    const size=limit(request.limit),binding=JSON.stringify(['recommendation',request.id,size]);
    const extract=(feed:any)=>mapItems(feed.videos??[]);
    return this.run(c,async client=>{if(request.cursor)return this.continuation(request.cursor,binding,size,c,extract);const feed=await client.getHomeFeed();return this.page(feed,extract(feed),size,binding,c);});
  }
  protected page(feed: any, items: MusicEntry[], size:number, binding:string, c:ProviderContext) {
    const output = items.slice(0,size); const remaining = items.slice(size);
    let nextCursor: string | undefined;
    if (remaining.length || feed.has_continuation) { if (this.cursors.size >= 64) fail('busy','youtube'); nextCursor=opaqueToken(); this.cursors.set(nextCursor,{feed,remaining,binding,scope:c.scope,until:c.host.now()+900000}); }
    return {items:output,...(nextCursor ? {nextCursor} : {})};
  }
  protected async continuation(token:string,binding:string,size:number,c:ProviderContext,extract:(feed:any)=>MusicEntry[]) {
    const state = this.cursors.get(token); if (!state || state.binding !== binding || state.scope !== c.scope || state.until <= c.host.now()) fail('stale-cursor','youtube');
    // Claim synchronously to prevent concurrent consumption; restore only on a non-cancelled failure.
    this.cursors.delete(token);
    try { const feed = state.remaining.length ? state.feed : await state.feed.getContinuation(); return this.page(feed,state.remaining.length ? state.remaining : extract(feed),size,binding,c); }
    catch(e) { if (!c.signal.aborted) this.cursors.set(token,state); throw e; }
  }
  async search(request:SearchRequest,c:ProviderContext) {
    if(request.mode==='music'||request.order!==undefined&&request.order!=='relevance')fail('unsupported','youtube');
    const size=limit(request.limit), binding=JSON.stringify(['search',request.query,'video',size]);
    const extract = (feed:any) => mapItems(feed.results ?? []);
    return this.run(c,async client => { if (request.cursor) return this.continuation(request.cursor,binding,size,c,extract);
      const feed = await client.search(request.query,{type:'video'});
      return this.page(feed,extract(feed),size,binding,c); });
  }
  async list(request:ListRequest,c:ProviderContext) {
    if (request.ref.kind !== 'playlist') fail('unsupported','youtube');
    const size=limit(request.limit),binding=JSON.stringify(['playlist',request.ref,size]);
    return this.run(c,async client => { if (request.cursor) return this.continuation(request.cursor,binding,size,c,f=>mapItems(f.items));
      const feed=await client.getPlaylist(request.ref.id); return this.page(feed,mapItems(feed.items),size,binding,c); });
  }
  async prepare(request:PrepareRequest,c:ProviderContext):Promise<PreparedPlayback> {
    const metadata = await this.metadata(request.ref,c);
    return this.options.tool.resolve(request,metadata,c);
  }
  async formats(ref: EntryRef, c: ProviderContext) { return this.options.tool.formats(ref, await this.metadata(ref, c), c); }
  diagnostics() { return {sessions:this.sessions.size,cursors:this.cursors.size}; }
  async dispose() { this.sessions.clear();this.cursors.clear(); await this.options.tool?.dispose(); }
}
