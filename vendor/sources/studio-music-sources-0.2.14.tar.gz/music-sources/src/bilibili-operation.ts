import { MusicSourceError } from './contracts.js';
import { SharedWork } from './shared-work.js';

interface Snapshot { status: number; headers: [string, string][]; body: Uint8Array }
interface Entry { bytes: number; value?: Snapshot; signal?: AbortSignal }
const responseLimit = 4 * 1024 * 1024, operationLimit = 8 * 1024 * 1024;

/** Explicitly owned by one host operation. Never share this object across accounts or operations. */
export class BilibiliResponseReuse {
  private stop = new AbortController();
  private shared = new SharedWork();
  private entries = new Map<string, Entry>();
  private bytes = 0;
  constructor(private fetcher: typeof fetch, private signal: AbortSignal, private onReuse?: () => void) {}

  private check() { this.signal.throwIfAborted(); this.stop.signal.throwIfAborted(); }
  private remove(key: string, entry: Entry) {
    if (this.entries.get(key) === entry) this.entries.delete(key);
    this.bytes -= entry.bytes; entry.bytes = 0;
  }
  private capacity(extra: number, except?: Entry) {
    for (const [key, entry] of this.entries) {
      if (this.bytes + extra <= operationLimit && (except || this.entries.size < 32)) break;
      if (entry !== except && entry.value) this.remove(key, entry);
    }
    if (this.bytes + extra > operationLimit || !except && this.entries.size >= 32)
      throw new MusicSourceError({ code: 'busy', provider: 'bilibili', retryable: true });
  }

  fetch: typeof fetch = async (input, init) => {
    this.check();
    const request = input instanceof Request ? input : undefined;
    const url = new URL(request ? request.url : String(input));
    const method = (init?.method ?? request?.method ?? 'GET').toUpperCase();
    if (url.origin !== 'https://api.bilibili.com' || !['/x/web-interface/view', '/x/player/wbi/playurl'].includes(url.pathname) || method !== 'GET')
      return this.fetcher(input, init);
    const signal = AbortSignal.any([this.signal, this.stop.signal, ...(init?.signal ? [init.signal] : request ? [request.signal] : [])]);
    signal.throwIfAborted();
    // Only signing time and its derived signature vary between these exact reads.
    url.searchParams.delete('wts'); url.searchParams.delete('w_rid'); url.searchParams.sort();
    const headers = new Headers(init?.headers ?? request?.headers);
    const key = JSON.stringify([url.href, [...headers.entries()].sort(), init?.credentials ?? request?.credentials,
      init?.redirect ?? request?.redirect, init?.cache ?? request?.cache, init?.mode ?? request?.mode]);
    let entry = this.entries.get(key);
    // A replacement must not join a producer whose last consumer already left.
    // Its retained bytes remain charged until the cancelled read actually ends.
    if (entry?.signal?.aborted) { this.entries.delete(key); entry = undefined; }
    if (entry) { try { this.onReuse?.(); } catch { /* Observation cannot change the request. */ } }
    else { this.capacity(0); entry = { bytes: 0 }; this.entries.set(key, entry); }
    const current = entry;
    const result = current.value ?? await this.shared.run(key, signal, async shared => {
      const combined = AbortSignal.any([shared, this.signal, this.stop.signal]);
      current.signal = combined;
      let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
      try {
        const response = await this.fetcher(input, { ...init, signal: combined });
        reader = response.body?.getReader();
        const chunks: Uint8Array[] = [];
        const cancel = () => { void reader?.cancel().catch(() => {}); };
        combined.addEventListener('abort', cancel, { once: true });
        try {
          combined.throwIfAborted();
          if (reader) for (;;) {
            const chunk = await reader.read(); combined.throwIfAborted();
            if (chunk.done) break;
            if (current.bytes + chunk.value.byteLength > responseLimit)
              throw new MusicSourceError({ code: 'upstream', provider: 'bilibili', retryable: true });
            this.capacity(chunk.value.byteLength, current);
            current.bytes += chunk.value.byteLength; this.bytes += chunk.value.byteLength;
            chunks.push(chunk.value);
          }
        } finally { combined.removeEventListener('abort', cancel); }
        const body = new Uint8Array(current.bytes); let at = 0;
        for (const chunk of chunks) { body.set(chunk, at); at += chunk.byteLength; }
        const value = { status: response.status, headers: [...response.headers.entries()], body };
        if (response.ok) current.value = value; else this.remove(key, current);
        return value;
      } catch (error) { this.remove(key, current); throw error; }
      finally { await reader?.cancel().catch(() => {}); reader?.releaseLock(); }
    });
    signal.throwIfAborted(); this.check();
    return new Response([204, 205, 304].includes(result.status) ? null : result.body.slice(), { status: result.status, headers: result.headers });
  };

  /** Cancels owned reads and waits for their physical cleanup before discarding bodies. */
  async dispose() { this.stop.abort(); await this.shared.dispose(); this.entries.clear(); this.bytes = 0; }
}
