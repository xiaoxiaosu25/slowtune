# @studio/player

文档版本：v2.32 · 2026-10-26

公共音视频播放能力：无界面播放装配、来源适配、进度记忆、队列、睡眠、系统媒体控制、轨道，以及 Stream、MediaDock 和轻量预览 UI。公共实现只维护于本包；产品提供认证、业务数据、来源服务和宿主端口。

自然完播要求本轮已开始播放，且最近一次定位后媒体位置实际推进；定位至结尾后的重复时间事件不消耗睡眠首数，队列仍按原结束策略接续。近结尾定位后确有自然推进仍计数。修复及慢听固定升级的范围见[维护证据](evidence/slowtune-maintenance-2026-10-26.md)。

Video.js 10 的 `hlsjs-video` 停止时使用明确原生空闲来源并清空目标元素，避免上游把 null 推断成新的 HLS 引擎；延迟清理不会覆盖新来源。该兼容处理只在 Video.js 后端维护，宿主仍通过现有 stop／load 与队列操作控制播放。

音频 UI 的媒体宿主显式形成布局盒；上游默认 `display: contents` 的 HLS 元素在收起画面后也遵守隐藏尺寸，不覆盖页面控制。

`PlaybackPlan.live` 显式表示直播：无点播断点／定位和自然完播接续，恢复回到现场；公共音频 UI 仍可展示视频，直播只提供倒计时睡眠。HTTP FLV 通过可选 `@studio/player/flv` 的 `installFlvPlayback(element, runtime)` 注入 mpegts.js，在同一元素上装卸，通过公开 customLoader 接口让停止后的迟到读取保持取消；核心不依赖 FLV 解码器。枕边声已完成受控及四平台短时音画、模式切换和停止释放，见[直播证据](evidence/live-2026-10-09.md)；其他产品不自动升级。

## 选择接入方式

| 需要 | 使用入口与说明 |
| --- | --- |
| 自绘界面、只取核心 | core、contracts；[核心与宿主](guides/core.md) |
| 挂载音频、视频或预览 | 可选 UI 子入口；[界面接入](guides/ui.md) |
| 队列、睡眠、进度或系统媒体 | 按需装配；[功能与场景](guides/features.md) |
| 延迟取源、真实轨道、探测或本机处理 | [来源与处理](guides/sources.md) |
| 核对可选 peer、构建与依赖体积 | [构建与依赖](guides/delivery.md) |

版本、完整导出和依赖以 [package.json](package.json) 为准。根入口包含默认功能组合；最小消费者使用 core 与所需子入口。导入不自动创建工作、访问存储或注册系统操作；UI 挂载时才使用 DOM 和已配置的播放上游。

```js
import { StudioPlayer } from '@studio/player/core';
const player = new StudioPlayer({ sourceResolver: hostSourceResolver });
player.attach(existingMediaElement);
await player.load(hostMediaSource);
await player.play();
await player.destroyAsync();
```

组装方负责依次销毁 UI、队列、播放器、来源桥接及自有宿主资源，具体所有权见指南。

## 当前支持与限制

- 默认后端采用固定 Video.js 正式版组合；公共兼容、原生释放修复及独立制品见[正式版证据](evidence/videojs-ga-2026-10-05.md)，浏览器范围与版本策略见[基线](../../../standards/BASELINE.md)。公共包仍为未发布的本地制品，各产品显式升级，不能外推为全部宿主已支持。
- 视频维护 Stream 内嵌与 MediaDock 模态舞台两套设计；Classic/Cinema 保留兼容参数。手机、平板的浏览器检查与真实设备验收分别记录。
- 音频套件可显式使用原生 video 承载混合音视频队列，`setMediaView` 原地展示或收起画面，继续复用同一套队列、进度和睡眠；只收起画面不减少视频传输。见[混合媒体检查](evidence/mixed-media-2026-10-08.md)。
- mpv 独立进程和实例宿主端口已有实现，未提供公开 Electron runtime 入口；U5 产品阶段尚未完成，当前按用户指示暂缓。
- ffprobe 与三个显式 FFmpeg 处理 profile 属可选 Node 能力，工具由宿主提供；不自动处理每次播放，也不随包分发工具。
- 原生音频、后台服务、远程转码、数据库、账号和产品来源流程由消费者维护。浏览器媒体元素需要请求头时由合适宿主交付。
- 资源身份、播放意图、原始时间轴和临时交付分别表达。取消、换源与销毁的释放责任按来源及宿主契约执行。
- 来源恢复中的异步内部暂停保留播放意图，显式用户暂停仍生效。MediaDock 固定制品的升级、真实来源与实际回退见[消费者证据](evidence/mediadock-ga-2026-10-05.md)。
- 初次媒体载入失败时保留尚未读取的断点，换源保留已读取但等待可定位范围的断点；已播放后暂停的故障恢复使用实际位置。显式从头加载、定位到零和暂停仍有效，见[恢复回归](evidence/review-fixes-2026-10-07.md)。慢听原候选最终自然接续未通过的[独立证据](evidence/music-app-ga-2026-10-05.md)保留；后续固定输入与验证由[消费者记录](../../../docs/audio-video/player/10-消费者接入记录.md)维护，受控恢复不覆盖独立真实上游失败。

安装用户可阅读包内 guides 与 [THIRD-PARTY](THIRD-PARTY.md)；指向平台 docs、examples、labs 和 evidence 的链接用于源码工作区查询。许可材料与工程验证的适用边界分别维护。

## 构建、验证与接续

在本目录按锁文件准备 `npm.cmd ci`，执行 `npm.cmd run build`、`npm.cmd test` 和 `npm.cmd run test:types`。在平台根运行 `node scripts/platform.mjs check player`；制品核对另选 `--kind=delivery`，不会发布或升级消费者。

| 入口 | 内容 |
| --- | --- |
| [能力文档](../../../docs/audio-video/player/README.md) | 方案、范围和验证口径 |
| [当前交接](../../../docs/audio-video/player/04-进度与交接.md) | 当前阶段、证据和遗留 |
| [消费者记录](../../../docs/audio-video/player/10-消费者接入记录.md) | 源码接线、固定制品和真实产品验收 |
| [HLS 展示与释放](evidence/hls-release-2026-10-09.md) | 单元素混合点播与停止释放的公共及产品验证 |
| [示例 A](../../../examples/audio-video/player/example-a/README.md)、[示例 B](../../../examples/audio-video/player/example-b/README.md) | 自绘与套件消费者 |
| [最近评审修复](evidence/review-fixes-2026-10-03.md) | 延迟断点、备用时间轴与字幕超时反馈 |

其他项目接入、升级、默认切换或移除本包时，在同次改动中更新消费者记录。新公共源码或重新打包不自动更新产品，也不替代原候选的验收结论。
