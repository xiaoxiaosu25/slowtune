import test from 'node:test';
import assert from 'node:assert/strict';
import { StudioPlayer } from '@studio/player/core';
import { MainMediaCoordinator } from '@studio/player/main-media';
import { VideoTracksController } from '@studio/player/video-tracks';
import { SleepTimerController } from '@studio/player/sleep-timer';
import { createPlayerPreset, mountPlayerFeatures } from '@studio/player/presets';
import { Media, Clock, Session, plan, items, settle, deferred, setup } from './helpers.mjs';

function scene(t, name, scope, options = {}) {
  const preset = createPlayerPreset(name, { ...options, features: { mediaSession: false, ...options.features, ...(scope ? { mainMedia: { scope } } : {}) } });
  const media = new Media(); preset.player.attach(media); preset.features.queue?.setItems(items);
  t.after(() => preset.destroy()); return { ...preset, media };
}

test('Video defaults compose real controllers with manual episodes and no implicit scope or play', t => {
  const video = scene(t, 'video');
  assert.ok(video.features.videoTracks instanceof VideoTracksController);
  assert.ok(video.features.sleepTimer);
  assert.equal(video.features.mainMedia, null);
  assert.equal(video.features.queue.snapshot.autoAdvance, false);
  assert.equal(video.player.state, 'idle'); assert.equal(video.media.playCalls, 0);
  const off = createPlayerPreset('video', { features: { queue: false, sleepTimer: false, mediaSession: false, videoTracks: false } });
  t.after(() => off.destroy());
  for (const key of ['queue', 'sleepTimer', 'mediaSession', 'videoTracks', 'mainMedia']) assert.equal(off.features[key], null);
});

test('Video manual episodes do not count as natural completions; sleep wins over explicit autoplay', async t => {
  const video = scene(t, 'video'); const { queue, sleepTimer } = video.features;
  queue.setAutoAdvance(true);
  sleepTimer.start({ trigger: { type: 'items', count: 1 }, action: 'stop' });
  await queue.select(0); await queue.next();
  assert.equal(sleepTimer.snapshot.remainingItems, 1);
  video.media.finish(); await settle();
  assert.equal(video.player.state, 'stopped'); assert.equal(queue.snapshot.current.id, 'b');
  assert.equal(video.media.playCalls, 2);
});

test('Turning off autoplay cancels an in-flight natural episode load', async t => {
  const gate = deferred();
  const video = scene(t, 'video', null, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const queue = video.features.queue; queue.setAutoAdvance(true); await queue.select(0);
  video.player.progressController.recordProgress('other', 30, 100, false);
  video.media.finish(); queue.setAutoAdvance(false); gate.resolve(); await settle();
  assert.equal(video.media.paused, true); assert.equal(video.media.playCalls, 1);
});

test('One injected product scope preempts audio/video before a new source starts; history remains actual', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const a = scene(t, 'audio', scope); const v = scene(t, 'video', scope);
  await a.features.queue.play(); a.media.currentTime = 28;
  await v.features.queue.play();
  assert.equal(a.player.paused, true); assert.equal(a.player.currentTime, 28);
  assert.equal(v.player.paused, false); assert.equal(scope.active, v.features.mainMedia);
  assert.deepEqual(a.features.queue.snapshot.history, ['a']);
  v.player.pause(); assert.equal(scope.active, null);
  assert.equal(a.player.paused, true); // release never resumes a previous owner
});

test('Independent scopes and unregistered media do not interfere', async t => {
  const scopes = [new MainMediaCoordinator(), new MainMediaCoordinator()]; t.after(() => scopes.forEach(scope => scope.destroy()));
  const a = scene(t, 'audio', scopes[0]); const b = scene(t, 'video', scopes[1]); const c = scene(t, 'audio');
  await a.features.queue.play(); await b.features.queue.play(); await c.features.queue.play();
  assert.deepEqual([a, b, c].map(scene => scene.player.paused), [false, false, false]);
});

test('A queued old pause event cannot cancel an already playing new episode or its sleep rule', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const video = scene(t, 'video', scope);
  video.features.sleepTimer.start({ trigger: { type: 'items', count: 1 }, action: 'stop' });
  await video.features.queue.select(0); await video.features.queue.select(1);
  // HTML pause events are asynchronous; by dispatch time this same element is already playing again.
  video.media.trigger('pause');
  assert.equal(video.player.paused, false); assert.equal(scope.active, video.features.mainMedia);
  assert.equal(video.features.sleepTimer.snapshot.remainingItems, 1);
  video.media.finish(); await settle();
  assert.equal(video.player.state, 'stopped'); assert.equal(scope.active, null);
});

test('Standalone play rejection releases main-media ownership and notifies once', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const { player, media } = setup(t); scope.register(player); await player.load(plan('rejected'));
  const failures = []; player.on('playerror', error => failures.push(error));
  const error = Object.assign(new Error('A user gesture is required'), { name: 'NotAllowedError' });
  media.play = () => Promise.reject(error);
  await assert.rejects(player.play(), { name: 'NotAllowedError' });
  assert.deepEqual(failures, [error]); assert.equal(scope.active, null);
  assert.equal(player.playbackRequested, false); assert.equal(player.paused, true);
});

test('Natural completion releases a manual episode but preserves an explicit queued continuation', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const video = scene(t, 'video', scope);
  await video.features.queue.play(); video.media.finish(); await settle();
  assert.equal(scope.active, null);
  video.features.queue.setAutoAdvance(true); await video.features.queue.play(); video.media.finish(); await settle();
  assert.equal(video.features.queue.snapshot.current.id, 'b');
  assert.equal(scope.active, video.features.mainMedia); assert.equal(video.player.paused, false);
});

test('Main-media preemption cancels a queue still waiting for progress storage', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const gate = deferred();
  const a = scene(t, 'audio', scope, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const b = scene(t, 'video', scope);
  a.player.progressController.recordProgress('previous', 20, 100, false);
  const pending = a.features.queue.play(); await b.features.queue.play(); gate.resolve();
  assert.equal(await pending, false); assert.equal(a.media.playCalls, 0); assert.equal(b.player.paused, false);
  assert.deepEqual(a.features.queue.snapshot.history, []);
});

test('A late native play promise and event cannot revive a preempted owner', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const a = scene(t, 'audio', scope); const b = scene(t, 'video', scope); const gate = deferred();
  a.media.play = async function () { await gate.promise; this.paused = false; this.trigger('play'); this.trigger('playing'); };
  const old = a.features.queue.play(); await settle(); await b.features.queue.play(); gate.resolve();
  assert.equal(await old, false); assert.equal(a.player.paused, true); assert.equal(b.player.paused, false);
  assert.equal(scope.active, b.features.mainMedia); assert.deepEqual(a.features.queue.snapshot.history, []);
});

test('Reentrant newer claim wins and cancels the claimant being superseded', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const a = scene(t, 'audio', scope); const b = scene(t, 'video', scope); const c = scene(t, 'video', scope);
  await a.features.queue.play(); await c.player.load(plan('c'));
  let triggered = false;
  a.player.on('pauseintent', () => { if (!triggered) { triggered = true; c.player.requestPlayback(); } });
  assert.equal(await b.features.queue.play(), false);
  assert.equal(scope.active, c.features.mainMedia); assert.equal(b.media.playCalls, 0);
});

test('Pause, stop, close and coordinator removal release ownership and never auto-resume', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const a = scene(t, 'audio', scope);
  for (const action of ['pause', 'stop', 'close']) {
    await a.features.queue.play(); assert.equal(scope.active, a.features.mainMedia);
    await a.player[action](); assert.equal(scope.active, null); assert.equal(a.media.paused, true);
  }
  await a.features.queue.play(); a.features.setEnabled('mainMedia', false);
  assert.equal(a.player.paused, true); assert.equal(scope.size, 0); assert.equal(a.player.isDestroyed, false);
  a.features.setEnabled('mainMedia', true); scope.destroy();
  assert.equal(scope.size, 0); assert.equal(a.features.mainMedia.isDestroyed, true);
});

test('Main-media and MediaSession control ownership are distinct', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const session = new Session();
  const a = scene(t, 'audio', scope, { features: { mediaSession: { session } } });
  const b = scene(t, 'video', scope, { features: { mediaSession: { session } } });
  a.features.mediaSession.activate(); await b.features.queue.play();
  assert.equal(scope.active, b.features.mainMedia); assert.equal(a.features.mediaSession.active, true);
  b.features.mediaSession.activate(); assert.equal(a.features.mediaSession.active, false);
  assert.equal(b.player.paused, false);
});

test('Source replacement retains identity, queue, sleeping, position and paused intent', async t => {
  const video = scene(t, 'video'); const { queue, sleepTimer } = video.features;
  await queue.play(); video.player.pause(); video.player.seek(35);
  video.player.setVolume(0.3); video.player.setMuted(true); video.player.setPlaybackRate(1.5);
  sleepTimer.start({ trigger: { type: 'items', count: 2 }, action: 'close' });
  video.player.replaceSource(plan('a', { playUrl: 'alternate.mp4' })); await settle();
  assert.equal(video.player.currentResourceId, 'a'); assert.equal(video.player.currentTime, 35);
  assert.equal(video.player.paused, true); assert.equal(video.player.playbackRate, 1.5); assert.equal(video.player.volume, 0.3);
  assert.equal(queue.snapshot.current.id, 'a'); assert.deepEqual(queue.snapshot.history, ['a']); assert.equal(sleepTimer.snapshot.remainingItems, 2);
  assert.throws(() => video.player.replaceSource(plan('another')), /resourceId/);
  assert.equal(video.media.src, 'alternate.mp4');
});

for (const action of ['stop', 'close', 'sleep']) {
  for (const seek of [undefined, 0, 47]) {
    test(`Source replacement: ${action} saves ${seek === undefined ? 'the pending position' : `the newer seek to ${seek}`} before metadata`, async t => {
      const saved = new Map();
      const { player, media } = setup(t, { progressStorage: {
        load: id => saved.get(id) ?? null, save: (id, position) => saved.set(id, position), clear: id => saved.delete(id),
      } });
      await player.load(plan('continuity')); await player.play();
      media.currentTime = 32;
      media.load = () => { media.currentTime = 0; media.duration = NaN; media.paused = true; media.ended = false; };
      player.replaceSource(plan('continuity', { playUrl: 'replacement.mp4' }));
      assert.equal(media.currentTime, 0);
      if (seek !== undefined) player.seek(seek);
      if (action === 'sleep') {
        const clock = new Clock();
        const timer = new SleepTimerController(player, { clock }); t.after(() => timer.destroy());
        timer.start({ trigger: { type: 'duration', durationMs: 1000 }, action: 'stop' });
        clock.jump(1000); await settle();
      } else await player[action]();
      assert.equal(saved.get('continuity'), seek ?? 32);
      assert.equal(player.state, 'stopped'); assert.equal(media.src, '');
      media.duration = 100; media.trigger('loadedmetadata'); await settle();
      assert.equal(media.paused, true); assert.equal(saved.get('continuity'), seek ?? 32);
    });
  }
}

for (const phase of ['before metadata', 'during resume']) {
  test(`Source replacement preserves newer controls set ${phase}`, async t => {
    const { player, media } = setup(t);
    await player.load(plan('controls')); await player.play(); player.pause(); player.seek(32);
    const update = () => { player.setMuted(true); player.setVolume(0.2); player.setPlaybackRate(2); };
    if (phase === 'during resume') player.on('resume', update);
    player.replaceSource(plan('controls', { playUrl: 'replacement.mp4' }));
    if (phase === 'before metadata') update();
    await settle();
    assert.deepEqual([media.muted, media.volume, media.playbackRate], [true, 0.2, 2]);
    assert.equal(player.currentTime, 32); assert.equal(player.paused, true);
  });
}

test('Explicitly loading an equivalent declarative source starts a fresh resource at zero exactly once', async t => {
  class DeclarativeMedia extends Media {
    value = null; loads = 0;
    get source() { return this.value; }
    set source(value) { const changed = value?.src !== this.value?.src; this.value = value; this.src = value?.src ?? ''; if (changed) this.load(); }
    load() { this.loads++; super.load(); }
  }
  const player = new StudioPlayer(); const media = new DeclarativeMedia(); player.attach(media); t.after(() => player.destroy());
  await player.load(plan('first', { playUrl: 'same.mp4' })); await settle();
  assert.equal(media.loads, 1); assert.equal(player.state, 'ready');
  await player.play(); player.seek(40);
  await player.load(plan('second', { playUrl: 'same.mp4' })); await settle();
  assert.equal(media.loads, 2); assert.equal(player.currentResourceId, 'second');
  assert.equal(player.currentTime, 0); assert.equal(player.paused, true); assert.equal(player.state, 'ready');
});

test('Fast same-resource replacements retain zero position instead of reading an older checkpoint', async t => {
  let reads = 0;
  const video = scene(t, 'video', null, { progressStorage: { load: () => { reads++; return 30; }, save() {}, clear() {} } });
  await video.features.queue.play(); video.player.pause(); video.player.seek(0);
  video.player.replaceSource(plan('a', { playUrl: 'first.mp4' }));
  video.player.replaceSource(plan('a', { playUrl: 'latest.mp4' })); await settle();
  assert.equal(video.player.currentTime, 0); assert.equal(video.media.src, 'latest.mp4'); assert.equal(reads, 1);
});

test('Late URL refresh cannot overwrite manual replacement, or resume after a later pause/stop', async t => {
  const gate = deferred();
  const video = scene(t, 'video', null, { sourceResolver: { resolveUrl: () => gate.promise } });
  await video.features.queue.play(); video.media.currentTime = 20;
  const old = video.player.sourceController.refreshSource('expired');
  video.player.replaceSource(plan('a', { playUrl: 'latest.mp4' })); video.player.pause();
  gate.resolve(plan('a', { playUrl: 'stale.mp4' })); await old; await settle();
  assert.equal(video.media.src, 'latest.mp4'); assert.equal(video.player.currentTime, 20); assert.equal(video.player.paused, true);
  video.player.replaceSource(plan('a', { playUrl: 'another.mp4' })); await video.player.stop(); await settle();
  assert.equal(video.media.src, ''); assert.equal(video.player.state, 'stopped');
});

class TrackList extends EventTarget {
  constructor(entries) { super(); this.entries = entries; this.selectedIndex = -1; entries.forEach((entry, index) => { this[index] = entry; }); this.length = entries.length; }
  [Symbol.iterator]() { return this.entries[Symbol.iterator](); }
  change() { this.dispatchEvent(new Event('change')); }
}
function tracksMedia(t) {
  const { player, media } = setup(t);
  media.textTracks = new TrackList([
    { id: 'zh', kind: 'subtitles', label: '中文', language: 'zh', mode: 'disabled' },
    { id: 'en', kind: 'subtitles', label: 'English', language: 'en', mode: 'disabled' },
  ]);
  media.audioTracks = new TrackList([{ id: 'a', language: 'zh', label: 'Original', enabled: true }, { id: 'b', language: 'en', label: 'Commentary', enabled: false }]);
  media.videoRenditions = new TrackList([{ id: 'low', width: 640, height: 360, bitrate: 400000 }, { id: 'high', width: 1280, height: 720, bitrate: 1000000 }]);
  const tracks = new VideoTracksController(player); t.after(() => tracks.destroy()); return { player, media, tracks };
}

test('Track selections change real exposed lists and preserve playback position and intent', async t => {
  const { player, media, tracks } = tracksMedia(t); await player.load(plan('x')); await player.play(); player.seek(25);
  tracks.selectSubtitle('en'); tracks.selectAudioTrack('b'); tracks.selectQuality('high');
  assert.equal(media.textTracks[1].mode, 'showing'); assert.equal(media.textTracks[0].mode, 'disabled');
  assert.equal(media.audioTracks[1].enabled, true); assert.equal(media.audioTracks[0].enabled, false);
  assert.equal(media.videoRenditions.selectedIndex, 1); assert.equal(player.currentTime, 25); assert.equal(player.paused, false);
  tracks.selectSubtitle('off'); tracks.selectQuality('auto'); assert.equal(media.textTracks[1].mode, 'disabled'); assert.equal(media.videoRenditions.selectedIndex, -1);
});

test('A late second subtitle cannot remain visible alongside the requested first track', async t => {
  const { player, media, tracks } = tracksMedia(t); await player.load(plan('exclusive-subtitle'));
  tracks.selectSubtitle('zh');
  media.textTracks[1].mode = 'showing'; media.textTracks.change(); await settle();
  assert.deepEqual([...media.textTracks].map(track => track.mode), ['showing', 'disabled']);
  tracks.selectSubtitle('off');
  media.textTracks[1].mode = 'showing'; media.textTracks.change(); await settle();
  assert.deepEqual([...media.textTracks].map(track => track.mode), ['disabled', 'disabled']);
});

for (const label of ['Original', '']) {
  test(`Explicit audio IDs distinguish tracks with identical ${label ? 'labels' : 'empty labels'} and language`, async t => {
    const { player, media, tracks } = tracksMedia(t);
    media.audioTracks = new TrackList([
      { id: 'first', language: 'en', label, enabled: true },
      { id: 'second', language: 'en', label, enabled: false },
    ]);
    await player.load(plan('duplicates'));
    tracks.selectAudioTrack('second');
    assert.equal(tracks.snapshot.audioTrack, 'second');
    media.audioTracks.change(); await settle();
    assert.equal(media.audioTracks[0].enabled, false); assert.equal(media.audioTracks[1].enabled, true);
    tracks.selectAudioTrack('first');
    assert.equal(tracks.snapshot.audioTrack, 'first');
  });
}

test('Audio continuity matches language and label when replacement tracks reuse different IDs', async t => {
  const { player, media, tracks } = tracksMedia(t); await player.load(plan('x'));
  tracks.selectAudioTrack('b');
  media.audioTracks = new TrackList([
    { id: 'b', language: 'zh', label: 'Original', enabled: true },
    { id: 'a', language: 'en', label: 'Commentary', enabled: false },
  ]);
  player.replaceSource(plan('x', { playUrl: 'replacement.mp4' })); await settle();
  assert.equal(tracks.snapshot.audioTrack, 'a');
  tracks.selectAudioTrack('b'); media.audioTracks.change(); await settle();
  assert.equal(tracks.snapshot.audioTrack, 'b');
});

test('Latest audio and quality selection wins when late list events report an older choice', async t => {
  const { player, media, tracks } = tracksMedia(t); await player.load(plan('x'));
  tracks.selectAudioTrack('b'); tracks.selectAudioTrack('a'); tracks.selectQuality('low'); tracks.selectQuality('high');
  media.audioTracks[0].enabled = false; media.audioTracks[1].enabled = true; media.audioTracks.change();
  media.videoRenditions.selectedIndex = 0; media.videoRenditions.change(); await settle();
  assert.equal(media.audioTracks[0].enabled, true); assert.equal(media.audioTracks[1].enabled, false);
  assert.equal(media.videoRenditions.selectedIndex, 1);
});

test('A later automatic rendition cannot silently override the requested manual quality on upstream rc.2', async t => {
  const { player, media, tracks } = tracksMedia(t); await player.load(plan('quality')); await player.play(); player.seek(15);
  tracks.selectQuality('low'); media.videoRenditions[0].active = false; media.videoRenditions[1].active = true;
  let changes = 0; media.videoRenditions.addEventListener('change', () => changes++);
  media.videoRenditions.dispatchEvent(new Event('activechange')); await settle();
  assert.equal(changes, 1); assert.equal(media.videoRenditions.selectedIndex, 0);
  // The corrective public event is not recursively reissued, and an intervening new selection wins.
  media.videoRenditions.dispatchEvent(new Event('activechange')); tracks.selectQuality('high'); await settle();
  assert.equal(changes, 1); assert.equal(media.videoRenditions.selectedIndex, 1);
  assert.equal(player.currentTime, 15); assert.equal(player.paused, false);
});

test('Track choices survive same resource replacement but are reset for another episode', async t => {
  const { player, tracks } = tracksMedia(t); await player.load(plan('x')); tracks.selectAudioTrack('b'); tracks.selectQuality('high');
  player.replaceSource(plan('x', { playUrl: 'new.mp4' })); await settle();
  assert.equal(tracks.snapshot.audioTrack, 'b'); assert.equal(tracks.snapshot.quality, 'high');
  await player.load(plan('y')); player.element.audioTracks[0].enabled = true; player.element.audioTracks[1].enabled = false;
  player.element.audioTracks.change(); await settle();
  assert.equal(tracks.snapshot.audioTrack, 'a');
});

test('Absent capabilities and declared unsupported subtitles are explicit, never static working menus', async t => {
  const { player } = setup(t); const tracks = new VideoTracksController(player); t.after(() => tracks.destroy());
  await player.load(plan('fixed', { tracks: { subtitles: [{ id: 'ass', src: '/a.ass', label: 'ASS', language: 'zh' }], audio: [{ id: 'external', src: '/tone.mp3', label: 'Other', language: 'en' }] } }));
  assert.equal(tracks.snapshot.qualityAvailable, false); assert.equal(tracks.snapshot.audioAvailable, false);
  assert.equal(tracks.snapshot.subtitles[0].status, 'unavailable');
  assert.throws(() => tracks.selectQuality('1080'), { name: 'NotSupportedError' }); assert.throws(() => tracks.selectAudioTrack('external'), { name: 'NotSupportedError' });
  assert.throws(() => tracks.selectSubtitle('ass'), { name: 'NotSupportedError' });
});

test('Feature lifecycle releases scope, list listeners and queued track work without destroying a borrowed player', async t => {
  const { player, media } = tracksMedia(t); const scope = new MainMediaCoordinator();
  const group = mountPlayerFeatures(player, { mainMedia: { scope }, videoTracks: true });
  await player.load(plan('x')); await player.play();
  media.audioTracks.change(); group.destroy(); await settle();
  assert.equal(scope.size, 0); assert.equal(player.paused, true); assert.equal(player.isDestroyed, false);
  assert.equal(group.videoTracks, null); scope.destroy();
  assert.throws(() => createPlayerPreset('video', { features: { mainMedia: true } }), /options object/);
});
