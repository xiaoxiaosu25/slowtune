import test from 'node:test';
import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const videoDirectory = fileURLToPath(new URL('../src/ui/video/', import.meta.url));

test('U5-4A: video UI keeps controls neutral and stream exposes a surface slot', async () => {
  const files = (await readdir(videoDirectory)).filter(file => file.endsWith('.ts'));
  const sources = new Map(await Promise.all(files.map(async file => [file, await readFile(path.join(videoDirectory, file), 'utf8')])));
  const allSource = [...sources.values()].join('\n');
  const index = sources.get('index.ts');
  const streamTemplate = sources.get('template-stream.ts');

  assert.ok(index && streamTemplate);
  assert.doesNotMatch(index, /@videojs\/html\/ui\/(?:time-slider|volume-slider|slider-track|slider-thumb|slider-fill|slider-buffer|mute-button|fullscreen-button|pip-button)/);
  assert.doesNotMatch(allSource, /media-(?:time-slider|volume-slider|slider-track|slider-thumb|slider-fill|slider-buffer|mute-button|fullscreen-button|pip-button)/);
  assert.match(allSource, /class="range-input" type="range"/);
  assert.match(index, /player\.seekAsync\(control\.valueAsNumber\)/);
  assert.match(index, /player\.setVolume\(control\.valueAsNumber\)/);
  assert.match(streamTemplate, /data-media-slot data-surface-slot="media"/);
  assert.doesNotMatch(allSource, /(?:from\s+|import\s*\()(['"])(?:electron|node:)/);
});
