import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { StudioPlayer } from '../dist/player.js';
import {
  createPlayerInstance,
  PortContractError,
} from '../dist/contracts/index.js';

const here = path.dirname(fileURLToPath(import.meta.url));

function surfaceFor(instance) {
  return {
    instance,
    create() {}, resize() {}, show() {}, hide() {}, focus() {}, requestFullscreen() {}, destroy() {},
  };
}

function mpvLaunch(instance, windowId = '7001') {
  return {
    instanceId: instance.instanceId,
    executable: 'C:/controlled/mpv/mpv.exe',
    ipcName: `studio-player-mpv-${instance.instanceId}`,
    surfaceTarget: { type: 'native-window', windowId },
    videoOutput: 'gpu-next',
    audioOutput: 'wasapi',
  };
}

test('U5-4B explicit mpv player shares one instance with the SurfacePort', () => {
  const instance = createPlayerInstance('u5-4b-test', 'mpv');
  const surface = surfaceFor(instance);
  const player = new StudioPlayer({ backend: 'mpv', instance, surfacePort: surface, mpv: mpvLaunch(instance) });
  assert.equal(player.instance, instance);
  assert.equal(player.ports.playback, player);
  assert.equal(player.ports.surface, surface);
  assert.equal(player.element, null);
  assert.throws(() => player.attach({}), TypeError);
  player.destroy();
});

test('U5-4B rejects an explicit mpv player without a surface and rejects a Video.js/native mismatch', () => {
  assert.throws(
    () => new StudioPlayer({ backend: 'mpv' }),
    error => error instanceof PortContractError && error.code === 'invalid-binding',
  );
  const videojs = createPlayerInstance('u5-4b-videojs-test', 'videojs');
  assert.throws(
    () => new StudioPlayer({ backend: 'videojs', instance: videojs, surfacePort: surfaceFor(videojs) }),
    error => error instanceof PortContractError && error.code === 'invalid-binding',
  );
});

test('stream UI creates the native surface lifecycle and keeps attach in the Video.js branch only', () => {
  const source = fs.readFileSync(path.join(here, '..', 'src', 'ui', 'video', 'index.ts'), 'utf8');
  assert.match(source, /if \(isMpv\) \{\s*await ensureSurface\(\);\s*\} else \{/s);
  assert.match(source, /get\('\[data-media-slot\]'\)\.append\(media\); player\.attach\(media\);/);
  assert.match(source, /surfacePort\.create/);
  assert.match(source, /surfacePort\.resize/);
  assert.match(source, /surfacePort\.requestFullscreen/);
  assert.match(source, /surfacePort\.destroy/);
});
