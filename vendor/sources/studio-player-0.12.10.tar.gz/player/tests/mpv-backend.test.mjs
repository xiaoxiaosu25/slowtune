/**
 * U2 第 2 步：mpv 后端（非 DOM 后端）真实通路检查。
 *
 * 取值必须来自真实 mpv，因此本文件在缺少 mpv 可执行文件或媒体样本时**跳过**（跳过不等于通过）。
 * 环境变量：
 *   STUDIO_PLAYER_MPV_BIN    官方 mpv 可执行文件路径（本文件全部用例的前提）
 *   STUDIO_PLAYER_MPV_MEDIA  单个视频样本（.mp4）
 *   STUDIO_PLAYER_MPV_HLS    多轨 HLS 样本（master.m3u8，用于轨道用例）
 *   STUDIO_PLAYER_MPV_LOG_DIR  mpv 日志输出目录（可选，默认系统临时目录）
 *
 * 本文件自己设置 `STUDIO_PLAYER_BACKEND=mpv` 与 `STUDIO_PLAYER_MPV_ARGS=--vo=null --ao=null`
 * （用例结束后恢复原值）：后者的目的是不弹真实窗口，**不证明画面呈现与声音输出**——真实窗口
 * 呈现属 U2 第 3 步的桌面验收，本文件不作任何呈现结论。
 *
 * 口径：本文件只证明"四项职责有真实通路、取值来自真实 mpv"，不证明产品可交付、不替代宿主验收。
 * 详见 packages/audio-video/player/evidence/u2-mpv-第2步-后端适配与后端选择.md。
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { StudioPlayer } from '@studio/player/core';
import { QueueController } from '@studio/player/queue';
import {
  MpvSession,
  MPV_ARGS_ENV,
  MPV_BACKEND_ENV,
  MPV_BIN_ENV,
} from '../dist/backends/mpv/index.js';

const MPV_BIN = process.env.STUDIO_PLAYER_MPV_BIN ?? '';
const MP4 = process.env.STUDIO_PLAYER_MPV_MEDIA ?? '';
const HLS = process.env.STUDIO_PLAYER_MPV_HLS ?? '';
const LOG_DIR = process.env.STUDIO_PLAYER_MPV_LOG_DIR || tmpdir();

const missingBinary = MPV_BIN ? false : '需要 STUDIO_PLAYER_MPV_BIN 指向官方 mpv 可执行文件';
const missingMp4 = missingBinary || (MP4 ? false : '需要 STUDIO_PLAYER_MPV_MEDIA 指向一个视频样本');
const missingHls = missingBinary || (HLS ? false : '需要 STUDIO_PLAYER_MPV_HLS 指向多轨 HLS 样本');

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

/** 等待一个条件成立；超时即失败，失败信息带上等待的目标。 */
async function waitFor(predicate, timeoutMs, message) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    if (predicate()) return;
    if (Date.now() > deadline) throw new Error(`等待超时（${timeoutMs} ms）：${message}`);
    await delay(50);
  }
}

/** 选择 mpv 后端并设置附加参数；返回恢复环境的函数（避免影响同进程内的其它测试文件）。 */
function selectMpvBackend(extraArgs, binary = MPV_BIN) {
  const keys = [MPV_BACKEND_ENV, MPV_BIN_ENV, MPV_ARGS_ENV];
  const previous = new Map(keys.map(key => [key, process.env[key]]));
  process.env[MPV_BACKEND_ENV] = 'mpv';
  if (binary) process.env[MPV_BIN_ENV] = binary;
  else delete process.env[MPV_BIN_ENV];
  process.env[MPV_ARGS_ENV] = extraArgs.join(' ');
  return () => {
    for (const [key, value] of previous) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  };
}

function logPath(name) {
  mkdirSync(LOG_DIR, { recursive: true });
  return path.join(LOG_DIR, name);
}

test('mpv 能力声明与输出面：默认交付独立窗口，声明之外的来源同步拒绝', { skip: missingBinary }, () => {
  const session = new MpvSession({ executable: MPV_BIN });
  assert.equal(session.backendName, 'mpv');
  assert.equal(session.outputMode, 'independent-window');
  assert.equal(session.capabilities.output, 'independent-window');
  assert.deepEqual([...session.capabilities.transports], ['range', 'hls', 'dash']);
  assert.deepEqual([...session.capabilities.trackKinds], ['video', 'audio', 'subtitle']);
  assert.ok(session.capabilities.codecs.includes('h264'));

  // 默认参数不覆盖输出面：画面落在 mpv 自己的独立窗口（跨进程嵌入尚未做）。
  const commandLine = session.commandLine();
  assert.equal(commandLine[0], MPV_BIN);
  assert.ok(!commandLine.some(argument => argument.startsWith('--vo')), '默认不应覆盖 --vo');
  assert.ok(!commandLine.some(argument => argument.startsWith('--ao')), '默认不应覆盖 --ao');
  assert.ok(commandLine.some(argument => argument.startsWith('--input-ipc-server=')), '必须建立 IPC 端点');
  assert.ok(commandLine.includes('--no-config'), '不读宿主 mpv 配置：行为可追溯');

  // 宿主/验证可以覆盖输出面，附加参数追加在内置参数之后。
  const headless = new MpvSession({ executable: MPV_BIN, extraArgs: ['--vo=null', '--ao=null'] });
  assert.ok(headless.commandLine().includes('--vo=null'));

  // 声明之外的来源在应用阶段同步拒绝：沿用核心"来源拒绝 → 备用源 → error"的既有规则。
  assert.throws(() => session.applyDelivery({ src: 'https://example.com/live', transport: 'webrtc' }),
    /mpv 后端不支持该来源/);
  assert.throws(() => session.applyDelivery({ src: '/media/notes.txt', type: 'text/plain' }),
    /不是媒体类型/);
  // 未指定可执行文件时不静默降级：加载来源直接拒绝。
  const bare = new MpvSession({});
  assert.throws(() => bare.applyDelivery({ src: '/media/episode.mp4', type: 'video/mp4' }), /STUDIO_PLAYER_MPV_BIN/);
});

test('mpv 会话与事实反馈：直接驱动后端，取值来自真实 mpv', { skip: missingMp4 }, async () => {
  const file = logPath('backend-session.log');
  const session = new MpvSession({ executable: MPV_BIN, extraArgs: ['--vo=null', '--ao=null', `--log-file=${file}`] });
  try {
    assert.equal(session.running, false);
    const { deduped } = session.applyDelivery({ src: MP4, type: 'video/mp4' });
    assert.equal(deduped, false);
    assert.equal(session.src, MP4);

    await waitFor(() => session.running && session.mpvVersion.length > 0, 15000, '会话进程启动并完成版本握手');
    assert.match(session.mpvVersion, /^mpv v\d+\.\d+/, '版本来自真实 mpv 的 mpv-version 属性');
    assert.equal(session.commandLine().some(argument => argument.includes(MP4)), false, '媒体路径不经命令行，只经 IPC');

    await waitFor(() => session.duration > 0, 15000, '时长推送');
    assert.ok(session.duration > 0, '时长来自 duration 推送');
    assert.equal(session.paused, true, '加载后停在暂停态，等 play() 明确起播');
    assert.ok(session.videoTracks().length >= 1, 'track-list 推送里有视频轨');

    await session.play();
    await waitFor(() => session.paused === false && session.currentTime > 0.1, 15000, '起播与时间推进');
    assert.ok(session.currentTime > 0, '当前时间来自 time-pos 推送');

    const target = Math.min(1, session.duration / 2);
    session.currentTime = target;
    await waitFor(() => Math.abs(session.currentTime - target) < 0.75, 15000, '定位后位置推进到目标附近');

    session.playbackRate = 1.5;
    await waitFor(() => Math.abs(session.playbackRate - 1.5) < 0.001, 8000, '倍速推送');
    session.volume = 0.25;
    await waitFor(() => Math.abs(session.volume - 0.25) < 0.02, 8000, '音量推送');
    session.muted = true;
    await waitFor(() => session.muted === true, 8000, '静音推送');
    assert.ok(session.buffered().seconds >= 0, '缓冲事实来自 demuxer-cache-state');

    session.pause();
    await waitFor(() => session.paused === true, 8000, '暂停推送');

    // 播到结尾：结束事实由 eof-reached / end-file 推出。
    session.currentTime = Math.max(0, session.duration - 0.5);
    await session.play();
    await waitFor(() => session.ended === true && session.paused === true, 20000, '完播');

    // 完播后再次 play()：与媒体元素一致，从开头重放而不是无声空操作。
    await session.play();
    await waitFor(() => session.ended === false && session.paused === false && session.currentTime > 0.1, 20000,
      '完播后重放回到开头并继续推进');
    assert.ok(session.currentTime < session.duration, '重放位置在开头一侧');
  } finally {
    await session.close();
  }
  assert.equal(session.running, false, 'close() 结束会话进程');

  const log = readFileSync(file, 'utf8');
  assert.match(log, /VO: \[null\]/, 'mpv 日志显示本次使用的输出面');
  assert.match(log, /mpv v\d/, '日志可追溯到真实 mpv');
});

test('mpv 输出面与轨道：轨道列举与选择写入都来自真实 mpv', { skip: missingHls }, async () => {
  const session = new MpvSession({ executable: MPV_BIN, extraArgs: ['--vo=null', '--ao=null'] });
  try {
    session.applyDelivery({ src: HLS, type: 'application/vnd.apple.mpegurl', transport: 'hls' });
    await waitFor(() => session.audioTracks().length >= 2, 20000, 'HLS 多音轨列表');

    const languages = session.audioTracks().map(track => track.language).sort();
    assert.deepEqual(languages, ['en', 'zh'], '音轨语言来自真实样本');
    assert.ok(session.videoTracks().length >= 1);
    assert.equal(session.videoTracks().filter(track => track.selected).length, 1, 'mpv 报告当前生效的视频轨');

    const current = session.audioTracks().find(track => track.selected);
    const other = session.audioTracks().find(track => !track.selected);
    assert.ok(current && other, '样本应有两条音轨且其中一条生效');

    await session.selectAudioTrack(other.id);
    await waitFor(() => session.audioTracks().find(track => track.id === other.id)?.selected === true, 10000,
      '选择写入后由 track-list 推送确认');
    assert.equal(session.audioTracks().find(track => track.id === current.id)?.selected, false);

    // 关闭字幕：mpv 的 sid=no，回执成功即受理。
    await session.selectSubtitleTrack('off');
    assert.deepEqual(session.subtitleTracks(), [], '该样本没有字幕轨');
  } finally {
    await session.close();
  }
  assert.equal(session.running, false);
});

test('mpv 后端选择：经核心的既有通路驱动，Video.js 路径不受影响', { skip: missingMp4 }, async () => {
  const restore = selectMpvBackend(['--vo=null', '--ao=null']);
  const player = new StudioPlayer();
  const states = [];
  const positions = [];
  player.on('statechange', state => states.push(state));
  player.on('timeupdate', time => positions.push(time));
  try {
    const loaded = await player.load({ src: MP4, type: 'video/mp4', resourceId: 'mpv-core-sample' });
    assert.equal(loaded.source.src, MP4);
    await waitFor(() => player.state === 'ready' || player.state === 'playing', 20000, '元数据就绪');
    assert.ok(player.duration > 0, '核心读到的时长来自真实 mpv');

    await player.play();
    await waitFor(() => player.state === 'playing', 20000, '核心进入 playing');
    await waitFor(() => player.currentTime > 0.1, 20000, '核心读到时间推进');

    player.setPlaybackRate(0.5);
    await waitFor(() => Math.abs(player.playbackRate - 0.5) < 0.001, 10000, '倍速经会话生效');
    player.setVolume(0.4);
    await waitFor(() => Math.abs(player.volume - 0.4) < 0.02, 10000, '音量经会话生效');
    player.setMuted(false);
    await waitFor(() => player.muted === false, 10000, '静音经会话生效');

    player.pause();
    await waitFor(() => player.state === 'paused', 10000, '暂停经会话生效');

    player.seek(0.2);
    await player.play();
    await waitFor(() => player.state === 'playing', 10000, '定位后继续播放');

    // 完播：核心既有的 ended 规则在非 DOM 后端上照常成立。
    player.seek(player.duration - 0.4);
    await waitFor(() => player.state === 'ended', 25000, '自然完播进入 ended');
    assert.ok(states.includes('loading') && states.includes('ready'), '状态流经过 loading 与 ready');
    assert.ok(positions.length > 0, 'timeupdate 由真实推送驱动');

    await player.stop();
    assert.equal(player.state, 'stopped');
  } finally {
    player.destroy();
    restore();
  }
});

test('mpv 缺失时的公开行为：经既有 error 通道拒绝，不降级到 Video.js', async () => {
  // 未指定可执行文件：加载来源时同步拒绝（能力判定之前），沿用"来源拒绝 → 备用源 → error"。
  const restoreUnset = selectMpvBackend([], '');
  const first = new StudioPlayer();
  const firstErrors = [];
  first.on('error', (error, switched, code) => firstErrors.push({ switched, code, message: String(error?.message ?? error) }));
  try {
    await first.load({ src: '/media/episode.mp4', type: 'video/mp4' });
    await waitFor(() => first.state === 'error', 10000, '未指定可执行文件时进入失败终态');
    assert.equal(first.failed, true);
    assert.equal(first.canFallback, false, '没有备用源时不再尝试回退');
    assert.equal(firstErrors.at(-1)?.switched, false);
    assert.equal(firstErrors.at(-1)?.code, 'no-fallback');
    assert.match(firstErrors.at(-1)?.message ?? '', /STUDIO_PLAYER_MPV_BIN/);
    // 不静默降级到既有后端：媒体槽里没有承载元素，也没有 Video.js 通路。
    assert.equal(first.element, null);
  } finally {
    first.destroy();
    restoreUnset();
  }

  // 指定了不存在的可执行文件：启动失败同样经既有 error 通道上报，而不是抛到调用方之外。
  const bogus = path.join(tmpdir(), `no-such-mpv-${process.pid}.exe`);
  const restoreBogus = selectMpvBackend([], bogus);
  const second = new StudioPlayer();
  const secondErrors = [];
  second.on('error', (error, _switched, code) => secondErrors.push({ code, message: String(error?.message ?? error) }));
  try {
    await second.load({ src: '/media/episode.mp4', type: 'video/mp4' });
    await waitFor(() => second.state === 'error', 15000, '可执行文件不可用时进入失败终态');
    assert.equal(second.failed, true);
    assert.match(secondErrors[0]?.message ?? '', /mpv 进程启动失败/);
  } finally {
    second.destroy();
    restoreBogus();
  }
});

test('mpv：element 为 null，attach() 明确拒绝，队列按中立结束事实自动续播',
  { skip: missingMp4 }, async () => {
    const restore = selectMpvBackend(['--vo=null', '--ao=null']);
    const player = new StudioPlayer();
    const queue = new QueueController(player, { autoAdvance: true });
    try {
      queue.setItems([
        { id: 'first', source: { src: MP4, type: 'video/mp4', resourceId: 'mpv-limit-1' } },
        { id: 'second', source: { src: MP4, type: 'video/mp4', resourceId: 'mpv-limit-2' } },
      ]);
      await queue.select(0);
      await waitFor(() => player.state === 'playing', 20000, '队列第一项起播');

      // 独立进程后端没有承载元素：element 为 null，attach() 明确失败而不是静默忽略。
      assert.equal(player.element, null);
      assert.throws(() => player.attach({ localName: 'video' }), /没有可挂载的承载元素/);

      // 不带定位直接等自然完播：`--vo=null --ao=null` 下播放不按实时时钟推进，样本很快放完，
      // 避免"文件已经放完才定位"造成的无谓失败告警。
      await waitFor(() => player.state === 'ended', 25000, '第一项自然完播');

      await waitFor(() => queue.snapshot.current?.id === 'second', 10000, '队列按中立结束事实自动续播到第二项');
      assert.equal(queue.snapshot.current?.id, 'second');
    } finally {
      queue.destroy();
      player.destroy();
      restore();
    }
  });
