import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { StudioPlayer, createPlayerPreset as rootPreset } from '@studio/player';
import { StudioPlayer as CorePlayer } from '@studio/player/core';
import { createPlayerPreset, mountPlayerFeatures } from '@studio/player/presets';
import { Media, Clock, Session, plan, items, settle, deferred, metadataFactory, setup } from './helpers.mjs';

function preset(t, name, options = {}) {
  const result = createPlayerPreset(name, options);
  const media = new Media();
  result.player.attach(media);
  t.after(() => result.destroy());
  return { ...result, media };
}

function countSubscriptions(player) {
  const active = new Set();
  const on = player.on.bind(player);
  player.on = (event, listener) => {
    const unsubscribe = on(event, listener);
    active.add(unsubscribe);
    return () => { active.delete(unsubscribe); unsubscribe(); };
  };
  return active;
}

test('Preview: no optional controllers or implicit browser APIs, and basic playback works', async t => {
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  Object.defineProperty(globalThis, 'navigator', { configurable: true, get() { throw new Error('unexpected system API access'); } });
  try {
    const { player, features, media } = preset(t, 'preview');
    assert.equal(features.queue, null);
    assert.equal(features.sleepTimer, null);
    assert.equal(features.mediaSession, null);
    assert.equal(player.progressController, null);
    await player.load(plan('preview'));
    await player.play();
    assert.equal(media.paused, false);
  } finally {
    if (descriptor) Object.defineProperty(globalThis, 'navigator', descriptor);
    else delete globalThis.navigator;
  }
});

test('Audio: defaults to sequential queue; creating a preset does not take system ownership', async t => {
  const port = new Session();
  const { player, features, media } = preset(t, 'audio', { features: { mediaSession: { session: port, createMetadata: metadataFactory } } });
  assert.ok(features.sleepTimer);
  assert.equal(features.mediaSession.active, false);
  assert.equal(port.handlers.size, 0);
  features.queue.setItems(items.slice(0, 2));
  await features.queue.select(0);
  features.mediaSession.activate();
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'b');
  assert.equal(media.playCalls, 2);
  assert.equal(port.metadata.title, 'Title b');
});

test('Video: enabling a queue keeps ended stopped, including explicitly undefined defaults', async t => {
  const { player, features, media } = preset(t, 'video', { features: { queue: { autoAdvance: undefined } } });
  features.queue.setItems(items);
  await features.queue.select(0);
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
  assert.equal(media.playCalls, 1);
  await features.queue.next();
  assert.equal(player.currentResourceId, 'b');
  features.setEnabled('queue', false);
  features.setEnabled('queue', true);
  features.queue.setItems(items);
  await features.queue.select(0);
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
});

test('Preset overrides: explicit false wins and video can explicitly opt into auto advance', async t => {
  const audio = preset(t, 'audio', { features: { queue: false, mediaSession: false, sleepTimer: false } });
  assert.equal(audio.features.queue, null);
  assert.equal(audio.features.mediaSession, null);
  assert.equal(audio.features.sleepTimer, null);
  const video = preset(t, 'video', { features: { queue: { autoAdvance: true } } });
  video.features.queue.setItems(items);
  await video.features.queue.select(0);
  video.media.finish();
  await settle();
  assert.equal(video.player.currentResourceId, 'b');
});

test('Native element default follows the scene and an explicit host choice wins', t => {
  const audio = new Media(); audio.localName = 'audio';
  const video = new Media();
  const host = { querySelector: selector => selector === 'audio' ? audio : selector === 'video' ? video : null };
  const one = createPlayerPreset('audio', { features: { mediaSession: false } });
  const two = createPlayerPreset('audio', { nativeElementTag: 'video', features: { mediaSession: false } });
  t.after(() => { one.destroy(); two.destroy(); });
  one.player.attach(host);
  two.player.attach(host);
  assert.equal(one.player.element, audio);
  assert.equal(two.player.element, video);
});

test('Progress: explicit disable does not call a provided store; enable requires and uses its port', async t => {
  let reads = 0;
  const storage = { load() { reads++; return 25; }, save() {}, clear() {} };
  const off = preset(t, 'audio', { progress: false, progressStorage: storage, features: { mediaSession: false } });
  await off.player.load(plan('off'));
  await off.player.play();
  off.media.currentTime = 30;
  off.media.trigger('timeupdate');
  off.destroy();
  assert.equal(reads, 0);
  assert.equal(off.player.progressController, null);
  const on = preset(t, 'video', { progress: true, progressStorage: storage });
  await on.player.load(plan('on'));
  await settle();
  assert.equal(reads, 1);
  assert.equal(on.player.currentTime, 25);
  assert.throws(() => createPlayerPreset('video', { progress: true }), /progressStorage/);
  assert.throws(() => createPlayerPreset('video', { progressPolicy: {} }), /requires progressStorage/);
});

test('Feature toggles preserve unrelated queue state and timer deadlines; repeat enable is a no-op', async t => {
  const clock = new Clock();
  const { player, features } = preset(t, 'audio', { features: { sleepTimer: { clock }, mediaSession: false } });
  features.queue.setItems(items);
  await features.queue.select(1);
  const queue = features.queue;
  const timer = features.sleepTimer;
  timer.start(5000);
  features.setEnabled('queue', true);
  features.setEnabled('mediaSession', true);
  features.setEnabled('mediaSession', false);
  assert.equal(features.queue, queue);
  assert.equal(queue.snapshot.index, 1);
  assert.equal(features.sleepTimer, timer);
  assert.equal(timer.snapshot.deadline, 5000);
  features.setEnabled('sleepTimer', false);
  clock.jump(6000);
  assert.equal(player.paused, false);
  assert.equal(clock.tasks.size, 0);
  features.setEnabled('sleepTimer', true);
  assert.equal(features.sleepTimer.snapshot.status, 'idle');
});

test('Queue toggles reconnect system navigation without replacing its owner or metadata', async t => {
  const port = new Session();
  const { player, features, media } = preset(t, 'audio', { features: { mediaSession: { session: port, createMetadata: metadataFactory } } });
  features.queue.setItems(items);
  await features.queue.select(0);
  const system = features.mediaSession;
  system.activate();
  const staleNext = port.handlers.get('nexttrack');
  features.setEnabled('queue', false);
  assert.equal(features.mediaSession, system);
  assert.equal(system.active, true);
  assert.equal(port.metadata.title, 'Title a');
  assert.equal(port.handlers.has('nexttrack'), false);
  features.setEnabled('queue', true);
  features.queue.setItems(items);
  await features.queue.select(0);
  const before = media.playCalls;
  staleNext({ action: 'nexttrack' });
  await settle();
  assert.equal(media.playCalls, before);
  port.invoke('nexttrack');
  await settle();
  assert.equal(player.currentResourceId, 'b');
});

test('Root/subpath share implementations; toggling an inactive group cannot steal another system owner', async t => {
  assert.equal(StudioPlayer, CorePlayer);
  assert.equal(rootPreset, createPlayerPreset);
  const port = new Session();
  const options = { features: { mediaSession: { session: port, createMetadata: metadataFactory } } };
  const first = preset(t, 'audio', options);
  const second = preset(t, 'audio', options);
  await first.player.load(plan('first'));
  await second.player.load(plan('second'));
  first.features.mediaSession.activate();
  second.features.mediaSession.activate();
  first.features.setEnabled('queue', false);
  first.features.setEnabled('queue', true);
  assert.equal(first.features.mediaSession.active, false);
  assert.equal(second.features.mediaSession.active, true);
  assert.equal(port.metadata.title, 'Title second');
  first.destroy();
  port.invoke('play');
  await settle();
  assert.equal(second.player.paused, false);
});

test('Destroying features cancels pending queue autoplay while leaving the borrowed player alive', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const features = mountPlayerFeatures(player, { queue: true });
  features.queue.setItems(items);
  player.progressController.recordProgress('old', 25, 100, false);
  const selection = features.queue.select(0);
  features.destroy();
  features.destroy();
  gate.resolve();
  assert.equal(await selection, false);
  assert.equal(media.playCalls, 0);
  assert.equal(player.isDestroyed, false);
  await player.load(plan('manual'));
  await player.play();
  assert.equal(player.paused, false);
  assert.throws(() => features.setEnabled('queue', true), /destroyed/);
});

for (const disposal of ['queue', 'disable', 'features']) {
  for (const operation of ['select', 'resume']) {
    test(`Queue ${disposal} cancels a native ${operation} request still waiting for data`, async t => {
      const { player, media } = setup(t);
      const features = mountPlayerFeatures(player, { queue: true });
      const queue = features.queue; queue.setItems(items);
      if (operation === 'resume') await queue.select(0, { autoplay: false });
      const gate = deferred();
      media.play = () => {
        media.playCalls++; media.paused = false; media.trigger('play');
        return gate.promise.then(() => { media.paused = false; media.trigger('playing'); });
      };
      const selection = operation === 'resume' ? queue.play() : queue.select(0);
      await settle(); assert.equal(media.playCalls, 1);
      if (disposal === 'queue') queue.destroy();
      else if (disposal === 'disable') features.setEnabled('queue', false);
      else features.destroy();
      const pausedAtDisposal = media.paused;
      gate.resolve(); assert.equal(await selection, false); await settle();
      assert.equal(pausedAtDisposal, true); assert.equal(player.paused, true);
      assert.equal(player.playbackRequested, false); assert.equal(player.isDestroyed, false);
      assert.equal(player.currentResourceId, 'a');
      media.play = Media.prototype.play;
      await player.play(); assert.equal(player.paused, false);
    });
  }
}

test('Queue removal preserves playback that has already succeeded or emitted playing', async t => {
  for (const pendingPromise of [false, true]) {
    const { player, media } = setup(t);
    const features = mountPlayerFeatures(player, { queue: true }); features.queue.setItems(items);
    const gate = deferred();
    if (pendingPromise) media.play = () => { Media.prototype.play.call(media); return gate.promise; };
    const selection = features.queue.select(0); await settle();
    assert.equal(player.paused, false);
    features.destroy(); assert.equal(player.paused, false);
    gate.resolve(); await selection;
    assert.equal(player.paused, false); assert.equal(player.isDestroyed, false);
  }
});

test('Queue removal cannot cancel a newer playback requested directly on the borrowed player', async t => {
  const { player, media } = setup(t);
  const features = mountPlayerFeatures(player, { queue: true }); features.queue.setItems(items);
  const oldGate = deferred(); const newGate = deferred();
  media.play = () => oldGate.promise.then(() => Media.prototype.play.call(media));
  const selection = features.queue.select(0); await settle();
  media.play = () => newGate.promise.then(() => Media.prototype.play.call(media));
  const direct = player.play();
  features.destroy();
  oldGate.resolve(); assert.equal(await selection, false);
  newGate.resolve(); await direct;
  assert.equal(player.paused, false); assert.equal(player.playbackRequested, true);
});

test('Queue disposal from native playback intent cancels before the media starts', async t => {
  const { player, media } = setup(t);
  const features = mountPlayerFeatures(player, { queue: true }); features.queue.setItems(items);
  let intents = 0;
  player.on('playintent', () => { if (++intents === 2) features.destroy(); });
  assert.equal(await features.queue.select(0), false);
  assert.equal(media.playCalls, 0); assert.equal(player.playbackRequested, false);
});

test('Invalid options fail before adding listeners or accessing host resources', t => {
  const { player } = setup(t);
  const subscriptions = countSubscriptions(player);
  for (const features of [
    { queue: { autoAdvance: 'yes' } }, { queue: null }, { sleepTimer: { clock: {} } },
    { queue: true, sleepTimer: { visibilityTarget: {} } },
    { mediaSession: { session: {} } }, { mediaSession: { queue: {} } }, { random: true },
  ]) {
    assert.throws(() => mountPlayerFeatures(player, features), TypeError);
    assert.equal(subscriptions.size, 0);
  }
  assert.throws(() => createPlayerPreset('unknown'), /Unknown player preset/);
  assert.throws(() => createPlayerPreset('preview', { progressStorage: {} }), /progressStorage.load/);
  const features = mountPlayerFeatures(player);
  t.after(() => features.destroy());
  assert.throws(() => features.setEnabled('random', true), /Unknown player feature/);
  assert.throws(() => features.setEnabled('queue', 'yes'), /boolean/);
  assert.equal(features.queue, null);
});

test('A host registration failure rolls back mounted features and all lifecycle subscriptions', async t => {
  const { player } = setup(t);
  await player.load(plan('continuous'));
  await player.play();
  const subscriptions = countSubscriptions(player);
  const visibility = new Media();
  const page = new Media();
  const add = page.addEventListener.bind(page);
  page.addEventListener = (...args) => {
    add(...args);
    throw new Error('host registration failed');
  };
  assert.throws(() => mountPlayerFeatures(player, {
    queue: true, sleepTimer: { visibilityTarget: visibility, pageTarget: page },
  }), /host registration failed/);
  assert.equal(visibility.listenerCount, 0);
  assert.equal(page.listenerCount, 0);
  assert.equal(subscriptions.size, 0);
  assert.equal(player.isDestroyed, false);
  assert.equal(player.paused, false);
});

test('Borrowed feature groups survive twenty mount/remove cycles without interrupting playback', async t => {
  const { player, media } = setup(t);
  await player.load(plan('continuous'));
  await player.play();
  const subscriptions = countSubscriptions(player);
  const clock = new Clock();
  const port = new Session();
  for (let cycle = 0; cycle < 20; cycle++) {
    const features = mountPlayerFeatures(player, {
      queue: true, sleepTimer: { clock }, mediaSession: { session: port, createMetadata: metadataFactory },
    });
    features.sleepTimer.start(1000);
    features.mediaSession.activate();
    features.destroy();
    clock.jump(2000);
    assert.equal(subscriptions.size, 0);
    assert.equal(clock.tasks.size, 0);
    assert.equal(port.handlers.size, 0);
    assert.equal(player.paused, false);
  }
  const owned = preset(t, 'audio', { features: { sleepTimer: { clock }, mediaSession: { session: port } } });
  await owned.player.load(plan('owned'));
  await owned.player.play();
  owned.features.sleepTimer.start(1000);
  owned.player.destroy();
  owned.destroy();
  assert.equal(owned.features.isDestroyed, true);
  assert.equal(owned.features.queue, null);
  assert.equal(owned.media.listenerCount, 0);
  assert.equal(owned.media.paused, true);
  assert.equal(clock.tasks.size, 0);
  assert.equal(media.paused, false);
});

test('Packaging: core-only consumers do not import optional controllers or UI', async () => {
  const result = await build({
    stdin: { contents: "export { StudioPlayer } from '@studio/player/core';", resolveDir: process.cwd(), sourcefile: 'core-consumer.js' },
    bundle: true, write: false, metafile: true, platform: 'browser', format: 'esm', minify: true,
  });
  const inputs = Object.keys(result.metafile.inputs);
  assert.ok(inputs.some(path => path.endsWith('/player.js')));
  assert.equal(inputs.some(path => /\/(queue|sleep-timer|media-session|main-media|video-tracks|presets|ui)\//.test(path.replaceAll('\\', '/'))), false);
});
