import test from 'node:test';
import assert from 'node:assert/strict';
import {setup,plan,deferred,settle} from './helpers.mjs';

for (const pause of ['player', 'media']) test(`recovery after ${pause} pause uses the actual playback position`, async t => {
  const contexts = [];
  const { player, media } = setup(t, {
    sourceResolver: { recoverSource: (_id, _plan, context) => {
      contexts.push(context);
      return plan('a', { playUrl: 'recovered.mp4' });
    } },
  });
  await player.load(plan('a'));
  await player.play();
  // Natural progress must not depend on seek() cancelling the initial resume state.
  media.currentTime = 40;
  media.trigger('timeupdate');
  if (pause === 'player') player.pause();
  else media.pause();
  media.trigger('error');
  await settle();
  await settle();
  assert.equal(contexts.length, 1);
  assert.equal(contexts[0].positionSeconds, 40);
  assert.equal(contexts[0].paused, true);
  assert.equal(player.currentTime, 40);
  assert.equal(player.paused, true);
  assert.equal(media.playCalls, 1);
});

for (const change of ['refresh', 'fallback', 'recovery']) test(`${change} preserves a checkpoint waiting for seekable`, async t => {
  let reads = 0;
  const { player, media } = setup(t, {
    progressStorage: { load: () => { reads++; return 20; }, save() {}, clear() {} },
    sourceResolver: {
      resolveUrl: (_id, current) => ({ ...current, playUrl: 'refreshed.mp4' }),
      recoverSource: () => plan('a', { playUrl: 'recovered.mp4' }),
    },
  });
  media.seekable = { length: 0, start: () => 0, end: () => 100 };
  await player.load(plan('a', { fallbackUrl: 'fallback.mp4' }));
  await settle();
  assert.equal(reads, 1);
  assert.equal(player.currentTime, 0);
  if (change === 'refresh') await player.sourceController.refreshSource('expired');
  else if (change === 'fallback') assert.equal(player.switchToFallback(), true);
  else media.trigger('error');
  await settle();
  assert.equal(player.currentTime, 0);
  media.seekable = { length: 1, start: () => 0, end: () => 100 };
  media.trigger('canplay');
  await settle();
  assert.equal(player.currentTime, 20);
  assert.equal(reads, 1);
  assert.equal(player.paused, true);
});

for(const action of ['resume','restart','seek-zero','pause'])test(`initial media recovery preserves checkpoint intent: ${action}`,async t=>{
  let loads=0;
  let saved={positionSeconds:20,durationSeconds:100,updatedAt:Date.now()};
  const writes=[];
  const replacement=deferred();
  const {player,media}=setup(t,{
    progressStorage:{load:()=>{loads++;return saved;},save:(_id,position,duration,record)=>{saved=record??{positionSeconds:position,durationSeconds:duration,updatedAt:Date.now()};writes.push(position);},clear(){}},
    sourceResolver:{recoverSource:()=>replacement.promise},
  });
  media.load=()=>{media.currentTime=0;media.paused=true;media.duration=media.src.includes('recovered')?100:NaN;if(media.src.includes('recovered'))queueMicrotask(()=>media.trigger('loadedmetadata'));};
  media.pause=()=>{media.paused=true;setImmediate(()=>media.trigger('pause'));};
  await player.load(plan('a'),{restart:action==='restart'});
  player.requestPlayback();
  // 原生 play 请求先于 metadata/真正 playing；尚无可用媒体位置。
  media.paused=false;media.trigger('play');media.trigger('timeupdate');media.trigger('error');await settle();
  assert.equal(saved.positionSeconds,20);
  assert.deepEqual(writes,[]);
  if(action==='seek-zero')player.seek(0);
  if(action==='pause')player.pause();
  replacement.resolve(plan('a',{playUrl:'recovered.mp4'}));await settle();await settle();await settle();
  assert.equal(player.currentTime,['restart','seek-zero'].includes(action)?0:20);
  assert.equal(loads,['restart','seek-zero'].includes(action)?0:1);
  assert.equal(player.paused,action==='pause');
});
