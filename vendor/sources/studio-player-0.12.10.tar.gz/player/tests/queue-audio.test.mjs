import test from 'node:test';
import assert from 'node:assert/strict';
import { QueueController } from '@studio/player/queue';
import { SleepTimerController } from '@studio/player/sleep-timer';
import { createPlayerPreset } from '@studio/player/presets';
import { Media, Clock, Session, plan, items, settle, deferred, metadataFactory, setup } from './helpers.mjs';

function queueFor(t, options, playerOptions) {
  const base = setup(t, playerOptions);
  const queue = new QueueController(base.player, options);
  queue.setItems(items);
  return { ...base, queue };
}

test('Shuffle visits the cycle without replacement; previous/next traverse actual history', async t => {
  const { queue, player } = queueFor(t, { order: 'shuffle', random: () => 0 });
  await queue.selectId('a');
  await queue.next();
  await queue.next();
  const heard = queue.snapshot.history;
  assert.deepEqual(heard, ['a', 'b', 'c']);
  assert.equal(await queue.next(), false);
  await queue.previous();
  assert.equal(player.currentResourceId, heard[1]);
  await queue.previous();
  assert.equal(player.currentResourceId, heard[0]);
  assert.equal(await queue.previous(), false);
  await queue.next();
  assert.equal(player.currentResourceId, heard[1]);
  assert.deepEqual(queue.snapshot.history, heard);
});

test('History excludes loading, paused selections and rejected playback; retry commits once', async t => {
  const { queue, player, media } = queueFor(t, { order: 'shuffle' });
  await queue.selectId('a', { autoplay: false });
  assert.deepEqual(queue.snapshot.history, []);
  await player.play();
  const play = media.play.bind(media);
  media.play = () => Promise.reject(new Error('blocked'));
  await assert.rejects(queue.selectId('b'), /blocked/);
  assert.deepEqual(queue.snapshot.history, ['a']);
  media.play = play;
  await queue.previous();
  assert.equal(player.currentResourceId, 'a');
  await queue.selectId('b');
  player.pause();
  await queue.play();
  assert.deepEqual(queue.snapshot.history, ['a', 'b']);
});

test('Explicit selection branches history only after real playback; back/forward ignore list order', async t => {
  const { queue, player } = queueFor(t);
  for (const id of ['a', 'c', 'b']) await queue.selectId(id);
  await queue.back();
  assert.equal(player.currentResourceId, 'c');
  queue.move('c', 0);
  await queue.back();
  assert.equal(player.currentResourceId, 'a');
  await queue.forward();
  assert.equal(player.currentResourceId, 'c');
  await queue.selectId('a');
  assert.deepEqual(queue.snapshot.history, ['a', 'c', 'a']);
  assert.equal(queue.snapshot.canForward, false);
});

test('Native play intent while waiting for data is not history; rejected readiness never commits', async t => {
  const { queue, media } = queueFor(t, { order: 'shuffle' });
  const originalPlay = media.play.bind(media);
  const waiting = deferred();
  media.play = () => { media.paused = false; media.trigger('play'); return waiting.promise; };
  const selection = queue.selectId('a');
  await settle();
  assert.equal(queue.snapshot.loading, true);
  assert.deepEqual(queue.snapshot.history, []);
  waiting.reject(new Error('network failed before playing'));
  await assert.rejects(selection, /network failed/);
  assert.deepEqual(queue.snapshot.history, []);
  media.play = originalPlay;
  await queue.retry();
  assert.deepEqual(queue.snapshot.history, ['a']);
  await queue.selectId('b', { autoplay: false });
  // 原生/上游控件可绕过 queue.play；仍以媒体 playing 事实提交历史。
  media.paused = false; media.trigger('play');
  assert.deepEqual(queue.snapshot.history, ['a']);
  media.trigger('playing');
  assert.deepEqual(queue.snapshot.history, ['a', 'b']);
});

test('Distinct queue entries can share one resource and survive reorder without reload', async t => {
  const { queue, player, media } = queueFor(t);
  queue.setItems([{ id: 'first', source: plan('same') }, { id: 'second', source: plan('same') }]);
  await queue.selectId('first');
  await queue.selectId('second');
  media.currentTime = 42;
  const plays = media.playCalls;
  queue.move('second', 0);
  assert.equal(queue.snapshot.current.id, 'second');
  assert.equal(queue.snapshot.index, 0);
  assert.equal(player.currentTime, 42);
  assert.equal(media.playCalls, plays);
  assert.deepEqual(queue.snapshot.history, ['first', 'second']);
  await queue.previous();
  assert.equal(queue.snapshot.current.id, 'first');
  assert.equal(player.currentResourceId, 'same');
});

test('List edits validate before mutation, and snapshots isolate source identity and metadata', async t => {
  const { queue, player } = queueFor(t);
  const source = plan('new', { metadata: { title: 'Before' } });
  queue.add([{ id: 'new', source }], 1);
  source.resourceId = 'tampered';
  source.metadata.title = 'After';
  assert.throws(() => queue.add([{ id: 'x', source: 'x.mp3' }, items[0]]), /unique/);
  assert.throws(() => queue.move('a', 99), RangeError);
  assert.equal(queue.snapshot.items.length, 4);
  await queue.selectId('new');
  assert.equal(player.currentResourceId, 'new');
  assert.equal(player.currentMetadata.title, 'Before');
  assert.throws(() => { queue.snapshot.current.source.resourceId = 'mutated'; }, TypeError);
});

test('Insert-next overrides shuffle, keeps input ordering and can prioritize an existing entry', async t => {
  const { queue, player } = queueFor(t, { order: 'shuffle', random: () => 0.8 });
  await queue.selectId('a');
  queue.insertNext([{ id: 'd', source: plan('d') }, { id: 'e', source: plan('e') }]);
  assert.deepEqual(queue.snapshot.upNext, ['d', 'e']);
  await queue.next();
  assert.equal(player.currentResourceId, 'd');
  await queue.next();
  assert.equal(player.currentResourceId, 'e');
  queue.enqueueNext('a');
  await queue.next();
  assert.equal(player.currentResourceId, 'a');
  assert.deepEqual(queue.snapshot.upNext, []);
});

test('Removing non-current items prunes history without resetting playback or its cursor', async t => {
  const { queue, media } = queueFor(t, { order: 'shuffle' });
  for (const id of ['a', 'b', 'c']) await queue.selectId(id);
  media.currentTime = 31;
  await queue.remove('b');
  assert.deepEqual(queue.snapshot.history, ['a', 'c']);
  assert.equal(queue.snapshot.historyIndex, 1);
  assert.equal(media.currentTime, 31);
  await queue.previous();
  assert.equal(queue.snapshot.current.id, 'a');
});

test('Removing current preserves playing/paused intent, while deleting the last item releases the source', async t => {
  const { queue, player, media } = queueFor(t);
  await queue.selectId('b');
  await queue.remove('b');
  assert.equal(queue.snapshot.current.id, 'c');
  assert.equal(player.paused, false);
  player.pause();
  await queue.remove('c');
  assert.equal(queue.snapshot.current.id, 'a');
  assert.equal(player.paused, true);
  await queue.remove('a');
  assert.equal(queue.snapshot.current, null);
  assert.equal(player.state, 'stopped');
  assert.equal(media.src, '');
});

test('Deleting current after stop never loads or plays its successor; play explicitly reopens it', async t => {
  const { queue, player, media } = queueFor(t);
  await queue.selectId('b');
  await player.stop();
  await queue.remove('b');
  assert.equal(queue.snapshot.current.id, 'c');
  assert.equal(player.state, 'stopped');
  assert.equal(media.src, '');
  assert.equal(media.playCalls, 1);
  await queue.play();
  assert.equal(player.currentResourceId, 'c');
  assert.equal(media.playCalls, 2);
});

test('Rapid selection and edits retain entry identity while delayed storage flushes', async t => {
  const gate = deferred();
  const { queue, player, media } = queueFor(t, {}, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  player.progressController.recordProgress('old', 15, 100, false);
  const first = queue.selectId('a');
  queue.move('a', 2);
  const second = queue.selectId('b');
  const remove = queue.remove('b');
  gate.resolve();
  assert.equal(await first, false);
  assert.equal(await second, false);
  assert.equal(await remove, true);
  assert.equal(queue.snapshot.current.id, 'c');
  assert.equal(player.currentResourceId, 'c');
  assert.equal(media.playCalls, 1);
  assert.deepEqual(queue.snapshot.history, ['c']);
});

test('Rapid historical previous operations use the requested cursor, not stale resolved playback', async t => {
  const gate = deferred();
  let slow = false;
  const { queue, player } = queueFor(t, { order: 'shuffle' }, { progressStorage: { load: () => null, save: () => slow ? gate.promise : undefined, clear() {} } });
  for (const id of ['a', 'b', 'c']) await queue.selectId(id);
  slow = true;
  player.progressController.recordProgress('c', 20, 100, false);
  const first = queue.previous();
  const second = queue.previous();
  gate.resolve();
  assert.equal(await first, false);
  assert.equal(await second, true);
  assert.equal(player.currentResourceId, 'a');
  assert.deepEqual(queue.snapshot.history, ['a', 'b', 'c']);
  assert.equal(queue.snapshot.historyIndex, 0);
});

test('Selecting a new item silences the previous source immediately while its progress is saved', async t => {
  const gate = deferred();
  let slow = false;
  const { queue, player, media } = queueFor(t, {}, { progressStorage: { load: () => null, save: () => slow ? gate.promise : undefined, clear() {} } });
  await queue.selectId('a');
  slow = true;
  player.progressController.recordProgress('a', 23, 100, false);
  const pending = queue.selectId('b');
  assert.equal(media.paused, true);
  assert.equal(player.state, 'loading');
  assert.equal(queue.snapshot.loaded, false);
  gate.resolve();
  await pending;
  assert.equal(player.currentResourceId, 'b');
  assert.equal(media.paused, false);
});

test('Clear cancels pending selection and late playback without accepting a removed resource', async t => {
  const gate = deferred();
  const { queue, player, media } = queueFor(t, {}, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  player.progressController.recordProgress('old', 15, 100, false);
  const pending = queue.selectId('b');
  const clearing = queue.clear();
  gate.resolve();
  await clearing;
  assert.equal(await pending, false);
  assert.equal(media.playCalls, 0);
  assert.equal(media.src, '');
  assert.equal(player.currentResourceId, null);
  assert.deepEqual(queue.snapshot.history, []);
});

test('A nested external load of the same resource invalidates queue ownership', async t => {
  const { queue, player, media } = queueFor(t);
  let external;
  let once = true;
  player.on('loadstart', () => {
    if (once) { once = false; external = player.load(plan('a', { playUrl: 'external.mp4' })); }
  });
  assert.equal(await queue.selectId('a'), false);
  await external;
  assert.equal(queue.snapshot.current, null);
  assert.deepEqual(queue.snapshot.history, []);
  assert.equal(media.src, 'external.mp4');
  assert.equal(media.playCalls, 0);
});

test('A load failure stays on that item, never loops across failures, and permits explicit retry', async t => {
  const { queue, player, media } = queueFor(t, { repeat: 'all' });
  queue.add([{ id: 'bad', source: plan('bad', { mimeType: 'application/broken' }) }]);
  await queue.selectId('c');
  media.finish();
  await settle();
  assert.equal(queue.snapshot.current.id, 'bad');
  assert.ok(queue.snapshot.error);
  assert.deepEqual(queue.snapshot.history, ['c']);
  assert.equal(media.playCalls, 1);
  media.canPlayType = () => 'probably';
  await queue.retry();
  assert.equal(player.currentResourceId, 'bad');
  assert.equal(queue.snapshot.error, null);
});

test('Single repeat restarts at zero, coalesces history and still permits manual next', async t => {
  const { queue, player, media } = queueFor(t, { repeat: 'one' });
  queue.setItems([{ id: 'a', source: plan('a', { resumePositionSeconds: 45 }) }, items[1]]);
  await queue.selectId('a');
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
  assert.equal(media.currentTime, 0);
  assert.equal(media.playCalls, 2);
  assert.deepEqual(queue.snapshot.history, ['a']);
  await queue.next();
  assert.equal(player.currentResourceId, 'b');
});

test('List repeat wraps, shuffle repeat avoids immediate duplicates and one-item loops remain valid', async t => {
  const { queue, player, media } = queueFor(t, { repeat: 'all' });
  await queue.selectId('c');
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
  queue.setOrder('shuffle');
  for (let index = 0; index < 9; index++) {
    const previous = queue.snapshot.current.id;
    await queue.next();
    assert.notEqual(queue.snapshot.current.id, previous);
  }
  queue.setItems([items[0]]);
  await queue.play();
  await queue.next();
  assert.equal(queue.snapshot.current.id, 'a');
  assert.deepEqual(queue.snapshot.history, ['a']);
});

test('Sleep beats single/list/shuffle repeat in either mounting order; manual navigation does not count', async t => {
  for (const order of ['sequential', 'shuffle']) for (const repeat of ['one', 'all']) for (const timerFirst of [true, false]) {
    const { player, media } = setup(t);
    const first = timerFirst ? new SleepTimerController(player) : null;
    const queue = new QueueController(player, { order, repeat });
    const timer = first ?? new SleepTimerController(player);
    queue.setItems(items);
    await queue.selectId('a');
    timer.start({ trigger: { type: 'items', count: 2 }, action: 'stop' });
    await queue.selectId('b');
    assert.equal(timer.snapshot.remainingItems, 2);
    media.finish();
    await settle();
    assert.equal(timer.snapshot.remainingItems, 1);
    const calls = media.playCalls;
    media.finish();
    await settle();
    assert.equal(player.state, 'stopped');
    assert.equal(media.playCalls, calls);
    assert.equal(timer.snapshot.status, 'expired');
    assert.equal(queue.snapshot.items.length, 3);
  }
});

test('Audio preset supplies sleep, passes queue modes through toggling, and remains headless', async t => {
  const clock = new Clock();
  const port = new Session();
  const preset = createPlayerPreset('audio', { features: {
    queue: { order: 'shuffle', repeat: 'all', random: () => 0 },
    sleepTimer: { clock }, mediaSession: { session: port, createMetadata: metadataFactory },
  } });
  t.after(() => preset.destroy());
  assert.ok(preset.features.sleepTimer);
  assert.equal(preset.player.element, null);
  assert.equal(port.handlers.size, 0);
  assert.equal(clock.tasks.size, 0);
  const media = new Media(); preset.player.attach(media);
  const { queue, sleepTimer, mediaSession } = preset.features;
  queue.setItems([{ ...items[0], source: plan('a', { metadata: {} }), title: 'Queue title', artist: 'Artist', album: 'Album', artwork: [{ src: 'cover.svg' }] }, ...items.slice(1)]);
  mediaSession.activate();
  await queue.play();
  assert.equal(port.metadata.title, 'Queue title');
  assert.equal(port.metadata.artist, 'Artist');
  sleepTimer.start(23000);
  preset.features.setEnabled('queue', false);
  preset.features.setEnabled('queue', true);
  assert.equal(preset.features.queue.snapshot.order, 'shuffle');
  assert.equal(preset.features.queue.snapshot.repeat, 'all');
  assert.equal(preset.features.sleepTimer, sleepTimer);
  assert.equal(sleepTimer.snapshot.remainingMs, 23000);
  assert.equal(mediaSession.active, true);
});

test('Closing audio during delayed single-repeat playback cancels late work and clears system ownership', async t => {
  const gate = deferred();
  const clock = new Clock();
  const port = new Session();
  const preset = createPlayerPreset('audio', { features: { queue: { repeat: 'one' }, sleepTimer: { clock }, mediaSession: { session: port, createMetadata: metadataFactory } } });
  t.after(() => preset.destroy());
  const media = new Media(); preset.player.attach(media);
  const { queue, sleepTimer, mediaSession } = preset.features;
  queue.setItems(items);
  await queue.play();
  mediaSession.activate();
  const play = media.play.bind(media);
  media.play = () => gate.promise.then(play);
  sleepTimer.start({ trigger: { type: 'duration', durationMs: 1000 }, action: 'close' });
  let closes = 0;
  preset.player.on('closerequest', () => closes++);
  media.finish();
  await settle();
  clock.jump(1000);
  gate.resolve();
  await settle();
  assert.equal(preset.player.state, 'stopped');
  assert.equal(media.paused, true);
  assert.equal(port.handlers.size, 0);
  assert.equal(closes, 1);
  assert.equal(queue.snapshot.items.length, 3);
});

test('Pause then play while a queue load is delayed follows the latest explicit playback intent', async t => {
  const gate = deferred();
  const { queue, player, media } = queueFor(t, {}, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  player.progressController.recordProgress('old', 20, 100, false);
  const original = queue.selectId('b');
  player.pause();
  assert.equal(queue.snapshot.autoplayPending, false);
  const replay = queue.play();
  gate.resolve();
  assert.equal(await original, false);
  assert.equal(await replay, true);
  assert.equal(media.playCalls, 1);
  assert.deepEqual(queue.snapshot.history, ['b']);
});

test('A whole-list replacement cannot overwrite a newer selection or edit during checkpoint storage', async t => {
  for (const operation of ['select', 'edit']) {
    const gate = deferred(); let delayed = false;
    const { queue, player, media } = queueFor(t, {}, { progressStorage: { load: () => null, save: () => delayed ? gate.promise : undefined, clear() {} } });
    await queue.selectId('a'); media.currentTime = 25; delayed = true;
    const replace = queue.replaceItems([{ id: 'replacement', source: plan('replacement') }]);
    const next = operation === 'select' ? queue.selectId('c') : queue.add([{ id: 'added', source: plan('added') }]);
    gate.resolve();
    assert.equal(await replace, false);
    await next;
    assert.equal(queue.snapshot.items.some(item => item.id === 'replacement'), false);
    if (operation === 'select') assert.equal(player.currentResourceId, 'c');
    else assert.equal(queue.snapshot.items.at(-1).id, 'added');
  }
});

test('A selection from a queue-cleared callback wins over the earlier clear', async t => {
  const { queue, player, media } = queueFor(t);
  await queue.selectId('a');
  let next; let armed = true;
  queue.addEventListener('change', () => {
    if (armed && !queue.snapshot.items.length) {
      armed = false;
      queue.add([{ id: 'new', source: plan('new') }]);
      next = queue.selectId('new');
    }
  });
  await queue.clear(); await next;
  assert.equal(player.currentResourceId, 'new');
  assert.equal(media.paused, false);
  assert.deepEqual(queue.snapshot.history, ['new']);
});

test('Public audio UI entry imports without DOM and shares core/controller modules', async () => {
  const ui = await import('@studio/player/ui/audio');
  assert.equal(typeof ui.mountAudioPlayer, 'function');
  await assert.rejects(ui.mountAudioPlayer(null), /mount element/);
});
