import test from 'node:test';
import assert from 'node:assert/strict';
import { StudioPlayer, QueueController, SleepTimerController, MediaSessionController } from '@studio/player';
import { MediaSessionController as SubpathMediaSession } from '@studio/player/media-session';

import { Media, Clock, Session, plan, items, settle, deferred, metadataFactory, setup } from './helpers.mjs';

test('Queue: validates atomically, snapshots do not expose the mutable list, and boundaries are explicit', async t => {
  const { player } = setup(t);
  const queue = new QueueController(player);
  assert.equal(await queue.next(), false);
  queue.setItems(items);
  assert.throws(() => queue.setItems([items[0], items[0]]), TypeError);
  assert.equal(queue.snapshot.items.length, 3);
  queue.snapshot.items.pop();
  assert.equal(queue.snapshot.items.length, 3);
  await assert.rejects(queue.select(-1), RangeError);
  await queue.select(0, { autoplay: false });
  assert.equal(player.paused, true);
  assert.equal(await queue.previous(), false);
  await queue.next();
  assert.equal(player.currentResourceId, 'b');
  assert.equal(queue.snapshot.index, 1);
  await queue.previous();
  assert.equal(player.currentResourceId, 'a');
});

test('Queue: native ended advances once and stops at the last item', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player);
  queue.setItems(items.slice(0, 2));
  await queue.select(0);
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'b');
  assert.equal(media.playCalls, 2);
  assert.equal(player.paused, false);
  media.finish();
  await settle();
  assert.equal(queue.snapshot.index, 1);
  assert.equal(media.playCalls, 2);
  assert.equal(player.paused, true);
});

test('Queue: automatic advance is optional and external load leaves no stale selection', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player, { autoAdvance: false });
  queue.setItems(items);
  await queue.select(0);
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
  await player.load(plan('outside'));
  assert.equal(queue.snapshot.index, -1);
  assert.equal(queue.snapshot.items.length, 3);
});

test('Queue: last selection wins while storage delays the preceding load', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const queue = new QueueController(player);
  queue.setItems(items);
  player.progressController.recordProgress('old', 25, 100, false);
  const first = queue.select(0);
  const last = queue.select(2);
  gate.resolve();
  assert.equal(await first, false);
  assert.equal(await last, true);
  assert.equal(player.currentResourceId, 'c');
  assert.equal(media.playCalls, 1);
});

test('Queue: external load invalidates a pending selection, including the same resource ID', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const queue = new QueueController(player);
  queue.setItems(items);
  player.progressController.recordProgress('old', 25, 100, false);
  const selection = queue.select(0);
  const external = player.load(plan('a', { playUrl: 'external.mp4' }));
  gate.resolve();
  await external;
  assert.equal(await selection, false);
  assert.equal(queue.snapshot.index, -1);
  assert.equal(media.src, 'external.mp4');
  assert.equal(media.playCalls, 0);
});

test('Queue: a change listener can supersede a selection without the old operation loading afterward', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player);
  queue.setItems(items);
  let nested;
  queue.addEventListener('change', () => {
    if (queue.snapshot.index === 0) nested = queue.select(2);
  });
  assert.equal(await queue.select(0), false);
  assert.equal(await nested, true);
  assert.equal(player.currentResourceId, 'c');
  assert.equal(media.playCalls, 1);
});

test('Queue: an aborted play remains a cancellation rather than a load failure', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player);
  queue.setItems(items);
  media.play = () => Promise.reject(Object.assign(new Error('paused'), { name: 'AbortError' }));
  let errors = 0;
  queue.addEventListener('error', () => errors++);
  assert.equal(await queue.select(0), false);
  assert.equal(errors, 0);
  assert.equal(queue.snapshot.error, null);
});

test('Queue: rejected play is surfaced and does not skip through the list', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player);
  queue.setItems(items);
  const error = Object.assign(new Error('User gesture required'), { name: 'NotAllowedError' });
  media.play = () => Promise.reject(error);
  let observed;
  queue.addEventListener('error', event => { observed = event.detail; });
  await assert.rejects(queue.select(0), { name: 'NotAllowedError' });
  media.finish();
  await settle();
  assert.equal(queue.snapshot.index, 0);
  assert.equal(observed, error);
  assert.equal(player.paused, true);
});

test('Queue: removing a feature cancels pending autoplay and keeps basic playback available', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const queue = new QueueController(player);
  queue.setItems(items);
  player.progressController.recordProgress('old', 25, 100, false);
  const selection = queue.select(0);
  queue.destroy();
  gate.resolve();
  assert.equal(await selection, false);
  assert.equal(media.playCalls, 0);
  await player.play();
  assert.equal(player.paused, false);
  media.finish();
  await settle();
  assert.equal(player.currentResourceId, 'a');
});

test('SleepTimer: restart replaces its deadline, cancellation clears tasks without pausing', async t => {
  const { player } = setup(t);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  await player.load(plan('a'));
  await player.play();
  assert.equal(clock.tasks.size, 0);
  assert.throws(() => timer.start(Infinity), RangeError);
  timer.start(5000);
  clock.jump(1000);
  assert.equal(timer.snapshot.remainingMs, 4000);
  timer.start(10000);
  assert.equal(clock.tasks.size, 1);
  clock.jump(5000);
  assert.equal(timer.snapshot.remainingMs, 5000);
  timer.cancel();
  clock.jump(20000);
  assert.equal(clock.tasks.size, 0);
  assert.equal(player.paused, false);
});

test('SleepTimer: a delayed wake corrects wall time, expires once, and permits later manual play', async t => {
  const { player } = setup(t);
  const clock = new Clock();
  const visibility = new EventTarget();
  const timer = new SleepTimerController(player, { clock, visibilityTarget: visibility });
  await player.load(plan('a'));
  await player.play();
  let expired = 0;
  timer.addEventListener('expire', () => expired++);
  timer.start(1000);
  clock.jump(60000, false);
  visibility.dispatchEvent(new Event('visibilitychange'));
  assert.equal(player.paused, true);
  assert.equal(timer.snapshot.status, 'expired');
  assert.equal(clock.tasks.size, 0);
  visibility.dispatchEvent(new Event('visibilitychange'));
  assert.equal(expired, 1);
  await player.play();
  assert.equal(player.paused, false);
});

test('SleepTimer: expiry beats ended regardless of feature registration order', async t => {
  for (const timerFirst of [true, false]) {
    const { player, media } = setup(t);
    const clock = new Clock();
    const timer = timerFirst ? new SleepTimerController(player, { clock }) : null;
    const queue = new QueueController(player);
    const actualTimer = timer ?? new SleepTimerController(player, { clock });
    queue.setItems(items);
    await queue.select(0);
    actualTimer.start(1000);
    clock.jump(1000, false);
    media.finish();
    await settle();
    assert.equal(player.paused, true);
    assert.equal(media.playCalls, 1, 'an expired timer must prevent the next play');
    assert.equal(actualTimer.snapshot.status, 'expired');
  }
});

test('SleepTimer: expiry also cancels automatic next while progress writes are pending', async t => {
  const gate = deferred();
  let delayed = false;
  const { player, media } = setup(t, {
    progressStorage: { load: () => null, save: () => delayed ? gate.promise : undefined, clear() {} },
  });
  const queue = new QueueController(player);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  queue.setItems(items);
  await queue.select(0);
  delayed = true;
  player.progressController.recordProgress('a', 25, 100, false);
  void player.progressController.flush();
  timer.start(1000);
  media.finish();
  assert.equal(queue.snapshot.index, 1);
  clock.jump(1000);
  gate.resolve();
  await settle();
  assert.equal(media.playCalls, 1);
  assert.equal(player.paused, true);
});

test('Lifecycle: detach cancels a pending load, timer and queue but supports a later attach', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  const queue = new QueueController(player);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  queue.setItems(items);
  player.progressController.recordProgress('old', 25, 100, false);
  const pending = queue.select(0);
  timer.start(1000);
  player.detach();
  gate.resolve();
  assert.equal(await pending, false);
  assert.equal(media.listenerCount, 0);
  assert.equal(clock.tasks.size, 0);
  assert.equal(queue.snapshot.index, -1);
  assert.equal(player.state, 'idle');
  player.attach(media);
  await queue.select(1);
  assert.equal(player.currentResourceId, 'b');
});

test('MediaSession: importing or constructing without browser support has no global dependency', t => {
  const { player } = setup(t);
  const session = new MediaSessionController(player, { session: null });
  assert.equal(session.supported, false);
  assert.equal(session.activate(), false);
  session.sync();
  session.destroy();
});

test('MediaSession: metadata and position follow actual media facts, including native controls', async t => {
  const { player, media } = setup(t);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, createMetadata: metadataFactory });
  assert.equal(session.active, false);
  session.activate();
  await player.load(plan('a'));
  assert.equal(port.metadata.title, 'Title a');
  await player.play();
  assert.equal(port.playbackState, 'playing');
  media.currentTime = 12;
  media.playbackRate = 1.5;
  media.trigger('ratechange');
  assert.deepEqual(port.position, { duration: 100, position: 12, playbackRate: 1.5 });
  media.pause();
  assert.equal(port.playbackState, 'paused');
  media.paused = false; // sync reads the element even without an updated state label.
  session.sync();
  assert.equal(port.playbackState, 'playing');
  media.duration = Infinity;
  media.trigger('durationchange');
  assert.equal(port.position, undefined);
});

test('MediaSession: actions control the same player and surface play rejection', async t => {
  const { player, media } = setup(t);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, createMetadata: metadataFactory });
  session.activate();
  await player.load(plan('a'));
  port.invoke('play');
  await settle();
  assert.equal(player.paused, false);
  port.invoke('pause');
  assert.equal(player.paused, true);
  port.invoke('seekto', { seekTime: 50 });
  port.invoke('seekforward', { seekOffset: 10 });
  assert.equal(player.currentTime, 60);
  port.invoke('seekbackward', { seekOffset: 500 });
  assert.equal(player.currentTime, 0);
  port.invoke('seekto', { seekTime: NaN });
  assert.equal(player.currentTime, 0);
  let error;
  session.addEventListener('error', event => { error = event.detail; });
  media.play = () => Promise.reject(Object.assign(new Error('blocked'), { name: 'NotAllowedError' }));
  port.invoke('play');
  await settle();
  assert.equal(error.name, 'NotAllowedError');
  assert.equal(port.playbackState, 'paused');
});

test('MediaSession: a simple source title survives adaptation and clears on an untitled source', async t => {
  const { player } = setup(t);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, createMetadata: metadataFactory });
  session.activate();
  await player.load({ src: 'a.mp4', title: 'Simple title', resourceId: 'a' });
  assert.equal(port.metadata.title, 'Simple title');
  await player.load('b.mp4');
  assert.equal(port.metadata.title, 'b.mp4');
});

test('MediaSession: handlers from a previous activation cannot act after reactivation', async t => {
  const { player, media } = setup(t);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, createMetadata: metadataFactory });
  await player.load(plan('a'));
  session.activate();
  const stale = port.handlers.get('play');
  session.deactivate();
  session.activate();
  stale({ action: 'play' });
  await settle();
  assert.equal(media.playCalls, 0);
  port.invoke('play');
  await settle();
  assert.equal(media.playCalls, 1);
});

test('MediaSession: a late rejection from an old activation is not reported to the new activation', async t => {
  const { player, media } = setup(t);
  const port = new Session();
  const gate = deferred();
  media.play = () => gate.promise;
  const session = new MediaSessionController(player, { session: port, createMetadata: metadataFactory });
  await player.load(plan('a'));
  session.activate();
  let errors = 0;
  session.addEventListener('error', () => errors++);
  port.invoke('play');
  session.deactivate();
  session.activate();
  gate.reject(Object.assign(new Error('old rejection'), { name: 'NotAllowedError' }));
  await settle();
  assert.equal(errors, 0);
  assert.equal(session.active, true);
  assert.equal(port.handlers.has('play'), true);
});

test('MediaSession: queue controls track boundaries and can be removed independently', async t => {
  const { player } = setup(t);
  const queue = new QueueController(player);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, queue, createMetadata: metadataFactory });
  session.activate();
  queue.setItems(items.slice(0, 2));
  await queue.select(0);
  assert.equal(port.handlers.has('previoustrack'), false);
  assert.equal(port.handlers.has('nexttrack'), true);
  port.invoke('nexttrack');
  await settle();
  assert.equal(player.currentResourceId, 'b');
  assert.equal(port.metadata.title, 'Title b');
  assert.equal(port.handlers.has('nexttrack'), false);
  assert.equal(port.handlers.has('previoustrack'), true);
  queue.destroy();
  assert.equal(port.handlers.has('previoustrack'), false);
  assert.equal(port.handlers.has('play'), true);
  assert.equal(player.paused, false);
});

test('MediaSession: one owner per port across root/subpath exports, stale handlers and disposal are harmless', async t => {
  assert.equal(MediaSessionController, SubpathMediaSession);
  const first = setup(t);
  const second = setup(t);
  const port = new Session();
  const a = new MediaSessionController(first.player, { session: port, createMetadata: metadataFactory });
  const b = new SubpathMediaSession(second.player, { session: port, createMetadata: metadataFactory });
  await first.player.load(plan('a'));
  await second.player.load(plan('b'));
  a.activate();
  const oldPlay = port.handlers.get('play');
  b.activate();
  assert.equal(a.active, false);
  assert.equal(port.metadata.title, 'Title b');
  oldPlay({ action: 'play' });
  a.destroy();
  assert.equal(port.handlers.has('play'), true);
  port.invoke('play');
  await settle();
  assert.equal(first.media.playCalls, 0);
  assert.equal(second.media.playCalls, 1);
  b.destroy();
  assert.equal(port.handlers.size, 0);
  assert.equal(port.metadata, null);
  assert.equal(port.position, undefined);
});

test('MediaSession: partial action/position/metadata support degrades without stopping playback', async t => {
  const { player } = setup(t);
  const port = new Session();
  const install = port.setActionHandler.bind(port);
  port.setActionHandler = (action, handler) => {
    if (action === 'seekto') throw new Error('unsupported');
    install(action, handler);
  };
  port.setPositionState = () => { throw new Error('unsupported'); };
  const session = new MediaSessionController(player, {
    session: port,
    createMetadata() { throw new TypeError('bad artwork'); },
  });
  let errors = 0;
  session.addEventListener('error', () => errors++);
  session.activate();
  await player.load(plan('a'));
  await player.play();
  assert.equal(player.paused, false);
  assert.equal(port.handlers.has('play'), true);
  assert.equal(port.handlers.has('seekto'), false);
  assert.equal(port.metadata, null);
  assert.equal(errors, 1);
});

test('Lifecycle: internal native/HLS media rebinding retains the queue and timer', async t => {
  const { player, media } = setup(t);
  const hls = new Media();
  hls.localName = 'hlsjs-video';
  const host = {
    querySelector: selector => selector === 'hlsjs-video' ? hls : media,
  };
  media.closest = hls.closest = () => host;
  Object.defineProperty(hls, 'source', {
    set(value) { this.src = value?.src ?? ''; this.load(); },
  });
  const queue = new QueueController(player);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  queue.setItems([items[0], { id: 'hls', source: plan('hls', { transport: 'hls', playUrl: 'stream.m3u8' }) }]);
  await queue.select(0);
  timer.start(5000);
  await queue.next();
  assert.equal(player.element, hls);
  assert.equal(queue.snapshot.index, 1);
  assert.equal(timer.snapshot.status, 'running');
  assert.equal(media.listenerCount, 0);
  assert.ok(hls.listenerCount > 0);
});

test('Lifecycle: twenty complete cycles leave no media listeners, timer tasks, or system handlers', async () => {
  for (let i = 0; i < 20; i++) {
    const player = new StudioPlayer();
    const media = new Media();
    player.attach(media);
    const queue = new QueueController(player);
    const clock = new Clock();
    const timer = new SleepTimerController(player, { clock });
    const port = new Session();
    const session = new MediaSessionController(player, { session: port, queue, createMetadata: metadataFactory });
    queue.setItems(items);
    session.activate();
    await queue.select(0);
    timer.start(1000);
    player.destroy();
    player.destroy();
    clock.jump(5000);
    assert.equal(media.listenerCount, 0);
    assert.equal(media.paused, true);
    assert.equal(clock.tasks.size, 0);
    assert.equal(port.handlers.size, 0);
    assert.equal(port.metadata, null);
    assert.equal(player.progressController, null);
    assert.throws(() => timer.start(1000), /destroyed/);
    assert.throws(() => player.attach(media), /destroyed/);
  }
});
