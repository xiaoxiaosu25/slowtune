import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getEventListeners } from 'node:events';
import { mountPreviewPlayer } from '@studio/player/ui/preview';
import { MainMediaCoordinator } from '@studio/player/main-media';
import { Clock, Media, deferred, plan, setup, settle } from './helpers.mjs';

// 最小 DOM 端口替身：只验证真实公共 UI 的接线/取消；不充当布局或浏览器证据。
class Node extends EventTarget {
  dataset = {}; style = { setProperty() {}, removeProperty() {} }; attributes = new Map(); children = []; hidden = false; value = ''; textContent = '';
  constructor(document) { super(); this.ownerDocument = document; }
  append(node) { this.children.push(node); node.parent = this; }
  remove() { if (this.parent) this.parent.children = this.parent.children.filter(node => node !== this); }
  setAttribute(key, value) { this.attributes.set(key, value); }
  getAttribute(key) { return this.attributes.get(key) ?? null; }
  removeAttribute(key) { this.attributes.delete(key); }
  focus() { this.ownerDocument.activeElement = this; }
  attachShadow() { const nodes = new Map(); return this.shadowRoot = { innerHTML: '', querySelector: selector => { if (!nodes.has(selector)) nodes.set(selector, new Node(this.ownerDocument)); return nodes.get(selector); } }; }
}
function mediaNode(document) {
  const node = new Media(); node.ownerDocument = document; node.setAttribute = () => {}; node.remove = Node.prototype.remove; return node;
}
function uiSetup(t, options = {}, host) {
  const document = host?.ownerDocument ?? { createElement() { return new Node(document); }, defaultView: { matchMedia: () => ({ matches: true }) } };
  const root = host ?? new Node(document); const media = mediaNode(document); let creations = 0;
  const ui = mountPreviewPlayer(root, { media: { source: plan('a'), title: 'A' }, createMediaElement: () => { creations++; return media; }, ...options });
  t.after(() => ui.destroy());
  return { ui, media, root, document, creations: () => creations, query: selector => ui.element.shadowRoot.querySelector(selector) };
}
test('preview mount is synchronous, does not create media, resolve source or access progress; destroy clears shell', t => {
  const { ui, root, creations } = uiSetup(t);
  assert.equal(creations(), 0); assert.equal(ui.player.element, null); assert.equal(ui.player.currentResourceId, null);
  assert.equal(ui.player.progressController, null); assert.equal(root.children.length, 1);
  ui.destroy(); ui.destroy(); assert.equal(root.children.length, 0); assert.equal(ui.player.isDestroyed, true);
});
test('late async media after destroy cannot attach, play or rebuild UI', async t => {
  const task = deferred(); const { ui, media, root } = uiSetup(t, { createMediaElement: () => task.promise });
  const playing = ui.play(); ui.destroy(); task.resolve(media);
  await assert.rejects(playing, { name: 'AbortError' }); assert.equal(media.playCalls, 0); assert.equal(media.listenerCount, 0); assert.equal(root.children.length, 0);
});
test('close cancels late import; reopen only restores shell', async t => {
  const task = deferred(); const { ui, media } = uiSetup(t, { createMediaElement: () => task.promise });
  const playing = ui.play(); await ui.close(); assert.equal(ui.isClosed, true); ui.open(); task.resolve(media);
  await assert.rejects(playing, { name: 'AbortError' }); assert.equal(ui.player.element, null); assert.equal(media.playCalls, 0); assert.equal(ui.isClosed, false);
});
test('A to B during async creation ignores A, including late errors', async t => {
  const a = deferred(), b = deferred(); let calls = 0; const errors = [];
  const { ui, media, document } = uiSetup(t, { createMediaElement: () => ++calls === 1 ? a.promise : b.promise, onError: e => errors.push(e) });
  const first = ui.play(); const firstResult = assert.rejects(first, /old import/);
  await ui.setMedia({ source: plan('b'), title: 'B' }); const second = ui.play(); b.resolve(media); await second;
  a.reject(new Error('old import')); await firstResult;
  assert.equal(ui.player.currentResourceId, 'b'); assert.equal(errors.length, 0); assert.equal(media.playCalls, 1);
  assert.equal(ui.element.shadowRoot.querySelector('strong').textContent, 'B');
});
test('pause resumes same session, form/theme changes preserve position; stop reloads; ended replays', async t => {
  const { ui, media } = uiSetup(t); await ui.play(); media.currentTime = 37; ui.pause();
  ui.setView('mini'); ui.setTheme('dark'); ui.setTokens({ accent: '#ff0' }); await ui.play();
  assert.equal(ui.player.element, media); assert.equal(media.currentTime, 37); assert.equal(ui.player.currentResourceId, 'a');
  await ui.stop(); assert.equal(media.src, ''); await ui.play(); assert.equal(ui.player.currentResourceId, 'a');
  media.finish(); assert.equal(ui.player.currentResourceId, 'a'); await ui.play(); assert.equal(media.currentTime, 0);
  ui.destroy(); assert.equal(media.listenerCount, 0); assert.equal(media.src, '');
});
test('play rejection shows actionable state and next click can continue', async t => {
  const { ui, media, query } = uiSetup(t); media.play = () => Promise.reject(new DOMException('blocked','NotAllowedError'));
  await assert.rejects(ui.play(), { name: 'NotAllowedError' }); assert.match(query('.status').textContent, /点击继续/);
  assert.notEqual(query('[data-action=play]').textContent, '暂停'); media.play = Media.prototype.play; await ui.play();
  assert.equal(query('[data-action=play]').textContent, '暂停');
});
test('close during pending media play prevents a late playing event', async t => {
  const task = deferred(); const { ui, media } = uiSetup(t);
  media.play = () => task.promise.then(() => { media.paused = false; media.trigger('playing'); });
  const playing = ui.play(); await settle(); await ui.close(); task.resolve(); await assert.rejects(playing, { name: 'AbortError' });
  assert.equal(media.paused, true); assert.equal(ui.isClosed, true); assert.equal(media.src, '');
});
test('explicit progress stores checkpoint; newer selection cancels waiting close', async t => {
  const write = deferred(); const saved = []; let closed = 0;
  const { ui, media } = uiSetup(t, { progressStorage: { load: () => null, save: (...args) => { saved.push(args); return write.promise; }, clear() {} }, onClose: () => closed++ });
  await ui.play(); media.currentTime = 20; const closing = ui.close(); const result = assert.rejects(closing, { name:'AbortError' });
  const replacing = ui.setMedia({ source: plan('b') }); write.resolve(); await replacing; await result;
  assert.equal(closed, 0); assert.equal(saved[0][0], 'a'); assert.equal(saved[0][1], 20);
});
test('muted hover leaves audio scope untouched; unmute claims it; destroy releases it', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const audio = setup(t);
  scope.register(audio.player); await audio.player.load(plan('audio')); await audio.player.play();
  const { ui, media } = uiSetup(t, { mainMedia: { scope }, hoverPreview: true, hoverDelayMs: 0 });
  ui.element.dispatchEvent(new Event('pointerenter')); await new Promise(r => setTimeout(r, 10));
  assert.equal(media.muted, true); assert.equal(audio.media.paused, false); assert.equal(scope.size, 1);
  await ui.setMuted(false); assert.equal(audio.media.paused, true); assert.equal(scope.active.player, ui.player);
  ui.destroy(); assert.equal(scope.size, 1); assert.equal(scope.active, null);
});
test('hover leave cancels timer and pending import; touch does not hover', async t => {
  const task = deferred(); let calls = 0; const { ui, media } = uiSetup(t, { hoverPreview: true, hoverDelayMs: 0, createMediaElement: () => { calls++; return task.promise; } });
  const touch = new Event('pointerenter'); Object.defineProperty(touch,'pointerType',{value:'touch'}); ui.element.dispatchEvent(touch);
  await new Promise(r => setTimeout(r, 5)); assert.equal(calls, 0);
  ui.element.dispatchEvent(new Event('pointerenter')); ui.element.dispatchEvent(new Event('pointerleave'));
  await new Promise(r => setTimeout(r, 5)); assert.equal(calls, 0);
  ui.element.dispatchEvent(new Event('pointerenter')); await new Promise(r => setTimeout(r, 5)); assert.equal(calls, 1);
  ui.element.dispatchEvent(new Event('pointerleave')); task.resolve(media); await settle(); assert.equal(media.playCalls, 0); assert.equal(ui.player.element, null);
});
test('scope preemption while import is pending cancels preview start', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const task = deferred();
  const { ui, media } = uiSetup(t, { mainMedia: { scope }, createMediaElement: () => task.promise });
  const playing = ui.play(); const result = assert.rejects(playing, { name:'AbortError' });
  const other = setup(t); scope.register(other.player); await other.player.load(plan('other')); await other.player.play(); task.resolve(media); await result;
  assert.equal(media.playCalls, 0); assert.equal(other.media.paused, false);
});
test('A pending media play cannot override B state or error', async t => {
  const task = deferred(); const errors = []; const { ui, media } = uiSetup(t, { onError: e => errors.push(e) });
  media.play = () => task.promise; const first = ui.play(); const result = assert.rejects(first); await settle();
  await ui.setMedia({source:plan('b'),title:'B'}); media.play = Media.prototype.play; await ui.play(); task.reject(new Error('old A failure')); await result;
  assert.equal(ui.player.currentResourceId,'b'); assert.equal(errors.length,0); assert.equal(media.paused,false);
});
test('failed media initialization can be retried and external player destruction removes UI', async t => {
  let first = true; const context = uiSetup(t, { createMediaElement: () => { if (first) { first = false; throw new Error('import failed'); } return context.media; } });
  await assert.rejects(context.ui.play(), /import failed/); await context.ui.play(); assert.equal(context.media.playCalls, 1);
  context.ui.player.destroy(); assert.equal(context.ui.isDestroyed, true); assert.equal(context.root.children.length, 0); assert.equal(context.media.listenerCount, 0);
});

test('unmuting an idle, paused or closed preview does not claim the scope until playback', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy());
  const audio = setup(t); scope.register(audio.player); await audio.player.load(plan('audio')); await audio.player.play();
  const { ui, creations } = uiSetup(t, { mainMedia: { scope } });
  await ui.setMuted(false);
  assert.equal(audio.media.paused, false); assert.equal(scope.active.player, audio.player); assert.equal(creations(), 0);
  await ui.play(); assert.equal(audio.media.paused, true); ui.pause(); await audio.player.play();
  await ui.setMuted(true); await ui.setMuted(false);
  assert.equal(audio.media.paused, false); assert.equal(ui.player.paused, true);
  await ui.close(); await ui.setMuted(false);
  assert.equal(audio.media.paused, false); assert.equal(ui.isClosed, true);
});

test('muting while the initial media play is pending preserves the latest playback intent', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const gate = deferred();
  const { ui, media } = uiSetup(t, { mainMedia: { scope } });
  let first = true;
  media.play = function () {
    if (!first) return Media.prototype.play.call(this);
    first = false;
    return gate.promise.then(() => { this.paused = false; this.trigger('play'); this.trigger('playing'); });
  };
  const playing = ui.play().catch(error => error); await settle();
  const muting = ui.setMuted(true); await muting; gate.resolve(); await playing;
  assert.equal(media.muted, true); assert.equal(media.paused, false); assert.equal(scope.active, null);
});

test('a cancelled mute restart cannot mute a newer source or report its stale error', async t => {
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); const gate = deferred(); const errors = [];
  const { ui, media } = uiSetup(t, { mainMedia: { scope }, onError: error => errors.push(error) });
  await ui.play(); media.play = () => gate.promise;
  const muting = ui.setMuted(true).catch(error => error); await settle();
  await ui.setMedia({ source: plan('b') }); await ui.setMuted(false); media.play = Media.prototype.play; await ui.play();
  gate.reject(new Error('late mute restart')); await muting;
  assert.equal(ui.player.currentResourceId, 'b'); assert.equal(media.muted, false); assert.equal(media.paused, false);
  assert.deepEqual(errors, []);
});

test('media volume changes update preview controls and survive pause and resume', async t => {
  const { ui, media, query } = uiSetup(t); await ui.play();
  ui.player.setVolume(0.25); ui.player.setMuted(true); media.trigger('volumechange');
  assert.equal(query('[data-volume]').value, '0.25'); assert.equal(query('[data-action=mute]').getAttribute('aria-pressed'), 'true');
  ui.pause(); await ui.play(); assert.equal(media.volume, 0.25); assert.equal(media.muted, true);
});

test('audio posters remain visible when MIME is inferred from a URL or an untyped source', async t => {
  for (const source of ['clip.mp3', { src: 'clip.wav', resourceId: 'clip' }]) {
    const { ui, query } = uiSetup(t, { media: { source, poster: '/cover.png' } });
    await ui.play(); assert.equal(query('img').hidden, false);
    await ui.setMedia({ source: plan('video'), poster: '/cover.png' }); await ui.play(); assert.equal(query('img').hidden, true);
  }
});

test('reopening moves focus to a visible control without loading or playing', async t => {
  const { ui, media, query, document } = uiSetup(t); await ui.play(); await ui.close();
  assert.equal(document.activeElement, query('[data-action=open]')); const plays = media.playCalls;
  ui.open(); assert.equal(document.activeElement, query('[data-action=play]')); assert.equal(media.playCalls, plays); assert.equal(media.src, '');
});

test('hover requires a fine pointer, waits 250ms by default and is cancelled on view change or destroy', async t => {
  const clock = new Clock(); t.mock.method(globalThis, 'setTimeout', clock.setTimeout); t.mock.method(globalThis, 'clearTimeout', clock.clearTimeout);
  const { ui, media, document, creations } = uiSetup(t, { hoverPreview: true });
  document.defaultView.matchMedia = () => ({ matches: false }); ui.element.dispatchEvent(new Event('pointerenter'));
  assert.equal(clock.tasks.size, 0);
  document.defaultView.matchMedia = () => ({ matches: true }); ui.element.dispatchEvent(new Event('pointerenter'));
  clock.jump(249); await settle(); assert.equal(creations(), 0);
  ui.setView('mini'); clock.jump(1); await settle(); assert.equal(creations(), 0); assert.equal(clock.tasks.size, 0);
  ui.setView('card'); ui.element.dispatchEvent(new Event('pointerenter'));
  clock.jump(250); await settle(); assert.equal(creations(), 1); assert.equal(media.muted, true); assert.equal(media.playCalls, 1);
  await ui.stop(); ui.element.dispatchEvent(new Event('pointerenter')); ui.destroy();
  clock.jump(250); await settle(); assert.equal(creations(), 1); assert.equal(clock.tasks.size, 0);
});

test('explicit progress restores after close and reopen, isolates resources and clears natural completion', async t => {
  const saved = new Map(); const storage = {
    load: id => saved.get(id), save: (id, position) => saved.set(id, position), clear: id => saved.delete(id),
  };
  const { ui, media } = uiSetup(t, { progressStorage: storage });
  await ui.play(); media.currentTime = 24; await ui.close(); assert.equal(saved.get('a'), 24);
  ui.open(); await ui.play(); await settle(); assert.equal(media.currentTime, 24);
  await ui.setMedia({ source: plan('b') }); await ui.play(); await settle(); assert.equal(media.currentTime, 0);
  ui.player.seek(42); await ui.setMedia({ source: plan('a') }); await ui.play(); await settle();
  assert.equal(saved.get('b'), 42); assert.equal(media.currentTime, 24);
  media.finish(); await settle(); await ui.close(); assert.equal(saved.has('a'), false); assert.equal(saved.get('b'), 42);
  ui.open(); await ui.play(); await settle(); assert.equal(media.currentTime, 0);
});

test('late progress for A cannot move B, and manual seek to zero wins over delayed restore', async t => {
  const a = deferred(), b = deferred(); const reads = [];
  const { ui, media } = uiSetup(t, { progressStorage: { load: id => { reads.push(id); return id === 'a' ? a.promise : b.promise; }, save() {}, clear() {} } });
  await ui.play(); await settle(); await ui.setMedia({ source: plan('b') }); await ui.play(); await settle();
  ui.player.seek(0); a.resolve(60); b.resolve(35); await settle();
  assert.deepEqual(reads, ['a', 'b']); assert.equal(ui.player.currentResourceId, 'b'); assert.equal(media.currentTime, 0);
});

test('reopen cancels a close waiting for storage without late callbacks or automatic playback', async t => {
  const write = deferred(); let closed = 0; const errors = [];
  const { ui, media } = uiSetup(t, { progressStorage: { load: () => null, save: () => write.promise, clear() {} }, onClose: () => closed++, onError: error => errors.push(error) });
  await ui.play(); media.currentTime = 23; const closing = ui.close(); const cancelled = assert.rejects(closing, { name: 'AbortError' });
  ui.open(); write.resolve(); await cancelled;
  assert.equal(closed, 0); assert.deepEqual(errors, []); assert.equal(ui.isClosed, false); assert.equal(media.paused, true); assert.equal(media.src, '');
});

test('failed checkpoint reports an error and releases media without announcing a successful close', async t => {
  const failure = new Error('storage unavailable'); const errors = []; let closed = 0;
  const { ui, media, query } = uiSetup(t, { progressStorage: { load: () => null, save() { throw failure; }, clear() {} },
    onError: error => errors.push(error), onClose: () => closed++ });
  await ui.play(); media.currentTime = 23;
  await assert.rejects(ui.close(), /storage unavailable/);
  assert.equal(closed, 0); assert.equal(ui.isClosed, false); assert.deepEqual(errors, [failure]);
  assert.match(query('.status').textContent, /storage unavailable/); assert.equal(media.paused, true); assert.equal(media.src, '');
});

test('twenty preview lifecycles release observed DOM, media listeners, timers and scope registrations', async t => {
  const clock = new Clock(); t.mock.method(globalThis, 'setTimeout', clock.setTimeout); t.mock.method(globalThis, 'clearTimeout', clock.clearTimeout);
  const scope = new MainMediaCoordinator(); t.after(() => scope.destroy()); let host;
  for (let cycle = 0; cycle < 20; cycle++) {
    const { ui, media, root, query, creations } = uiSetup(t, { hoverPreview: true, mainMedia: { scope },
      progressStorage: { load: () => null, save() {}, clear() {} } }, host);
    host = root; ui.element.dispatchEvent(new Event('pointerenter')); assert.equal(clock.tasks.size, 1);
    clock.jump(250); await settle(); await ui.setMuted(false); ui.player.seek(20);
    assert.equal(scope.active.player, ui.player); assert.ok(media.listenerCount > 0); assert.ok(clock.tasks.size > 0);
    const targets = [[ui.element, 'pointerenter'], [ui.element, 'pointerleave'],
      ...['play', 'stop', 'close', 'open', 'mute'].map(action => [query('[data-action=' + action + ']'), 'click']),
      [query('[data-progress]'), 'input'], [query('[data-volume]'), 'input']];
    ui.destroy(); ui.destroy(); clock.jump(1000); await settle();
    assert.equal(root.children.length, 0); assert.equal(media.src, ''); assert.equal(media.paused, true); assert.equal(media.listenerCount, 0);
    assert.equal(clock.tasks.size, 0); assert.equal(scope.size, 0); assert.equal(scope.active, null);
    for (const [target, event] of targets) assert.equal(getEventListeners(target, event).length, 0, `cycle ${cycle + 1}: ${event}`);
    ui.element.dispatchEvent(new Event('pointerenter')); clock.jump(250); assert.equal(creations(), 1);
  }
});
