import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import { mkdtemp, writeFile, rm, open } from 'node:fs/promises';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { LocalMediaProbe } from '@studio/player/probe';
import { normalizeFfprobeMedia, describeProbedMedia } from '@studio/player/source-adapter';
import { createSeekableInput } from '../dist/probe/seekable-input.js';

const aac = { index: 1, codec_type: 'audio', codec_name: 'aac', profile: 'LC', codec_tag_string: 'mp4a', extradata: '\n00000000: 1188 56e5 00  ....\n', channels: 1, sample_rate: '48000', disposition: { default: 1 } };
const h264 = { index: 0, codec_type: 'video', codec_name: 'h264', codec_tag_string: 'avc1', extradata: '\n00000000: 014d 401f ffe1 0031  .M@....1\n', width: 320, height: 180, avg_frame_rate: '24/1' };
const raw = streams => ({ format: { format_name: 'mov,mp4,m4a,3gp,3g2,mj2', duration: '4', tags: { major_brand: 'isom', location: 'secret' } }, streams });

test('codec strings derive from configuration bytes and AAC object type, not names or guessed profiles', () => {
  const result = normalizeFfprobeMedia(raw([h264, aac]), true);
  const description = describeProbedMedia(result);
  assert.equal(description.video.codec, 'avc1.4d401f'); assert.equal(description.audio.codec, 'mp4a.40.2');
  assert.equal(description.video.framerate, 24); assert.ok(!JSON.stringify(result).includes('secret'));
  const unknown = describeProbedMedia(normalizeFfprobeMedia(raw([{ ...h264, extradata: undefined }, { ...aac, extradata: 'invalid' }]), true));
  assert.equal(unknown.video.codec, undefined); assert.equal(unknown.audio.codec, undefined);
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([{ ...aac, profile: 'HE-AAC' }]), true)).audio.codec, undefined);
});

test('partial input never proves a track is absent; complete audio ignores attached cover art', () => {
  const cover = { ...h264, disposition: { attached_pic: 1 } };
  const partial = describeProbedMedia(normalizeFfprobeMedia(raw([aac]), false));
  assert.equal(partial.video, undefined);
  const complete = describeProbedMedia(normalizeFfprobeMedia(raw([aac, cover]), true));
  assert.equal(complete.video, null); assert.equal(complete.audio.codec, 'mp4a.40.2');
});

test('unknown streams and containers preserve uncertainty', () => {
  const input = raw([aac, { index: 2, codec_type: 'unknown' }]);
  assert.equal(normalizeFfprobeMedia(input, true).tracksComplete, false);
  const mov = raw([h264]); mov.format.tags.major_brand = 'qt  ';
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(mov, true)).video.mimeType, 'video/quicktime');
  mov.format.tags.major_brand = 'unknown';
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(mov, true)).video, undefined);
});

test('default and explicit track selection use real stream indices', () => {
  const result = normalizeFfprobeMedia(raw([{ ...aac, index: 2, disposition: {} }, { ...aac, index: 4, codec_name: 'ac3' }]), true);
  assert.equal(describeProbedMedia(result).audio.codec, 'ac-3');
  assert.equal(describeProbedMedia(result, { audio: 2 }).audio.codec, 'mp4a.40.2');
  assert.equal(describeProbedMedia(result, { audio: null }).audio, null);
  assert.throws(() => describeProbedMedia(result, { audio: 0 }), TypeError);
  assert.throws(() => normalizeFfprobeMedia(raw([aac, aac]), true), /invalid-media/);
});

const dump = bytes => '\n00000000: ' + Buffer.from(bytes).toString('hex').match(/.{1,4}/g).join(' ') + '  text\n';
test('HEVC, AV1, VP9 and DTS retain observed configuration and never invent missing fields', () => {
  const hevc = { ...h264, codec_name: 'hevc', codec_tag_string: 'hev1', extradata: dump([1,1,0x60,0,0,0,0xb0,0,0,0,0,0,93,...new Array(10).fill(0)]) };
  const result = normalizeFfprobeMedia(raw([hevc, { ...aac, codec_name: 'dts', profile: 'DTS' }]), true);
  assert.equal(describeProbedMedia(result).video.codec, 'hev1.1.6.L93.B0');
  assert.equal(describeProbedMedia(result).audio.codec, 'dtsc');
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([{ ...hevc, extradata: undefined }]), true)).video.codec, undefined);
  const av1 = { ...h264, codec_name: 'av1', codec_tag_string: 'av01', extradata: dump([0x81,8,0xc0,0]) };
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([av1]), true)).video.codec, 'av01.0.08H.10');
  const vp9 = { ...h264, codec_name: 'vp9', profile: 'Profile 2', level: 31, pix_fmt: 'yuv420p10le', extradata: undefined };
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([vp9]), true)).video.codec, 'vp09.02.31.10');
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([{ ...vp9, level: -99 }]), true)).video.codec, undefined);
  assert.equal(describeProbedMedia(normalizeFfprobeMedia(raw([{ ...aac, codec_name: 'dts', profile: undefined }]), true)).audio.codec, undefined);
});
test('WebM and Matroska identity comes from bounded EBML DocType, not an extension or shared demuxer', () => {
  const json = { format: { format_name: 'matroska,webm' }, streams: [{ ...aac, codec_name: 'opus' }] };
  for (const name of ['webm','matroska']) {
    const header = new Uint8Array([0x1a,0x45,0xdf,0xa3,0x80 | (name.length + 3),0x42,0x82,0x80 | name.length,...Buffer.from(name)]);
    const result = normalizeFfprobeMedia(json, false, { seekable: true, header });
    assert.equal(result.container.kind, name); assert.equal(result.tracksComplete, true);
  }
  assert.equal(normalizeFfprobeMedia(json, false, { seekable: true }).container, undefined);
  assert.equal(normalizeFfprobeMedia(json, false, { seekable: true }).tracksComplete, false);
});
test('seekable reads charge actual repeated ranges, enforce the budget and close sockets on abort', async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'studio-range-'));
  const file = path.join(directory, 'input'); await writeFile(file, Buffer.alloc(4096));
  const handle = await open(file, 'r'); let actual = 0;
  const reader = { read: async (...args) => { const result = await handle.read(...args); actual += result.bytesRead; return result; } };
  const controller = new AbortController();
  const server = await createSeekableInput(http, reader, 4096, 40, controller.signal, error => controller.abort(error));
  const get = range => new Promise((resolve, reject) => {
    const request = http.get(server.url, { headers: { Range: range } }, response => {
      let bytes = 0; response.on('data', chunk => bytes += chunk.length); response.on('end', () => resolve(bytes)); response.on('error', reject);
    }); request.on('error', reject);
  });
  try {
    assert.equal(await get('bytes=4080-4095'), 16);
    assert.equal(await get('bytes=4080-4095'), 16);
    assert.equal(server.snapshot().bytesRead, 32); assert.equal(actual, 32);
    await assert.rejects(get('bytes=0-31'));
    assert.equal(controller.signal.reason.code, 'probe-limit'); assert.equal(actual, 40);
  } finally { await server.close(); await handle.close(); await rm(directory, { recursive: true, force: true }); }
  await assert.rejects(get('bytes=0-1'));
});

test('local process lifecycle enforces byte/output budgets, concurrency, cancellation and timeout', async t => {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'studio-probe-'));
  const file = path.join(directory, 'input.bin'); await writeFile(file, new Uint8Array(4096));
  const original = childProcess.spawn;
  let mode = 'success', calls = 0, killed = 0, received = 0;
  childProcess.spawn = (executable, args, options) => {
    calls++;
    assert.equal(options.shell, false); assert.ok(!args.includes(file));
    assert.deepEqual(args.slice(args.indexOf('-protocol_whitelist'), args.indexOf('-protocol_whitelist') + 2), ['-protocol_whitelist', 'pipe']);
    const child = new EventEmitter(); child.stdin = new PassThrough(); child.stdout = new PassThrough(); child.stderr = new PassThrough();
    let closed = false;
    const close = code => { if (!closed) { closed = true; child.emit('close', code); } };
    child.kill = () => { killed++; setImmediate(() => close(null)); return true; };
    child.stdin.on('data', bytes => { received += bytes.length; });
    const currentMode = mode;
    child.stdin.on('finish', () => {
      if (currentMode === 'hang') return;
      if (currentMode === 'output') { child.stdout.write('x'.repeat(2048)); return; }
      if (currentMode === 'invalid') { child.stderr.write('private-path'); close(1); return; }
      if (currentMode === 'early-close') child.stdin.emit('error', Object.assign(new Error('pipe closed'), { code: 'ECONNRESET' }));
      child.stdout.write(JSON.stringify(raw([aac]))); close(0);
    });
    return child;
  };
  syncBuiltinESMExports();
  try {
    const probe = new LocalMediaProbe({ executable: process.execPath, maxConcurrent: 1 });
    const inspect = (input, options = {}) => probe.inspect(input, { ...options, readMode: 'prefix' });
    const result = await inspect(file, { maxReadBytes: 128 });
    assert.equal(received, 128); assert.equal(result.bytesRead, 128); assert.equal(result.inputComplete, false);
    assert.equal(result.media.tracksComplete, false);
    mode = 'hang'; const controller = new AbortController();
    const pending = inspect(file, { signal: controller.signal });
    await assert.rejects(inspect(file), error => error.code === 'busy');
    // 等待子进程真正创建，验证取消清理而不只是打开前取消。
    while (calls < 2) await new Promise(resolve => setImmediate(resolve));
    controller.abort('private reason'); await assert.rejects(pending, error => error.code === 'cancelled' && !error.message.includes('private'));
    await assert.rejects(inspect(file, { timeoutMs: 20 }), error => error.code === 'timeout');
    mode = 'output'; await assert.rejects(inspect(file, { maxOutputBytes: 128 }), error => error.code === 'output-limit');
    mode = 'invalid'; await assert.rejects(inspect(file), error => error.code === 'invalid-media' && !error.message.includes('private'));
    await assert.rejects(inspect(file, { maxReadBytes: 128 }), error => error.code === 'probe-limit');
    mode = 'success'; assert.equal((await inspect(file)).inputComplete, true);
    mode = 'early-close'; assert.equal((await inspect(file)).media.source, 'ffprobe');
    mode = 'hang'; const stopping = inspect(file); const rejected = assert.rejects(stopping, error => error.code === 'cancelled');
    while (calls < 9) await new Promise(resolve => setImmediate(resolve));
    await probe.stop(); await rejected;
    mode = 'success'; assert.equal((await inspect(file)).inputComplete, true);
    assert.ok(killed >= 3);
    for (const input of ['https://example.invalid/file.mp4', 'relative.mp4', '//server/share/media']) await assert.rejects(probe.inspect(input), error => error.code === 'invalid-input');
    await assert.rejects(probe.inspect(directory), error => error.code === 'invalid-input');
    await assert.rejects(probe.inspect(file, { maxReadBytes: 0 }), error => error.code === 'invalid-input');
    await probe.destroy(); await probe.destroy(); assert.equal(probe.isDestroyed, true);
    await assert.rejects(inspect(file), error => error.code === 'cancelled');
  } finally {
    childProcess.spawn = original; syncBuiltinESMExports(); await rm(directory, { recursive: true, force: true });
  }
});
