import test from 'node:test';
import assert from 'node:assert/strict';
import { assessBrowserMedia } from '@studio/player/source-adapter';

const video = { mimeType: 'video/mp4', codec: 'avc1.4d401f', width: 640, height: 360, bitrate: 500000, framerate: 24 };
const audio = { mimeType: 'audio/mp4', codec: 'mp4a.40.2', channels: '2', samplerate: 48000, bitrate: 96000 };
const media = { transport: 'range', video, audio };
const supported = { supported: true, smooth: false, powerEfficient: false, keySystemAccess: null };

test('preflight queries both selected tracks and their container combination', async () => {
  const calls = [];
  const result = await assessBrowserMedia(media, { environment: {
    canPlayType: (kind, type) => { calls.push({ kind, type }); return 'probably'; },
    decodingInfo: async configuration => { assert.equal(configuration.type, 'file'); assert.ok(configuration.audio); assert.ok(configuration.video); return supported; },
  } });
  assert.equal(result.status, 'expected-supported');
  assert.equal(result.smooth, false); // 可解码不等于流畅或硬件解码。
  assert.equal(result.powerEfficient, false);
  assert.deepEqual(calls.map(call => call.kind), ['video', 'audio', 'video']);
  assert.match(calls[2].type, /avc1.4d401f,mp4a.40.2/);
  assert.ok(Object.isFrozen(result.evidence[0]));
});

test('supported video cannot mask an unsupported soundtrack', async () => {
  const result = await assessBrowserMedia(media, { environment: { canPlayType: kind => kind === 'audio' ? '' : 'probably' } });
  assert.equal(result.status, 'unsupported');
  assert.ok(result.evidence.some(item => item.target === 'audio' && item.result === 'unsupported'));
});

test('missing soundtrack information is unknown; explicitly silent video can be assessed', async () => {
  const options = { environment: { canPlayType: () => 'probably' } };
  assert.equal((await assessBrowserMedia({ transport: 'range', video }, options)).reason, 'metadata-incomplete');
  assert.equal((await assessBrowserMedia({ transport: 'range', video, audio: null }, options)).status, 'expected-supported');
});

test('container MIME alone does not prove its codec is supported', async () => {
  let called = false;
  const result = await assessBrowserMedia({ transport: 'range', video: { mimeType: 'video/mp4' }, audio: null }, {
    environment: { canPlayType: () => { called = true; return 'probably'; } },
  });
  assert.equal(result.reason, 'metadata-incomplete'); assert.equal(called, false);
});

test('pure audio queries an audio element and no video decoding configuration', async () => {
  const result = await assessBrowserMedia({ transport: 'range', video: null, audio }, { environment: {
    canPlayType: kind => { assert.equal(kind, 'audio'); return 'maybe'; },
    decodingInfo: async configuration => { assert.equal(configuration.video, undefined); assert.ok(configuration.audio); return supported; },
  } });
  assert.equal(result.status, 'expected-supported');
});

test('raw FLAC and MP3 use codec-specific MIME without an invalid redundant codec parameter', async () => {
  for (const [mimeType, codec] of [['audio/flac', 'flac'], ['audio/mpeg', 'mp3']]) {
    const result = await assessBrowserMedia({ transport: 'range', video: null, audio: { mimeType, codec } }, {
      environment: { canPlayType: (kind, type) => { assert.equal(type, mimeType); return 'probably'; } },
    });
    assert.equal(result.status, 'expected-supported');
  }
});

test('API disagreement is unknown in either direction', async () => {
  for (const [native, decoded] of [['', true], ['probably', false]]) {
    const result = await assessBrowserMedia(media, { environment: {
      canPlayType: () => native, decodingInfo: async () => ({ ...supported, supported: decoded }),
    } });
    assert.equal(result.reason, 'api-conflict'); assert.equal(result.status, 'unknown');
  }
});

test('partial APIs, maybe, and exceptions do not manufacture support', async () => {
  assert.equal((await assessBrowserMedia(media, { environment: {} })).reason, 'api-unavailable');
  assert.equal((await assessBrowserMedia(media, { environment: { canPlayType: () => 'maybe' } })).reason, 'api-inconclusive');
  const result = await assessBrowserMedia(media, { environment: { canPlayType: () => { throw new Error('secret-url'); } } });
  assert.equal(result.reason, 'api-error'); assert.ok(!JSON.stringify(result).includes('secret-url'));
});

test('file decoding support never becomes a claim of HLS/DASH/WebRTC support', async () => {
  for (const transport of ['hls', 'dash', 'webrtc']) {
    const result = await assessBrowserMedia({ ...media, transport }, { environment: { canPlayType: () => { throw new Error('must not query'); } } });
    assert.equal(result.reason, 'transport-not-assessed'); assert.equal(result.evidence.length, 0);
  }
});

test('different containers require a combined query, not two isolated positive hints', async () => {
  const result = await assessBrowserMedia({ ...media, audio: { ...audio, mimeType: 'audio/webm', codec: 'opus' } }, { environment: { canPlayType: () => 'probably' } });
  assert.equal(result.status, 'unknown');
});

test('decode query timeout is bounded and observes a late rejection', async () => {
  let rejectLate;
  const result = await assessBrowserMedia(media, { timeoutMs: 10, environment: {
    decodingInfo: () => new Promise((resolve, reject) => { rejectLate = reject; }),
  } });
  assert.equal(result.reason, 'query-timeout');
  rejectLate(new Error('late')); await new Promise(resolve => setImmediate(resolve));
});

test('cancellation rejects promptly even when the browser query ignores it', async () => {
  const controller = new AbortController();
  const pending = assessBrowserMedia(media, { signal: controller.signal, environment: {
    decodingInfo: () => new Promise(() => {}),
  } });
  controller.abort('private cancellation reason');
  await assert.rejects(pending, error => error.name === 'AbortError' && !error.message.includes('private'));
  await assert.rejects(assessBrowserMedia(media, { signal: controller.signal }), { name: 'AbortError' });
});

test('input is snapshotted before an async query', async () => {
  const input = structuredClone(media); let configuration;
  const pending = assessBrowserMedia(input, { environment: { decodingInfo: async value => { configuration = value; return supported; } } });
  input.audio.codec = 'ac-3';
  await pending; assert.match(configuration.audio.contentType, /mp4a.40.2/);
});

test('invalid input is rejected and absent tracks have an explicit reason', async () => {
  for (const timeoutMs of [0, -1, Infinity, NaN, 60001]) await assert.rejects(assessBrowserMedia(media, { timeoutMs }), TypeError);
  for (const track of [{ ...video, mimeType: 'video/mp4; codecs="anything"' }, { ...video, codec: 'avc1,secret' }, { ...video, width: NaN }]) {
    await assert.rejects(assessBrowserMedia({ ...media, video: track }), TypeError);
  }
  assert.equal((await assessBrowserMedia({ transport: 'range', video: null, audio: null })).reason, 'no-tracks');
});

test('runtime import and API-free assessment work without a DOM', async () => {
  assert.equal(typeof document, 'undefined');
  assert.equal((await assessBrowserMedia(media)).status, 'unknown');
});

test('container failure and per-track explanations are separate from codec and route hints', async () => {
  const result = await assessBrowserMedia({ ...media, container: { mimeType: 'video/x-matroska' } }, { environment: {
    canPlayType: (kind, type) => type === 'video/x-matroska' ? '' : 'probably',
  } });
  assert.equal(result.status, 'unsupported'); assert.equal(result.suggestedPath, 'compatible-source-or-explicit-host');
  assert.equal(result.checks.find(check => check.target === 'container').status, 'unsupported');
  assert.equal(result.checks.find(check => check.target === 'video').status, 'expected-supported');
});
const hls = { ...media, transport: 'hls', route: 'mse-hls', container: { mimeType: 'video/mp2t' }, mseContainer: { mimeType: 'video/mp4' } };
test('MSE HLS checks the configured adapter and selected codecs with media-source queries', async () => {
  let configuration;
  const result = await assessBrowserMedia(hls, { environment: {
    hlsAdapter: mime => { assert.equal(mime, 'video/mp2t'); return true; },
    isTypeSupported: type => { assert.match(type, /mp4/); return true; },
    decodingInfo: async input => { configuration = input; return supported; },
    canPlayType: () => { throw new Error('MSE must not use file canPlayType'); },
  } });
  assert.equal(result.status, 'expected-supported'); assert.equal(configuration.type, 'media-source');
  assert.ok(result.evidence.some(item => item.api === 'isTypeSupported' && item.target === 'audio'));
});
test('a running HLS framework never manufactures missing audio or unknown codec support', async () => {
  const environment = { hlsAdapter: () => true, isTypeSupported: type => !type.includes('ac-3') };
  assert.equal((await assessBrowserMedia({ ...hls, audio: { ...audio, codec: 'ac-3' } }, { environment })).status, 'unsupported');
  assert.equal((await assessBrowserMedia({ ...hls, video: { ...video, codec: undefined } }, { environment })).status, 'unknown');
  assert.equal((await assessBrowserMedia(hls, { environment: { isTypeSupported: () => true } })).reason, 'path-not-configured');
  assert.equal((await assessBrowserMedia({ ...hls, mseContainer: undefined }, { environment })).reason, 'path-not-configured');
});
test('native HLS and MSE HLS are explicit independent routes', async () => {
  const result = await assessBrowserMedia({ ...media, transport: 'hls', route: 'native-hls' }, { environment: {
    canPlayType: (kind, type) => type.includes('mpegurl') ? '' : 'probably',
  } });
  assert.equal(result.status, 'unsupported');
  assert.equal(result.checks.find(check => check.target === 'path').status, 'unsupported');
});

for (const subtype of ['mp2t', 'mp4']) test(`native HLS ${subtype} does not consume file capability evidence`, async () => {
  const calls = [];
  const result = await assessBrowserMedia({ ...media, transport: 'hls', route: 'native-hls',
    container: { mimeType: `video/${subtype}` },
    video: { ...media.video, mimeType: `video/${subtype}` }, audio: { ...audio, mimeType: `audio/${subtype}` },
  }, { environment: {
    canPlayType: (kind, type) => { calls.push(type); return type.includes('mpegurl') ? 'probably' : ''; },
    decodingInfo: async () => { assert.fail('Native HLS must not use file decodingInfo'); },
  } });
  assert.deepEqual(calls, ['application/vnd.apple.mpegurl']);
  assert.equal(result.status, 'unknown');
  assert.equal(result.checks.find(check => check.target === 'path').status, 'expected-supported');
  for (const target of ['container', 'video', 'audio', 'combined']) {
    assert.equal(result.checks.find(check => check.target === target).status, 'unknown');
  }
});
