/**
 * U1 判据3（依赖独立）的类型探针。
 *
 * 口径见 docs/audio-video/player/03-后端与引擎边界.md 第 7 节：只取 `core` 与 `contracts` 的消费者
 * 必须能在不安装具体引擎的前提下构建并通过类型检查。
 *
 * tests/tsconfig.core-only.json 用包自引用解析 `@studio/player/core` 与
 * `@studio/player/contracts`，并用 `paths` 把 `@videojs/*` 指向不存在的 `./__absent__/*`。
 * 实测（记录在 docs/audio-video/player/04-进度与交接.md 第 3 节）：在 `moduleResolution: NodeNext` 下
 * 该映射**不阻断** node_modules 回落——`@videojs/*` 仍然会被解析到 node_modules。因此本探针
 * 今天成立，靠的是「`dist` 的类型图根本没有走到 `@videojs/*`」：没有导入，上游声明就不会被
 * 加载；一旦加载，上游声明自身的缺陷会立刻让它变红。
 * 反向验证：临时加一行 `import type {} from '@videojs/html';` → exit 2、18 条 TS2417/TS2694。
 * 本文件只做检查，不参与运行时；它不是 core-only 打包检查的替代。
 */
import { StudioPlayer } from '@studio/player/core';
import type { PlayableInput, ProgressStoragePort } from '@studio/player/contracts';
import { isPlaybackPlan } from '@studio/player/contracts';

/** 宿主注入的进度存储：实现 ProgressStoragePort，不引入任何引擎依赖。 */
const progressStorage: ProgressStoragePort = {
  load: (resourceId: string) => (resourceId ? { positionSeconds: 12, durationSeconds: 600, updatedAt: 0 } : null),
  save: (resourceId: string, positionSeconds: number, durationSeconds?: number) => {
    void [resourceId, positionSeconds, durationSeconds];
  },
  clear: (resourceId: string) => { void resourceId; },
};

const planInput: PlayableInput = {
  resourceId: 'episode-1',
  mediaType: 'video',
  strategy: 'direct',
  transport: 'hls',
  playUrl: '/master.m3u8',
  mimeType: 'application/vnd.apple.mpegurl',
};

const simpleInput: PlayableInput = { src: '/episode.mp3', type: 'audio/mpeg', resourceId: 'episode-2' };

/** 只用 core + contracts 的消费者：构造播放器、加载来源、读进度控制器。 */
export async function coreOnlyConsumer(element: HTMLMediaElement): Promise<number> {
  const player = new StudioPlayer({ progressStorage, nativeElementTag: 'video' });
  player.attach(element);
  const loaded = await player.load(planInput);
  const resourceId: string = loaded.resourceId;
  const loadedUrl: string = loaded.source.src;
  void loadedUrl;
  if (isPlaybackPlan(simpleInput)) throw new Error('simple media source must not be a playback plan');
  await player.load(simpleInput, { restart: true });
  player.replaceSource(planInput);
  const position: number = player.currentTime;
  const progress = player.progressController;
  progress?.recordProgress(resourceId, position, 600, false);
  const resumePosition = progress ? await progress.getResumePosition(resourceId, 600) : 0;
  player.destroy();
  return resumePosition;
}

void [planInput, simpleInput, coreOnlyConsumer];



