import test from 'node:test';
import assert from 'node:assert/strict';
import { setup, plan, settle, Clock } from './helpers.mjs';
import { QueueController } from '../dist/queue/index.js';
import { SleepTimerController } from '../dist/sleep-timer/index.js';
import { installFlvPlayback } from '../dist/flv/index.js';
import { applyDelivery, releaseDelivery } from '../dist/backends/videojs/element.js';
import { FlvFetchLoader } from '../dist/flv/loader.js';

test('live ignores finite windows/checkpoints, resumes at the live edge and keeps VOD progress intact',async t=>{
  const writes=[],reads=[];
  const {player,media}=setup(t,{progressStorage:{load:id=>{reads.push(id);return 40;},save:(...v)=>writes.push(v),clear:id=>writes.push(id)}});
  await player.load(plan('live',{live:true}));await settle();assert.equal(player.duration,Infinity);assert.deepEqual(reads,[]);
  media.seekable={length:1,start:()=>100,end:()=>120};await player.play();assert.equal(media.currentTime,118);
  player.seek(0);await player.seekAsync(2);assert.equal(media.currentTime,118);
  player.setPlaybackRate(2);assert.equal(player.playbackRate,1);
  media.trigger('timeupdate');await player.stopAndReset();assert.deepEqual(writes,[]);
  await player.load(plan('vod'));await settle();assert.deepEqual(reads,['vod']);
});

test('live recovery starts a current session without restoring an old time, and completion cannot advance a VOD queue',async t=>{
  const contexts=[];const {player,media}=setup(t,{sourceResolver:{recoverSource:(_id,_plan,context)=>{contexts.push(context);return plan('live',{live:true,playUrl:'fresh.mp4'});}}});
  const queue=new QueueController(player);t.after(()=>queue.destroy());
  queue.setItems([{id:'live',source:plan('live',{live:true})},{id:'vod',source:plan('vod')}]);
  await queue.select(0);media.currentTime=1000;media.trigger('error');await settle();await settle();
  assert.equal(contexts[0].positionSeconds,0);assert.equal(player.currentTime,0);assert.equal(player.currentPlan.live,true);
  media.finish();await settle();await settle();assert.equal(queue.snapshot.current.id,'live');
});

test('live supports countdown sleep with full stop, and rejects finite-item triggers',async t=>{
  const {player,media}=setup(t);const clock=new Clock();const sleep=new SleepTimerController(player,{clock,visibilityTarget:null,pageTarget:null});t.after(()=>sleep.destroy());
  await player.load(plan('live',{live:true}));await player.play();
  for(const trigger of [{type:'items',count:1},{type:'current'}])assert.throws(()=>sleep.start({trigger}),/duration sleep only/);
  sleep.start({trigger:{type:'duration',durationMs:1000},action:'stop'});clock.jump(1001);await settle();assert.equal(player.state,'stopped');assert.equal(media.src,'');
});

test('optional FLV engine owns the existing target and cannot attach after stop or replace a newer source',async()=>{
  const target={removeAttribute(){},load(){},pause(){}};
  const element=Object.assign(new EventTarget(),{localName:'hlsjs-video',source:null,target,removeAttribute(){}});
  let created=0,destroyed=0,attached;
  const runtime={isSupported:()=>true,Events:{ERROR:'error'},createPlayer:()=>{created++;return{on(){},off(){},load(){},unload(){},attachMediaElement(media){attached=media;},detachMediaElement(){},destroy(){destroyed++;}};}};
  const uninstall=installFlvPlayback(element,runtime),flv={src:'/live',transport:'flv',type:'video/x-flv',live:true};
  applyDelivery(element,flv,'native');releaseDelivery(element);await Promise.resolve();assert.equal(created,0);
  applyDelivery(element,flv,'native');await Promise.resolve();assert.equal(created,1);assert.equal(attached,target);
  applyDelivery(element,{src:'vod.mp4',type:'video/mp4'},'native');await Promise.resolve();assert.equal(destroyed,1);assert.equal(element.source.src,'vod.mp4');
  applyDelivery(element,flv,'native');applyDelivery(element,{src:'new.mp4',type:'video/mp4'},'native');await Promise.resolve();assert.equal(created,1);
  uninstall();assert.throws(()=>applyDelivery(element,flv,'native'),/not installed/);
});

test('FLV fetch cancellation suppresses late EOF after destroy while active network failure remains observable',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);
  let resolveFetch,streamController,cancelled=0;const callbacks=[];
  globalThis.fetch=async()=>new Promise(resolve=>resolveFetch=resolve);
  const loader=new FlvFetchLoader({getConfig:url=>({url})},{});
  loader.onDataArrival=()=>callbacks.push('data');loader.onError=()=>callbacks.push('error');loader.onComplete=()=>callbacks.push('complete');
  loader.open({url:'http://localhost/live'},{from:0,to:-1});loader.destroy();
  resolveFetch(new Response(new ReadableStream({cancel(){cancelled++;}})));await settle();assert.equal(cancelled,1);assert.deepEqual(callbacks,[]);
  globalThis.fetch=async()=>new Response(new ReadableStream({start(c){streamController=c;c.enqueue(new Uint8Array([70,76,86]));},cancel(){cancelled++;}}));
  loader.onDataArrival=()=>callbacks.push('data');loader.onError=()=>callbacks.push('error');loader.onComplete=()=>callbacks.push('complete');
  loader.open({url:'http://localhost/live'},{from:0,to:-1});await settle();assert.deepEqual(callbacks,['data']);loader.destroy();await settle();assert.deepEqual(callbacks,['data']);assert.equal(cancelled,2);
  globalThis.fetch=async()=>{throw new Error('network');};loader.onError=()=>callbacks.push('error');
  loader.open({url:'http://localhost/live'},{from:0,to:-1});await settle();assert.deepEqual(callbacks,['data','error']);loader.destroy();
});
