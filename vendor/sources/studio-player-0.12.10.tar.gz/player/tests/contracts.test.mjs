import test from 'node:test';
import assert from 'node:assert/strict';
import {
  adaptPlayableToSource,
  inferMediaMimeType,
  isSameVideojsSource,
  toVideojsSource,
  SourceController,
  ProgressController,
  StudioPlayer,
  DEFAULT_PROGRESS_POLICY,
} from '../dist/index.js';

function deferredWrite() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
}

// 新回归使用 EventTarget，确保移除监听和来源重置与真实媒体的关键语义一致。
class TestMedia extends EventTarget {
  localName = 'video'; src = ''; currentTime = 0; duration = 100;
  paused = true; ended = false;
  canPlayType(type) { return type === 'video/mp4' ? 'probably' : ''; }
  load() { this.currentTime = 0; this.paused = true; this.ended = false; }
  play() { this.paused = false; this.ended = false; this.trigger('play'); return Promise.resolve(); }
  pause() { this.paused = true; this.trigger('pause'); }
  removeAttribute(name) { if (name === 'src') this.src = ''; }
  trigger(name) { this.dispatchEvent(new Event(name)); }
}

const playbackPlan = (resourceId, extra = {}) => ({
  resourceId, mediaType: 'video', strategy: 'direct', transport: 'range',
  playUrl: `${resourceId}.mp4`, ...extra,
});
const settle = () => new Promise(resolve => setImmediate(resolve));

test('32. StudioPlayer: failed pending play retains intent across fallback without stored resume', async () => {
  const handlers = new Map();
  let rejectPrimary;
  let calls = 0;
  const media = {
    localName: 'video', src: '', currentTime: 0, duration: 100, paused: true, ended: false,
    canPlayType: () => 'maybe', load() {}, removeAttribute() {}, pause() { this.paused = true; },
    play() {
      calls++;
      if (calls === 1) return new Promise((_, reject) => { rejectPrimary = reject; });
      this.paused = false;
      return Promise.resolve();
    },
    addEventListener(name, fn) { handlers.set(name, fn); },
    removeEventListener(name) { handlers.delete(name); },
  };
  const player = new StudioPlayer({ autoResume: false });
  player.attach(media);
  await player.load({ resourceId: 'fallback-intent', mediaType: 'video', strategy: 'direct', transport: 'range', playUrl: 'bad.mp4', fallbackUrl: 'good.mp4' });
  const cancelled = assert.rejects(player.play(), { name: 'AbortError' });
  handlers.get('error')(new Error('primary failed before playing'));
  rejectPrimary(Object.assign(new Error('no supported source'), { name: 'NotSupportedError' }));
  await cancelled;
  handlers.get('loadedmetadata')();
  await Promise.resolve();
  assert.equal(calls, 2);
  assert.equal(media.paused, false);
  assert.equal(media.src, 'good.mp4');
  player.destroy();
});

test('33. StudioPlayer: explicit pause cancels pending fallback playback intent', async () => {
  const handlers = new Map();
  let calls = 0;
  const media = {
    localName: 'video', src: '', currentTime: 5, duration: 100, paused: false, ended: false,
    canPlayType: () => 'maybe', load() {}, removeAttribute() {},
    pause() { this.paused = true; }, play() { calls++; return Promise.resolve(); },
    addEventListener(name, fn) { handlers.set(name, fn); }, removeEventListener(name) { handlers.delete(name); },
  };
  const player = new StudioPlayer(); player.attach(media);
  await player.load({ resourceId: 'pause-intent', mediaType: 'video', strategy: 'direct', transport: 'range', playUrl: 'a.mp4', fallbackUrl: 'b.mp4' });
  await player.play();
  player.switchToFallback();
  player.pause();
  handlers.get('loadedmetadata')();
  await Promise.resolve();
  assert.equal(calls, 1);
  player.destroy();
});

test('34. StudioPlayer: current autoplay rejection remains NotAllowedError', async () => {
  const player = new StudioPlayer();
  const error = Object.assign(new Error('user gesture required'), { name: 'NotAllowedError' });
  player.attach({ localName: 'video', play: () => Promise.reject(error), pause() {} });
  await assert.rejects(player.play(), candidate => candidate === error);
  player.destroy();
});

test('35. StudioPlayer: fallback at position zero restores the persisted resume point', async () => {
  const handlers = new Map();
  let rejectPrimary;
  let playCalls = 0;
  let currentSrc = '';
  const media = {
    localName: 'video',
    get src() { return currentSrc; },
    set src(value) { currentSrc = value; this.currentTime = 0; this.paused = true; },
    currentTime: 0,
    duration: 100,
    paused: true,
    ended: false,
    canPlayType: () => 'maybe',
    load() {},
    removeAttribute() {},
    pause() { this.paused = true; },
    play() {
      playCalls += 1;
      if (playCalls === 1) {
        return new Promise((_, reject) => { rejectPrimary = reject; });
      }
      this.paused = false;
      return Promise.resolve();
    },
    addEventListener(name, fn) { handlers.set(name, fn); },
    removeEventListener(name, fn) {
      if (handlers.get(name) === fn) handlers.delete(name);
    },
    trigger(name, data) { handlers.get(name)?.(data); },
  };
  const stored = {
    'fallback-stored-resume': {
      positionSeconds: 42,
      durationSeconds: 100,
      updatedAt: Date.now(),
    },
  };
  const player = new StudioPlayer({
    progressStorage: {
      load: id => stored[id],
      async save() {},
      async clear() {},
    },
  });
  player.attach(media);

  await player.load({
    resourceId: 'fallback-stored-resume',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'bad.mp4',
    fallbackUrl: 'good.mp4',
  });

  const pendingPlay = assert.rejects(player.play(), { name: 'AbortError' });
  media.trigger('error', new Error('primary failed before playback started'));
  rejectPrimary(Object.assign(new Error('no supported source'), { name: 'NotSupportedError' }));
  await pendingPlay;

  media.trigger('loadedmetadata');
  await new Promise(resolve => setTimeout(resolve, 0));

  assert.equal(media.src, 'good.mp4');
  assert.equal(media.currentTime, 42, '位置 0 不能阻止读取已保存的断点');
  assert.equal(media.paused, false, '原本的播放意图应在恢复断点后继续');
  assert.equal(playCalls, 2);
  player.destroy();
});

test('26. StudioPlayer: latest load wins while old progress is saving', async () => {
  const gate = deferredWrite();
  const player = new StudioPlayer({ progressStorage: {
    load: () => null, save: () => gate.promise, clear() {},
  }});
  const sources = [];
  player.on('sourcechange', source => sources.push(source.src));
  player.progressController.recordProgress('old', 20, 100, false);
  const first = player.load('a.mp4');
  const rejected = assert.rejects(first, { name: 'AbortError' });
  const second = player.load('b.mp4');
  gate.resolve();
  await Promise.all([rejected, second]);
  assert.equal(player.currentResourceId, 'b.mp4');
  assert.deepEqual(sources, ['b.mp4']);
  player.destroy();
});

test('27. StudioPlayer: destroy invalidates a pending load', async () => {
  const gate = deferredWrite();
  const player = new StudioPlayer({ progressStorage: {
    load: () => null, save: () => gate.promise, clear() {},
  }});
  player.progressController.recordProgress('old', 20, 100, false);
  const rejected = assert.rejects(player.load('a.mp4'), { name: 'AbortError' });
  player.destroy();
  gate.resolve();
  await rejected;
  assert.equal(player.currentResourceId, null);
  assert.equal(player.state, 'idle');
  await assert.rejects(player.load('b.mp4'), { name: 'AbortError' });
});

test('28. ProgressController: clear waits for old saves and later saves follow clear', async () => {
  const saveGate = deferredWrite();
  const clearGate = deferredWrite();
  let stored = null;
  const calls = [];
  const controller = new ProgressController({
    load: () => stored,
    async save(id, pos) {
      calls.push(`save:${id}:${pos}`);
      if (id === 'x' && pos === 50) await saveGate.promise;
      stored = pos;
    },
    async clear() { calls.push('clear'); await clearGate.promise; stored = null; },
  });
  controller.recordProgress('x', 50, 100, false);
  const first = controller.flush();
  const clearing = controller.clearProgress('x');
  assert.deepEqual(calls, ['save:x:50']);
  saveGate.resolve(); await first;
  assert.deepEqual(calls, ['save:x:50', 'clear']);
  controller.recordProgress('x', 60, 100, false);
  const second = controller.flush();
  assert.equal(calls.length, 2, 'new save must wait for clear');
  clearGate.resolve();
  await Promise.all([clearing, second]);
  assert.equal(stored, 60);
  await controller.clearProgress('x');
  assert.equal(stored, null);
  controller.destroy();
});

test('29. ProgressController: natural completion queues clear behind in-flight save', async () => {
  const gate = deferredWrite();
  let stored = null;
  const controller = new ProgressController({
    load: () => stored,
    async save(_id, pos) { await gate.promise; stored = pos; },
    clear() { stored = null; },
  });
  controller.recordProgress('x', 89, 100, true);
  const first = controller.flush();
  controller.recordProgress('x', 90, 100, true);
  controller.recordProgress('x', 95, 100, true);
  controller.recordProgress('x', 100, 100, 'paused');
  const finishing = controller.flush();
  gate.resolve();
  await Promise.all([first, finishing]);
  assert.equal(stored, null);
  controller.destroy();
});

test('30. ProgressController: failed writes do not block clear or independent resources', async () => {
  const gate = deferredWrite();
  const values = new Map();
  const controller = new ProgressController({
    load: id => values.get(id),
    save(id, pos) {
      if (id === 'sync-error') throw new Error('storage unavailable');
      if (id === 'slow') return gate.promise.then(() => { throw new Error('async failure'); });
      values.set(id, pos);
    },
    clear(id) { values.delete(id); },
  });
  controller.recordProgress('slow', 20, 100, false);
  const first = controller.flush();
  controller.recordProgress('independent', 30, 100, false);
  const second = controller.flush();
  assert.equal(values.get('independent'), 30);
  controller.recordProgress('sync-error', 40, 100, false);
  const third = controller.flush();
  const clearing = controller.clearProgress('slow');
  gate.resolve();
  await Promise.all([first, second, third, clearing]);
  assert.equal(values.has('slow'), false);
  controller.destroy();
});

test('31. StudioPlayer: metadata updates preserve active and terminal states', async () => {
  class Media extends EventTarget {
    localName = 'video'; src = ''; duration = 100;
    currentTime = 0; paused = true; ended = false;
    canPlayType() { return 'maybe'; }
    load() {} pause() { this.paused = true; } removeAttribute() {}
  }
  const media = new Media(); const player = new StudioPlayer();
  player.attach(media); await player.load('x.mp4');
  media.dispatchEvent(new Event('durationchange'));
  assert.equal(player.state, 'ready');
  for (const [event, expected] of [['play', 'playing'], ['pause', 'paused'], ['ended', 'ended'], ['error', 'error']]) {
    media.paused = event !== 'play';
    media.ended = event === 'ended';
    media.dispatchEvent(new Event(event));
    media.dispatchEvent(new Event('durationchange'));
    media.dispatchEvent(new Event('loadedmetadata'));
    assert.equal(player.state, expected);
  }
  assert.equal(player.failed, true);
  player.destroy();
});

test('1. inferMediaMimeType: correctly deduces stream types', () => {
  assert.equal(inferMediaMimeType('https://example.com/live/playlist.m3u8'), 'application/vnd.apple.mpegurl');
  assert.equal(inferMediaMimeType('https://example.com/api/hls/123/stream.m3u8?token=abc'), 'application/vnd.apple.mpegurl');
  assert.equal(inferMediaMimeType('https://example.com/api/hls/123/stream.bin'), undefined);
  assert.equal(inferMediaMimeType('https://example.com/video/movie.mp4?sign=xyz'), 'video/mp4');
  assert.equal(inferMediaMimeType('https://example.com/audio/song.mp3'), 'audio/mpeg');
  assert.equal(inferMediaMimeType('https://example.com/unknown', 'hls'), 'application/vnd.apple.mpegurl');
  // Declared MIME overrides deduction
  assert.equal(inferMediaMimeType('https://example.com/stream', undefined, 'custom/mime'), 'custom/mime');
});

test('2. adaptPlayableToSource: maps canonical PlaybackPlan to Video.js source', () => {
  const plan = {
    resourceId: 'res-mediadock-001',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'hls',
    playUrl: 'http://127.0.0.1:8000/api/hls/movie-001/master.m3u8?token=sign123',
    fallbackUrl: 'http://127.0.0.1:8000/api/stream/movie-001/transcode',
    expiresAt: Date.now() + 3600 * 1000,
    resumePositionSeconds: 125,
    timeouts: { connect: 10, stall: 15 },
    headers: {
      'X-Studio-Client': 'Desktop-Link',
      'Authorization': 'Bearer test-token'
    }
  };

  const adapted = adaptPlayableToSource(plan);

  assert.equal(adapted.resourceId, 'res-mediadock-001');
  assert.equal(adapted.originalPlan.resumePositionSeconds, 125);
  assert.equal(adapted.fallbackUrl, plan.fallbackUrl);
  assert.equal(adapted.source.src, plan.playUrl);
  assert.equal(adapted.source.type, 'application/vnd.apple.mpegurl');
  assert.equal(adapted.carrier, 'managed');

  // Verify headers passed to xhrSetup（带请求头的注入只发生在受管承载的 Video.js 描述上）
  const videojsSource = toVideojsSource(adapted.source, adapted.carrier);
  assert.ok(videojsSource.engine?.hlsJs?.xhrSetup);
  const mockXhr = {
    headers: {},
    setRequestHeader(k, v) { this.headers[k] = v; }
  };
  videojsSource.engine.hlsJs.xhrSetup(mockXhr);
  assert.equal(mockXhr.headers['X-Studio-Client'], 'Desktop-Link');
  assert.equal(mockXhr.headers['Authorization'], 'Bearer test-token');
  // 等价判定按对象身份比较 engine：同一份描述与自身等价，重复组装出的新 engine 不等价。
  assert.equal(isSameVideojsSource(videojsSource, videojsSource), true);
  assert.equal(isSameVideojsSource(videojsSource, toVideojsSource(adapted.source, adapted.carrier)), false,
    '每份 Video.js 描述有各自的 engine 对象，等价判定必须按身份而不是按值');
  assert.equal(isSameVideojsSource(null, videojsSource), false);
});

test('3. adaptPlayableToSource: supports degradation to SimpleMediaSource and string', () => {
  const simpleObj = {
    src: 'https://example.com/audio.mp3',
    title: 'Test Audio'
  };
  const adaptedObj = adaptPlayableToSource(simpleObj);
  assert.equal(adaptedObj.source.src, 'https://example.com/audio.mp3');
  assert.equal(adaptedObj.source.type, 'audio/mpeg');

  const rawString = 'https://example.com/video.mp4';
  const adaptedString = adaptPlayableToSource(rawString);
  assert.equal(adaptedString.source.src, rawString);
  assert.equal(adaptedString.source.type, 'video/mp4');

  const nativeWithHeaders = adaptPlayableToSource({
    src: 'https://example.com/video.mp4',
    type: 'video/mp4',
    headers: { Authorization: 'Bearer test-token' },
  });
  assert.equal(nativeWithHeaders.carrier, 'native');
  assert.equal(toVideojsSource(nativeWithHeaders.source, nativeWithHeaders.carrier).engine, undefined,
    '原生承载没有任意请求头注入能力，不得伪装成支持 headers');
});

test('4. SourceController: manages plan lifecycle and fallback', () => {
  const plan = {
    resourceId: 'res-fallback-001',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/primary.mp4',
    fallbackUrl: 'https://backup.example.com/secondary.mp4',
    expiresAt: Date.now() + 30 * 1000, // 30s remaining (< 60s)
  };

  const controller = new SourceController();
  controller.loadInput(plan);

  assert.equal(controller.getCurrentResourceId(), 'res-fallback-001');
  assert.equal(controller.getCurrentSource()?.src, 'https://cdn.example.com/primary.mp4');
  assert.equal(controller.isNearExpiry(60), true);

  // Switch to fallback
  const fallbackResult = controller.switchToFallback();
  assert.ok(fallbackResult);
  assert.equal(controller.getCurrentSource()?.src, 'https://backup.example.com/secondary.mp4');
  assert.equal(controller.getCurrentPlan()?.strategy, 'fallback');
  assert.equal(controller.getCurrentPlan()?.fallbackUrl, undefined); // Prevent infinite fallback

  controller.destroy();
});

test('5. SourceController: supports a fallback with independent transport metadata', () => {
  const controller = new SourceController();
  controller.loadInput({
    resourceId: 'res-cross-transport',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/primary.m3u8',
    fallback: {
      playUrl: 'https://backup.example.com/secondary.mp4',
      transport: 'range',
      mimeType: 'video/mp4',
    },
  });

  const fallbackResult = controller.switchToFallback();
  assert.ok(fallbackResult);
  assert.equal(fallbackResult.source.src, 'https://backup.example.com/secondary.mp4');
  assert.equal(fallbackResult.source.type, 'video/mp4');
  assert.equal(fallbackResult.originalPlan.transport, 'range');
  assert.equal(fallbackResult.originalPlan.strategy, 'fallback');
  controller.destroy();
});

test('6. SourceController: discards stale refreshes and closes replaced sessions', async () => {
  const closedSessions = [];
  let resolveRefresh;
  const resolver = {
    resolveUrl() {
      return new Promise((resolve) => {
        resolveRefresh = resolve;
      });
    },
    onSessionClose(endpoint) {
      closedSessions.push(endpoint);
    },
  };

  const controller = new SourceController(resolver);
  controller.loadInput({
    resourceId: 'resource-a',
    mediaType: 'video',
    strategy: 'transcode',
    transport: 'hls',
    playUrl: 'https://example.com/a.m3u8',
    processing: { available: true, sessionEndpoint: '/session/a' },
  });

  const refresh = controller.refreshSource('expired');
  controller.loadInput({
    resourceId: 'resource-b',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://example.com/b.mp4',
    processing: { available: true, sessionEndpoint: '/session/b' },
  });

  resolveRefresh('https://example.com/a-refreshed.m3u8');
  assert.equal(await refresh, null);
  assert.equal(controller.getCurrentResourceId(), 'resource-b');
  assert.deepEqual(closedSessions, ['/session/a']);

  controller.destroy();
  assert.deepEqual(closedSessions, ['/session/a', '/session/b']);
});

test('7. ProgressController: calculates resume position correctly', () => {
  const storageMock = {
    data: {},
    async load(id) { return this.data[id]; },
    async save(id, pos) { this.data[id] = pos; },
    async clear(id) { delete this.data[id]; }
  };

  const controller = new ProgressController(storageMock);

  // 1. < 5s -> should start from 0
  assert.equal(controller.calculateResumePosition(3, 100), 0);
  assert.equal(controller.calculateResumePosition(4.9, 100), 0);

  // 2. Normal position -> resumes accurately (number and ProgressRecord)
  assert.equal(controller.calculateResumePosition(50, 100), 50);
  assert.equal(controller.calculateResumePosition({ positionSeconds: 50, updatedAt: 1726000000 }, 100), 50);

  // 3. > 95% -> should start from 0 (completed)
  assert.equal(controller.calculateResumePosition(96, 100), 0);
  assert.equal(controller.calculateResumePosition({ positionSeconds: 96, updatedAt: 1726000000 }, 100), 0);

  // 4. Remaining < 10s -> should start from 0 (completed)
  assert.equal(controller.calculateResumePosition(92, 100), 0);
});

test('8. ProgressController: records progress and cleans up upon completion', async () => {
  const savedRecords = {};
  const storageMock = {
    data: { 'res-1': 50 },
    async load(id) { return this.data[id]; },
    async save(id, pos, dur, record) {
      this.data[id] = pos;
      savedRecords[id] = record;
    },
    async clear(id) {
      delete this.data[id];
      delete savedRecords[id];
    }
  };

  const controller = new ProgressController(storageMock, { saveDebounceMs: 50 });

  // Record normal progress
  controller.recordProgress('res-1', 65, 200);
  await controller.flush();
  assert.equal(storageMock.data['res-1'], 65);
  assert.ok(savedRecords['res-1']?.updatedAt > 0);
  assert.equal(savedRecords['res-1']?.positionSeconds, 65);

  // 从阈值前自然越过完播边界（而不是 seek 到尾部）才清空
  controller.recordProgress('res-1', 188, 200, true);
  controller.recordProgress('res-1', 191, 200, true);
  // Wait a tick for promise
  await new Promise(r => setTimeout(r, 10));
  assert.equal(storageMock.data['res-1'], undefined); // Cleared!

  controller.destroy();
});

test('9. StudioPlayer: handles media events, progress recording, and auto-fallback', async () => {
  const storageMock = {
    data: { 'res-video-1': 120 },
    async load(id) { return this.data[id]; },
    async save(id, pos) { this.data[id] = pos; },
    async clear(id) { delete this.data[id]; }
  };

  // 模拟一个 HTMLMediaElement
  const listeners = {};
  const mockMedia = {
    localName: 'video',
    src: '',
    currentTime: 0,
    duration: 300,
    paused: true,
    addEventListener(event, fn) {
      if (!listeners[event]) listeners[event] = [];
      listeners[event].push(fn);
    },
    removeEventListener(event, fn) {
      if (listeners[event]) {
        listeners[event] = listeners[event].filter(f => f !== fn);
      }
    },
    trigger(event, data) {
      listeners[event]?.forEach(fn => fn(data));
    },
    play() { this.paused = false; this.trigger('play'); },
    pause() { this.paused = true; this.trigger('pause'); }
  };

  const player = new StudioPlayer({
    progressStorage: storageMock,
    progressPolicy: { saveDebounceMs: 20 }
  });

  player.attach(mockMedia);

  // 1. 加载播放计划
  const plan = {
    resourceId: 'res-video-1',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/movie.mp4',
    fallbackUrl: 'https://backup.example.com/movie.mp4',
    durationSeconds: 300
  };

  await player.load(plan);
  assert.equal(mockMedia.src, 'https://cdn.example.com/movie.mp4');

  // 2. 模拟 metadata 加载触发自动断点恢复
  mockMedia.trigger('loadedmetadata');
  await new Promise(r => setTimeout(r, 10));
  assert.equal(mockMedia.currentTime, 120); // 成功恢复到 120 秒！

  // 3. 模拟播放与进度记录
  mockMedia.currentTime = 150;
  mockMedia.trigger('timeupdate');
  mockMedia.trigger('pause'); // pause 触发立即 flush
  await new Promise(r => setTimeout(r, 10));
  assert.equal(storageMock.data['res-video-1'], 150);

  // 4. 模拟播放遇到致命错误 -> 自动触发 fallback
  let fallbackEventTriggered = false;
  player.on('fallback', (source) => {
    fallbackEventTriggered = true;
  });

  mockMedia.trigger('error', new Error('Network timeout'));
  assert.equal(fallbackEventTriggered, true);
  assert.equal(mockMedia.src, 'https://backup.example.com/movie.mp4');

  // 5. 模拟播放结束 -> 自动清除进度
  mockMedia.ended = true;
  mockMedia.trigger('ended');
  await new Promise(r => setTimeout(r, 10));
  assert.equal(storageMock.data['res-video-1'], undefined);

  player.destroy();
});

test('10. Edge Cases: short media progress retention and blob source adaptation', async () => {
  // 1. 短媒体（15秒）在第 6 秒不会被当成完播清空
  const storageMock = {
    data: {},
    async load(id) { return this.data[id]; },
    async save(id, pos) { this.data[id] = pos; },
    async clear(id) { delete this.data[id]; }
  };

  const controller = new ProgressController(storageMock, { saveDebounceMs: 20 });
  controller.recordProgress('short-15s', 6, 15);
  await controller.flush();
  assert.equal(storageMock.data['short-15s'], 6); // 应当保留，不被清空！

  // 计算断点恢复：6 秒应当精准返回 6 秒，不归零
  const resumePos = controller.calculateResumePosition(6, 15);
  assert.equal(resumePos, 6);

  // 2. Blob 本地文件输入：能自动推导出 video/mp4 并使用原生承载
  const blobPlan = {
    resourceId: 'local-file-my_clip.mp4',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'blob:http://127.0.0.1:8188/d8e7-mock-blob',
    durationSeconds: 0,
    metadata: { name: 'my_clip.mp4' }
  };
  const adapted = adaptPlayableToSource(blobPlan);
  assert.equal(adapted.source.type, 'video/mp4');
  assert.equal(adapted.carrier, 'native'); // 避免被错误识别为 HLS

  controller.destroy();
});

test('11. ProgressController: throttles saves during continuous playback to avoid progress loss', async () => {
  const saveCalls = [];
  const storageMock = {
    async load() { return null; },
    async save(id, pos, dur, record) {
      saveCalls.push({ id, pos, dur, record });
    },
    async clear() {}
  };

  // 节流间隔 40ms，防抖 100ms
  const controller = new ProgressController(storageMock, {
    saveDebounceMs: 100,
    saveThrottleIntervalMs: 40,
  });

  // 模拟连续播放（每 10ms 触发一次 timeupdate，快于 100ms 防抖，防抖本应永远无法触发）
  controller.recordProgress('continuous-vid', 1, 100);
  await new Promise(r => setTimeout(r, 10));
  controller.recordProgress('continuous-vid', 2, 100);
  await new Promise(r => setTimeout(r, 15));
  controller.recordProgress('continuous-vid', 3, 100);
  await new Promise(r => setTimeout(r, 20)); // 总耗时已超 45ms (> 40ms 节流间隔)

  // 此处触发应该命中节流心跳落盘！
  controller.recordProgress('continuous-vid', 4, 100);
  await new Promise(r => setTimeout(r, 10));

  assert.ok(saveCalls.length >= 1, '持续播放时节流心跳落盘应当被成功触发');
  assert.ok(saveCalls[0].pos >= 1, '节流保存的进度应当有效');
  assert.ok(saveCalls[0].record?.updatedAt > 0, '节流保存应包含时间戳');

  controller.destroy();
});

// ——— 阶段 4 补全回归：P1-1 / P1-3 / P1-4 / P1-5 ———

test('12. StudioPlayer: applies a fallback source exactly once (P1-1)', async () => {
  let srcSetCount = 0;
  let loadCount = 0;
  const media = {
    localName: 'video',
    _src: '',
    get src() { return this._src; },
    set src(value) { this._src = value; srcSetCount += 1; },
    currentTime: 0,
    duration: 100,
    paused: true,
    canPlayType: () => 'probably',
    addEventListener() {},
    removeEventListener() {},
    load() { loadCount += 1; },
    play() { return Promise.resolve(); },
    pause() {},
  };

  const player = new StudioPlayer({});
  player.attach(media);
  await player.load({
    resourceId: 'res-once',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/primary.mp4',
    fallbackUrl: 'https://cdn.example.com/secondary.mp4',
  });

  assert.equal(srcSetCount, 1, '初始加载只应赋值一次 src');
  assert.equal(loadCount, 1, '初始加载只应触发一次 load()');

  const sourceChangeEvents = [];
  player.on('sourcechange', (source) => sourceChangeEvents.push(source.src));

  assert.equal(player.switchToFallback(), true);
  assert.equal(srcSetCount, 2, '回退时不应重复应用来源（每个来源恰好一次）');
  assert.equal(loadCount, 2);
  assert.equal(sourceChangeEvents.length, 1, '回退只应触发一次 sourcechange');

  player.destroy();
});

test('13. SourceController: refreshes a near-expiry source once (P1-2)', async () => {
  const reasons = [];
  const controller = new SourceController({
    resolver: {
      async resolveUrl(_resourceId, _plan, reason) {
        reasons.push(reason);
        return 'https://cdn.example.com/refreshed.m3u8';
      },
    },
    expiryCheckIntervalMs: 30,
    expiryBufferSeconds: 60,
  });

  controller.loadInput({
    resourceId: 'res-expiring',
    mediaType: 'video',
    strategy: 'transcode',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/current.m3u8',
    expiresAt: Date.now() + 3000,
  });

  await new Promise(r => setTimeout(r, 140));
  controller.destroy();

  assert.ok(reasons.length >= 1, '临近过期时应触发自动换源');
  assert.equal(reasons[0], 'expired');
  assert.equal(controller.getCurrentSource(), null, '销毁后不应再持有来源');

  // 无 resolver 时不能产生空转或未捕获异常
  const noResolver = new SourceController({ expiryCheckIntervalMs: 20 });
  noResolver.loadInput({
    resourceId: 'res-no-resolver',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/a.mp4',
    expiresAt: Date.now() + 1000,
  });
  await new Promise(r => setTimeout(r, 60));
  noResolver.destroy();
  assert.ok(true, '无 resolver 时过期检查应静默跳过');
});

test('14. StudioPlayer: stops after the fallback attempt limit (P1-3)', async () => {
  const listeners = {};
  const media = {
    localName: 'video',
    src: '',
    currentTime: 0,
    duration: 100,
    paused: true,
    ended: false,
    canPlayType: () => 'probably',
    addEventListener(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    removeEventListener() {},
    load() {},
    play() { return Promise.resolve(); },
    pause() {},
    trigger(event, data) { listeners[event]?.forEach(fn => fn(data)); },
  };

  const player = new StudioPlayer({});
  player.attach(media);

  const errorEvents = [];
  player.on('error', (_err, switched, code) => errorEvents.push({ switched, code }));

  await player.load({
    resourceId: 'res-limit',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/primary.mp4',
    fallbackUrl: 'https://cdn.example.com/secondary.mp4',
  });

  assert.equal(player.state, 'loading');

  // 主源致命错误 → 切至备用源（第 1 次也是唯一 1 次）
  media.trigger('error', new Error('primary failed'));
  assert.equal(errorEvents.length, 1);
  assert.equal(errorEvents[0].switched, true);
  assert.equal(errorEvents[0].code, 'attempted-fallback');
  assert.equal(player.failed, false);
  assert.equal(player.canFallback, false, '备用源自身不再提供下一级回退');

  // 备用源也失败 → 不得无限循环，直接判定为失败终态
  media.trigger('error', new Error('fallback failed'));
  assert.equal(errorEvents[1].switched, false);
  assert.equal(errorEvents[1].code, 'fallback-limit');
  assert.equal(player.state, 'error');
  assert.equal(player.failed, true);

  // 再多次错误也不改变结论（无重试风暴）
  media.trigger('error', new Error('fallback failed again'));
  assert.equal(errorEvents.length, 3);
  assert.equal(player.failed, true);

  // 换源后失败态解除
  await player.load({
    resourceId: 'res-recover',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/recover.mp4',
  });
  assert.equal(player.failed, false);
  assert.equal(player.state, 'loading');

  player.destroy();
});

test('15. StudioPlayer: keeps progress when paused near the end (P1-5)', async () => {
  const saved = {};
  const storageMock = {
    async load(id) { return saved[id]; },
    async save(id, pos) { saved[id] = pos; },
    async clear(id) { delete saved[id]; },
  };

  const player = new StudioPlayer({ progressStorage: storageMock });
  await player.load({
    resourceId: 'res-tail',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/movie.mp4',
    durationSeconds: 100,
  });

  const controller = player.progressController;
  assert.ok(controller);

  // 先放一个已存断点，确保后面的 undefined 是"被清空"而不是"还没保存"
  await storageMock.save('res-tail', 50);

  // 自然播放越过尾部阈值视为看完 → 清空
  controller.recordProgress('res-tail', 89, 100, true);
  controller.recordProgress('res-tail', 90.5, 100, true);
  await new Promise(r => setTimeout(r, 10));
  assert.equal(saved['res-tail'], undefined, '播放中连续越过结尾边界应清空断点');

  // 暂停状态拖到 96% → 不能清空，只做暂存
  controller.recordProgress('res-tail', 96, 100, false);
  await controller.flush();
  assert.equal(saved['res-tail'], 96, '暂停在结尾附近必须保留断点');

  // 暂停后从尾部继续播放一个心跳，也不能把 seek 误判为自然完播
  controller.recordProgress('res-tail', 96.2, 100, true);
  await controller.flush();
  assert.equal(saved['res-tail'], 96.2, '从尾部恢复播放时应继续保留断点');

  player.destroy();
});

test('16. adaptPlayableToSource: only real HLS sources enter the MSE path (P1-4)', () => {
  const plainVideo = adaptPlayableToSource({
    resourceId: 'plain-mp4',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/movie.mp4',
  });
  assert.equal(plainVideo.source.type, 'video/mp4');
  assert.equal(plainVideo.carrier, 'native');

  // 无扩展名但声明为 HLS：必须显式给出 M3U8 类型并进入 hls.js
  const signedHls = adaptPlayableToSource({
    resourceId: 'signed-hls',
    mediaType: 'video',
    strategy: 'proxy',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/api/hls/stream?token=sign123',
    headers: { Authorization: 'Bearer test-token' },
  });
  assert.equal(signedHls.source.type, 'application/vnd.apple.mpegurl');
  assert.equal(signedHls.carrier, 'managed');
  assert.ok(toVideojsSource(signedHls.source, signedHls.carrier).engine?.hlsJs?.xhrSetup);

  // 无扩展名且无任何类型提示：标记为原生承载，调用方需自行补 type
  const unknownType = adaptPlayableToSource('https://cdn.example.com/stream/12345');
  assert.equal(unknownType.source.type, undefined);
  assert.equal(unknownType.carrier, 'native');

  // mp3 直链不能被当作 HLS
  const audio = adaptPlayableToSource({
    resourceId: 'song',
    mediaType: 'audio',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/song.mp3',
  });
  assert.equal(audio.source.type, 'audio/mpeg');
  assert.equal(audio.carrier, 'native');
});

test('17. adaptPlayableToSource: derives type from a local file name hint (P1-4)', () => {
  const adapted = adaptPlayableToSource({
    src: 'blob:http://127.0.0.1:8188/9f8e-mock',
    resourceId: 'local-file-song.mp3',
  });
  assert.equal(adapted.source.type, 'audio/mpeg', 'blob 地址应能借助 resourceId 推导出真实类型');
  assert.equal(adapted.carrier, 'native');
});

test('18. SourceController: string refresh clears stale expiry and runs once', async () => {
  const reasons = [];
  const controller = new SourceController({
    resolver: {
      async resolveUrl(_resourceId, _plan, reason) {
        reasons.push(reason);
        return 'https://cdn.example.com/refreshed.m3u8';
      },
    },
    expiryCheckIntervalMs: 20,
    expiryBufferSeconds: 60,
  });

  controller.loadInput({
    resourceId: 'res-expiring-once',
    mediaType: 'video',
    strategy: 'transcode',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/current.m3u8',
    expiresAt: Date.now() + 1000,
  });

  await new Promise(r => setTimeout(r, 90));
  controller.destroy();

  assert.deepEqual(reasons, ['expired'], '只返回 URL 时不能沿用旧 expiresAt 形成刷新风暴');
});

test('19. StudioPlayer: a new load resets fallback budget for the same resource', async () => {
  const listeners = {};
  const media = {
    localName: 'video',
    src: '',
    currentTime: 0,
    duration: 100,
    paused: true,
    ended: false,
    canPlayType: () => 'probably',
    addEventListener(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    removeEventListener(event, fn) {
      listeners[event] = (listeners[event] || []).filter(current => current !== fn);
    },
    load() {},
    play() { this.paused = false; return Promise.resolve(); },
    pause() { this.paused = true; },
    trigger(event, data) { for (const fn of listeners[event] || []) fn(data); },
  };
  const player = new StudioPlayer();
  player.attach(media);
  const plan = {
    resourceId: 'same-resource-retry',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/primary.mp4',
    fallbackUrl: 'https://cdn.example.com/fallback.mp4',
  };

  await player.load(plan);
  media.trigger('error', new Error('primary failed'));
  assert.equal(media.src, 'https://cdn.example.com/fallback.mp4');

  await player.load(plan);
  media.trigger('error', new Error('primary failed again'));
  assert.equal(media.src, 'https://cdn.example.com/fallback.mp4');
  assert.equal(player.failed, false, '同一资源重新加载后应允许再次尝试备用源');
  player.destroy();
});

test('20. StudioPlayer: destroy stops and releases the attached media', async () => {
  let pauseCalls = 0;
  const media = {
    localName: 'video',
    _src: '',
    get src() { return this._src; },
    set src(value) { this._src = value; },
    currentTime: 0,
    duration: 100,
    paused: false,
    canPlayType: () => 'probably',
    addEventListener() {},
    removeEventListener() {},
    load() {},
    play() { return Promise.resolve(); },
    pause() { pauseCalls += 1; this.paused = true; },
    removeAttribute(name) { if (name === 'src') this.src = ''; },
  };  const player = new StudioPlayer();
  player.attach(media);
  await player.load('https://cdn.example.com/movie.mp4');
  const beforeDestroy = pauseCalls;
  player.destroy();

  assert.equal(pauseCalls, beforeDestroy + 1);
  assert.equal(media.src, '');
  assert.equal(media.paused, true);
});

test('21. StudioPlayer: fallback preserves position and playing intent', async () => {
  const listeners = {};
  let currentSrc = '';
  const media = {
    localName: 'video',
    get src() { return currentSrc; },
    set src(value) { currentSrc = value; this.currentTime = 0; this.paused = true; },
    currentTime: 0,
    duration: 100,
    paused: true,
    ended: false,
    canPlayType: () => 'probably',
    addEventListener(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    removeEventListener(event, fn) {
      listeners[event] = (listeners[event] || []).filter(current => current !== fn);
    },
    load() {},
    play() {
      this.paused = false;
      for (const fn of listeners.play || []) fn();
      return Promise.resolve();
    },
    pause() { this.paused = true; },
    removeAttribute(name) { if (name === 'src') this.src = ''; },
    trigger(event, data) { for (const fn of listeners[event] || []) fn(data); },
  };
  const player = new StudioPlayer();
  player.attach(media);
  await player.load({
    resourceId: 'continuity',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/primary.mp4',
    fallbackUrl: 'https://cdn.example.com/fallback.mp4',
  });

  media.trigger('loadedmetadata');
  await new Promise(r => setTimeout(r, 0));
  media.currentTime = 42;
  media.paused = false;
  media.trigger('error', new Error('primary failed'));
  media.trigger('loadedmetadata');
  await new Promise(r => setTimeout(r, 0));

  assert.equal(media.src, 'https://cdn.example.com/fallback.mp4');
  assert.equal(media.currentTime, 42);
  assert.equal(media.paused, false);
  player.destroy();
});

test('22. Source adaptation: common HLS MIME aliases still select MSE', () => {
  const adapted = adaptPlayableToSource({
    resourceId: 'hls-alias',
    mediaType: 'video',
    strategy: 'proxy',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/stream',
    mimeType: 'application/x-mpegURL; charset=utf-8',
  });

  assert.equal(adapted.source.type, 'application/vnd.apple.mpegurl');
  assert.equal(adapted.carrier, 'managed');
});

test('23. StudioPlayer: rebinds HLS and native elements across fallback', async () => {
  const makeMedia = (localName, isCustom) => {
    const listeners = {};
    const media = {
      localName,
      currentTime: 0,
      duration: 100,
      paused: true,
      ended: false,
      canPlayType: () => 'probably',
      addEventListener(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
      removeEventListener(event, fn) {
        listeners[event] = (listeners[event] || []).filter(current => current !== fn);
      },
      load() {},
      play() { this.paused = false; return Promise.resolve(); },
      pause() { this.paused = true; },
      removeAttribute(name) {
        if (name === 'src' && !isCustom) this.src = '';
      },
      trigger(event, data) { for (const fn of listeners[event] || []) fn(data); },
    };
    if (isCustom) {
      let currentSource = null;
      Object.defineProperty(media, 'source', {
        get() { return currentSource; },
        set(value) { currentSource = value; this.currentTime = 0; this.paused = true; },
      });
    } else {
      let currentSrc = '';
      Object.defineProperty(media, 'src', {
        get() { return currentSrc; },
        set(value) { currentSrc = value; this.currentTime = 0; this.paused = true; },
      });
    }
    return media;
  };

  const hls = makeMedia('hlsjs-video', true);
  const native = makeMedia('video', false);
  const container = {
    localName: 'video-player',
    querySelector(selector) {
      if (selector === 'hlsjs-video') return hls;
      if (selector === 'video' || selector === 'video, audio') return native;
      return null;
    },
  };
  hls.closest = () => container;
  native.closest = () => container;

  const player = new StudioPlayer();
  player.attach(container);
  assert.equal(player.element, native, '无 MSE 来源时容器应优先使用原生元素');

  await player.load({
    resourceId: 'cross-path',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/primary.m3u8',
    fallback: {
      playUrl: 'https://cdn.example.com/fallback.mp4',
      transport: 'range',
      mimeType: 'video/mp4',
    },
  });
  assert.equal(player.element, hls);
  assert.equal(hls.source.src, 'https://cdn.example.com/primary.m3u8');

  hls.trigger('error', new Error('HLS failed'));
  assert.equal(player.element, native, 'HLS fallback 到 MP4 时应重绑到原生元素');
  assert.equal(native.src, 'https://cdn.example.com/fallback.mp4');
  player.destroy();
});

test('24. StudioPlayer: ignores stale resume results after reloading the same resource', async () => {
  const listeners = {};
  let currentSrc = '';
  let resolveLoad;
  const media = {
    localName: 'video',
    get src() { return currentSrc; },
    set src(value) { currentSrc = value; this.currentTime = 0; },
    currentTime: 0,
    duration: 100,
    paused: true,
    ended: false,
    canPlayType: () => 'probably',
    addEventListener(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    removeEventListener(event, fn) {
      listeners[event] = (listeners[event] || []).filter(current => current !== fn);
    },
    load() {},
    play() { return Promise.resolve(); },
    pause() {},
    removeAttribute(name) { if (name === 'src') this.src = ''; },
    trigger(event, data) { for (const fn of listeners[event] || []) fn(data); },
  };
  const storage = {
    load() { return new Promise(resolve => { resolveLoad = resolve; }); },
    async save() {},
    async clear() {},
  };
  const player = new StudioPlayer({ progressStorage: storage });
  player.attach(media);
  const firstPlan = {
    resourceId: 'same-resource-generation',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/first.mp4',
  };
  await player.load(firstPlan);
  media.trigger('loadedmetadata');

  const secondLoad = player.load({ ...firstPlan, playUrl: 'https://cdn.example.com/second.mp4' });
  resolveLoad(80);
  await secondLoad;
  await new Promise(r => setTimeout(r, 0));

  assert.equal(media.src, 'https://cdn.example.com/second.mp4');
  assert.equal(media.currentTime, 0, '旧资源的异步断点不能写入新会话');
  player.destroy();
});

test('25. SourceController: superseded refresh cannot clear a newer refresh lock', async () => {
  const resolvers = [];
  let calls = 0;
  const controller = new SourceController({
    resolver: {
      resolveUrl() {
        calls += 1;
        return new Promise(resolve => resolvers.push(resolve));
      },
    },
    expiryCheckIntervalMs: 0,
  });

  const plan = {
    resourceId: 'refresh-generation',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'hls',
    playUrl: 'https://cdn.example.com/first.m3u8',
    expiresAt: Date.now() - 1,
  };
  controller.loadInput(plan);
  const firstRefresh = controller.refreshSource('expired');

  controller.loadInput({ ...plan, playUrl: 'https://cdn.example.com/second.m3u8' });
  const secondRefresh = controller.refreshSource('expired');
  assert.equal(calls, 2, '新会话应能建立自己的刷新请求');

  resolvers[0]('https://cdn.example.com/stale.m3u8');
  await firstRefresh;
  assert.equal(await controller.refreshSource('retry'), null, '旧请求收尾不能释放新请求的锁');
  assert.equal(calls, 2);
  resolvers[1]('https://cdn.example.com/fresh.m3u8');
  await secondRefresh;

  assert.equal(controller.getCurrentSource()?.src, 'https://cdn.example.com/fresh.m3u8');
  controller.destroy();
});

// ——— 阶段 4 精简回归：显式失败、媒体元素识别、跳变不算完播 ———

test('36. StudioPlayer: attach() fails loudly instead of hijacking an unrelated page element', () => {
  // 页面里存在一个与本播放器无关的 <video>
  const foreign = { localName: 'video', play() {}, pause() {} };
  const previousDocument = globalThis.document;
  globalThis.document = { querySelector: () => foreign };

  try {
    const player = new StudioPlayer();
    const emptyContainer = { localName: 'video-player', querySelector: () => null };

    assert.throws(
      () => player.attach(emptyContainer),
      /attach\(\) 找不到可承载播放的媒体元素/,
      '容器内没有媒体元素时必须显式失败，而不是选中页面中其它 <video>'
    );
    assert.equal(player.element, null, '失败后不应挂载任何元素');
    player.destroy();
  } finally {
    if (previousDocument === undefined) delete globalThis.document;
    else globalThis.document = previousDocument;
  }
});

test('37. StudioPlayer: recognizes upstream media element tags and never completes on a seek', async (t) => {
  const saved = {};
  const media = new TestMedia();
  media.localName = 'dash-video';

  const player = new StudioPlayer({
    progressStorage: {
      load: id => saved[id],
      save(id, pos) { saved[id] = pos; },
      clear(id) { delete saved[id]; },
    },
  });
  t.after(() => player.destroy());

  // 不抛错即证明标签识别覆盖 *-video / *-audio，而不只是写死的三个标签
  player.attach(media);
  await player.load({
    resourceId: 'res-seek',
    mediaType: 'video',
    strategy: 'direct',
    transport: 'range',
    playUrl: 'https://cdn.example.com/movie.mp4',
    durationSeconds: 100,
  });

  await player.play();
  assert.equal(media.paused, false, '必须在播放中验证跳转，暂停状态无法检出缺失的 seeking 保护');
  assert.equal(player.state, 'playing');

  // 连续播放推进到 50 秒
  media.currentTime = 50;
  media.trigger('timeupdate');

  // 由原生控件/上游皮肤发起的定位：媒体报告 seeking，随后上报跳变后的位置
  media.trigger('seeking');
  media.currentTime = 97;
  media.trigger('timeupdate');
  await player.progressController.flush();

  assert.equal(saved['res-seek'], 97, '定位到结尾附近不得被当作完播清空');
  assert.notEqual(player.state, 'ended', '定位不应把状态改成 ended');

  player.destroy();
});

test('38. StudioPlayer: unsupported new source stops old playback without misattributing progress', async (t) => {
  const saved = new Map();
  const errors = [];
  const media = new TestMedia();
  const player = new StudioPlayer({ progressStorage: {
    load: id => saved.get(id), save: (id, pos) => { saved.set(id, pos); }, clear: id => { saved.delete(id); },
  }});
  t.after(() => player.destroy());
  player.on('error', (_error, switched, code) => errors.push({ switched, code }));
  player.attach(media);
  await player.load(playbackPlan('old'));
  await player.play();
  media.currentTime = 12;
  media.trigger('timeupdate');
  await player.load(playbackPlan('new', { playUrl: 'new.mkv', mimeType: 'video/x-matroska' }));
  assert.equal(player.state, 'error');
  assert.equal(player.failed, true);
  assert.equal(media.paused, true);
  assert.equal(media.src, '');
  assert.deepEqual(errors, [{ switched: false, code: 'no-fallback' }]);
  media.currentTime = 12;
  media.trigger('timeupdate');
  media.trigger('loadedmetadata');
  player.seek(40);
  await player.progressController.flush();
  assert.equal(saved.get('old'), 12);
  assert.equal(saved.has('new'), false);
  await assert.rejects(player.play(), { name: 'NotSupportedError' });
  await player.load(playbackPlan('recovered'));
  await player.play();
  assert.equal(player.state, 'playing');
  assert.equal(player.failed, false);
});

test('39. StudioPlayer: synchronous source rejection uses fallback without reviving obsolete state', async (t) => {
  for (const fallbackPlayable of [true, false]) {
    const media = new TestMedia();
    const player = new StudioPlayer();
    t.after(() => player.destroy());
    player.attach(media);
    await player.load(playbackPlan('old'));
    await player.play();
    media.currentTime = 12;
    const sources = [], errors = [], fallbacks = [];
    player.on('sourcechange', source => sources.push(source.src));
    player.on('fallback', source => fallbacks.push(source.src));
    player.on('error', (_error, switched, code) => errors.push({ switched, code }));
    await player.load(playbackPlan('new', {
      playUrl: 'new.mkv', mimeType: 'video/x-matroska',
      fallback: { playUrl: 'backup.mp4', transport: 'range', mimeType: fallbackPlayable ? 'video/mp4' : 'video/x-matroska' },
    }));
    media.trigger('loadedmetadata');
    await settle();
    assert.equal(media.currentTime, 0, '新资源的备用源不能继承旧资源位置');
    assert.equal(media.paused, true, '新资源不能继承旧资源播放意图');
    assert.equal(player.failed, !fallbackPlayable);
    assert.equal(player.state, fallbackPlayable ? 'ready' : 'error');
    assert.equal(media.src, fallbackPlayable ? 'backup.mp4' : '');
    assert.deepEqual(sources, fallbackPlayable ? ['backup.mp4'] : []);
    assert.deepEqual(fallbacks, fallbackPlayable ? ['backup.mp4'] : []);
    assert.deepEqual(errors, [{ switched: fallbackPlayable, code: fallbackPlayable ? 'attempted-fallback' : 'fallback-limit' }]);
    player.destroy();
  }
});

test('40. StudioPlayer: metadata and canplay share one pending resume read', async (t) => {
  const gate = deferredWrite();
  let reads = 0;
  const media = new TestMedia();
  const player = new StudioPlayer({ progressStorage: {
    load() { reads++; return gate.promise; }, save() {}, clear() {},
  }});
  t.after(() => player.destroy());
  const resumed = [];
  player.on('resume', pos => resumed.push(pos));
  player.attach(media);
  await player.load(playbackPlan('resume'));
  media.trigger('loadedmetadata'); media.trigger('canplay');
  assert.equal(reads, 1);
  gate.resolve(20);
  await settle();
  media.trigger('canplay');
  assert.equal(media.currentTime, 20);
  assert.deepEqual(resumed, [20]);
  assert.equal(reads, 1);
});

test('41. StudioPlayer: API and native seeks supersede a delayed automatic resume', async (t) => {
  for (const nativeSeek of [false, true]) {
    const gate = deferredWrite();
    const media = new TestMedia();
    let reads = 0;
    const player = new StudioPlayer({ progressStorage: {
      load() { reads++; return gate.promise; }, save() {}, clear() {},
    }});
    t.after(() => player.destroy());
    player.attach(media);
    await player.load(playbackPlan('manual'));
    media.trigger('loadedmetadata');
    if (nativeSeek) {
      media.currentTime = 60;
      media.trigger('seeking');
    } else {
      player.seek(60);
    }
    media.trigger('canplay');
    gate.resolve(20);
    await settle();
    assert.equal(media.currentTime, 60);
    assert.equal(reads, 1);
    player.destroy();
  }
});

test('42. StudioPlayer: a seek before metadata suppresses stored positioning', async (t) => {
  let reads = 0;
  const media = new TestMedia();
  const player = new StudioPlayer({ progressStorage: {
    load() { reads++; return 20; }, save() {}, clear() {},
  }});
  t.after(() => player.destroy());
  player.attach(media);
  await player.load(playbackPlan('early-seek'));
  player.seek(60);
  media.trigger('loadedmetadata'); media.trigger('canplay');
  await settle();
  assert.equal(media.currentTime, 60);
  assert.equal(reads, 0);
});

test('43. StudioPlayer: seeking during fallback restore preserves playback intent', async (t) => {
  const gate = deferredWrite();
  const media = new TestMedia();
  const player = new StudioPlayer({ progressStorage: { load: () => gate.promise, save() {}, clear() {} } });
  t.after(() => player.destroy());
  player.attach(media);
  await player.load(playbackPlan('fallback-seek', { fallbackUrl: 'backup.mp4' }));
  await player.play();
  player.switchToFallback();
  media.trigger('loadedmetadata');
  player.seek(60);
  gate.resolve(20);
  await settle();
  assert.equal(media.currentTime, 60);
  assert.equal(media.paused, false);
});

test('44. SourceController: abandoned refresh plans release their new session after switch or destroy', async (t) => {
  for (const destroyFirst of [false, true]) {
    const gate = deferredWrite();
    const closed = [];
    const controller = new SourceController({ expiryCheckIntervalMs: 0, resolver: {
      resolveUrl: () => gate.promise, onSessionClose: endpoint => { closed.push(endpoint); },
    }});
    t.after(() => controller.destroy());
    controller.loadInput(playbackPlan('a', { processing: { sessionEndpoint: '/a' } }));
    const refresh = controller.refreshSource('retry');
    if (destroyFirst) controller.destroy();
    else controller.loadInput(playbackPlan('b', { processing: { sessionEndpoint: '/b' } }));
    gate.resolve(playbackPlan('a', { processing: { sessionEndpoint: '/abandoned' } }));
    assert.equal(await refresh, null);
    assert.deepEqual(closed, ['/a', '/abandoned']);
    assert.equal(controller.getCurrentResourceId(), destroyFirst ? null : 'b');
    controller.destroy();
    assert.deepEqual(closed, destroyFirst ? ['/a', '/abandoned'] : ['/a', '/abandoned', '/b']);
  }
});

test('45. SourceController: stale refresh cannot close a current or already released session', async (t) => {
  for (const returnedEndpoint of ['/a', '/b']) {
    const gate = deferredWrite(), closed = [];
    const controller = new SourceController({ expiryCheckIntervalMs: 0, resolver: {
      resolveUrl: () => gate.promise, onSessionClose: endpoint => { closed.push(endpoint); },
    }});
    t.after(() => controller.destroy());
    controller.loadInput(playbackPlan('a', { processing: { sessionEndpoint: '/a' } }));
    const refresh = controller.refreshSource('retry');
    controller.loadInput(playbackPlan('b', { processing: { sessionEndpoint: '/b' } }));
    gate.resolve(playbackPlan('a', { processing: { sessionEndpoint: returnedEndpoint } }));
    assert.equal(await refresh, null);
    assert.deepEqual(closed, ['/a']);
    controller.destroy();
    assert.deepEqual(closed, ['/a', '/b']);
  }
});

test('46. ProgressController: completion stays cleared through tail updates and permits seek or replay', async (t) => {
  const saved = new Map(), cleared = [];
  const controller = new ProgressController({
    load: id => saved.get(id), save: (id, pos) => { saved.set(id, pos); },
    clear(id) { cleared.push(id); saved.delete(id); },
  }, { saveDebounceMs: 5 });
  t.after(() => controller.destroy());
  for (const id of ['seek', 'replay']) {
    controller.recordProgress(id, 89, 100);
    await controller.flush();
    controller.recordProgress(id, 90.5, 100);
    for (const pos of [91, 95, 100]) controller.recordProgress(id, pos, 100);
    controller.recordProgress(id, 100, 100, 'paused');
  }
  await new Promise(resolve => setTimeout(resolve, 15));
  await controller.flush();
  assert.equal(saved.size, 0, '完播后的防抖/暂停/尾部事件不能重建断点');
  assert.deepEqual(cleared, ['seek', 'replay']);
  controller.recordProgress('seek', 97, 100, false);
  controller.recordProgress('replay', 0, 100);
  controller.recordProgress('replay', 12, 100);
  await controller.flush();
  assert.equal(saved.get('seek'), 97);
  assert.equal(saved.get('replay'), 12);
});

test('47. StudioPlayer: paused and ended tail events cannot resurrect completed progress', async (t) => {
  const saved = new Map();
  const media = new TestMedia();
  const player = new StudioPlayer({ progressStorage: {
    load: id => saved.get(id), save: (id, pos) => { saved.set(id, pos); }, clear: id => { saved.delete(id); },
  }});
  t.after(() => player.destroy());
  player.attach(media);
  await player.load(playbackPlan('tail'));
  await player.play();
  for (const pos of [89, 90.5, 91]) { media.currentTime = pos; media.trigger('timeupdate'); }
  player.pause();
  media.currentTime = 91.1;
  media.trigger('timeupdate');
  await player.progressController.flush();
  assert.equal(saved.has('tail'), false);
  player.seek(97);
  media.trigger('timeupdate');
  await player.progressController.flush();
  assert.equal(saved.get('tail'), 97, '显式定位仍允许重新记忆');
  media.ended = true;
  media.trigger('ended');
  media.trigger('timeupdate');
  await player.progressController.flush();
  assert.equal(saved.has('tail'), false);
});

test('48. StudioPlayer: a synchronously rejected refresh preserves position through fallback', async (t) => {
  const media = new TestMedia();
  const player = new StudioPlayer({ autoResume: false, sourceResolver: {
    resolveUrl: (_id, plan) => ({ ...plan, playUrl: 'unsupported.mkv', mimeType: 'video/x-matroska' }),
  }});
  t.after(() => player.destroy());
  player.attach(media);
  await player.load(playbackPlan('refresh', {
    fallback: { playUrl: 'backup.mp4', transport: 'range', mimeType: 'video/mp4' },
  }));
  await player.play();
  media.currentTime = 42;
  const sources = [];
  player.on('sourcechange', source => sources.push(source.src));
  await player.sourceController.refreshSource('retry');
  media.trigger('loadedmetadata');
  await settle();
  assert.equal(media.currentTime, 42);
  assert.equal(media.paused, false);
  assert.equal(player.state, 'playing');
  assert.deepEqual(sources, ['backup.mp4']);
});
