import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PlaybackAudioAnalysis} from '../dist/analysis/index.js';

function environment(t,options={}){
  const originals=new Map(['window','document','location','navigator'].map(key=>[key,Object.getOwnPropertyDescriptor(globalThis,key)]));
  let binds=0,closes=0;const connections=[];
  class Context extends EventTarget{
    state=options.resume?'suspended':'running';destination={output:true};
    async resume(){await options.resume;this.state='running';}
    createAnalyser(){return {fftSize:0,smoothingTimeConstant:0,disconnect(){}};}
    createMediaElementSource(){binds++;return {connect:node=>connections.push(node),disconnect(){}};}
    async close(){closes++;this.state='closed';}
  }
  for(const [key,value]of Object.entries({window:{AudioContext:Context},document:new EventTarget(),location:{href:'http://local.test/',origin:'http://local.test'},navigator:{userActivation:{isActive:false}}}))Object.defineProperty(globalThis,key,{configurable:true,value});
  t.after(()=>{for(const [key,descriptor]of originals)if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];});
  const audio=Object.assign(new EventTarget(),{currentSrc:options.url??'http://local.test/media',src:''});
  return {audio,counts:()=>({binds,closes}),connections};
}
test('analysis is lazy, binds one graph for the element and preserves a direct audio output',async t=>{
  const env=environment(t),analysis=new PlaybackAudioAnalysis(env.audio);assert.equal(analysis.getSnapshot(),'idle');assert.equal(env.counts().binds,0);
  analysis.request(true);assert.equal(analysis.getSnapshot(),'waiting');assert.equal(env.counts().binds,0);
  analysis.request(true,true);await new Promise(resolve=>setImmediate(resolve));assert.equal(analysis.getSnapshot(),'ready');assert.equal(env.counts().binds,1);assert(env.connections.some(node=>node.output));assert.equal(env.connections.length,2);
  analysis.request(false);analysis.request(true,true);assert.equal(env.counts().binds,1);await analysis.dispose();assert.equal(env.counts().closes,1);assert.equal(analysis.analyser,null);
});
test('cross-origin failure leaves native output intact and disposing during resume cannot bind a late graph',async t=>{
  const env=environment(t,{url:'https://external.test/audio'}),analysis=new PlaybackAudioAnalysis(env.audio);analysis.request(true,true);await new Promise(resolve=>setImmediate(resolve));assert.equal(analysis.getSnapshot(),'unavailable');assert.equal(env.counts().binds,0);await analysis.dispose();
  let release;const pending=new Promise(resolve=>release=resolve),second=environment(t,{resume:pending}),late=new PlaybackAudioAnalysis(second.audio);late.request(true,true);const closed=late.dispose();release();await closed;assert.equal(second.counts().binds,0);assert.equal(second.counts().closes,1);
});
