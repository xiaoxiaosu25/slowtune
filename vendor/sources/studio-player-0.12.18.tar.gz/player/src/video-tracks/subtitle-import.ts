import type { StudioPlayer } from '../player.js';
import { readSubtitleFile } from '../source-adapter/subtitles.js';
import type { VideoTracksController } from './index.js';

/** 导入并选中当前资源的本地字幕。离开宿主界面时可取消仍在读取的文件。 */
export function createSubtitleImport(player: StudioPlayer, tracks: VideoTracksController) {
  if (player.isDestroyed || tracks.isDestroyed) throw new Error('Cannot import subtitles for a destroyed player');
  let disposed = false;
  let revision = 0;
  let subtitleURL: string | null = null;
  let selecting = false;
  const release = () => {
    revision++;
    selecting = false;
    if (subtitleURL) URL.revokeObjectURL(subtitleURL);
    subtitleURL = null;
  };
  const changed = () => {
    if (selecting && tracks.snapshot.subtitles.some(track => track.id === 'imported' && !['error', 'unavailable'].includes(track.status ?? ''))) {
      selecting = false;
      tracks.selectSubtitle('imported');
    }
  };
  const canImport = () => Boolean(player.currentPlan && player.state !== 'stopped');
  const destroy = () => {
    if (disposed) return;
    disposed = true;
    release();
    off.forEach(cleanup => cleanup());
    tracks.removeEventListener('change', changed);
  };
  const off = [player.on('loadstart', release), player.on('closerequest', release), player.on('stop', release), player.on('destroy', destroy)];
  tracks.addEventListener('change', changed);
  return {
    async importSubtitle(file: File): Promise<void> {
      if (disposed || tracks.isDestroyed) throw new Error('Subtitle importer has been destroyed');
      if (!/\.(srt|vtt)$/i.test(file.name)) throw new TypeError('Choose SRT or WebVTT subtitles');
      if (!canImport()) throw new Error('Load a video playback plan before importing subtitles');
      const request = ++revision;
      const resource = player.currentResourceId;
      const current = () => !disposed && !tracks.isDestroyed && request === revision && resource === player.currentResourceId && canImport();
      let text: string;
      try { text = await readSubtitleFile(file); }
      catch (error) {
        if (current()) throw error;
        return;
      }
      const plan = player.currentPlan;
      if (!current() || !plan) return;
      const url = URL.createObjectURL(new Blob([text], { type: 'text/vtt' }));
      const previous = subtitleURL;
      selecting = true;
      try {
        player.replaceSource({ ...plan, tracks: { ...plan.tracks,
          subtitles: [...(plan.tracks?.subtitles?.filter(track => track.id !== 'imported') ?? []),
            { id: 'imported', src: url, type: 'text/vtt', label: file.name, language: 'und', default: true }] } });
      } catch (error) {
        selecting = false;
        URL.revokeObjectURL(url);
        throw error;
      }
      subtitleURL = url;
      if (previous) URL.revokeObjectURL(previous);
      changed();
    },
    cancelPending() { revision++; },
    destroy,
  };
}
