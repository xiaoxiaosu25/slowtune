import type { TrackPort, TrackPortOption } from '../contracts/ports.js';
import type { StudioPlayer } from '../player.js';
import { qualityAccessOf, type EngineTrackAccess } from '../backends/videojs/tracks.js';
export { normalizeSubtitles, readSubtitleFile } from '../source-adapter/subtitles.js';
export { createSubtitleImport } from './subtitle-import.js';

export interface VideoTrackOption extends TrackPortOption {}
export interface VideoQualityOption extends VideoTrackOption {
  readonly width?: number;
  readonly height?: number;
  readonly bitrate?: number;
  readonly active: boolean;
}
export interface VideoTracksSnapshot {
  readonly resourceId: string | null;
  readonly subtitles: readonly VideoTrackOption[];
  readonly audio: readonly VideoTrackOption[];
  readonly qualities: readonly VideoQualityOption[];
  readonly subtitle: string;
  readonly audioTrack: string | null;
  readonly quality: string;
  readonly subtitleAvailable: boolean;
  readonly audioAvailable: boolean;
  readonly qualityAvailable: boolean;
  readonly subtitleReason: string | null;
  readonly audioReason: string | null;
  readonly qualityReason: string | null;
}

export interface VideoTracksOptions {
  /** 测试或宿主可以显式提供一个后端中立轨道端口。 */
  trackPort?: TrackPort;
}

function unsupported(message: string): never {
  const error = new Error(message);
  error.name = 'NotSupportedError';
  throw error;
}

const audioKey = (track: TrackPortOption): string => `${track.language ?? ''}|${track.label ?? ''}`;
const qualityKey = (track: { width?: number; height?: number; bitrate?: number }): string =>
  `${track.width ?? ''}|${track.height ?? ''}|${track.bitrate ?? ''}`;

/**
 * 公共轨道控制器只消费 `TrackPort`。Video.js 的 DOM、字幕节点和列表对象由
 * `backends/videojs/tracks.ts` 承接；mpv 的 `track-list` 由 mpv 适配器承接。
 * 画质保留为 Video.js 的兼容扩展，不放进 U5-2 定稿的窄 TrackPort。
 */
export class VideoTracksController extends EventTarget {
  private port: TrackPort | null = null;
  private readonly injectedPort: TrackPort | null;
  private portCleanup: (() => void) | null = null;
  private quality: EngineTrackAccess | null = null;
  private resourceId: string | null = null;
  private disposed = false;
  private queued = false;
  private recheckQuality = false;
  private qualityReassertion = '';
  private applying = false;
  private subtitleWanted: string | null = null;
  private audioWanted: { id: string; key: string } | null = null;
  private qualityWanted: { id: string; key: string } | 'auto' | null = null;
  private lists: unknown[] = [];
  private readonly listCleanup: Array<() => void> = [];
  private readonly subscriptions: Array<() => void>;
  private lastSnapshot = '';

  constructor(private readonly player: StudioPlayer, options: VideoTracksOptions = {}) {
    super();
    if (player.isDestroyed) throw new Error('Cannot attach tracks to a destroyed player');
    this.injectedPort = options.trackPort ?? null;
    this.subscriptions = [
      player.on('loadstart', () => this.reset()),
      player.on('sourcechange', () => this.bind()),
      player.on('mediachange', () => this.bind()),
      player.on('stop', () => this.reset()),
      player.on('detach', () => { this.reset(); this.bind(); }),
      player.on('destroy', () => this.destroy()),
    ];
    this.bind();
  }

  get isDestroyed(): boolean { return this.disposed; }

  get snapshot(): VideoTracksSnapshot {
    const port = this.resourceId ? this.port?.snapshot : null;
    const subtitles = (port?.subtitles ?? []).map(track => ({ ...track }));
    const audio = (port?.audio ?? []).map(track => ({ ...track }));
    const qualities = (this.resourceId ? this.quality?.renditions() ?? [] : []).map((track, index): VideoQualityOption => ({
      id: track.id,
      label: track.height ? `${track.height}p` : track.bitrate ? `${Math.round(track.bitrate / 1000)} kbps` : `画质 ${index + 1}`,
      width: track.width,
      height: track.height,
      bitrate: track.bitrate,
      selected: track.selected,
      active: track.active,
      status: 'ready',
    }));
    const subtitleAvailable = subtitles.some(track => track.status !== 'unavailable' && track.status !== 'error');
    const audioAvailable = audio.length > 1;
    const qualityAvailable = qualities.length > 1;
    return Object.freeze({
      resourceId: this.resourceId,
      subtitles: Object.freeze(subtitles.map(track => Object.freeze(track))),
      audio: Object.freeze(audio.map(track => Object.freeze(track))),
      qualities: Object.freeze(qualities.map(track => Object.freeze(track))),
      subtitle: port?.subtitle ?? 'off',
      audioTrack: port?.audioTrack ?? null,
      quality: qualities.find(track => track.selected)?.id ?? 'auto',
      subtitleAvailable,
      audioAvailable,
      qualityAvailable,
      subtitleReason: subtitleAvailable ? null
        : subtitles.some(track => track.status === 'error') ? '字幕文件加载失败'
          : subtitles.some(track => track.status === 'unavailable') ? subtitles.find(track => track.status === 'unavailable')?.reason ?? '字幕不可用'
            : '当前来源没有可用字幕',
      audioReason: audioAvailable ? null : '当前来源或后端没有可切换音轨',
      qualityReason: qualityAvailable ? null : '当前来源为固定画质，或后端未提供多档选择',
    });
  }

  selectSubtitle(id: string): void {
    this.assertLive();
    const option = this.resourceId ? this.port?.snapshot.subtitles.find(track => track.id === id) : undefined;
    if (id !== 'off' && (!option || option.status === 'unavailable' || option.status === 'error')) {
      unsupported('Subtitle is not available');
    }
    this.subtitleWanted = id;
    this.applySelection();
    this.notify();
  }

  selectAudioTrack(id: string): void {
    this.assertLive();
    const track = this.resourceId ? this.port?.snapshot.audio.find(entry => entry.id === id) : undefined;
    if (!this.snapshot.audioAvailable || !track) unsupported('Audio track selection is not available');
    this.audioWanted = { id, key: audioKey(track) };
    this.applySelection();
    this.notify();
  }

  selectQuality(id: string): void {
    this.assertLive();
    const track = this.resourceId ? (this.quality?.renditions() ?? []).find(entry => entry.id === id) : undefined;
    if (!this.snapshot.qualityAvailable || (id !== 'auto' && !track)) {
      unsupported('Quality selection is not available');
    }
    this.qualityWanted = id === 'auto' ? 'auto' : { id, key: qualityKey(track!) };
    this.qualityReassertion = '';
    this.applySelection();
    this.notify();
  }

  destroy(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const unsubscribe of this.subscriptions) unsubscribe();
    this.portCleanup?.();
    this.portCleanup = null;
    for (const cleanup of this.listCleanup.splice(0)) cleanup();
    this.port = null;
    this.quality = null;
    this.dispatchEvent(new Event('destroy'));
  }

  private reset(): void {
    this.resourceId = null;
    this.subtitleWanted = null;
    this.audioWanted = null;
    this.qualityWanted = null;
    this.qualityReassertion = '';
    this.notify();
  }

  private bind(): void {
    if (this.disposed) return;
    const nextPort = this.injectedPort ?? this.player.trackPort;
    if (nextPort !== this.port) {
      this.portCleanup?.();
      this.port = nextPort;
      this.portCleanup = nextPort?.onChange(() => this.schedule(true)) ?? null;
      this.quality = qualityAccessOf(nextPort);
      this.syncLists();
    }
    const id = this.player.currentResourceId;
    if (this.resourceId && id !== this.resourceId) this.reset();
    this.resourceId = id;
    this.syncLists();
    this.applySelection();
    this.notify();
  }

  private syncLists(): void {
    const next = [this.quality?.audioList() ?? null, this.quality?.renditionList() ?? null];
    if (next.every((list, index) => list === this.lists[index])) return;
    for (const cleanup of this.listCleanup.splice(0)) cleanup();
    this.lists = next;
    for (const list of next) if (list?.addEventListener) {
      for (const event of ['change', 'addtrack', 'removetrack', 'addrendition', 'removerendition', 'activechange']) {
        const callback = () => this.schedule(event === 'activechange');
        list.addEventListener(event, callback);
        this.listCleanup.push(() => list.removeEventListener(event, callback));
      }
    }
  }

  private schedule(recheckQuality = false): void {
    this.recheckQuality ||= recheckQuality;
    if (this.queued || this.disposed) return;
    this.queued = true;
    queueMicrotask(() => {
      this.queued = false;
      if (this.disposed) return;
      const recheck = this.recheckQuality;
      this.recheckQuality = false;
      this.syncLists();
      this.applySelection(recheck);
      this.notify();
    });
  }

  private applySelection(recheckQuality = false): void {
    if (this.applying || !this.resourceId) return;
    this.applying = true;
    try {
      const port = this.port;
      if (port && this.subtitleWanted !== null) {
        const current = port.snapshot;
        if (this.subtitleWanted === 'off' || current.subtitles.some(track => track.id === this.subtitleWanted)) {
          if (current.subtitle !== this.subtitleWanted || current.subtitles.some(track => track.selected && track.id !== this.subtitleWanted)) {
            this.invokePort(() => port.selectSubtitle(this.subtitleWanted!));
          }
        }
      }
      if (port && this.audioWanted) {
        const current = port.snapshot;
        const wanted = this.audioWanted;
        // 同一条目保留 ID 且语义未变时优先 ID；列表重建后若 ID 被复用但
        // 语义变了，则先按语言/名称找回原条目，再以 ID 作最后回退。
        const byId = current.audio.find(track => track.id === wanted.id);
        const chosen = byId && audioKey(byId) === wanted.key ? byId
          : current.audio.find(track => audioKey(track) === wanted.key) ?? byId;
        if (chosen) {
          this.audioWanted = { id: chosen.id, key: audioKey(chosen) };
          if (current.audioTrack !== chosen.id) this.invokePort(() => port.selectAudioTrack(chosen.id));
        }
      }
      const quality = this.quality;
      if (quality && this.qualityWanted) {
        const wanted = this.qualityWanted;
        const index = wanted === 'auto' ? -1 : quality.renditions().findIndex(track => qualityKey(track) === wanted.key);
        if (index >= 0 || wanted === 'auto') {
          if (quality.renditionSelectedIndex() !== index) quality.setRenditionSelectedIndex(index);
          else if (recheckQuality && index >= 0 && quality.renditions().some((track, activeIndex) => track.active && activeIndex !== index)) {
            // rc.2 的公开列表桥可能跳过同值写入；重发仍由 Video.js 适配原语完成。
            const signature = `${index}:${Math.floor(quality.currentTime())}:${quality.activeRenditionIndex()}`;
            if (signature !== this.qualityReassertion) {
              this.qualityReassertion = signature;
              quality.dispatchRenditionChange();
            }
          }
        }
      }
    } finally {
      this.applying = false;
    }
  }

  private invokePort(run: () => Promise<void> | void): void {
    try {
      void Promise.resolve(run()).catch(error => this.reportError(error));
    } catch (error) {
      this.reportError(error);
    }
  }

  private reportError(error: unknown): void {
    if (!this.disposed) this.dispatchEvent(new CustomEvent('error', { detail: error }));
  }

  private notify(): void {
    if (this.disposed) return;
    const value = JSON.stringify(this.snapshot);
    if (value === this.lastSnapshot) return;
    this.lastSnapshot = value;
    this.dispatchEvent(new Event('change'));
  }

  private assertLive(): void {
    if (this.disposed) throw new Error('Video tracks have been destroyed');
  }
}
