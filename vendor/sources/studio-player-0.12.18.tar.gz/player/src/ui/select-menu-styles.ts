/** Opt-in native select menus, shared by player surfaces and nested sleep settings. */
export const selectMenuStyles = `
@supports (appearance:base-select) {
  select:not([multiple]):not([size]), select:not([multiple])[size="1"] {
    appearance:var(--studio-player-select-appearance,auto);
    position:relative; align-items:center; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
  }
  select::picker-icon { content:var(--studio-player-select-icon,normal); background:var(--studio-player-select-arrow,none) center/12px 12px no-repeat; min-width:12px; height:12px; margin-inline-start:auto; }
  select::picker(select) {
    appearance:var(--studio-player-select-appearance,auto);
    display:none; position-area:block-end span-inline-end; position-try-fallbacks:flip-block,flip-inline,flip-block flip-inline;
    width:max-content; min-width:min(max(anchor-size(self-inline),220px),calc(100vw - 24px));
    max-width:calc(100vw - 24px); max-height:min(380px,calc(100dvh - 24px));
    margin-block:4px; padding:var(--studio-player-menu-padding,8px);
    gap:var(--studio-player-menu-gap,2px);
    border:1px solid var(--studio-player-menu-border,var(--studio-player-border,#405154));
    border-radius:var(--studio-player-menu-radius,12px);
    background:var(--studio-player-menu-surface,var(--studio-player-surface,#182326));
    color:var(--studio-player-menu-text,var(--studio-player-text,#edf2f1));
    box-shadow:var(--studio-player-menu-shadow,0 8px 24px #0003);
    font-family:inherit; font-size:14px; font-weight:400; line-height:1.55; text-align:left;
    overflow:auto; overscroll-behavior:contain; scrollbar-width:thin;
  }
  select:open::picker(select) { display:grid; }
  select option {
    display:flex; align-items:center; gap:10px; min-height:var(--studio-player-menu-item-height,38px);
    padding:var(--studio-player-menu-item-padding,8px 14px); border:0;
    border-radius:var(--studio-player-menu-item-radius,6px);
    background:var(--studio-player-menu-surface,var(--studio-player-surface,#182326));
    color:var(--studio-player-menu-text,var(--studio-player-text,#edf2f1));
    font-family:inherit; font-size:14px; font-weight:500; line-height:1.55;
    white-space:normal; overflow-wrap:anywhere; cursor:pointer;
  }
  select option:checked {
    background:var(--studio-player-menu-selected,var(--studio-player-surface,#182326));
    color:var(--studio-player-menu-accent,var(--studio-player-accent,#74debb));
  }
  select option:is(:hover,:focus-visible):not(:disabled) {
    background:var(--studio-player-menu-hover,var(--studio-player-surface,#182326));
    color:var(--studio-player-menu-accent,var(--studio-player-accent,#74debb)); outline:0;
  }
  select option:disabled { opacity:.55; cursor:default; }
  select option::checkmark { order:1; margin-inline-start:auto; padding-inline-start:10px; color:var(--studio-player-menu-accent,var(--studio-player-accent,#74debb)); }
  select optgroup { padding:0; }
  select optgroup::legend { padding:10px 14px 4px; color:var(--studio-player-menu-muted,var(--studio-player-text-muted,#a7b7b8)); font-size:12px; font-weight:600; }
}
`;
