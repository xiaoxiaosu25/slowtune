import type { PlaybackEndAction } from '../player.js';
import type { SleepTimerController, SleepTimerTrigger } from '../sleep-timer/index.js';
import { selectMenuStyles } from './select-menu-styles.js';

export interface SleepTimerSettings {
  readonly element: HTMLElement;
  setDurationOnly(live: boolean): void;
  /** 只移除本组件的 DOM 与订阅，不取消计时或销毁借用的控制器。 */
  destroy(): void;
}

export interface SleepTimerSettingsOptions {
  /** YouTube 子面板已有标题时隐藏表单内部的重复标题。 */
  readonly showLegend?: boolean;
}

const actionLabels: Record<PlaybackEndAction, string> = { pause: '暂停', stop: '停止', close: '关闭播放器' };
const actionHints: Record<PlaybackEndAction, string> = {
  pause: '保留当前位置和播放会话，可直接继续播放。',
  stop: '释放播放资源并保留列表和页面；开启进度记忆时保存断点。',
  close: '停止后关闭播放器界面。',
};

const template = `
<style>
  :host { display: block; font: inherit; color: var(--studio-player-text, #edf2f1); color-scheme: inherit; }
  * { box-sizing: border-box; }
  [hidden] { display: none !important; }
  form { display: grid; gap: 14px; margin: 0; }
  fieldset { min-width: 0; margin: 0; padding: 0; border: 0; }
  legend { padding: 0; margin-bottom: 14px; font-size: 1rem; font-weight: 650; }
  .fields { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 12rem), 1fr)); gap: 12px; }
  label { display: grid; align-content: start; gap: 6px; min-width: 0; font-size: .875rem; }
  input, select, button { font: inherit; font-size: .875rem; color: inherit; min-width: 0; min-height: 44px;
    padding: 9px 12px; border: 1px solid var(--studio-player-border, #405154);
    border-radius: var(--studio-player-radius, 8px); background: var(--studio-player-surface, #182326); }
  input, select { width: 100%; }
  @media(max-width:840px){input,select{font-size:max(16px,1rem)}}
  select { color-scheme: inherit; }
  option {
    color: var(--studio-player-text, #edf2f1);
    background: var(--studio-player-option-background, var(--studio-player-surface, #182326));
  }
  .duration { display: grid; grid-template-columns: minmax(0, 1fr) minmax(5rem, .65fr); gap: 8px; }
  button { cursor: pointer; }
  button[type=submit] { border-color: var(--studio-player-accent, #74debb); }
  :is(button, input, select):focus-visible { outline: 2px solid var(--studio-player-accent, #74debb); outline-offset: 3px; }
  button:hover:enabled { border-color: var(--studio-player-accent, #74debb); }
  :disabled { opacity: .5; cursor: default; }
  .actions { display: flex; flex-wrap: wrap; gap: 8px; }
  .actions button { flex: 1 1 8rem; }
  p, output { display: block; margin: 0; font-size: .8125rem; line-height: 1.6; overflow-wrap: anywhere; }
  .hint { color: var(--studio-player-text-muted, #a7b7b8); }
  output { font-variant-numeric: tabular-nums; }
  .error { color: var(--studio-player-error, #ffb7aa); }
  ${selectMenuStyles}
</style>
<form aria-label="睡眠设置">
  <fieldset>
    <legend>睡眠设置</legend>
    <div class="fields">
      <label>结束条件
        <select data-field="trigger">
          <option value="duration">倒计时</option>
          <option value="items">自然播完 N 项</option>
          <option value="current">播完当前项</option>
        </select>
      </label>
      <div data-section="duration" class="duration">
        <label>时长<input data-field="duration" type="number" min="0.001" step="any" value="23" required inputmode="decimal"></label>
        <label>单位<select data-field="unit"><option value="60000">分钟</option><option value="1000">秒</option></select></label>
      </div>
      <label data-section="items" hidden>完成次数
        <input data-field="count" type="number" min="1" max="9007199254740991" step="1" value="3" required inputmode="numeric" disabled>
      </label>
      <label>结束动作
        <select data-field="action">
          <option value="pause">暂停</option><option value="stop">停止</option><option value="close">关闭播放器</option>
        </select>
      </label>
    </div>
  </fieldset>
  <p class="hint" data-trigger-hint></p>
  <p class="hint" data-action-hint></p>
  <div class="actions"><button type="submit" data-action="start-timer">设置睡眠</button>
    <button type="button" data-action="cancel-timer" disabled>取消设置</button></div>
  <output data-sleep-status>未设置睡眠</output>
  <p class="error" role="alert" data-sleep-error hidden></p>
</form>`;

/** 最小公共睡眠表单。导入不访问 DOM；样式封装在组件内，可通过公开 CSS 变量调整。 */
export function mountSleepTimerSettings(root: HTMLElement, timer: SleepTimerController, options: SleepTimerSettingsOptions = {}): SleepTimerSettings {
  if (timer.isDestroyed) throw new Error('Cannot mount settings for a destroyed sleep timer');
  const element = root.ownerDocument.createElement('div');
  const shadow = element.attachShadow({ mode: 'open' });
  shadow.innerHTML = template;
  const select = (name: string) => shadow.querySelector<HTMLSelectElement>(`[data-field="${name}"]`)!;
  const input = (name: string) => shadow.querySelector<HTMLInputElement>(`[data-field="${name}"]`)!;
  const form = shadow.querySelector('form')!;
  const legend = shadow.querySelector('legend')!;
  const cancel = shadow.querySelector<HTMLButtonElement>('[data-action="cancel-timer"]')!;
  const submit = shadow.querySelector<HTMLButtonElement>('[data-action="start-timer"]')!;
  const status = shadow.querySelector<HTMLOutputElement>('[data-sleep-status]')!;
  const error = shadow.querySelector<HTMLElement>('[data-sleep-error]')!;
  const triggerHint = shadow.querySelector<HTMLElement>('[data-trigger-hint]')!;
  const actionHint = shadow.querySelector<HTMLElement>('[data-action-hint]')!;
  legend.hidden = options.showLegend === false;
  const abort = new AbortController();
  let disposed = false;
  let draftError = '';
  let durationOnly = false;

  const initial = timer.snapshot;
  let ruleKey = JSON.stringify([initial.status === 'running', initial.trigger, initial.action]);
  select('action').value = initial.action;
  if (initial.trigger) {
    select('trigger').value = initial.trigger.type;
    if (initial.trigger.type === 'duration') input('duration').value = String(initial.trigger.durationMs / 60000);
    if (initial.trigger.type === 'items') input('count').value = String(initial.trigger.count);
  }

  function updateFields() {
    if (durationOnly) select('trigger').value = 'duration';
    const type = select('trigger').value;
    for (const section of ['duration', 'items']) {
      shadow.querySelector<HTMLElement>(`[data-section="${section}"]`)!.hidden = type !== section;
    }
    input('duration').disabled = timer.isDestroyed || type !== 'duration';
    select('unit').disabled = timer.isDestroyed || type !== 'duration';
    input('count').disabled = timer.isDestroyed || type !== 'items';
    triggerHint.textContent = type === 'duration' ? '按经过的时间倒计时；暂停播放时也继续计时。'
      : type === 'items' ? '仅自然播完才计数，手动切换或跳到末尾不计数。'
        : '等待当前项自然播完；手动切换后等待新的当前项。';
    actionHint.textContent = actionHints[select('action').value as PlaybackEndAction];
  }

  function render() {
    if (disposed) return;
    const snapshot = timer.snapshot;
    const nextRuleKey = JSON.stringify([snapshot.status === 'running', snapshot.trigger, snapshot.action]);
    if (nextRuleKey !== ruleKey) {
      ruleKey = nextRuleKey;
      // External quick presets update the form; timer ticks must preserve an unfinished draft.
      if (snapshot.status === 'running' && snapshot.trigger) {
        select('action').value = snapshot.action;
        select('trigger').value = snapshot.trigger.type;
        if (snapshot.trigger.type === 'duration') {
          input('duration').value = String(snapshot.trigger.durationMs / Number(select('unit').value));
        }
        if (snapshot.trigger.type === 'items') input('count').value = String(snapshot.trigger.count);
        updateFields();
      }
    }
    const label = actionLabels[snapshot.action];
    cancel.disabled = timer.isDestroyed || (snapshot.status !== 'running' && !snapshot.actionPending);
    submit.disabled = timer.isDestroyed;
    submit.textContent = snapshot.status === 'running' ? '重新设置' : '设置睡眠';
    if (timer.isDestroyed) {
      shadow.querySelectorAll<HTMLInputElement | HTMLSelectElement>('input, select').forEach(control => { control.disabled = true; });
      status.textContent = '睡眠功能已关闭';
    } else if (snapshot.status === 'running') {
      const seconds = Math.ceil(snapshot.remainingMs / 1000);
      const time = `${Math.floor(seconds / 60)} 分 ${String(seconds % 60).padStart(2, '0')} 秒`;
      status.textContent = snapshot.trigger?.type === 'duration' ? `${time}后${label}`
        : `再自然播完 ${snapshot.remainingItems} 项后${label}`;
    } else if (snapshot.actionPending) {
      status.textContent = `已触发${label}，正在完成结束操作。`;
    } else if (snapshot.error) {
      status.textContent = '结束操作未完全完成。';
    } else {
      status.textContent = snapshot.status === 'expired' ? `${label}操作已完成。` : '未设置睡眠';
    }
    const message = draftError || (snapshot.error instanceof Error ? snapshot.error.message : snapshot.error ? String(snapshot.error) : '');
    error.textContent = message;
    error.hidden = !message;
  }

  form.addEventListener('change', () => { draftError = ''; updateFields(); render(); }, { signal: abort.signal });
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const type = select('trigger').value;
    const trigger: SleepTimerTrigger = type === 'duration'
      ? { type, durationMs: Number(input('duration').value) * Number(select('unit').value) }
      : type === 'items' ? { type, count: Number(input('count').value) } : { type: 'current' };
    try {
      draftError = '';
      timer.start({ trigger, action: select('action').value as PlaybackEndAction });
    } catch (failure) {
      draftError = failure instanceof Error && failure.message.startsWith('Load an item')
        ? '请先加载媒体，再设置播完当前项。' : '设置未生效，请检查时长、次数和结束动作。';
    }
    render();
  }, { signal: abort.signal });
  cancel.addEventListener('click', () => { draftError = ''; timer.cancel(); }, { signal: abort.signal });
  timer.addEventListener('change', render);
  timer.addEventListener('destroy', render);
  updateFields();
  render();
  root.append(element);

  return {
    element,
    setDurationOnly(live) {
      if (durationOnly === live) return;
      durationOnly = live;
      for (const option of Array.from(select('trigger').options)) option.disabled = live && option.value !== 'duration';
      if (live && timer.snapshot.status === 'running' && timer.snapshot.trigger?.type !== 'duration') timer.cancel();
      updateFields(); render();
    },
    destroy() {
      if (disposed) return;
      disposed = true;
      abort.abort();
      timer.removeEventListener('change', render);
      timer.removeEventListener('destroy', render);
      element.remove();
    },
  };
}
