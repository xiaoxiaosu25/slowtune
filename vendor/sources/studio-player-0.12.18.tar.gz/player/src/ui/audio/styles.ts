import { selectMenuStyles } from '../select-menu-styles.js';

/** Scoped defaults. Consumers override only public CSS variables on the returned element or an ancestor. */
export const audioStyles = `
${selectMenuStyles}
:host {
  display:block; min-width:0; color-scheme:light; container-type:inline-size;
  --sa-bg:#fbf9f7; --sa-surface:#fff; --sa-soft:#f1eeeb; --sa-text:#242328;
  --sa-muted:#716d75; --sa-border:#e6e1df; --sa-accent:#ba3652; --sa-on-accent:#fff;
  --sa-error:#ae293c; --sa-shadow:0 12px 48px #392c2414;
  font-family:var(--studio-audio-font,Inter,"Segoe UI","Microsoft YaHei",sans-serif);
  font-size:14px; line-height:1.5;
}
:host([data-theme=dark]) { color-scheme:dark; --sa-bg:#18181c; --sa-surface:#222228; --sa-soft:#2c2c33;
  --sa-text:#f5f1f2; --sa-muted:#b1aab5; --sa-border:#38363f; --sa-accent:#f28ba1;
  --sa-on-accent:#30121b; --sa-error:#ff9caa; --sa-shadow:0 16px 56px #0005; }
@media(prefers-color-scheme:dark) {
  :host([data-theme=auto]) { color-scheme:dark; --sa-bg:#18181c; --sa-surface:#222228; --sa-soft:#2c2c33;
    --sa-text:#f5f1f2; --sa-muted:#b1aab5; --sa-border:#38363f; --sa-accent:#f28ba1;
    --sa-on-accent:#30121b; --sa-error:#ff9caa; --sa-shadow:0 16px 56px #0005; }
}
.root {
  --bg:var(--studio-audio-background,var(--sa-bg)); --surface:var(--studio-audio-surface,var(--sa-surface));
  --soft:var(--studio-audio-surface-alt,var(--sa-soft)); --text:var(--studio-audio-text,var(--sa-text));
  --muted:var(--studio-audio-text-muted,var(--sa-muted)); --border:var(--studio-audio-border,var(--sa-border));
  --accent:var(--studio-audio-accent,var(--sa-accent)); --on-accent:var(--studio-audio-on-accent,var(--sa-on-accent));
  --danger:var(--studio-audio-error,var(--sa-error)); --radius:var(--studio-audio-radius,20px);
  --studio-player-text:var(--text); --studio-player-text-muted:var(--muted); --studio-player-surface:var(--surface);
  --studio-player-border:var(--border); --studio-player-accent:var(--accent); --studio-player-error:var(--danger);
  color:var(--text); position:relative; isolation:isolate;
}
* { box-sizing:border-box; }
[hidden] { display:none!important; }
audio-player,media-container { display:block; }
audio,[data-media-host] { display:block!important; position:absolute!important; width:1px!important; height:1px!important; overflow:hidden!important; pointer-events:none; }
.root[data-media-view=video]:not([data-player-closed=true]) [data-media-host] {
  display:block; position:relative!important; width:100%!important; height:auto!important;
  aspect-ratio:16/9; max-height:min(60vh,640px); object-fit:contain; background:#000;
  border-radius:var(--radius); pointer-events:auto; margin-bottom:12px;
}
button,select { font:inherit; color:inherit; }
button { cursor:pointer; border:0; background:transparent; touch-action:manipulation; }
button:disabled,select:disabled { opacity:.4; cursor:default; }
button,select,summary,[role=slider] { -webkit-tap-highlight-color:transparent; }
:is(button,select,summary,[role=slider]):focus-visible { outline:3px solid var(--studio-audio-focus,var(--accent)); outline-offset:3px; }
button:hover:enabled { background:var(--soft); }
.root[data-embedded=true] .info>.eyebrow { display:none; }
.root[data-embedded=true] .artwork:disabled { opacity:1; }
.host-actions button { min-height:36px; }
svg { display:block; width:22px; height:22px; flex:none; pointer-events:none; }
.icon { display:inline-flex; align-items:center; justify-content:center; width:44px; height:44px; flex:none; border-radius:50%; padding:10px; }
.icon[aria-pressed=true] { color:var(--accent); background:var(--soft); }
.button { min-height:44px; border-radius:12px; padding:10px 16px; font-weight:600; background:var(--soft); }
.button.primary,.play { background:var(--accent); color:var(--on-accent); }
.button.primary:hover:enabled,.play:hover:enabled { background:var(--accent); filter:brightness(1.08); }
.button.danger { color:var(--danger); }
.surface,.closed { border:1px solid var(--border); border-radius:var(--radius); background:var(--bg); box-shadow:var(--studio-audio-shadow,var(--sa-shadow)); }
.surface { overflow:hidden; }
.expanded-header { display:none; align-items:center; justify-content:space-between; padding:14px 20px 0; gap:12px; }
.eyebrow { text-transform:uppercase; letter-spacing:.14em; font-size:11px; font-weight:700; color:var(--muted); }
.header-title { text-align:center; }
.header-title strong { display:block; font-weight:600; font-size:13px; }
.playback { display:grid; align-items:center; grid-template-columns:64px minmax(110px,1fr) minmax(220px,1.4fr) auto;
  grid-template-areas:"art info controls toolbar" "art info timeline toolbar"; gap:0 16px; padding:18px 20px; }
.artwork { grid-area:art; display:grid; place-items:center; overflow:hidden; position:relative; aspect-ratio:1; width:100%; padding:0; border-radius:12px;
  background:var(--studio-audio-surface-alt,linear-gradient(145deg,#d8b9b1,#827188)); color:var(--text); box-shadow:0 4px 12px #0001; }
.artwork img { display:block; width:100%; height:100%; object-fit:cover; position:absolute; inset:0; }
.artwork .placeholder { display:grid; place-items:center; width:100%; height:100%; background:radial-gradient(circle at 60% 38%,#fff3 0 22%,transparent 22.5% 29%,#fff2 29.5% 30%,transparent 30.5%); }
.placeholder svg { width:36%; height:36%; opacity:.9; }
.info { grid-area:info; min-width:0; }
.info h2 { margin:0; font-size:15px; font-weight:650; line-height:1.5; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.info p { margin:3px 0 0; color:var(--muted); font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.info .eyebrow { display:none; }
.transport { grid-area:controls; display:flex; align-items:center; justify-content:center; gap:5px; }
.play { width:46px; height:46px; margin:0 4px; }
.play svg { width:24px; height:24px; }
.repeat-wrap { position:relative; }
.repeat-one { position:absolute; font-size:10px; top:8px; right:6px; font-weight:750; }
.timeline { grid-area:timeline; display:grid; grid-template-columns:38px minmax(0,1fr) 38px; align-items:center; gap:6px; }
.time { color:var(--muted); font-size:10px; font-variant-numeric:tabular-nums; text-align:center; }
media-time-slider,media-volume-slider { display:flex; align-items:center; position:relative; height:28px; min-width:0; cursor:pointer; touch-action:none; }
media-slider-track { display:block; position:relative; height:4px; width:100%; border-radius:10px; background:var(--border); }
media-slider-buffer,media-slider-fill { display:block; position:absolute; height:100%; border-radius:inherit; left:0; top:0; }
media-slider-buffer { width:var(--media-slider-buffer); background:var(--muted); opacity:.3; }
media-slider-fill { width:var(--media-slider-fill); background:var(--accent); }
media-slider-thumb { display:block; position:absolute; left:var(--media-slider-fill); width:10px; height:10px; border-radius:50%;
  transform:translateX(-50%); background:var(--accent); opacity:0; }
:is(media-time-slider,media-volume-slider):is(:hover,:focus-within) media-slider-thumb { opacity:1; }
media-time-slider[aria-disabled=true],media-volume-slider[aria-disabled=true] { opacity:.4; cursor:default; }
.toolbar { grid-area:toolbar; display:flex; align-items:center; gap:2px; }
.toolbar .icon { position:relative; }
.badge { position:absolute; top:0; right:0; border-radius:8px; min-width:15px; padding:0 3px; background:var(--soft); color:var(--text); font-size:9px; }
.sleep-active { width:6px; height:6px; border-radius:50%; background:var(--accent); position:absolute; right:7px; top:7px; }
.statusline { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:0 20px 12px; min-height:24px; color:var(--muted); font-size:11px; }
.statusline p { margin:0; }
.status-indicator { display:inline-block; width:6px; height:6px; border-radius:50%; background:var(--muted); margin-right:7px; }
.root[data-state=playing] .status-indicator { background:var(--accent); }
.root[data-busy=true] .status-indicator { animation:pulse 1s ease-in-out infinite; }
.host-actions { display:flex; flex-wrap:wrap; gap:8px; }
.host-actions button { border-radius:8px; padding:4px 8px; color:var(--accent); }
.error { margin:0 16px 14px; padding:12px 14px; border:1px solid var(--danger); border-radius:12px; display:flex; align-items:center; gap:16px; color:var(--danger); font-size:13px; }
.error p { flex:1; margin:0; }
.empty { padding:28px 24px 12px; text-align:center; }
.empty h3 { margin:0 0 6px; font-size:19px; }
.empty p { margin:0 0 14px; color:var(--muted); }
.closed { display:flex; align-items:center; justify-content:space-between; gap:20px; padding:20px 24px; }
.closed p { margin:0; color:var(--muted); font-size:13px; }
.closed strong { display:block; margin-bottom:4px; }
.root[data-view=expanded] .expanded-header { display:flex; }
.root[data-view=expanded] .playback { grid-template-columns:minmax(180px,340px) minmax(230px,1fr);
  grid-template-areas:"art info" "art controls" "art timeline" "art toolbar"; gap:12px 36px; padding:30px 40px 32px; }
.root[data-view=expanded] .artwork { border-radius:calc(var(--radius) * .8); }
.root[data-view=expanded] .info .eyebrow { display:block; margin-bottom:16px; }
.root[data-view=expanded] .info h2 { font-size:clamp(20px,3vw,30px); line-height:1.25; white-space:normal; overflow-wrap:anywhere; }
.root[data-view=expanded] .info p { font-size:14px; margin-top:8px; white-space:normal; overflow-wrap:anywhere; }
.root[data-view=expanded] .transport { gap:16px; }
.root[data-view=expanded] .play { width:60px; height:60px; }
.root[data-view=expanded] .play svg { width:30px; height:30px; }
.root[data-view=expanded] .timeline { grid-template-columns:40px minmax(0,1fr) 40px; gap:10px; }
.root[data-view=expanded] .time { font-size:12px; }
.root[data-view=expanded] .toolbar { justify-content:center; gap:16px; }
.root[data-view=expanded] .toolbar [data-action=expand],.root[data-view=expanded] .bar-close { display:none; }
.root[data-view=expanded] .statusline { padding:0 40px 20px; }
.root[data-view=expanded][data-metadata=false] .playback { grid-template-areas:"art controls" "art timeline" "art toolbar"; align-content:center; }
.root[data-view=mini] .playback { grid-template-columns:44px minmax(0,1fr) 44px 44px; grid-template-areas:"art info controls toolbar"; padding:12px; gap:8px; }
.root[data-view=mini] .transport .icon:not(.play),.root[data-view=mini] .timeline,.root[data-view=mini] .toolbar .icon:not([data-action=expand]),.root[data-view=mini] .statusline { display:none; }
.root[data-view=mini]:is([data-busy=true],[data-state=stopped],[data-state=ended]) .statusline { display:flex; padding:0 12px 8px; }
.root[data-view=mini] .repeat-wrap { display:none; }
.root[data-view=mini] .play { width:44px; height:44px; margin:0; }
.root[data-view=mini] .info h2 { font-size:14px; }
.root[data-view=mini] .artwork { border-radius:8px; }
.root[data-view=mini] .error { display:block; }
.root[data-view=mini] .error .button { margin-top:8px; }
.root[data-layout=mobile] .playback { grid-template-columns:48px minmax(0,1fr) auto; grid-template-areas:"art info controls" "timeline timeline timeline" "toolbar toolbar toolbar"; padding:14px; gap:10px; }
.root[data-layout=mobile] .transport .icon:not(.play) { display:none; }
.root[data-layout=mobile]:not([data-view=expanded]) .repeat-wrap { display:none; }
.root[data-layout=mobile] .toolbar { justify-content:space-evenly; }
.root[data-layout=mobile] media-time-slider { height:44px; }
.root[data-layout=mobile][data-view=mini] .playback { grid-template-columns:44px minmax(0,1fr) 44px 44px; grid-template-areas:"art info controls toolbar"; gap:8px; padding:12px; }
.root[data-layout=mobile][data-view=expanded] .playback { display:flex; flex-direction:column; gap:22px; padding:24px 24px 18px; }
.root[data-layout=mobile][data-view=expanded] .artwork { width:min(100%,320px); }
.root[data-embedded=true][data-layout=mobile][data-view=expanded] .artwork { width:min(100%,240px); }
.root[data-layout=mobile][data-view=expanded] .info { width:100%; }
.root[data-layout=mobile][data-view=expanded] .info .eyebrow { display:none; }
.root[data-layout=mobile][data-view=expanded] .info h2 { font-size:24px; }
.root[data-layout=mobile][data-view=expanded] .timeline { width:100%; order:2; }
.root[data-layout=mobile][data-view=expanded] .transport { order:3; width:100%; justify-content:space-between; gap:8px; }
.root[data-layout=mobile][data-view=expanded] .transport .icon { display:inline-flex; }
.root[data-layout=mobile][data-view=expanded] .toolbar { order:4; width:100%; gap:12px; }
.root[data-layout=mobile][data-view=expanded] .statusline { padding:0 24px max(20px,env(safe-area-inset-bottom)); flex-wrap:wrap; }
/* The compact bar is opt-in; smaller containers retain the established layout. */
@container (min-width:880px) {
  .root[data-density=compact][data-layout=desktop][data-view=bar] .surface { display:grid; grid-template-columns:minmax(0,1fr) auto; align-items:center; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .playback {
    grid-template-columns:40px minmax(90px,1fr) auto minmax(110px,1fr) auto;
    grid-template-areas:"art info controls timeline toolbar"; gap:8px; padding:12px;
  }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .transport { gap:2px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .icon { width:34px; height:36px; padding:7px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .play { width:40px; height:40px; margin:0 2px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .info h2 { font-size:14px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .info p { margin-top:1px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .timeline { grid-template-columns:32px minmax(0,1fr) 32px; gap:4px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .statusline { padding:0 12px 0 0; min-height:0; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .statusline>p { position:absolute; width:1px; height:1px; overflow:hidden; clip-path:inset(50%); }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .host-actions { gap:2px; flex-wrap:nowrap; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .host-actions button { min-height:36px; padding:6px; white-space:nowrap; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] :is(.empty,.error) { grid-column:1/-1; }
  .root[data-density=compact][data-layout=desktop][data-view=bar]:is([data-busy=true],[data-state=stopped],[data-state=ended]) .surface { grid-template-columns:minmax(0,1fr); }
  .root[data-density=compact][data-layout=desktop][data-view=bar]:is([data-busy=true],[data-state=stopped],[data-state=ended]) .statusline { padding:0 12px 8px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar]:is([data-busy=true],[data-state=stopped],[data-state=ended]) .statusline>p { position:static; width:auto; height:auto; clip-path:none; }
}
/* Medium compact containers keep transport and a full-width timeline below it. */
@container (min-width:740px) and (max-width:879px) {
  .root[data-density=compact][data-layout=desktop][data-view=bar] .surface { display:grid; grid-template-columns:minmax(0,1fr) auto; align-items:center; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .playback { grid-template-columns:40px minmax(90px,1fr) auto auto; grid-template-areas:"art info controls toolbar" "timeline timeline timeline timeline"; gap:0 8px; padding:8px 12px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .artwork { width:40px; height:40px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .transport { gap:2px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .icon { width:36px; height:36px; padding:8px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .play { width:40px; height:40px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] :is([data-action=shuffle],.repeat-wrap,.toolbar [data-action=expand],.bar-close) { display:none; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .info h2 { font-size:14px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .timeline { width:100%; grid-template-columns:32px minmax(0,1fr) 32px; gap:4px; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .statusline { padding:0 12px 0 0; min-height:0; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .statusline>p { position:absolute; width:1px; height:1px; overflow:hidden; clip-path:inset(50%); }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .host-actions { flex-direction:column; gap:0; }
  .root[data-density=compact][data-layout=desktop][data-view=bar] .host-actions button { min-height:36px; padding:6px; white-space:nowrap; }
}
.root[data-media-view=video][data-view=expanded] .artwork { display:none; }
.root[data-media-view=video][data-view=expanded] .playback {
  grid-template-columns:minmax(0,1fr) minmax(220px,1fr);
  grid-template-areas:"info controls" "timeline toolbar"; gap:16px; padding:20px;
}
.root[data-media-view=video][data-view=expanded] .info .eyebrow { display:none; }
.root[data-media-view=video][data-view=expanded] .info h2 { font-size:20px; }
/* 浮层由 packages/audio-video/player/src/ui/overlay 的核提供（方案 P5）；这里只声明音频皮肤 tokens。
   核的主题默认值在 :where(.studio-overlay) 里（零特异性），因此下面这些同名属性按变体生效。 */
.studio-overlay {
  --studio-overlay-background:var(--bg); --studio-overlay-text:var(--text); --studio-overlay-muted:var(--muted);
  --studio-overlay-border:var(--border); --studio-overlay-hover:var(--soft); --studio-overlay-accent:var(--accent);
  --studio-overlay-focus:var(--accent); --studio-overlay-backdrop:#12101766; border-radius:var(--radius);
}
/* 音频面板比视频的窄菜单宽：队列抽屉与设置卡片原来是 min(460px, …)，这里按面板宽度还原。 */
.studio-overlay .studio-overlay-panel { min-width:min(460px,calc(100vw - 24px)); }
.dialog-header { display:flex; justify-content:space-between; align-items:center; gap:12px; padding:18px 20px 12px; position:sticky; top:0; background:var(--bg); z-index:3; }
.dialog-header h2 { font-size:19px; margin:0; }
.dialog-header p { font-size:12px; color:var(--muted); margin:3px 0 0; }
.dialog-body { padding:0 20px 22px; }
.tabs { display:flex; padding:4px; border-radius:12px; background:var(--soft); margin:0 20px 16px; }
.tabs button { flex:1; min-height:40px; border-radius:9px; color:var(--muted); }
.tabs [aria-selected=true] { color:var(--text); background:var(--surface); box-shadow:0 1px 4px #0001; font-weight:600; }
.queue-list,.history-list { padding:0; margin:0; list-style:none; }
.queue-row { position:relative; display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid var(--border); }
.queue-track { display:flex; gap:12px; align-items:center; flex:1; min-width:0; min-height:60px; padding:8px; text-align:left; border-radius:10px; }
.queue-number { width:24px; flex:none; text-align:center; font-size:12px; font-variant-numeric:tabular-nums; color:var(--muted); }
.queue-copy { display:block; min-width:0; }
.queue-copy strong,.queue-copy small { display:block; white-space:nowrap; text-overflow:ellipsis; overflow:hidden; }
.queue-copy strong { font-weight:550; font-size:14px; }
.queue-copy small { color:var(--muted); font-size:12px; margin-top:3px; }
.queue-row[data-current=true] .queue-track { color:var(--accent); background:var(--soft); }
.queue-row[data-current=true] .queue-number { color:var(--accent); }
.row-menu summary { list-style:none; cursor:pointer; }
.row-menu summary::-webkit-details-marker { display:none; }
.row-actions { position:absolute; right:0; top:50px; z-index:5; background:var(--surface); padding:6px; border:1px solid var(--border); border-radius:14px; min-width:160px; box-shadow:0 8px 28px #0003; }
.row-actions button { display:block; text-align:left; width:100%; min-height:44px; padding:10px 14px; border-radius:8px; }
.row-actions [data-queue-action=remove] { color:var(--danger); }
.queue-footer { display:flex; justify-content:space-between; flex-wrap:wrap; align-items:center; gap:8px; padding-top:18px; }
.hint { color:var(--muted); font-size:12px; margin:12px 0; }
.history-list li { display:flex; gap:12px; padding:12px 8px; border-bottom:1px solid var(--border); }
.history-list [aria-current=true] { color:var(--accent); background:var(--soft); border-radius:10px; }
.history-list span { overflow-wrap:anywhere; }
.history-controls { display:flex; gap:8px; margin-bottom:12px; }
.history-controls .button { flex:1; }
.settings-grid { display:grid; gap:18px; }
.settings-grid label { display:grid; gap:7px; font-size:13px; }
select { width:100%; border:1px solid var(--border); background:var(--surface); border-radius:10px; padding:10px 12px; min-height:44px; }
.volume-control { display:flex; align-items:center; gap:12px; }
.volume-control media-volume-slider { flex:1; height:44px; }
.volume-control media-mute-button { display:inline-flex; min-width:44px; min-height:44px; align-items:center; justify-content:center; border-radius:50%; background:var(--soft); }
.settings-actions { display:grid; grid-template-columns:1fr 1fr; gap:10px; padding-top:8px; }
.root[data-layout=mobile] .dialog-header { padding-top:22px; }
.sr-only { position:absolute; width:1px; height:1px; overflow:hidden; clip-path:inset(50%); white-space:nowrap; }
@keyframes pulse { 50% { opacity:.3; } }
@media(prefers-reduced-motion:reduce) { * { animation:none!important; scroll-behavior:auto!important; } }
`;
