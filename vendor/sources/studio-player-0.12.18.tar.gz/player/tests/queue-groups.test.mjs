import test from 'node:test';
import assert from 'node:assert/strict';
import { QueueController } from '@studio/player/queue';
import { MediaSessionController } from '@studio/player/media-session';
import { SleepTimerController } from '@studio/player/sleep-timer';
import { setup, plan, Session, metadataFactory, settle } from './helpers.mjs';

const entries = () => ['a1', 'a2', 'a3', 'solo', 'b1', 'b2', 'repeat'].map(id => ({
  id, source: plan(id === 'repeat' ? 'solo' : id),
  ...(/^[ab]/.test(id) ? { groupId: id[0] } : {}),
}));
function grouped(t, options = {}) {
  const base = setup(t), queue = new QueueController(base.player, { order: 'shuffle', shuffleGroups: true, random: () => 0, ...options });
  t.after(() => queue.destroy()); queue.setItems(entries()); return { ...base, queue };
}

test('group shuffle preserves member order, occurrences, preview and actual history', async t => {
  const { queue } = grouped(t);
  await queue.selectId('a1');
  assert.equal(queue.peekNext().id, 'a2'); assert.equal(queue.peekNext().id, 'a2');
  while (queue.snapshot.canNext) await queue.next();
  const heard = queue.snapshot.history;
  assert.equal(new Set(heard).size, 7);
  assert.deepEqual(heard.slice(0, 3), ['a1', 'a2', 'a3']);
  assert.equal(heard.indexOf('b2'), heard.indexOf('b1') + 1);
  await queue.previous(); const previous = queue.snapshot.current.id;
  await queue.next(); assert.equal(queue.snapshot.current.id, heard.at(-1));
  assert.equal(previous, heard.at(-2)); assert.deepEqual(queue.snapshot.history, heard);
});
test('priority overrides a group; remaining members resume without replaying consumed songs', async t => {
  const { queue } = grouped(t);
  await queue.selectId('a1'); queue.enqueueNext('solo');
  assert.equal(queue.peekNext().id, 'solo'); await queue.next();
  const heard = ['solo']; while (queue.snapshot.canNext) { await queue.next(); heard.push(queue.snapshot.current.id); }
  assert.equal(heard.indexOf('a3'), heard.indexOf('a2') + 1);
  assert.equal(heard.includes('a1'), false); assert.equal(new Set(heard).size, heard.length);
});
test('grouping a live selection and editing its members preserves media and modes', async t => {
  const { queue, media } = grouped(t, { shuffleGroups: false, repeat: 'all' });
  await queue.selectId('a1'); media.currentTime = 12; const plays = media.playCalls;
  queue.setShuffleGroups(true); queue.setGroup(['a1', 'a2', 'a3'], 'new');
  assert.equal(media.currentTime, 12); assert.equal(media.playCalls, plays);
  assert.equal(queue.snapshot.order, 'shuffle'); assert.equal(queue.snapshot.repeat, 'all');
  await queue.remove('a2'); assert.equal(queue.peekNext().id, 'a3');
  queue.enqueueNext('solo'); queue.move('solo', queue.snapshot.items.length - 1, { cancelUpNext: true });
  assert.equal(queue.peekNext().id, 'a3');
  const before = queue.snapshot.items; assert.throws(() => queue.setGroup(['a1', 'missing'], 'bad'), RangeError);
  assert.deepEqual(queue.snapshot.items, before);
});
test('group cycles include the full group and selecting a middle member continues its tail', async t => {
  const { queue } = grouped(t, { repeat: 'all' });
  await queue.selectId('a2'); assert.equal(queue.peekNext().id, 'a3');
  for (let n = 0; n < 18; n++) await queue.next();
  const heard = queue.snapshot.history;
  assert(heard.filter(id => id === 'a1').length >= 2);
  for (let index = 0; index < heard.length - 2; index++) if (heard[index] === 'a1') assert.deepEqual(heard.slice(index, index + 3), ['a1', 'a2', 'a3']);
});
test('native completion and system next share the group successor and sleep stays authoritative', async t => {
  const { queue, player, media } = grouped(t);
  const session = new Session(), system = new MediaSessionController(player, { queue, session, createMetadata: metadataFactory });
  t.after(() => system.destroy()); await queue.selectId('a1'); system.activate();
  session.invoke('nexttrack'); await settle(); assert.equal(queue.snapshot.current.id, 'a2');
  media.currentTime = 1; media.trigger('timeupdate'); media.finish(); await settle();
  assert.equal(queue.snapshot.current.id, 'a3');
  const timer = new SleepTimerController(player); t.after(() => timer.destroy());
  timer.start({trigger:{type:'current'},action:'pause'});
  media.currentTime = 1; media.trigger('timeupdate'); media.finish(); await settle();
  assert.equal(timer.snapshot.status, 'expired'); assert.equal(queue.snapshot.current.id, 'a3'); assert.equal(media.paused, true);
});
