# 公共界面接入

版本：v1.7 · 2026-11-07

[返回包入口](../README.md)。公开签名以包声明为准，真实支持以入口和证据所述环境为准。

## MediaDock 独立设计与共用能力

`ui/mediadock` 提供 MediaDock 风格的音频播放坞、移动正在播放页和视频舞台，保持独立 Shadow DOM 与两种色板。现有 `ui/audio`、`ui/video` 和预览继续独立使用；它们共用核心与功能控制器。类型和完整选项以该入口声明为准。

```js
import { mountMediaDockAudioPlayer } from '@studio/player/ui/mediadock';
const ui = await mountMediaDockAudioPlayer(root, {
  items, palette: 'studio', theme: 'auto',
  sourceResolver, progressStorage,
});
// 选择条目后才准备来源并播放；折叠保留同一会话。
await ui.queue.select(0);
ui.setView('mini');
ui.destroy();
```

产品在队列来源提供 `DeferredMediaSource.prepare`，核心先刷写旧断点、暂停旧来源，再调用可取消准备；无需伪造可播放 URL。准备超时由来源显式声明，迟到处理会话会释放。产品承担来源 API、凭据、缓存和处理策略；工作中的转换必须响应信号或返回带释放信息的计划。

分段处理计划声明 `timeline`，公共位置、时长、缓冲、进度和系统媒体会话继续使用原文件时间。窗口内定位映射为媒体相对秒数；窗口外 `seekAsync` 经产品 `prepareSource` 重建。服务器音轨/输出尺寸与 HLS 真实音轨/ABR 画质分开处理。`recoverSource` 使用同资源共用的有界回退预算，避免并行恢复；引擎内部重试仍由上游负责。

初始断点与换源连续位置在可定位范围尚未就绪时保留，后续媒体就绪或缓冲事件继续尝试；手动定位、停止和重新加载会覆盖旧恢复请求。完整备用交付独立声明时间轴，省略时按原文件零偏移处理；同交付镜像的 `fallbackUrl` 简写沿用主源时间轴。

`stop()` 保留原有断点语义；`stopAndReset()` 显式停止并清除存储断点，下一次加载同资源按从头准备。MediaDock 音频的归零按钮调用后者，音频关闭默认清空队列，折叠继续播放；视频两套默认保留队列，可显式配置清空。预热为可选产品租约，等待真实缓冲充足后准备下一项，不创建第二个播放器、不消费随机队列，取消与销毁释放租约。

字幕导入支持有界 SRT/WebVTT 与 UTF-8/GB18030 解码，转为标准 WebVTT；原时间轴字幕在偏移来源上裁剪和移动 cues。复杂 ASS、WebVTT region/style 块及未支持语法不作完整排版保证。

偏移字幕的请求超时会发布可见失败，换源或销毁造成的取消保持静默。断点、备用源和字幕边界的回归结果见[评审修复验证](../evidence/review-fixes-2026-10-03.md)。

宿主显式选择 `native-audio` 并提供 `NativeAudioPort` 时，核心发送命令并消费带 playbackId 的服务事实；公开媒体元素为空，状态不会由命令成功伪造。Android 服务、通知、音频焦点和 Cookie 由产品维护；未提供服务时拒绝装配。本轮只验证桥接夹具，实体 Android 尚未验收。消费者接线与真实服务字段映射示例见[整合检查](../../../../labs/audio-video/player/mediadock-check/README.md)。

## 直接挂载音频套件

```js
import { mountAudioPlayer } from '@studio/player/ui/audio';

const ui = await mountAudioPlayer(document.querySelector('#audio'), {
  items: [{
    id: 'entry-1', title: '第一集', artist: 'Studio',
    artwork: [{ src: '/cover.svg', type: 'image/svg+xml' }],
    source: { src: '/episode.mp3', type: 'audio/mpeg', resourceId: 'episode-1' },
  }],
  queue: { order: 'sequential', repeat: 'off' },
  theme: 'auto', layout: 'auto',
  onError: error => console.error(error),
});
// 点击公共播放按钮即可播放；挂载本身不加载或自动播放。
ui.setView('expanded');
ui.setTheme('dark');
ui.setTokens({ accent: '#43846a', 'on-accent': '#fff', radius: '10px' });
// 离开宿主时：
ui.destroy();
```

单条媒体同样传一个 `QueueItem`。返回的 `AudioPlayerUI` 拥有一个 audio 预设、媒体元素和界面，暴露 `player/queue/sleepTimer/mediaSession/mainMedia/element`，功能对象就是下文的独立实现。进度可传 `progressStorage/progressPolicy`；未提供端口时不保存断点。套件在实际播放时激活可用的系统媒体控制，停止/关闭后释放归属。主媒体互斥须另外传 `features.mainMedia: { scope }`。

| 配置 / 操作 | 语义 |
| --- | --- |
| `items`、`queue` | 初始列表及 `QueueOptions`；UI 始终保留队列。后续编辑调用 `ui.queue` |
| `features` | 可显式关闭或配置 SleepTimer、MediaSession；audio 默认包含它们，不自动启动睡眠规则 |
| `layout` / `setLayout` | `auto/desktop/mobile`；auto 按挂载容器宽度，小于 740px 使用移动布局 |
| `view` / `setView` | `bar/expanded/mini`；未指定时 PC 默认播放条、移动默认迷你条。显式切换后保持所选形态 |
| `presentation` / `setPresentation` | `{ embedded: true, queue: false }` 表示宿主拥有完整页面导航与同一队列的展示；隐藏重复的展开／关闭／形态设置和队列入口，传 `{}` 恢复默认，不加载资源 |
| `presentation.metadata` | `false` 时收起套件标题／作者，宿主自行展示同一队列元数据；默认显示，切回 `{}` 恢复 |
| `onRequestExpand` | 封面和展开按钮请求宿主播放页；提供时不再修改套件 view，也不加载媒体，未提供仍沿用原内部展开 |
| `nativeElementTag` | 默认 audio；混合音视频可显式设为 video，原生回退继续使用该标签。媒体与队列仍由本套件唯一持有 |
| `mediaView` / `setMediaView` | 默认 audio（收起媒体画面），video 展示同一个媒体元素。切换不加载资源、不定位、不改变暂停意图、队列或睡眠；原生 audio 不接受 video 展示 |
| `theme` / `setTheme` | `auto/light/dark`；auto 跟随系统颜色偏好 |
| `tokens` / `setTokens` | 设置本实例的公开变量；每次调用替换此前通过此 API 设置的变量，`{}` 恢复继承/默认值 |
| `setItems(items)` | 停止并保存后替换整个列表，不起播；返回是否仍为最新操作。追加/重排不应使用此方法 |
| `close()` / `open()` | 关闭先执行公共结束控制；重开保留队列但不播放。显式播放按钮调用 `queue.play()` 重新加载 |
| `destroy()` | 幂等销毁拥有的媒体、控制器、事件、定时任务和界面；外部 `player.destroy()` 同样释放 UI |
| `onRequestItems` | 有此回调才显示“添加音频”；宿主负责选文件或搜索，并通过 `ui.queue.add` 提供条目 |
| `actions` | 最多三个唯一 `id/label/run({ player, queue, current })` 宿主操作，显示于状态栏；可选 `visible(context)` 随渲染核对可见性 |
| `onClose` / `onError` | 已完成关闭的通知、错误反馈；不替宿主退出应用 |
| `createMediaElement(document)` | 默认原生 audio；需要其他类型可返回已注册的上游媒体元素，由套件拥有与释放。HLS 引擎仍需安装/注册，具体类型按产品范围验证 |

PC 提供封面、曲目信息、播放模式、进度、队列/历史面板和设置；移动提供迷你条、展开的正在播放视图与底部抽屉。队列行菜单可指定下一首、上下移动、移除；睡眠复用 `mountSleepTimerSettings`。键盘 Space/Enter 操作按钮，滑块方向键定位，页签方向键切换，弹窗 Tab 循环、Escape 关闭并恢复焦点。**面板即时生效**：队列是右侧抽屉（点外面关闭、不锁背景），设置与睡眠是居中的模态卡片（背景不可操作、锁滚动、Escape 关闭），窄视口下都转为底部抽屉。失败保持当前条目并提供重试；等待、停止、关闭和空列表均有反馈。UI 放在宿主布局中，吸底/定位由宿主决定。

视频 UI 可选 `queueLabel` 指定临时队列的入口与面板名称，不改持久集合或媒体标题。全部形态和皮肤只改变展示，共用同一媒体、位置、队列、睡眠与系统归属。UI 不提供替换内部 HTML 的接口；需要完全自绘时使用无头预设或独立控制器。

混合原生音视频队列可通过 `mountAudioPlayer(root, { nativeElementTag: 'video', mediaView: 'video' })` 装配，随后 `ui.setMediaView('audio')` 收起画面。每个条目仍填写真实音频或视频媒体类型；宿主在音频条目及浏览其他页面时选择收起画面。该路径继续传输完整原视频，不提供音轨提取或省流承诺。Stream／MediaDock 视频套件的多轨、字幕等完整视频特性仍使用原视频入口；两种套件不叠加创建会话。

### 公开皮肤变量

变量可设在 `ui.element` 或祖先；`tokens` 键是去掉 `--studio-audio-` 前缀的名字。默认明暗完整提供，替换主题应同时检查文字、交互与焦点的可读性。

**变量清单以样式模块为准**（`src/ui/audio/styles.ts`），覆盖主背景与面板、主次文字、强调色、边框与焦点、圆角与字体几类；本 README 不逐条誊抄。无封面的底色跟随显式 `surface-alt`，图标跟随文字色；未配置时保留原占位底色。

音视频与嵌套睡眠表单共用原生下拉样式。宿主在返回元素或祖先设置 `--studio-player-select-appearance: base-select` 后启用可定制选择面板；未设置或浏览器不支持时保留原生选择。公开的 `--studio-player-menu-*` 变量用于面板、选项、选中／悬停、字体颜色与投影，具体名字及回退值由 `src/ui/select-menu-styles.ts` 维护。这些变量跨 Shadow DOM 继承，不要求操作内部 DOM；不改变选项、表单提交、禁用和键盘行为。

视频 UI 可显式传入现有 `player`、`queueController`、`sleepTimerController` 和 `mediaSessionController`，复用音频 UI 持有的会话。只共享队列时，套件创建的系统媒体控制绑定该队列，沿用其元数据与上一首／下一首状态；显式借用的系统媒体控制保留宿主绑定和生命周期，见[回归证据](../evidence/shared-queue-media-session-2026-10-27.md)。宿主负责把同一媒体元素放到当前视图，并隐藏非当前 UI；切换呈现不调用取源、定位或播放。按需挂载完成后应重新核对最新页面与模式，不能用挂载前的状态覆盖用户的新选择。

[示例 B](../../../../examples/audio-video/player/example-b/README.md)消费此入口，并用“雪松”替换色彩、圆角和字体。文字、背景、边框和强调色同步传入嵌套睡眠表单。浏览器范围、截图和未执行的人工验收分别见[音频专项检查](../../../../labs/audio-video/player/audio-check/README.md)。

## 直接挂载视频套件

```js
import { mountVideoPlayer } from '@studio/player/ui/video';
import { MainMediaCoordinator } from '@studio/player/main-media';

const scope = new MainMediaCoordinator(); // 产品提供；同产品的音频也传入此 scope
const ui = await mountVideoPlayer(document.querySelector('#video'), {
  items: [{ id: 'entry-1', title: '第一集', source: {
    resourceId: 'video-1', mediaType: 'video', strategy: 'direct', transport: 'hls',
    playUrl: '/video/master.m3u8', mimeType: 'application/vnd.apple.mpegurl',
    tracks: { subtitles: [{ id: 'zh', src: '/video/zh.vtt', type: 'text/vtt', label: '中文', language: 'zh', default: true }] },
  } }],
  features: { mainMedia: { scope } },
  variant: 'stream', theme: 'auto', layout: 'auto', view: 'standard',
  controls: { preset: 'balanced' }, clearQueueOnClose: false,
});
ui.queue.setAutoAdvance(true); // 默认 false，消费者或用户显式开启
ui.setView('wide');
ui.setControls({ preset: 'custom', placement: { rate: 'toolbar', subtitle: 'toolbar', sleep: 'settings' } });
ui.setTokens({ accent: '#ae6828', 'on-accent': '#fff', timeline: '#ffc17b', radius: '6px' });
// 页面离开时（共享 scope 由创建它的产品在自身结束时销毁）：
ui.destroy();
scope.destroy();
```

`mountVideoPlayer(root, options)` 默认使用上游 `hlsjs-video`，需安装两个锁定 peer；同一个元素可播放 HLS 和原生 MP4。只需 MP4 时可传 `createMediaElement: document => document.createElement('video')`，不依赖 HLS peer。挂载不加载、不自动播放；单条视频传一个条目。默认媒体、资源类型和宿主能力以实际运行结果为准。

接口和完整选项以 `VideoPlayerOptions`、`VideoPlayerUI` 声明为准。视频 UI 始终启用 Queue 和 VideoTracks，睡眠与系统媒体可关闭，主媒体协调只接受显式 scope。初始/全量替换列表会拒绝明确标成音频的来源；直接操作公共 Queue 的类型筛选由消费者负责。

`variant` 默认 `stream`，`mediadock` 使用全页模态舞台、顶部标题与关闭入口，保留独立布局；Stream 内嵌于宿主容器。二者共用播放器、功能面板、缩略图选集、可读信息、睡眠、字幕避让与焦点规则。`classic/cinema` 已兼容映射到 Stream，不再维护额外完整实现。`ui/mediadock` 的视频挂载入口委托此实现，音频继续独立维护。mpv 仍只允许 Stream，本轮浏览器结果不扩大宿主支持。

“设置 → 更多设置 → 按钮布局”可选择集中、常用外置或逐项选择位置；消费者用 `controls/setControls` 配置同一映射。Stream 默认集中，MediaDock 默认外置倍速、字幕和睡眠。手机只在空间足够时保留并列倍速，所有功能同时可从设置访问；其他外置入口暂时折叠，恢复宽度后按原配置展示。缺失能力时外置入口隐藏，设置保留原因。设置与快捷入口打开同一面板；配置切换不重建媒体，不重置位置、暂停意图、队列或睡眠。配置只属于当前 UI 实例，跨挂载保存由消费者承担。

宽屏与紧凑布局均保留 contain 画面和可访问功能；Stream 宽屏使用容器内较宽画幅，MediaDock 宽屏移除舞台外缘。模态舞台按自身可用宽度判断布局。布局变化不改变鼠标播放暂停含义，触摸画面切换控件显隐。MediaDock 旧音频形态参数在视频兼容入口仍可调用，视频始终展示完整舞台。

主要控件及进度输入区域至少 44px；拖动预览与后台时间更新分开，松开后通过原始时间轴异步定位。菜单支持返回、关闭、方向键、Escape、Tab 与焦点返回，隐藏或禁用项不参与导航。播放列表共用缩略图、当前项标记、连播开关；宿主动作在视频信息中可访问。快捷睡眠执行暂停，自定义表单支持停止与关闭；信息按当前实际解码尺寸匹配画质与码率。字幕面板共用 SRT/WebVTT 导入，要求已加载播放计划；服务端音轨和输出尺寸要求当前计划及宿主重建端口，和真实 HLS 档位分别显示。

两套共用播放反馈、提示、控件自动隐藏、错误与重试。播放器范围内 Space/K 播放暂停、左右键定位、J/L 前后十秒、上下键音量；其余快捷键见控件提示。输入与菜单保留自身按键行为，模态 Escape 先关闭面板，再关闭播放器并保存。全屏/PiP 使用标准媒体 API，仅显示实际可用入口。原生 WebVTT 自动定位字幕按控制区避让，控件隐藏或销毁后恢复；明确定位、竖排及 region 字幕保留来源设置。本轮验证入口见[整合检查](../../../../labs/audio-video/player/video-check/consolidation.html)，历史体验证据保留其当时版本。

默认明暗与跟随系统均可用。公开变量与音频同名、前缀改为 `--studio-video-`：`background/surface/surface-alt/text/text-muted/accent/on-accent/border/focus/error/radius/font/shadow`，另有 `--studio-video-controls`（画面控件色）、`--studio-video-timeline`（进度强调色）。`tokens` 使用去掉前缀的键，`setTokens({})` 清除 API 覆盖。只允许这些变量及最多三个宿主动作，内部 DOM/CSS 不是稳定接口。

主题、布局、标准/宽屏原地更新，不重建媒体、选集、进度或睡眠。视频 UI 的 `close()` 立即停止声音、捕获断点、隐藏界面并通知 `onClose`，其 Promise 不等待存储网络；后台保存/释放失败交给 `onCloseError` 和 `player:closeerror`，不恢复旧界面。需要等待持久化与释放的无头消费者继续调用 `player.close()`；核心的 `closeintent` 表示即时退出，`closerequest` 表示完成清理。`open()` 只显示，下一次显式播放重载所选项；同资源快速重开优先使用待同步断点，旧关闭不能影响新会话。关闭/销毁会请求退出属于本实例的全屏与画中画。[示例 B](../../../../examples/audio-video/player/example-b/README.md)直接消费此入口并提供“琥珀”替换主题；[视频专项](../../../../labs/audio-video/player/video-check/README.md)给出真实多轨样本和独立验收步骤。

视频 UI 的普通播放/暂停、进度、音量、静音、全屏和画中画入口由本套件的 `button` 与 `input[type=range]` 控件承载，控件状态来自 `StudioPlayer` 的中立事实与事件。`stream` 模板保留内部 `[data-surface-slot="media"]` 媒体槽位；mpv 实例由宿主通过 `SurfacePort` 接入 native surface，Video.js 实例仍把媒体元素放入其中。平台最小 Electron 宿主已验证该接缝，但 UI 本身不提供 Electron、Node、native helper 或产品宿主实现。未提供真实能力的画质、PiP、字幕或音轨入口不会显示为成功状态。

手机竖屏的画面、控制与选集使用正常文档流，单独限制竖视频高度并保留完整比例；控制图标保持小尺寸，点击区域为 48px。横屏与全屏使用可用动态高度，界面按安全区留边；设置采用可见视口内的底部面板或横屏侧面板。浏览器尺寸已有验证，实际刘海、动态工具栏、软键盘、系统字体缩放与 Safari/WebView 行为仍须设备验收。

## 直接挂载轻量预览

```js
import { mountPreviewPlayer } from '@studio/player/ui/preview';
const ui = mountPreviewPlayer(document.querySelector('#preview'), {
  media: { source: { src: '/clip.mp4', type: 'video/mp4', resourceId: 'clip-1' }, title: '片刻', poster: '/cover.jpg' },
  view: 'card', theme: 'auto', hoverPreview: true,
  onError: error => console.error(error),
});
ui.setView('mini'); // 同一媒体、资源身份与位置，只改变布局
await ui.close();   // 停止/保存成功后隐藏内容并通知 onClose
ui.open();          // 只恢复界面；不加载、不播放
ui.destroy();       // 幂等释放；不释放消费者创建的 Object URL
```

挂载是**同步**的，返回 `PreviewPlayerUI`，无需等待即可调用关闭或销毁。首次 `play()` 才异步创建媒体：默认动态导入锁定 peer 的 `@videojs/html/media/hlsjs-video`，同元素用于现有音频、MP4、HLS 范围；只有原生来源时可传 `createMediaElement: doc => doc.createElement('video')`。工厂也允许返回 Promise，UI 拥有返回的媒体。动态导入本身无法物理中止，迟到结果会被逻辑取消并释放，不能附加回 UI 或起播；失败后可显式重试，不缓存 rejected Promise。接口风格沿用音视频的 `setTheme/setTokens/setView/open/close/destroy`；`await mountPreviewPlayer(...)` 仍可用，但它不代表媒体初始化完成。

输入 `media` 是 `{ source: PlayableInput, title?, poster? }`；`setMedia(media | null)` 立即取消旧操作并停止，等待断点保存，返回是否仍为最新选择，不自动播放。音频封面同时识别来源适配器推断的 MIME，URL 字符串或省略 `type` 的音频来源仍保留封面。`play()` 首次/停止/失败后重载，暂停后继续当前会话，自然完播保留资源、手动播放回到开头。`pause/stop/close` 沿用 core 规则；公开异步方法的非取消错误会通知 `onError` 且仍拒绝 Promise，按钮接线已处理拒绝。`onClose` 只在关闭完成后通知；关闭后 `open()` 将焦点移到可见的播放按钮（无媒体时为关闭按钮），不加载或起播。`destroy()` 与关闭不同，会释放 DOM、媒体、监听、悬停计时和自己的协调注册。调用借出的 `player.destroy()` 同样销毁 UI。

默认 `hoverPreview: false`；开启后仅 card 且 `(hover: hover) and (pointer: fine)` 生效，触屏和键盘聚焦不自动播放。`hoverDelayMs` 默认 250，静音起播，移出取消等待/待播放并停止释放来源。切换 mini 后脱离卡片移出规则，保留原会话。点击和原生按钮/滑块支持键盘；主要操作 44px，长标题截断并保留 title，窄容器允许控制换行。实际视觉、实体触屏和媒体效果待补验。

不创建 Queue、SleepTimer、MediaSession 或 VideoTracks；不静态导入音视频 UI 或 presets。UI 用 core 的最小组合，原 `createPlayerPreset('preview')` 的功能/进度默认值完全不变。UI 默认没有 Progress，只有显式传 `progressStorage` 才保存/恢复，`progressPolicy`、resolver、sourceOptions 沿用 core。`mainMedia: { scope }` 也必须显式提供；静音悬停不注册/抢占，显式有声播放或已有播放意图时通过 `setMuted(false)` 取消静音，先认领 scope 再允许声音。空闲、暂停、停止或关闭时设置静音只更新偏好，不抢占其他播放器；起播等待中改为静音保留播放意图，较新换源/取消优先。暂停/停止/关闭释放归属。媒体的 `volumechange` 同步到控件，暂停续播保留最新音量/静音设置。未提供 scope 不承诺跨实例互斥；没有全局主媒体单例，也不接管系统媒体键。

公开变量前缀 `--studio-preview-`，键为 `background/surface/text/text-muted/border/accent/focus/error/radius/font`。`tokens/setTokens` 只接受这些键，每次替换上次 API 覆盖，`{}` 恢复默认/继承。默认明/暗/跟随系统与示例 B 的完整琥珀替换色板均不依赖示例 CSS；切肤不重建会话。内部 DOM 不是公开接口。分块与实际字节数见任务报告及 B 的 `check-chunks.mjs`；构建图不替代网络行为检查。

## 最小睡眠设置组件

```js
import { mountSleepTimerSettings } from '@studio/player/ui/sleep-settings';

const settings = mountSleepTimerSettings(document.querySelector('#sleep-settings'), timer);
// 更换布局或移除面板时：
settings.destroy(); // 只移除自己的 DOM/订阅，借用的 timer 和睡眠规则继续有效
```

表单提供倒计时（分钟/秒）、自然完成次数、当前项和三种动作，以及重新设置、取消、剩余提示和错误反馈。组件有独立开放 Shadow DOM，样式随模块封装，不需要从 examples 复制脚本或 CSS。公开变量可在挂载父元素上配置：`--studio-player-accent`、`--studio-player-surface`、`--studio-player-text`、`--studio-player-text-muted`、`--studio-player-border`、`--studio-player-radius`、`--studio-player-error`；字体继承宿主。

`destroy()` 可重复调用且不销毁控制器；若控制器先销毁，表单禁用。A/B、音频与视频 UI 接入同一组件。表单、焦点与窄视口经过无头 Edge 自动检查；实体触屏与人工验收按各自记录处理。

原生 video 接入时，混合队列采用内容与条目的中性文案；未知作者仍明确标注。文案切换只作用于组件自己的固定文字，不改宿主传入的标题和资料。
