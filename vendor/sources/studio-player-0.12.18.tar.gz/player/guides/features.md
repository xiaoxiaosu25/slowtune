# 功能装配与场景

版本：v1.2 · 2026-11-13

[返回包入口](../README.md)。公开签名以包声明为准，真实支持以入口和证据所述环境为准。

## 产品范围主媒体协调

```js
const scope = new MainMediaCoordinator();
const audioOwner = scope.register(audioPlayer);
const videoOwner = scope.register(videoPlayer);
await videoPlayer.play(); // 同步暂停 scope 内的音频，再开始视频
videoOwner.release();    // 暂停并释放，不恢复音频
scope.destroy();         // 注销参与者，暂停活动者；不销毁借用的播放器
```

独立用 `scope.register(player)`，预设和音视频 UI 用 `features: { mainMedia: { scope } }`，共用同一实现。scope 提供 `active/size/isDestroyed/register/destroy` 和 `change/destroy` 事件；返回控制器提供 `active/isDestroyed/activate/release/destroy`。`activate()` 只认领、不会播放，通常直接调用 player/Queue 的播放操作即可。产品负责 scope 生命周期；不创建隐式全局单例。

最新播放意图同步抢占旧拥有者，旧者暂停并撤销 Queue 接续、未完成 play 和换源自动起播，位置、队列、睡眠规则保留。加载前可独立调用 `player.requestPlayback(): boolean` 预先声明意图，`playbackRequested` 读取意图；这不是已起播事实。队列自动使用此协议，历史仍只接受真正的 `playing` 或成功 play。暂停、停止、关闭、终态失败、播放拒绝、卸载和销毁释放归属；手动自然结束也释放，显式接续完成决策后由下一项持有。释放从不自动唤回前一个播放器，重入抢占以最新请求为准。

主媒体协调负责同范围不双重发声，MediaSession 负责某个系统端口的控制归属，两者独立：认领主媒体不自动占用系统媒体键。公共 UI 在真实起播时激活其系统控制；无头消费者自行选择系统拥有者。未注册实例和不同范围互不影响。

## 按场景接入

`createPlayerPreset(name, options)` 返回 `{ name, player, features, destroy }`。预设只负责功能选择、默认值和释放关系；不创建 DOM、不加载来源、不自动播放、不自动激活系统媒体控制。界面可以使用官方皮肤或产品自绘，来源和存储端口仍由产品传入。

| 场景 | 默认启用功能 | 开启队列后的默认行为 | 原生承载标签默认值 |
| --- | --- | --- | --- |
| `preview` 媒体预览 | 无 | 完播不接续，手动前后项 | `video` |
| `audio` 音频听播 | Queue、SleepTimer、MediaSession | 顺序接续、循环关闭 | `audio` |
| `video` 视频点播 | Queue、SleepTimer、MediaSession、VideoTracks | 完播不接续，手动选集 | `video` |

上表的“完播不接续”保持 `ended` 状态，不等于主动调用释放来源的 `stop()`。0.5.0 的 audio 默认创建空闲 SleepTimer，所有场景均不自动设置睡眠规则；`features.sleepTimer: false` 仍明确禁用。进度记忆由是否传入 `progressStorage` 决定。`progress: false` 即使收到存储端口也不接入；`progress: true` 必须提供含 `load/save/clear` 的端口。未明确关闭时，单独提供 `progressPolicy` 而缺少存储会抛错。没有隐式 localStorage。原生标签可用 `nativeElementTag` 覆盖，场景名不负责过滤产品传入的队列。

```js
import { createPlayerPreset } from '@studio/player/presets';

const audio = createPlayerPreset('audio', {
  features: { sleepTimer: true },
});
audio.player.attach(document.querySelector('audio'));
audio.features.queue.setItems([
  { id: 'episode-1', source: { src: '/episode-1.mp3', resourceId: 'episode-1' } },
  { id: 'episode-2', source: { src: '/episode-2.mp3', resourceId: 'episode-2' } },
]);
// 在用户操作中调用，并处理播放拒绝：
await audio.features.queue.select(0);
audio.features.mediaSession.activate();
audio.features.sleepTimer.start(15 * 60 * 1000);

audio.features.setEnabled('sleepTimer', false); // 取消计时，当前播放与队列继续
audio.destroy(); // 结束播放器并释放本组功能
```

`features` 的 `queue/sleepTimer/mediaSession` 接受 `false/true/配置对象`，`videoTracks` 接受布尔值，`mainMedia` 只接受 `false` 或 `{ scope }`。省略或 `undefined` 沿用场景默认；显式配置优先。0.6.0 的 video 新增上表空闲功能；要保留 0.5.0 的纯底座 video，传 `{ queue: false, sleepTimer: false, mediaSession: false, videoTracks: false }`。视频连播须显式 `{ queue: { autoAdvance: true } }`。系统队列由组合层接线，不能另传其他队列。

已有播放器可用 `mountPlayerFeatures(player, options)` 集中管理功能；此入口默认不启用功能，队列启用后默认顺序接续。也可直接使用下一节的独立控制器。

```js
import { mountPlayerFeatures } from '@studio/player/presets';

const features = mountPlayerFeatures(player, { queue: true, sleepTimer: true });
features.addEventListener('change', () => renderFeatures(features));
features.setEnabled('mediaSession', true);
features.mediaSession.activate();
features.destroy(); // 仅拆除这一组功能，借用的 player 仍可播放
```

组合组的 `queue/sleepTimer/mediaSession/videoTracks/mainMedia` 是当前控制器或 `null`，同时提供 `isDestroyed`、`change/destroy` 事件。重复启用不重建；切换一个功能保留其他功能的实例和状态。关闭后重新开启沿用最初配置，但不恢复旧列表或计时；产品需重新提供列表。队列开关只重连系统导航，不改变活动系统实例或当前媒体信息。mainMedia 必须在初始配置提供 scope，不能凭 `true` 隐式创建。

由组合组创建的控制器通过 `setEnabled` 拆除；直接构造的控制器自行 `destroy`。`features.destroy()` 保留播放器，移除 mainMedia 会暂停并释放其归属；预设 `destroy()` 销毁播放器，外部 `player.destroy()` 同样释放组合组。配置在装配前检查，装配失败清理本组资源并抛错。进度属于播放器创建配置，不通过这些功能开关切换。

## 结束控制与睡眠规则

`pause()` 同步暂停并取消待执行的接续，后续 `play()` 继续同一来源。`stop(): Promise<void>` 捕获当前实际位置，立即停止媒体、使旧加载/播放/刷新结果失效、清空来源并关闭处理会话、停用系统媒体归属；随后等待进度写入。列表、选择、控制器和挂载位置保留。停止后 `currentPlan/currentResourceId` 为空，媒体的位置可能归零；需要显示停止位置时监听 `stop({ resourceId, positionSeconds, durationSeconds, completed })`。

断点保存需要注入 `progressStorage`；没有端口时仍正常停止，但不隐式持久化。已自然完播的断点保持清除，不写回结束位置；未读完的起播断点不被尚未恢复的零秒覆盖。停止保存不套用完播清除阈值，重新加载时仍遵守宿主配置的恢复策略。存储保存或本次完播清除失败会拒绝 `stop/close`，播放资源已释放；调用方应展示失败。

`close({ signal? }): Promise<void>` 在停止和进度写入完成、请求仍有效时发出 `closerequest`。消费者监听该事件关闭自己的界面；它不会销毁播放器、操作页面 DOM 或退出应用。新 `load`、detach/destroy 或取消 signal 可阻止等待中的关闭请求，拒绝为 AbortError；已经执行的停止不会回滚。远端 `onSessionClose` 仍是尽力释放请求，停止不等待服务端确认；本机 `processing.session` 的释放会等待，远程真实后端另验。

停止后的底座 `player.play()` 拒绝为 InvalidStateError，先显式 `load(input)` 或调用 `queue.play()` / `queue.select(index)` 重载；重新打开 UI 本身不自动加载。外部状态枚举需包含 `stopped`，旧 `start(durationMs)` 调用无需修改。

```js
import { SleepTimerController } from '@studio/player/sleep-timer';

const timer = new SleepTimerController(player);
// 以下规则分别使用；重新 start 会替换前一个规则。
timer.start({ trigger: { type: 'duration', durationMs: 23 * 60 * 1000 }, action: 'pause' });
timer.start({ trigger: { type: 'items', count: 3 }, action: 'stop' });
timer.start({ trigger: { type: 'current' }, action: 'close' }); // 须已加载媒体
timer.addEventListener('error', event => showError(event.detail));
player.on('closerequest', () => closePlayerView());
timer.cancel();
```

倒计时按经过的墙钟时间计算，暂停时继续，恢复前台会校正；时长须为正有限毫秒数。计数须为正安全整数，只扣自然完播，手动切换、跳至末尾和重复 ended 不扣次数。“播完当前项”指下一次自然完播，手动换项后等待新的当前项。核心先发 `beforeended(completion)`，再发 `ended(completion)`，睡眠决策先于队列，独立装配顺序不影响优先级。`PlaybackCompletion` 含资源、位置、时长与 `natural`，调用方不能用普通定位事件伪造完播。

`snapshot` 包含 `status`（idle/running/expired）、`trigger`、`action`、`deadline/remainingMs`、`remainingItems`、`actionPending` 和 `error`。`change` 更新状态，`expire` 表示触发，`complete` 表示结束动作成功，`error` 反馈失败；不能只凭 expired 判定保存/关闭完成。重设/取消/卸载会撤销旧计时和等待中的关闭；手动 stop 取消尚在运行的睡眠。未启用队列时计数仍可用，但不会替消费者自动加载下一项。

## 可选产品功能

### 队列契约

`QueueItem.groupId` 是宿主声明的一次分组，不能替代条目 ID。同一资源可多次入队、属于不同组。`shuffleGroups: true` 或 `setShuffleGroups(true)` 让随机以组为单位、组内沿当前队列顺序；没有组的条目各为一个随机单位，默认仍逐项随机。切入组内某一项后继续其后的成员，本轮略过之前成员；列表循环下一轮包含完整组，并优先其他组。分组模式不改变全局 `order/repeat`。

`setGroup(ids, groupId?)` 校验全部 ID 后原位标记／解除分组，保留当前媒体、位置、播放意图和会话历史。`insertNext/enqueueNext` 的显式优先项仍先执行，随后剩余成员继续按组播放。`peekNext`、自然接续、系统媒体键与手动 `next` 使用同一决策；历史前后导航优先于新的随机决策。`move(id, index, {cancelUpNext:true})` 在重排时同时取消该条目的显式下一项优先级。

```js
import { QueueController, SleepTimerController, MediaSessionController } from '@studio/player';

const queue = new QueueController(player);
queue.setItems([
  { id: 'first', title: '第一段', source: { src: '/first.mp4', resourceId: 'first' } },
  { id: 'second', title: '第二段', source: '/second.mp4' },
]);
queue.addEventListener('change', () => renderQueue(queue.snapshot));
queue.addEventListener('error', event => showError(event.detail));
await queue.select(0); // 默认开始播放；传 { autoplay: false } 只加载

const timer = new SleepTimerController(player);
timer.start(15 * 60 * 1000); // 毫秒

const system = new MediaSessionController(player, { queue });
system.addEventListener('error', event => showError(event.detail));
system.activate(); // 显式选择系统媒体控件的活动实例；不支持时返回 false

// 三个功能均可各自 destroy()；player.destroy() 也会通知它们自动清理。
```

| 功能 | 公开操作与语义 |
| --- | --- |
| Queue | 顺序/随机、单曲/列表循环、实际会话历史与增删重排；API 和边界见下节。默认顺序接续，末项保持 ended；`autoAdvance: false` 关闭自动决策。外部 load 解除当前队列选择 |
| SleepTimer | `start/cancel/check/snapshot/destroy/isDestroyed`；时间/自然完成次数触发暂停、停止或关闭，规则与事件见上节。可注入 clock/生命周期目标用于非浏览器宿主和确定性测试 |
| MediaSession | `activate/deactivate/setQueue/updateMetadata/sync/destroy`、`supported/active/supportedActions`；同一端口仅一位活动拥有者。`setQueue(queue?)` 重连或移除导航依赖，保留系统归属与元数据，旧队列回调失效。播放事实读取媒体；支持播放、暂停、定位/快进退和可用的队列前后项。队列选择存在时播放操作复用 `queue.play()`；外部来源用底座。标题/艺术家/专辑/封面优先取已加载来源元数据，缺项回落到当前队列条目；可注入 getMetadata/createMetadata/session。无 API 或部分操作不支持时降级，不承诺原生后台播放 |

功能控制器使用标准 EventTarget。普通功能卸载保留当前基础播放并撤销后续自动操作，主媒体协调卸载另会暂停并释放归属；公开 detach 取消定时与选择、释放系统媒体控制，重新挂载后由宿主重新选择条目/激活系统控制。队列保存列表与接续意图，睡眠模块保存触发规则及执行状态，它们不保存另一份播放状态。

### 队列与会话历史

`new QueueController(player, { order: 'sequential', repeat: 'off', autoAdvance: true })`。
`order` 为 `sequential/shuffle`；`repeat` 为 `off/one/all`。单曲循环只影响完播，手动下一首正常前进。随机使用一轮不重复的候选池，列表循环耗尽后重新抽取并避免紧接着重复当前项；单条列表允许循环。可注入返回 `[0, 1)` 的 `random` 用于可复现检查。

| API | 行为 |
| --- | --- |
| `select(index, { autoplay?, restart? })`、`selectId(id, options)` | 默认加载并播放；`autoplay: false` 只加载。快速选择以最后一次为准 |
| `play()`、`retry()` | play 首次选第一项，暂停后继续，停止/失败后重新加载；retry 显式重试当前项并播放 |
| `next()`、`previous()` | 下一首优先消费下一项插入，再沿历史前进，再按播放模式选择；上一首先回实际历史，顺序模式无历史时才退相邻项，随机模式不猜上一首 |
| `back()`、`forward()` | 只沿实际历史导航；无目标返回 false。导航开始播放，未播放的预加载不进历史 |
| `setOrder(order)`、`setRepeat(repeat)` | 原地更新模式，不重建媒体或重置已发生的历史 |
| `setAutoAdvance(enabled)` | 显式切换完播接续；关闭也取消正在等待的自然接续，不影响当前已播放项 |
| `add(items, atIndex?)` | 默认追加，也可在指定索引插入；不重载当前来源 |
| `insertNext(items)`、`enqueueNext(id)` | 新条目按传入顺序插在当前项之后；或将现有条目移至下一首。优先于随机选择，当前项不能把自己加入下一首 |
| `move(id, toIndex)`、`remove(id)` | 按条目 ID 重排/移除；remove 异步，删除当前项可能需要保存/加载后继 |
| `clear()` | 清空列表与历史，停止本队列所属来源；外部 load 已解除的来源由外部负责 |
| `setItems(items)` | 兼容纯列表操作，清空选择与历史，不停止已播放的媒体；正在使用的全列表替换应调用 `replaceItems(items)` |
| `replaceItems(items)` | 先停止/保存，再替换，不自动播放；等待期间出现较新的选择或列表编辑时返回 false，保留较新操作 |

条目 ID 在队列内唯一，与 `source.resourceId` 分离，同一资源可有不同队列条目。加入时复制并冻结普通数据对象；快照修改不会改变内部条目。重排按 ID 保留当前资源和位置。删除非当前项不打断播放，并移除相应历史记录；删除当前项选原位置的后继，末尾则取前项：原来播放就继续，原来暂停就保持暂停，已停止时只更新选择而不加载。删除最后一项释放来源。

历史只在当前控制器会话中记录真正开始播放的条目，相邻同条目重播合并；返回历史后播放新项会截断旧前进分支。失败、只加载和被较新选择替代的异步结果不写入历史。失败停留在该条目并反馈 `error`，等待用户重试/选择，不无限自动跳过。睡眠在统一 `beforeended` 决策，优先于所有循环与接续；手动切歌不扣计数，停止/关闭撤销待执行播放。

`snapshot` 提供 `items/index/current/order/repeat/autoAdvance/loading/loaded/autoplayPending/error`、`canPrevious/canNext`、`history/historyIndex/canBack/canForward` 和 `upNext`。`history` 与 `upNext` 使用条目 ID；`historyIndex` 表示已实际播放的历史位置，加载中的历史目标与它可暂时不同。被替代/取消的异步选择返回 false；真实失败拒绝并发 `error`。进度记录属于资源 ID，队列历史不隐式持久化。

独立使用 `ProgressController.recordProgress` 时，第 4 参数：`true` 为连续播放，`false` 为定位/跳变，`'paused'` 为暂停中的普通上报。
同资源 save/clear 按调用顺序执行，`flush` 等待已提交写入；无积压时同步调用端口，保留 localStorage 卸载落盘。跨实例/设备仲裁由存储端负责。
显式 `saveCheckpoint(resourceId, positionSeconds, durationSeconds?)` 保存当时断点，取消该资源的防抖任务并返回写入错误；由 `StudioPlayer.stop()` 复用。

resolver 返回新会话即把释放责任交给控制器；过期结果中未采用的新端点会被关闭，当前仍使用的端点保留。
跨控制器共享远端会话时，宿主端口负责引用计数。
`SourceController.unload()` 释放当前来源/心跳/刷新和处理会话，保留配置与订阅用于再次加载；`destroy()` 进一步清除订阅。播放器消费者应使用 `player.stop()` 协调媒体、进度和功能清理。
