import test from 'node:test';
import assert from 'node:assert/strict';
import { validateConfig, resolveSettings, execute, evaluateCandidate, combineTruth, matchGroup, identityKey } from '../dist/index.js';
import {seededScore} from '../dist/executor.js';
import { config, access, row, group, settings } from './fixture.mjs';
const run = (rows, override = {}, recent = []) => execute({ candidates: rows, config: config(override), access, seed: 'fixed-seed', recent });

test('configuration rejects unsupported fields, empty groups, invalid budgets and malformed paths', () => {
  for (const value of [config({ algorithm: 'v2' }), config({ ai: {} }), config({ batchSize: 501 }), config({ include: { mode: 'any', groups: [group('x', [])] } }), config({ budget: { candidates: 100001, bytes: 10, timeoutMs: 1 } }), config({ scope: { ...config().scope, roots: [{ source: 'files', path: '/music/../private' }] } })]) assert.throws(() => validateConfig(value), e => e.code === 'invalid-config');
  assert.equal(validateConfig(config()).batchSize, 12);
});
test('complete three-valued any/all truth tables', () => {
  for (const a of ['yes', 'no', 'unknown']) for (const b of ['yes', 'no', 'unknown']) {
    assert.equal(combineTruth([a, b], 'any'), a === 'yes' || b === 'yes' ? 'yes' : a === 'unknown' || b === 'unknown' ? 'unknown' : 'no');
    assert.equal(combineTruth([a, b], 'all'), a === 'no' || b === 'no' ? 'no' : a === 'unknown' || b === 'unknown' ? 'unknown' : 'yes');
  }
  assert.equal(combineTruth([], 'all'), 'yes'); assert.equal(combineTruth([], 'any'), 'no');
});
test('literal normalization and missing fields never fake a hit', () => {
  assert.equal(matchGroup(row(1, { title: 'ＭＵＳＩＣ   Whisper' }), group('x', ['music whisper'])), 'yes');
  assert.equal(matchGroup(row(1, { title: undefined }), group('x', ['music'])), 'unknown');
  assert.equal(matchGroup(row(1, { title: 'music', tags: undefined }), group('x', ['music', 'asmr'], ['title', 'tags'], 'all')), 'unknown');
  assert.equal(matchGroup(row(1), group('x', ['music', 'unmatched'], ['title'], 'all')), 'no');
  assert.equal(matchGroup(row(1, { title: 'abc', author: 'def' }), group('x', ['c d'], ['title', 'author'])), 'no');
});
test('compiled scalar and array matching preserves reference truth, Unicode normalization and scores',()=>{
  const values=[undefined,'music','ＭＵＳＩＣ  Whisper','İSTANBUL','cafe\u0301'];
  for(const algorithm of ['literal-v1','literal-case-v1'])for(const mode of ['any','all'])for(const title of values)for(const tags of [undefined,[],['noise'],['whisper','café']]){
    const candidate=row('comparison',{title,tags});
    const rule=group('mixed',['music','whisper'],['title','tags'],mode);
    for(const excluded of [false,true]){
      const configuration=config({algorithm,include:{mode:'all',groups:excluded?[]:[rule]},exclude:excluded?[rule]:[],preferences:[{...group('bonus',['café','istanbul'],['title','tags']),weight:7}]});
      const expected=evaluateCandidate(candidate,configuration,access),actual=execute({candidates:[candidate],config:configuration,access,seed:'comparison'});
      assert.equal(actual.items.length,Number(expected.pass));
      if(expected.pass){assert.equal(actual.items[0].score,expected.score);assert.deepEqual(actual.items[0].reasons,expected.reasons);}
      else assert.equal(actual.diagnostics.eligible,0);
    }
  }
});
test('exclusion wins; unknown exclusion rejects; preferences only award known hits', () => {
  const c = config({ include: { mode: 'all', groups: [group('missing', ['foo'], ['author'])] }, exclude: [group('deny', ['music'])] });
  const rejected = evaluateCandidate(row(1, { author: undefined }), c, access);
  assert.equal(rejected.truth, 'no'); assert.equal(rejected.pass, false);
  assert.equal(run([row(1, { tags: undefined })], { exclude: [group('tag', ['noise'], ['tags'])] }).items.length, 0);
  const result = run([row(1, { author: undefined })], { preferences: [{ ...group('bonus', ['A'], ['author']), weight: 10 }] });
  assert.equal(result.items[0].score, 0);
});
test('empty include list imposes no limit; group-level and between-group combination remain distinct', () => {
  assert.equal(run([row(1)]).items.length, 1);
  const groups = [group('a', ['music', 'no'], ['title'], 'any'), group('b', ['missing'], ['tags'])];
  assert.equal(run([row(1)], { include: { mode: 'any', groups } }).items.length, 1);
  assert.equal(run([row(1)], { include: { mode: 'all', groups } }).items.length, 0);
});
test('hard authorization/source/directory/board/category/media/live bounds never broaden', () => {
  const scope = { sources: ['files'], roots: [{ source: 'files', path: '/music' }], media: ['audio'], boards: ['b'], categories: ['music'] };
  const rows = [row(1, { board: 'b' }), row(2, { board: 'b', authorized: false }), row(3, { board: 'b', path: '/musical/3' }), row(4, { board: 'b', source: 'other' }), row(5, { categories: undefined, board: 'b' }), row(6, { board: undefined }), row(7, { board: 'b', media: undefined })];
  const result = run(rows, { scope }); assert.deepEqual(result.items.map(i => i.candidate.identity.id), ['1']); assert(result.shortage.includes('rules-or-scope'));
  assert.equal(run([row(1, { media: 'live', live: undefined })]).items.length, 0);
  assert.equal(run([row(1, { media: 'live', live: false })]).items.length, 0);
  assert.equal(run([row(1, { media: 'live', live: true })]).items.length, 1);
});
test('stable identity separates native parts and rejects private/temporary objects', () => {
  const result = run([row(1), row(1, { source: 'other' }), row(1, { identity: { namespace: 'file', id: '1', part: 'cid-2' } })]);
  assert.equal(result.items.length, 2); assert.equal(result.diagnostics.duplicates, 1);
  assert.notEqual(identityKey({ namespace: 'x', id: 'a:b' }), identityKey({ namespace: 'x:a', id: 'b' }));
  assert.throws(() => run([row(1, { playbackUrl: 'secret' })]), e => e.code === 'invalid-candidate');
});
test('compact deduplication and streamed random scores retain exact JSON identity ordering',()=>{
  const candidates=[];
  for(const namespace of ['files','a:b','a','引用"\\'])for(const id of ['1','b:c','c','é','😀','quoted"\\'])for(const part of [undefined,'1','分P']){
    candidates.push(row(candidates.length,{identity:{namespace,id,...(part===undefined?{}:{part})}}));
  }
  const seed='seed-引号"😀',unique=new Map(candidates.map(candidate=>[identityKey(candidate.identity),candidate]));
  const result=execute({candidates:[...candidates,candidates[0],candidates[1]],config:config({order:'random',batchSize:500}),access,seed});
  const expected=[...unique.keys()].sort((a,b)=>seededScore(seed,a)-seededScore(seed,b)||(a<b?-1:a>b?1:0));
  assert.deepEqual(result.items.map(item=>item.key),expected);assert.equal(result.diagnostics.duplicates,2);
});
test('order, scores, missing time and seeded random have deterministic stable ties', () => {
  const rows = [row(3), row(2, { title: 'bonus music', timestamp: 100 }), row(1, { timestamp: 100 })];
  assert.deepEqual(run(rows).items.map(i => i.candidate.identity.id), ['3', '2', '1']);
  assert.deepEqual(run(rows, { order: 'time' }).items.map(i => i.candidate.identity.id), ['1', '2', '3']);
  assert.deepEqual(run(rows, { order: 'score', preferences: [{ ...group('x', ['bonus']), weight: 7 }] }).items.map(i => i.candidate.identity.id), ['2', '1', '3']);
  assert.deepEqual(run(rows, { order: 'random' }), run(rows, { order: 'random' }));
  assert.deepEqual(run([...rows].reverse(), { order: 'random' }).items.map(i => i.key), run(rows, { order: 'random' }).items.map(i => i.key));
});
test('weighted source mixing and diversity only shrink an eligible pool', () => {
  const rows = [...Array.from({ length: 8 }, (_, i) => row(i)), ...Array.from({ length: 8 }, (_, i) => row(i + 20, { source: 'other' }))];
  const result = run(rows, { batchSize: 6, mix: [{ source: 'files', weight: 2 }, { source: 'other', weight: 1 }] });
  assert.equal(result.items.filter(i => i.candidate.source === 'files').length, 4);
  assert.equal(result.items.filter(i => i.candidate.source === 'other').length, 2);
  const limited = run(rows, { diversity: { author: 1, directory: 1 } }); assert.equal(limited.items.length, 2); assert(limited.shortage.includes('diversity'));
  assert.equal(run([row(1, { author: undefined }), row(2, { author: undefined })], { diversity: { author: 1, directory: 0 } }).items.length, 1);
});
test('recent dedup defaults to no repeat; explicit repeat remains in bounds and follows fresh', () => {
  const recent = [identityKey(row(1).identity)];
  assert.deepEqual(run([row(1), row(2)], {}, recent).items.map(i => i.candidate.identity.id), ['2']);
  const repeat = run([row(1), row(2), row(3, { authorized: false })], { repeat: 'after-fresh', mix: [{ source: 'files', weight: 2 }] }, recent);
  assert.deepEqual(repeat.items.map(i => i.candidate.identity.id), ['2', '1']); assert.equal(repeat.items[1].repeated, true);
});
test('preset upgrades preserve explicit personal section replacements and explain provenance', () => {
  const doc = settings(); doc.overrides = { batchSize: 3, include: { mode: 'all', groups: [group('personal', ['轻语'])] } };
  doc.preset.revision = 'preset-2'; doc.preset.config.batchSize = 20; doc.preset.config.order = 'score';
  const result = resolveSettings(doc); assert.equal(result.config.batchSize, 3); assert.equal(result.config.order, 'score'); assert.equal(result.origins.include, 'personal');
  assert.deepEqual(doc.overrides.include, result.config.include);
});
test('batch assessment and individual explanations agree across missing/matching/nonmatching facts', () => {
  const values = [undefined, 'music', 'noise'], modes = ['any', 'all'];
  for (const title of values) for (const author of values) for (const tags of [undefined, [], ['noise'], ['music']]) for (const includeMode of modes) for (const termMode of modes) {
    const c = config({ include: { mode: includeMode, groups: [group('one', ['music', 'x'], ['title', 'author'], termMode), group('two', ['music'], ['tags'])] }, exclude: [group('deny', ['noise'], ['tags'])], preferences: [{ ...group('bonus', ['music'], ['author']), weight: 5 }] });
    const candidate = row(1, { title, author, tags }), evaluation = evaluateCandidate(candidate, c, access);
    const batch = execute({ candidates: [candidate], config: c, access, seed: 'parity' });
    assert.equal(batch.items.length, Number(evaluation.pass)); if (evaluation.pass) assert.equal(batch.items[0].score, evaluation.score);
  }
});
