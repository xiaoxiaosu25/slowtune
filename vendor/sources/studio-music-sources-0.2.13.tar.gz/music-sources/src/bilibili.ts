import { fail, MusicSourceError, resourceId, type MusicProvider, type MusicEntry, type EntryRef, type ProviderContext, type SearchRequest, type ListRequest, type LibraryRequest, type PrepareRequest, type PreparedPlayback } from './contracts.js';
import {BilibiliSessions,bilibiliAccount,bilibiliLibrary} from './bilibili-session.js';
import {opaqueToken} from './node.js';
import { obj, array, str, number, limit, text, imageUrl, dedupe, boundedJson, expires, selectFormat, normalizeError } from './util.js';
import { SharedWork } from './shared-work.js';
export { BilibiliResponseReuse } from './bilibili-operation.js';

const API = 'https://api.bilibili.com';
const MIXIN = [46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52];
export function wbiMixinKey(imageUrl:string,subUrl:string):string {
  const keys=[imageUrl,subUrl].map(u=>new URL(u).pathname.split('/').pop()!.split('.')[0]).join('');
  if(keys.length!==64)fail('upstream','bilibili');return MIXIN.map(i=>keys[i]).join('').slice(0,32);
}
export async function signWbi(params: Record<string, string>, key: string, now: number, md5: (s: string) => string | Promise<string>): Promise<string> {
  const values = { ...params, wts: String(Math.floor(now / 1000)) };
  const query = Object.keys(values).sort().map(k => `${encodeURIComponent(k)}=${encodeURIComponent(values[k as keyof typeof values].replace(/[!'()*]/g,''))}`).join('&');
  return query + '&w_rid=' + await md5(query + key);
}
function video(raw: unknown): MusicEntry {
  const r = obj(raw); const id = str(r.bvid); if (!/^BV[a-zA-Z0-9]{10}$/.test(id)) fail('upstream','bilibili');
  const cid = r.cid || r.ugc?.first_cid ? String(r.cid ?? r.ugc.first_cid) : undefined;
  const ref: EntryRef = { provider: 'bilibili', kind: 'video', id, ...(cid && /^\d+$/.test(cid) && cid !== '0' ? { part: cid } : {}) };
  const author = typeof r.author === 'object' ? r.author : r.owner ?? r.upper;
  let duration: number | undefined;
  if (typeof r.duration === 'number') duration = number(r.duration);
  else if (typeof r.duration === 'string' && /^\d+:\d+(?::\d+)?$/.test(r.duration)) duration = r.duration.split(':').reduce((n: number,s: string) => n * 60 + Number(s), 0);
  return { ref, resourceId: resourceId(ref), title: text(r.title ?? r.music_title), url: `https://www.bilibili.com/video/${id}`, artwork: imageUrl(r.pic ?? r.cover), durationSeconds: duration,
    ...(typeof r.tag === 'string' ? { tags: r.tag.split(',').map((tag: string) => tag.trim()).filter(Boolean) } : {}),
    ...(author?.name ? { uploader: { name: str(author.name), id: String(author.mid) } } : typeof r.author === 'string' && !r.music_title ? { uploader: { name: r.author, id: String(r.mid) } } : {}),
    ...(r.music_title && typeof r.author === 'string' ? { artists: r.author.split(',').filter(Boolean) } : {}) };
}
function apiError(code: number): never { return fail(code === -101 ? 'authentication' : [-403,-10403,-352,-412].includes(code) ? 'restricted' : [-404,62002].includes(code) ? 'not-found' : code === -509 ? 'rate-limited' : 'upstream', 'bilibili', String(code)); }
export class BilibiliProvider implements MusicProvider {
  readonly capabilities = { provider: 'bilibili' as const, operations: ['metadata','parts','recommendation','hot-chart','new-music','search','video-search','favorite','season','prepare','video-prepare','formats','account','library','qr-login','disconnect'], anonymous: true,
    limitations: ['Account, personal lists and QR success are implemented but require real user acceptance.', 'Audio uses independent DASH tracks. Video requires a single progressive MP4; segmented and video-only deliveries are rejected.'] };
  private login=new BilibiliSessions();
  private accountChecks=new WeakMap<ProviderContext,Promise<unknown>>();
  private visitors=new Map<string,{until:number;cookie:string}>();
  private shared = new SharedWork();
  private metadataWork = new SharedWork();
  private keys = new Map<string, { key: string; until: number }>();
  private cursors=new Map<string,{page:number;binding:string;scope:string;until:number}>();
  account(c:ProviderContext){return bilibiliAccount(c);}
  async library(r:LibraryRequest,c:ProviderContext){const size=limit(r.limit),binding=JSON.stringify(['library',size]),page=this.page(r.cursor,binding,c);const result=await bilibiliLibrary(r,c,page);return{items:result.items,...(result.hasMore?{nextCursor:this.next(page,binding,c)}:{})};}
  beginLogin(c:ProviderContext){return this.login.begin(c);}
  pollLogin(id:string,c:ProviderContext){return this.login.poll(id,c);}
  cancelLogin(id:string,c:ProviderContext){return this.login.cancel(id,c);}
  forgetCredentials(ref:string){this.login.forget(ref);const prefix=JSON.stringify([ref]).slice(0,-1)+',';for(const key of this.visitors.keys())if(key.startsWith(prefix))this.visitors.delete(key);for(const key of this.keys.keys())if(key.startsWith(prefix))this.keys.delete(key);this.shared.cancelWhere(key=>key.startsWith('wbi:'+prefix)||key.startsWith('visitor:'+prefix));this.metadataWork.cancelWhere(key=>String(JSON.parse(key)[0]).startsWith(prefix));for(const[key,cursor]of this.cursors)if(cursor.scope.startsWith(prefix))this.cursors.delete(key);}
  private async request(path: string, params: Record<string,string>, c: ProviderContext, signed = false): Promise<any> {
    if(c.credential?.cookie){let check=this.accountChecks.get(c);if(!check){check=this.account(c);this.accountChecks.set(c,check);}await check;}
    let query = new URLSearchParams(params).toString();
    if (signed) {
      if (!c.host.md5) fail('unsupported','bilibili');
      let state = this.keys.get(c.scope);
      if (!state || state.until <= c.host.now()) {
        state = await this.shared.run(`wbi:${c.scope}`, c.signal, async signal => {
        const nav = obj(await boundedJson(await c.host.fetch(`${API}/x/web-interface/nav`, { headers: this.headers(c), signal })));
        const imgs = obj(obj(nav.data).wbi_img);
        signal.throwIfAborted();
        const value = { key: wbiMixinKey(str(imgs.img_url),str(imgs.sub_url)), until: c.host.now() + 3600000 };
        if (this.keys.size >= 8) this.keys.delete(this.keys.keys().next().value!);
        this.keys.set(c.scope, value); return value;
        });
      }
      query = await signWbi(params, state.key, c.host.now(), c.host.md5);
    }
    const data = obj(await boundedJson(await c.host.fetch(`${API}${path}?${query}`, { headers: this.headers(c), signal: c.signal })));
    if (typeof data.code !== 'number') fail('upstream','bilibili');
    if (data.code !== 0) { if (signed && [-403,-352].includes(data.code)) this.keys.delete(c.scope); apiError(data.code); }
    if (data.data?.v_voucher) fail('restricted','bilibili','v_voucher');
    return obj(data.data);
  }
  private headers(c: ProviderContext): Record<string,string> { return { 'User-Agent': 'Mozilla/5.0', Referer: 'https://www.bilibili.com/', ...(c.credential?.cookie ? { Cookie: c.credential.cookie } : {}) }; }
  private async visitor(c:ProviderContext):Promise<string>{
    if(/(?:^|;\s*)buvid3=/.test(c.credential?.cookie??''))return c.credential!.cookie!;
    const now=c.host.now();for(const[key,value]of this.visitors)if(value.until<=now)this.visitors.delete(key);
    let visitor=this.visitors.get(c.scope);
    if(!visitor){
      visitor = await this.shared.run(`visitor:${c.scope}`, c.signal, async signal => {
        const response=await boundedJson(await c.host.fetch(API+'/x/frontend/finger/spi',{headers:this.headers(c),signal}));if(response.code!==0)apiError(response.code);const d=obj(response.data);for(const key of ['b_3','b_4'])if(typeof d[key]!=='string'||!d[key]||d[key].length>256||/[;\r\n]/.test(d[key]))fail('upstream','bilibili');
        signal.throwIfAborted();if(this.visitors.size>=8)this.visitors.delete(this.visitors.keys().next().value!);
        const value={cookie:`buvid3=${d.b_3}; buvid4=${d.b_4}`,until:c.host.now()+900000};this.visitors.set(c.scope,value); return value;
      });
    }
    const cookie=visitor.cookie;c.signal.throwIfAborted();
    const account=c.credential?.cookie??'';const names=new Set(account.split(';').map(v=>v.trim().split('=',1)[0]));
    return[account,...cookie.split('; ').filter(pair=>!names.has(pair.split('=',1)[0]))].filter(Boolean).join('; ');
  }
  async metadata(ref: EntryRef, c: ProviderContext): Promise<MusicEntry> {
    return this.metadataWork.run(JSON.stringify([c.scope, resourceId(ref)]), c.signal, signal => this.readMetadata({ ...ref }, { ...c, signal }));
  }
  private async readMetadata(ref: EntryRef, c: ProviderContext): Promise<MusicEntry> {
    if (ref.kind !== 'video') fail('unsupported','bilibili');
    const r = await this.request('/x/web-interface/view', { bvid: ref.id }, c);
    const parts = array(r.pages).map(p => {
      const page = obj(p); const partRef: EntryRef = { ...ref, part: String(number(page.cid)) };
      return { ...video({ ...r, cid: page.cid }), ref: partRef, resourceId: resourceId(partRef), title: r.pages.length > 1 ? `${text(r.title)} / ${text(page.part)}` : text(r.title), durationSeconds: number(page.duration) };
    });
    const entry = ref.part ? parts.find(p => p.ref.part === ref.part) : parts[0];
    if (!entry) fail('not-found','bilibili');
    return { ...entry, parts };
  }
  async discover(c: ProviderContext) {
    const definitions = [
      { id: 'music-recommendation', title: '音乐分区推荐', kind: 'recommendation' as const, path: '/x/web-interface/region/feed/rcmd', params: { display_id: '1', request_cnt: '20', from_region: '1003' }, field: 'archives' },
      { id: 'hot-chart', title: '热歌榜', kind: 'chart' as const, path: '/x/centralization/interface/music/hot/rank', params: { plat: '2' }, field: 'list' },
      { id: 'new-music', title: '新歌', kind: 'new' as const, path: '/x/centralization/interface/new/music', params: {}, field: 'list' }
    ];
    return Promise.all(definitions.map(async d => {
      try { const r = await this.request(d.path, d.params as Record<string,string>,c); return { id: d.id, title: d.title, kind: d.kind, page: { items: dedupe(array(r[d.field]).filter(v => v.bvid).map(video)) } }; }
      catch (e) { if (c.signal.aborted) throw e; const error = normalizeError(e,c); return { id: d.id, title: d.title, kind: d.kind, error: { ...error.toJSON(), provider: 'bilibili' as const } }; }
    }));
  }
  private page(cursor: string | undefined, binding: string, c: ProviderContext): number {
    for(const[id,state]of this.cursors)if(state.until<=c.host.now())this.cursors.delete(id);
    if (!cursor) return 1;if(typeof cursor!=='string'||! /^[\w-]{32}$/.test(cursor))fail('stale-cursor','bilibili');const data=this.cursors.get(cursor);
    if (!data || data.binding !== binding || data.scope !== c.scope || data.until <= c.host.now() || data.page > 10000) fail('stale-cursor','bilibili');
    return data.page;
  }
  private next(page:number,binding:string,c:ProviderContext){for(const[id,state]of this.cursors)if(state.until<=c.host.now())this.cursors.delete(id);if(this.cursors.size>=64)fail('busy','bilibili');const id=opaqueToken();this.cursors.set(id,{page:page+1,binding,scope:c.scope,until:c.host.now()+900000});return id;}
  async search(request: SearchRequest, c: ProviderContext) {
    const size = limit(request.limit), binding = JSON.stringify(['search',request.query,size,request.mode]); const page = this.page(request.cursor,binding,c);
    if(c.credential?.cookie)await this.account(c);
    const cookie=await this.visitor(c);
    const scoped={...c,credential:{...c.credential,revision:c.credential?.revision??'anonymous-visitor',cookie}};
    // Visitor identifiers are anonymous cookies, not a logged-in account.
    const params=new URLSearchParams({search_type:'video',keyword:request.query,tids:request.mode === 'video' ? '0' : '3',page:String(page),page_size:String(size)});
    const response=obj(await boundedJson(await c.host.fetch(`${API}/x/web-interface/search/type?${params}`,{headers:this.headers(scoped),signal:c.signal})));
    if(typeof response.code!=='number')fail('upstream','bilibili');if(response.code!==0)apiError(response.code);const r=obj(response.data);if(r.v_voucher)fail('restricted','bilibili','v_voucher');
    // Video search also inserts typed course/live cards without a video identity.
    // Skip those cards before parsing; malformed video rows must still fail.
    const videos = array(r.result).filter(value => { const row = obj(value); return row.type === undefined || str(row.type) === 'video'; });
    return { items: dedupe(videos.map(video)), ...(page < number(r.numPages) ? { nextCursor: this.next(page,binding,c) } : {}) };
  }
  async list(request: ListRequest, c: ProviderContext) {
    if (request.ref.kind === 'video') { const entry = await this.metadata(request.ref,c); return { items: entry.parts ?? [entry] }; }
    const size = limit(request.limit), binding = JSON.stringify(['list',request.ref,size]); const page = this.page(request.cursor,binding,c);
    const fav = request.ref.id.match(/^fav:(\d+)$/), season = request.ref.id.match(/^season:(\d+):(\d+)$/);
    if (fav) {
      const r = await this.request('/x/v3/fav/resource/list', { media_id: fav[1], pn: String(page), ps: String(size), order: 'mtime', type: '0', tid: '0', platform: 'web' },c);
      return { items: dedupe(array(r.medias ?? []).filter(v => v.type === 2 && /^BV/.test(v.bvid)).map(video)), ...(r.has_more ? { nextCursor: this.next(page,binding,c) } : {}) };
    }
    if (season) {
      const r = await this.request('/x/polymer/web-space/seasons_archives_list', { mid: season[1], season_id: season[2], page_num: String(page), page_size: String(size), sort_reverse: 'false' },c);
      return { items: dedupe(array(r.archives).map(video)), ...(page * size < number(obj(r.page).total) ? { nextCursor: this.next(page,binding,c) } : {}) };
    }
    return fail('invalid-input','bilibili');
  }
  private async tracks(ref: EntryRef, c: ProviderContext) {
    const entry = await this.metadata(ref,c);
    const r = await this.request('/x/player/wbi/playurl', { bvid: entry.ref.id, cid: str(entry.ref.part), fnval: '4048', fnver: '0', fourk: '1', qn: '80' },c,true);
    if (!r.dash) fail('unsupported','bilibili');
    const dash = obj(r.dash); const raw = [...array(dash.audio ?? []), ...(dash.flac?.audio ? [dash.flac.audio] : []), ...array(dash.dolby?.audio ?? [])];
    const formats = raw.map(value => {
      const a = obj(value); const url = str(a.baseUrl ?? a.base_url); if (new URL(url).protocol !== 'https:') fail('upstream','bilibili');
      const codec = str(a.codecs), mimeType = str(a.mimeType ?? a.mime_type);
      if (!mimeType.startsWith('audio/')) fail('unsupported','bilibili');
      return { format: { id: String(number(a.id)), codec, mimeType, container: mimeType.includes('mp4') ? 'mp4' : mimeType.includes('webm') ? 'webm' : mimeType.slice(6), bitrate: number(a.bandwidth) }, url,
        alternatives: array(a.backupUrl ?? a.backup_url ?? []).map(str) };
    });
    return { entry, formats };
  }
  async formats(ref: EntryRef, c: ProviderContext) { return (await this.tracks(ref, c)).formats.map(value => ({ ...value.format })); }
  async prepare(request: PrepareRequest, c: ProviderContext): Promise<PreparedPlayback> {
    if (request.media === 'video') return this.prepareVideo(request, c);
    const { entry, formats } = await this.tracks(request.ref, c);
    const selected = selectFormat(formats,request.codecs ?? (request.quality==='lossless'?['flac','alac']:['mp4a']),request.formatId,request.quality);
    return { resourceId: entry.resourceId, entry, format: selected.format, delivery: { url: selected.url, headers: {'User-Agent':'Mozilla/5.0',Referer:'https://www.bilibili.com/'}, expiresAt: expires(selected.url), alternatives: selected.alternatives, requiresHost: true } };
  }
  private async prepareVideo(request: PrepareRequest, c: ProviderContext): Promise<PreparedPlayback> {
    if (request.quality === 'lossless') fail('unsupported', 'bilibili');
    const entry = await this.metadata(request.ref, c);
    const response = await this.request('/x/player/wbi/playurl', { bvid: entry.ref.id, cid: str(entry.ref.part), fnval: '1', fnver: '0', qn: '16', fourk: '0' }, c, true);
    const segments = array(response.durl ?? []);
    if (segments.length !== 1 || response.format !== 'mp4' || response.video_codecid !== 7) fail('unsupported', 'bilibili');
    const segment = obj(segments[0]), url = str(segment.url);
    if (new URL(url).protocol !== 'https:') fail('upstream', 'bilibili');
    const format = { id: `mp4-${number(response.quality)}`, codec: 'avc1', audioCodec: 'mp4a', container: 'mp4', mimeType: 'video/mp4', byteLength: number(segment.size) };
    selectFormat([{ format }], request.codecs, request.formatId, request.quality);
    return { resourceId: entry.resourceId, entry, format, delivery: { url, alternatives: array(segment.backup_url ?? []).map(str),
      headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://www.bilibili.com/' }, expiresAt: expires(url), requiresHost: true } };
  }
  async dispose() { await this.shared.dispose(); await this.metadataWork.dispose(); this.keys.clear();this.login.dispose();this.visitors.clear();this.cursors.clear(); }
}
