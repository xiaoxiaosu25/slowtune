import type { IconNode } from 'lucide';

/** Serialize trusted Lucide nodes without DOM access, including during Node imports. */
export function iconMarkup(nodes: IconNode): string {
  const escape = (value: string | number) => String(value).replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');
  return `<svg class="lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${nodes.map(([tag, attributes]) => `<${tag} ${Object.entries(attributes).filter(([, value]) => value !== undefined).map(([key, value]) => `${key}="${escape(value!)}"`).join(' ')}></${tag}>`).join('')}</svg>`;
}
