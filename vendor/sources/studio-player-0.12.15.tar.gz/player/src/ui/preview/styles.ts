export const previewStyles = `
:host{display:block;min-width:0;color-scheme:light;--p-bg:#fff;--p-surface:#eef1f3;--p-text:#19232d;--p-muted:#526170;--p-border:#c6cfd6;--p-accent:#235dad;--p-focus:#176ad0}
:host([data-theme=dark]){color-scheme:dark;--p-bg:#151c24;--p-surface:#26323e;--p-text:#f3f6fa;--p-muted:#b5c2ce;--p-border:#526170;--p-accent:#8dbaff;--p-focus:#a5caff}
@media(prefers-color-scheme:dark){:host([data-theme=auto]){color-scheme:dark;--p-bg:#151c24;--p-surface:#26323e;--p-text:#f3f6fa;--p-muted:#b5c2ce;--p-border:#526170;--p-accent:#8dbaff;--p-focus:#a5caff}}
*{box-sizing:border-box}[hidden]{display:none!important}
.root{container-type:inline-size;background:var(--studio-preview-background,var(--p-bg));color:var(--studio-preview-text,var(--p-text));border:1px solid var(--studio-preview-border,var(--p-border));border-radius:var(--studio-preview-radius,16px);padding:12px;font:var(--studio-preview-font,14px/1.5 system-ui,sans-serif);overflow:hidden}
.screen{position:relative;aspect-ratio:16/9;background:var(--studio-preview-surface,var(--p-surface));border-radius:8px;overflow:hidden}
.screen img,.screen video,.screen audio,.screen hlsjs-video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}
.screen img{z-index:1;pointer-events:none}
.heading{display:flex;align-items:center;gap:8px;margin-top:8px}.heading strong{min-width:0;flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
button,input{font:inherit}button{min-width:44px;min-height:44px;padding:8px 10px;border:1px solid var(--studio-preview-border,var(--p-border));border-radius:8px;background:var(--studio-preview-surface,var(--p-surface));color:inherit;cursor:pointer}button:disabled,input:disabled{opacity:.5;cursor:default}
button:focus-visible,input:focus-visible{outline:3px solid var(--studio-preview-focus,var(--p-focus));outline-offset:2px}button[data-action=play]{font-weight:700;color:var(--studio-preview-accent,var(--p-accent))}
.controls{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.timeline{display:flex;gap:8px;align-items:center}.timeline input{flex:1;min-width:0}input[type=range]{height:44px;accent-color:var(--studio-preview-accent,var(--p-accent))}.volume{display:flex;align-items:center;gap:4px}.volume input{width:80px}.status{min-height:1.5em;margin:6px 0;color:var(--studio-preview-text-muted,var(--p-muted));overflow-wrap:anywhere}.status[data-error=true]{color:var(--studio-preview-error,#cf4545)}
.root[data-view=mini] .screen{width:88px;aspect-ratio:1;float:left;margin:0 10px 8px 0}.root[data-view=mini] .heading{margin-top:0}.root[data-view=mini] .timeline{clear:both}
@container(max-width:280px){.volume{width:100%}.volume input{flex:1}.root[data-view=mini] .screen{width:60px}.timeline output{font-size:12px}}
`;
