import { createPlayerPreset, type PlayerPresetOptions } from '../../presets/index.js';
import { mountQueuePrefetch, type QueueItem, type QueueOptions, type QueuePrefetchOptions } from '../../queue/index.js';
import { mountSleepTimerSettings } from '../sleep-settings.js';
import { iconMarkup } from '../icon.js';
import { Play, Pause, Volume2, VolumeX, Music2, ListMusic, Repeat, Repeat1, Shuffle } from 'lucide';
import { audioTemplate, mobileTemplate } from './templates.js';
import { styles } from './styles.js';
import type { VideoControlsOptions } from '../video/index.js';
export { mountMediaDockVideoPlayer, type MediaDockVideoPlayerUI } from './video.js';

export interface MediaDockPlayerOptions extends PlayerPresetOptions {
  items?: readonly QueueItem[];
  queue?: QueueOptions;
  theme?: 'auto' | 'light' | 'dark';
  palette?: 'mint' | 'studio';
  layout?: 'auto' | 'desktop' | 'mobile';
  view?: 'bar' | 'mini' | 'expanded';
  prefetch?: QueuePrefetchOptions;
  controls?: VideoControlsOptions;
  /** 音频沿用默认清空；两套视频统一默认保留，可显式设为 true。 */
  clearQueueOnClose?: boolean;
  originalFileUrl?: (item: Readonly<QueueItem>) => string | null;
  /** 服务端输出尺寸与 HLS ABR 画质分开声明，未提供时不展示。 */
  outputHeights?: readonly number[];
  onClose?: () => void;
  onError?: (error: unknown) => void;
}

export interface MediaDockPlayerUI {
  readonly element: HTMLElement;
  readonly player: ReturnType<typeof createPlayerPreset>['player'];
  readonly queue: NonNullable<ReturnType<typeof createPlayerPreset>['features']['queue']>;
  readonly features: Readonly<Pick<ReturnType<typeof createPlayerPreset>['features'], 'queue' | 'sleepTimer' | 'mediaSession' | 'videoTracks' | 'mainMedia'>>;
  setTheme(theme: 'auto' | 'light' | 'dark'): void;
  setPalette(palette: 'mint' | 'studio'): void;
  setLayout(layout: 'auto' | 'desktop' | 'mobile'): void;
  setView(view: 'bar' | 'mini' | 'expanded'): void;
  setItems(items: readonly QueueItem[]): Promise<boolean>;
  open(): void;
  close(): Promise<void>;
  importSubtitle(file: File): Promise<void>;
  destroy(): void;
}

let registration: Promise<unknown> | undefined;
function register() {
  return registration ??= import('@videojs/html/media/hlsjs-video').catch(error => { registration = undefined; throw error; });
}
function time(value: number) {
  const total = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
  return (total >= 3600 ? `${Math.floor(total / 3600)}:` : '') + `${String(Math.floor(total / 60) % 60).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
function choice(value: string, allowed: readonly string[]) { if (!allowed.includes(value)) throw new TypeError(`Unknown MediaDock option: ${value}`); }

export function mountMediaDockAudioPlayer(root: HTMLElement, options: MediaDockPlayerOptions = {}): Promise<MediaDockPlayerUI> { return mount(root, options); }

async function mount(root: HTMLElement, options: MediaDockPlayerOptions): Promise<MediaDockPlayerUI> {
  if (!root?.ownerDocument) throw new TypeError('MediaDock UI needs a mount element');
  choice(options.theme ?? 'auto', ['auto', 'light', 'dark']);
  choice(options.palette ?? 'mint', ['mint', 'studio']);
  choice(options.layout ?? 'auto', ['auto', 'desktop', 'mobile']);
  choice(options.view ?? 'bar', ['bar', 'mini', 'expanded']);
  if (options.features?.queue === false) throw new TypeError('MediaDock UI requires its shared queue');
  if (options.outputHeights?.some(height => !Number.isInteger(height) || height < 0 || height > 4320)) throw new TypeError('Invalid output height');
  if ((options.backend ?? options.player?.backend ?? 'videojs') === 'videojs') await register();
  const { items = [], queue: queueOptions, theme: initialTheme = 'auto', palette = 'mint', layout: initialLayout = 'auto',
    view: initialView = 'bar', prefetch, clearQueueOnClose = true, originalFileUrl, outputHeights: _output, controls: _controls, onClose, onError, features, ...playerOptions } = options;
  const preset = createPlayerPreset('audio', { ...playerOptions, features: { ...features, queue: queueOptions ?? features?.queue ?? true } });
  const { player } = preset; const { queue: nullableQueue, sleepTimer, videoTracks, mediaSession } = preset.features; const queue = nullableQueue!;
  const doc = root.ownerDocument;
  const element = doc.createElement('div'); element.dataset.studioMediaDock = 'audio'; element.dataset.palette = palette;
  const shadow = element.attachShadow({ mode: 'open' });
  const template = (audioTemplate + mobileTemplate).replace('<div id="m-now"', '<dialog id="m-now"').replace(/<\/div>\s*$/, '</dialog>');
  shadow.innerHTML = `<style>${styles}</style>${template}<dialog class="dock-sleep" aria-label="睡眠定时器"><header><h2>睡眠定时器</h2><button type="button" data-sleep-close aria-label="关闭睡眠设置">${iconMarkup(VolumeX)}</button></header><div data-sleep-form></div></dialog>`;
  const get = <T extends HTMLElement = HTMLElement>(id: string): T | null => shadow.querySelector<T>('#' + id);
  const all = <T extends HTMLElement = HTMLElement>(selector: string): T[] => Array.from(shadow.querySelectorAll<T>(selector));
  const setText = (id: string, text: string) => { const node = get(id); if (node && node.textContent !== text) node.textContent = text; };
  const hidden = (id: string, value: boolean) => { const node = get(id); if (node) { node.hidden = value; node.classList.remove('hidden'); } };
  const abort = new AbortController(); const off: Array<() => void> = [];
  let disposed = false, closed = false, view = initialView, layout = initialLayout, theme = initialTheme;
  let lastError: unknown = null, panel: string | null = null, panelTrigger: HTMLElement | null = null;
  let scrubbing: { resource: string | null; input: HTMLInputElement } | null = null;
  let phase = '', queueKey = '', lastPlaying: boolean | null = null;
  const sleep = shadow.querySelector<HTMLDialogElement>('.dock-sleep')!;
  const sleepSettings = sleepTimer ? mountSleepTimerSettings(shadow.querySelector<HTMLElement>('[data-sleep-form]')!, sleepTimer) : null;
  const mq = doc.defaultView!.matchMedia('(max-width: 768px)');
  const dark = doc.defaultView!.matchMedia('(prefers-color-scheme: dark)');
  const mediaHost = doc.createElement('div'); mediaHost.hidden = true; mediaHost.append(doc.createElement('audio')); shadow.append(mediaHost);
  const managed = doc.createElement('hlsjs-video'); managed.setAttribute('playsinline', ''); mediaHost.append(managed);
  const modal = get<HTMLDialogElement>('m-now')!;
  // Hidden sources are selected by the core's existing Video.js delivery adapter.
  if (player.backend === 'videojs') player.attach(mediaHost);
  player.setVolume(.8);
  queue.setItems(items); root.append(element);
  const warming = prefetch ? mountQueuePrefetch(player, queue, prefetch) : null;

  function report(error: unknown) { if (disposed || (error as Error)?.name === 'AbortError') return; lastError = error; onError?.(error); render(); }
  function perform(operation: () => unknown | Promise<unknown>) { if (!disposed) void Promise.resolve().then(operation).catch(report); }
  function bind(id: string, operation: () => unknown | Promise<unknown>) { get(id)?.addEventListener('click', () => perform(operation), { signal: abort.signal }); }
  function popup(name: string | null, trigger?: HTMLElement) {
    const previous = panelTrigger; panel = name; panelTrigger = trigger ?? null;
    const rate = get('playerRateMenu'); rate?.classList.toggle('is-open', name === 'rate'); rate?.setAttribute('aria-hidden', String(name !== 'rate'));
    hidden('playerPlaylistPanel', name !== 'queue'); hidden('m-now-queue', name !== 'queue'); hidden('m-now-queue-backdrop', name !== 'queue');
    for (const node of all('[aria-expanded]')) node.setAttribute('aria-expanded', String(node === trigger && Boolean(name)));
    if (name) {
      const scope = name === 'rate' ? rate : element.dataset.layout === 'mobile' ? get('m-now-queue') : get('playerPlaylistPanel');
      scope?.querySelector<HTMLElement>('button:not(:disabled),select:not(:disabled)')?.focus();
    } else previous?.focus();
  }
  function togglePanel(name: string, trigger: string) { popup(panel === name ? null : name, get(trigger) ?? undefined); }
  function updateModal() {
    const shouldOpen = !closed && element.dataset.layout === 'mobile' && view === 'expanded';
    modal.hidden = !shouldOpen; modal.classList.remove('hidden');
    if (shouldOpen && !modal.open) modal.showModal();
    if (!shouldOpen && modal.open) modal.close();
    modal.classList.toggle('open', shouldOpen); modal.setAttribute('aria-hidden', String(!shouldOpen));
  }
  function presentation() {
    element.dataset.theme = theme === 'auto' ? dark.matches ? 'dark' : 'light' : theme;
    element.dataset.layout = layout === 'auto' ? mq.matches ? 'mobile' : 'desktop' : layout;
    if (panel) popup(null);
    updateModal(); render();
  }
  function togglePlay() { if (queue.snapshot.loading && queue.snapshot.autoplayPending || !player.paused) player.pause(); else return queue.play(); }
  function mode() {
    const snapshot = queue.snapshot;
    if (snapshot.order === 'shuffle') { queue.setOrder('sequential'); queue.setRepeat('off'); }
    else if (snapshot.repeat === 'off') queue.setRepeat('all');
    else if (snapshot.repeat === 'all') queue.setRepeat('one');
    else { queue.setOrder('shuffle'); queue.setRepeat('all'); }
  }
  function renderQueue() {
    const snapshot = queue.snapshot;
    const key = JSON.stringify([snapshot.items.map(item => [item.id, item.title]), snapshot.current?.id]);
    if (key === queueKey) return; queueKey = key;
    for (const id of ['playerPlaylistContent', 'm-now-queue-list']) {
      const target = get(id); if (!target) continue; target.replaceChildren();
      snapshot.items.forEach((item, index) => {
        const button = doc.createElement('button'); button.type = 'button'; button.className = id === 'm-now-queue-list' ? 'm-now-qitem' : 'player-playlist-item';
        button.classList.toggle('active', snapshot.current?.id === item.id); button.setAttribute('aria-current', String(snapshot.current?.id === item.id));
        const number = doc.createElement('span'); number.className = 'player-playlist-index'; number.textContent = String(index + 1);
        const title = doc.createElement('span'); title.className = 'player-playlist-name'; title.textContent = item.title ?? item.id;
        button.append(number, title); button.addEventListener('click', () => { popup(null); perform(() => queue.selectId(item.id)); }); target.append(button);
      });
      if (!snapshot.items.length) target.textContent = '播放队列为空';
    }
  }
  function render() {
    if (disposed) return;
    const snapshot = queue.snapshot; const data = player.currentMetadata ?? {};
    const current = snapshot.current;
    const title = String(data.title ?? data.name ?? current?.title ?? '未在播放');
    const subtitle = [data.artist ?? current?.artist, data.album ?? current?.album].filter(Boolean).join(' · ');
    const state = lastError ? '播放失败，请重试' : snapshot.loading ? '正在准备来源' : phase || ({idle:'准备就绪',loading:'正在加载',ready:'准备就绪',playing:'正在播放',paused:'已暂停',stopped:'已停止',ended:'播放结束',error:'播放失败'}[player.state]);
    for (const id of ['playerTrackName','playerMiniTrackName','m-mini-name','m-now-title']) setText(id, title);
    for (const id of ['playerTrackSubtitle','m-now-subtitle']) setText(id, subtitle);
    for (const id of ['playerTrackStatusText','playerMiniStatus','m-mini-status','m-now-status']) setText(id, state);
    const playing = !player.paused && !player.failed;
    if (playing !== lastPlaying) {
      lastPlaying = playing;
      for (const id of ['playerPlayBtn','playerMiniPlayBtn','m-mini-playpause','m-now-playpause']) {
        const button = get(id); if (!button) continue; button.innerHTML = iconMarkup(playing ? Pause : Play); button.setAttribute('aria-label', playing ? '暂停' : '播放');
      }
    }
    get('globalAudioPlayer')?.classList.toggle('is-playing', playing);
    const modeId = snapshot.order === 'shuffle' ? 'shuffle' : snapshot.repeat === 'one' ? 'repeat-one' : snapshot.repeat === 'all' ? 'repeat-all' : 'order';
    const modeLabel = {shuffle:'随机', 'repeat-one':'单曲循环','repeat-all':'列表循环',order:'顺序'}[modeId];
    get('playerModeBtn')?.setAttribute('data-mode', modeId);
    for (const id of ['playerModeBtn','m-now-mode']) get(id)?.setAttribute('aria-label', `播放模式：${modeLabel}，点击切换`);
    setText('m-now-mode-label', modeLabel); const modeIcon = get('m-now-mode-icon'); if (modeIcon) modeIcon.innerHTML = iconMarkup(modeId === 'shuffle' ? Shuffle : modeId === 'repeat-one' ? Repeat1 : modeId === 'repeat-all' ? Repeat : ListMusic);
    for (const id of ['playerPrevBtn','m-now-prev']) { const node = get<HTMLButtonElement>(id); if (node) node.disabled = !snapshot.canPrevious; }
    for (const id of ['playerNextBtn','m-now-next','m-mini-next']) { const node = get<HTMLButtonElement>(id); if (node) node.disabled = !snapshot.canNext; }
    for (const id of ['playerRateValue','playerRateCurrent','m-now-rate-value']) setText(id, `${player.playbackRate}×`);
    for (const id of ['playerRateSelect','m-now-rate']) { const select = get<HTMLSelectElement>(id); if (select) select.value = String(player.playbackRate); }
    all<HTMLButtonElement>('[data-rate]').forEach(button => { const selected = Number(button.dataset.rate) === player.playbackRate; button.classList.toggle('active', selected); button.setAttribute('aria-checked', String(selected)); });
    for (const id of ['playerMuteBtn','m-now-mute']) { const node = get(id); if (node) { node.innerHTML = iconMarkup(player.muted ? VolumeX : Volume2); node.setAttribute('aria-label', player.muted ? '取消静音' : '静音'); } }
    for (const id of ['playerVolumeSlider','m-now-volume']) { const input = get<HTMLInputElement>(id); if (input) { input.value = String(player.volume); input.style.setProperty('--range-progress', `${player.volume * 100}%`); input.style.setProperty('--volume-percent', `${player.volume * 100}%`); } }
    setText('m-now-volume-value', `${Math.round(player.volume * 100)}%`);
    const duration = player.duration; const position = scrubbing ? Number(scrubbing.input.value) / 1000 * duration : player.currentTime;
    const percent = duration > 0 && Number.isFinite(duration) ? Math.min(100, position / duration * 100) : 0;
    for (const id of ['playerCurrentTime','m-now-cur']) setText(id, time(position));
    for (const id of ['playerTotalTime','m-now-dur']) setText(id, time(duration));
    for (const id of ['playerProgressBar','m-now-seek']) { const input = get<HTMLInputElement>(id); if (input) { if (scrubbing?.input !== input) input.value = String(percent * 10); input.disabled = !player.currentResourceId || !(duration > 0 && Number.isFinite(duration)); input.setAttribute('aria-valuetext', `${time(position)} / ${time(duration)}`); input.style.setProperty('--range-progress', `${percent}%`); } }
    for (const id of ['playerProgressFill']) get(id)?.style.setProperty('width', `${percent}%`);
    const buffer = duration > 0 ? player.buffered.map(range => `transparent ${range.start / duration * 100}%, var(--text-faint) ${range.start / duration * 100}% ${range.end / duration * 100}%, transparent ${range.end / duration * 100}%`).join(',') : '';
    for (const id of ['playerBufferFill']) { const node = get(id); if (node) { node.style.width = '100%'; node.style.background = buffer ? `linear-gradient(to right,${buffer})` : 'none'; } }
    get('m-now-seek')?.style.setProperty('--buffered-track', buffer ? `linear-gradient(to right,${buffer})` : 'none');
    get('m-mini')?.style.setProperty('--m-mini-progress', `${percent}%`);
    for (const id of ['playerArtwork','playerMiniArtwork','m-mini-artwork','m-now-artwork']) {
      const node = get(id); if (!node) continue;
      const artwork = (Array.isArray(data.artwork) ? data.artwork : current?.artwork)?.[0]?.src;
      let img = node.querySelector('img');
      if (artwork) { if (!img) { img = doc.createElement('img'); img.alt = ''; node.append(img); } if (img.getAttribute('src') !== artwork) img.src = artwork; node.classList.add('has-artwork'); }
      else { img?.remove(); node.classList.remove('has-artwork'); }
    }
    for (const id of ['playerQueueCount','m-now-queue-label']) setText(id, id === 'playerQueueCount' ? String(snapshot.items.length) : `队列 ${snapshot.items.length}`);
    for (const id of ['playerQueueMeta','m-now-queue-meta']) setText(id, `${snapshot.items.length} 首曲目`);
    for (const id of ['playerPlaybackActions','m-now-feedback-actions']) hidden(id, !lastError);
    for (const id of ['playerSaveOriginal','m-now-save-original']) {
      const link = get<HTMLAnchorElement>(id); if (link) { const url = current && originalFileUrl?.(current); link.hidden = !url; if (url) link.href = url; else link.removeAttribute('href'); }
    }
    hidden('globalAudioPlayer', closed || view === 'mini'); hidden('playerMiniTrigger', closed || view !== 'mini'); hidden('m-mini', closed || view === 'expanded');
    for (const id of ['playerSleepBtn','m-now-sleep']) hidden(id, !sleepTimer);
    renderQueue();
  }
  const playIds = ['playerPlayBtn','playerMiniPlayBtn','m-mini-playpause','m-now-playpause']; playIds.forEach(id => bind(id, togglePlay));
  ['playerPrevBtn','m-now-prev'].forEach(id => bind(id, () => queue.previous()));
  ['playerNextBtn','m-now-next','m-mini-next'].forEach(id => bind(id, () => queue.next()));
  ['playerRewindBtn','m-now-rewind'].forEach(id => bind(id, () => player.seekAsync(player.currentTime - 10)));
  ['playerForwardBtn','m-now-forward'].forEach(id => bind(id, () => player.seekAsync(player.currentTime + 10)));
  ['playerStopBtn','m-now-stop'].forEach(id => bind(id, () => player.stopAndReset()));
  ['playerModeBtn','m-now-mode'].forEach(id => bind(id, mode));
  ['playerMuteBtn','m-now-mute'].forEach(id => bind(id, () => player.setMuted(!player.muted)));
  ['playerRetryBtn','m-now-retry'].forEach(id => bind(id, () => { lastError = null; return queue.retry(); }));
  ['playerCollapseBtn','m-now-collapse'].forEach(id => bind(id, () => { view = 'mini'; popup(null); updateModal(); render(); }));
  ['playerMiniExpandBtn','m-mini-open'].forEach(id => bind(id, () => { view = element.dataset.layout === 'mobile' ? 'expanded' : 'bar'; updateModal(); render(); }));
  ['playerPlaylistToggleBtn','m-now-queuebtn'].forEach(id => bind(id, () => togglePanel('queue', id)));
  ['playerPlaylistCloseBtn','m-now-queue-close'].forEach(id => bind(id, () => popup(null)));
  get('m-now-queue-backdrop')?.addEventListener('click', () => popup(null), {signal:abort.signal});
  bind('clearPlaylistBtn', () => queue.clear()); bind('playerRateMenuBtn', () => togglePanel('rate','playerRateMenuBtn'));
  all<HTMLButtonElement>('[data-rate]').forEach(button => button.addEventListener('click', () => { player.setPlaybackRate(Number(button.dataset.rate)); popup(null); }, {signal:abort.signal}));
  for (const id of ['playerRateSelect','m-now-rate']) get<HTMLSelectElement>(id)?.addEventListener('change', event => player.setPlaybackRate(Number((event.target as HTMLSelectElement).value)), {signal:abort.signal});
  for (const id of ['playerVolumeSlider','m-now-volume']) get<HTMLInputElement>(id)?.addEventListener('input', event => player.setVolume(Number((event.target as HTMLInputElement).value)), {signal:abort.signal});
  for (const id of ['playerProgressBar','m-now-seek']) {
    const input = get<HTMLInputElement>(id); if (!input) continue;
    input.addEventListener('input', () => { scrubbing = {resource:player.currentResourceId,input}; render(); }, {signal:abort.signal});
    input.addEventListener('change', () => { const captured = scrubbing; scrubbing = null; if (!captured || captured.resource === player.currentResourceId) perform(() => player.seekAsync(Number(input.value) / 1000 * player.duration)); render(); }, {signal:abort.signal});
    input.addEventListener('pointercancel', () => { scrubbing = null; render(); }, {signal:abort.signal});
  }
  function openSleep(trigger?: HTMLElement) { popup(null); if (!sleepTimer) return; panelTrigger = trigger ?? null; sleep.showModal(); }
  for (const id of ['playerSleepBtn','m-now-sleep']) bind(id, () => openSleep(get(id) ?? undefined));
  shadow.querySelector('[data-sleep-close]')!.addEventListener('click', () => sleep.close(), {signal:abort.signal});
  sleep.addEventListener('close', () => panelTrigger?.focus(), {signal:abort.signal});
  function closePresentation() { popup(null); closed = true; sleep.close(); updateModal(); if (clearQueueOnClose) queue.setItems([]); render(); onClose?.(); }
  async function close() { if (disposed || closed) return; await player.close(); }
  for (const id of ['playerCloseBtn','playerErrorCloseBtn','m-now-close']) bind(id, close);
  modal.addEventListener('cancel', event => { event.preventDefault(); if (panel) popup(null); else { view = 'mini'; updateModal(); render(); } }, {signal:abort.signal});
  shadow.addEventListener('keydown', rawEvent => {
    const event = rawEvent as KeyboardEvent;
    if (event.key === 'Escape' && panel) { event.preventDefault(); event.stopPropagation(); popup(null); return; }
    if (panel && event.key === 'Tab') {
      const scope = panel === 'rate' ? get('playerRateMenu') : element.dataset.layout === 'mobile' ? get('m-now-queue') : get('playerPlaylistPanel');
      const candidates = Array.from(scope?.querySelectorAll<HTMLElement>('button:not(:disabled),select:not(:disabled)') ?? []).filter(node => node.getClientRects().length);
      if (candidates.length) { event.preventDefault(); const index = candidates.indexOf(shadow.activeElement as HTMLElement); candidates[(index + (event.shiftKey ? -1 : 1) + candidates.length) % candidates.length].focus(); } return;
    }
  }, {signal:abort.signal});
  function destroy() {
    if(disposed)return;disposed=true;abort.abort();off.forEach(cleanup=>cleanup());warming?.destroy();sleepSettings?.destroy();
    sleep.close();modal.close();preset.destroy();element.remove();
  }
  off.push(player.on('closerequest',closePresentation),player.on('destroy',destroy),player.on('loadstart',()=>{lastError=null;phase='';scrubbing=null;render();}));
  for (const event of ['statechange','timeupdate','durationchange','volumechange','ratechange','sourcechange','playing','pause','stop'] as const) off.push(player.on(event,render));
  off.push(player.on('mediachange',()=>{for(const child of Array.from(mediaHost.children)) (child as HTMLElement).hidden=child!==player.element;}));
  off.push(player.on('playerror',report),player.on('error',(error,switched)=>{if(!switched)report(error);}),player.on('diagnostic',diagnostic=>{phase=diagnostic.code==='buffering-started'?'缓冲中':diagnostic.code==='resolve-start'?'正在重新连接':'';render();}));
  off.push(player.on('playing',()=>{if(!closed&&!player.paused&&player.state==='playing'&&player.currentResourceId)mediaSession?.activate();}));
  const featureError=(event:Event)=>report((event as CustomEvent).detail);
  queue.addEventListener('error',featureError);mediaSession?.addEventListener('error',featureError);
  off.push(()=>{queue.removeEventListener('error',featureError);mediaSession?.removeEventListener('error',featureError);});
  doc.addEventListener('pointerdown',event=>{
    if(!panel)return;
    const pane=panel==='rate'?get('playerRateMenu'):element.dataset.layout==='mobile'?get('m-now-queue'):get('playerPlaylistPanel');
    const path=event.composedPath();if(!path.includes(pane!)&&!path.includes(panelTrigger!))popup(null);
  },{signal:abort.signal});
  const queueChanged=()=>render();queue.addEventListener('change',queueChanged);off.push(()=>queue.removeEventListener('change',queueChanged));
  const change=()=>presentation();mq.addEventListener('change',change);dark.addEventListener('change',change);off.push(()=>{mq.removeEventListener('change',change);dark.removeEventListener('change',change);});
  // Media change from initial attach occurred before subscriptions were installed.
  for(const child of Array.from(mediaHost.children)) (child as HTMLElement).hidden=child!==player.element;
  presentation();
  const publicFeatures = Object.freeze({get queue(){return preset.features.queue;},get sleepTimer(){return preset.features.sleepTimer;},get mediaSession(){return preset.features.mediaSession;},get videoTracks(){return preset.features.videoTracks;},get mainMedia(){return preset.features.mainMedia;}});
  return {element,player,queue,features:publicFeatures,
    setTheme(value){choice(value,['auto','light','dark']);theme=value;presentation();},setPalette(value){choice(value,['mint','studio']);element.dataset.palette=value;},
    setLayout(value){choice(value,['auto','desktop','mobile']);layout=value;presentation();},setView(value){choice(value,['bar','mini','expanded']);view=value;updateModal();render();},
    async setItems(value){const changed=await queue.replaceItems(value);if(changed){closed=false;updateModal();render();}return changed;},
    open(){closed=false;updateModal();render();},close,async importSubtitle(){throw new TypeError('Subtitle import requires a video player');},destroy};
}
