/** Shared interaction geometry and states; each skin supplies its palette and silhouette. */
export const sharedVideoStyles = `
:host{container:studio-video / inline-size;max-width:100%}

.video-settings-content{padding:0 16px 12px}
.video-playback-settings,.video-sleep-quick{min-width:0;padding:8px 0}
.video-settings-actions,.video-sleep-quick>div{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.video-settings-actions button,.video-sleep-quick button{display:flex;align-items:center;justify-content:flex-start;gap:10px;min-height:44px;padding:10px 12px;border:1px solid var(--studio-overlay-border,var(--border));border-radius:8px;background:var(--studio-overlay-hover,var(--soft,transparent));color:inherit;font:inherit;font-size:13px;text-align:left;cursor:pointer}
.video-settings-actions button svg{width:20px;height:20px;flex:none}
.video-settings-actions button:hover:enabled,.video-sleep-quick button:hover:enabled{background:var(--studio-overlay-hover,var(--soft,transparent));border-color:var(--studio-overlay-accent,var(--accent))}
.video-settings-actions button[aria-pressed=true],.video-sleep-quick button[aria-pressed=true]{border-color:var(--studio-overlay-accent,var(--accent));color:var(--studio-overlay-accent,var(--accent));background:var(--studio-overlay-hover,var(--soft,transparent))}
.video-settings-hint{margin:8px 0 12px;color:var(--studio-overlay-muted,var(--muted));font-size:12px;line-height:1.6;overflow-wrap:anywhere}
.video-volume-setting{display:grid;gap:4px;font-size:13px;margin-bottom:8px}
.video-volume-setting>span{display:flex;justify-content:space-between;align-items:center}
.video-volume-setting input{display:block;min-width:0;width:100%;height:44px;accent-color:var(--studio-overlay-accent,var(--accent));margin:0}
.video-info-title{font-size:15px;line-height:1.5;overflow-wrap:anywhere;margin:8px 0}
.video-info-facts{display:grid;gap:0;margin:12px 0;font-size:13px}
.video-info-facts>div{display:grid;grid-template-columns:minmax(76px,.7fr) minmax(0,1.3fr);gap:12px;padding:10px 0;border-bottom:1px solid var(--studio-overlay-border,var(--border))}
.video-info-facts dt{color:var(--studio-overlay-muted,var(--muted))}.video-info-facts dd{margin:0;overflow-wrap:anywhere}
.root .settings-grid>.video-playback-settings{grid-column:1/-1}
.root .settings-grid>div:has(>.video-playback-settings){grid-column:1/-1}
.root .video-end-slate{position:absolute;inset:0;display:grid;place-items:center;padding:54px 16px 110px;background:#0007;z-index:2;text-align:center;pointer-events:none}
.video-end-card{pointer-events:auto;width:min(100%,400px);padding:20px;border-radius:12px;background:#101820e6;color:#fff}
.video-end-card p{margin:0;font-size:12px;color:#c8d1d8}.video-end-card h2{font-size:18px;margin:10px 0 16px;overflow-wrap:anywhere}
.video-end-card>div{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.root [data-popup-panel=episodes] .cinema-sidebar{display:flex!important;flex-direction:column;padding:0 16px 12px;margin:0;max-width:none;border:0;box-shadow:none;background:transparent}
.root [data-popup-panel=episodes] .cinema-sidebar-title{display:none}
.root [data-popup-panel=episodes] .cinema-sidebar-header{margin-bottom:8px}
.root [data-popup-panel=episodes] .episode-list{max-height:none}

.root{--video-ease:cubic-bezier(.2,.7,.2,1);--video-control-radius:10px;--video-control-hover:#ffffff20;--video-control-active:#ffffff32;--video-focus:var(--studio-video-focus,#9ad9ff)}
.root .screen{width:100%;min-width:0;container:studio-video-screen / inline-size}
.root media-container:focus{outline:none}
.root .screen:focus-visible{outline:2px solid var(--video-focus);outline-offset:-3px;border-radius:inherit}
.root .studio-overlay :is(input,select,button):focus-visible{outline:2px solid var(--video-focus);outline-offset:-2px}
.root .screen-heading{gap:12px;pointer-events:none}
.root .screen-heading>span{min-width:0;flex:1}
.root .screen-actions{display:flex;align-items:center;flex:none;gap:4px;pointer-events:auto}
.root .controls :is(button,.volume){flex-shrink:0}
.root .volume:focus-within{overflow:visible}
.root .screen button{position:relative;-webkit-tap-highlight-color:transparent;transition:background-color 160ms var(--video-ease),color 160ms var(--video-ease),box-shadow 160ms var(--video-ease),scale 120ms var(--video-ease)}
.root .screen :is(.icon,.cinema-btn,.stream-btn,.text-control,.pip-control,.fullscreen-control):not(.center-play){min-width:44px;min-height:44px;border-radius:var(--video-control-radius);border:1px solid transparent}
.root .screen button:disabled{opacity:.35;cursor:default;scale:1;box-shadow:none}
.root .stream-text-btn{min-height:44px;min-width:44px}
.root .screen button:active:enabled{scale:.94;background-color:var(--video-control-active)}
.root .screen :is(button,.range-input):focus-visible{outline:2px solid var(--video-focus);outline-offset:2px}
.root .screen :is(button,.range-input){-webkit-tap-highlight-color:transparent}
.root .controls button:is([aria-expanded=true],[aria-pressed=true]),.root .screen-actions button[aria-expanded=true]{background-color:var(--video-control-active);box-shadow:none}
.root .controls button svg,.root .screen-actions button svg{width:22px;height:22px;pointer-events:none;flex:none}
.root .controls,.root .screen-heading{transition:opacity 180ms var(--video-ease),visibility 180ms}
.root[data-controls-hidden=true] :is(.controls,.screen-heading){opacity:0;visibility:hidden;pointer-events:none}
.root .controls:focus-within:has(:focus-visible),.root .screen-heading:focus-within:has(:focus-visible){opacity:1;visibility:visible;pointer-events:auto}
.root .playback-glyph{position:relative;display:block;flex:none;width:24px;height:24px;pointer-events:none}
.root .playback-glyph>[data-glyph]{position:absolute;inset:0;display:grid;place-items:center;transition:opacity 140ms var(--video-ease),transform 180ms var(--video-ease)}
.root .playback-glyph svg{width:100%;height:100%;margin:0}
.root [data-playback=play] [data-glyph=pause],.root [data-playback=pause] [data-glyph=play]{opacity:0;transform:scale(.7)}
.root [data-playback=play] [data-glyph=play],.root [data-playback=pause] [data-glyph=pause]{opacity:1;transform:scale(1)}
.root .playback-feedback{position:absolute;top:64px;left:50%;transform:translateX(-50%);z-index:12;display:flex;align-items:center;gap:8px;padding:8px 12px;border:0;border-radius:20px;background:#101419e8;color:#fff;font-size:12px;line-height:20px;pointer-events:none}
.root .playback-feedback svg{width:18px;height:18px;flex:none}
/* The paused frame stays readable. Only actionable controls intercept the picture. */
.root .center{pointer-events:none;z-index:2}
.root .center :is(button,.center-actions){pointer-events:auto}
.root[data-state=paused] .center{display:flex;opacity:1;visibility:visible;background:none;backdrop-filter:none;-webkit-backdrop-filter:none}
.root[data-state=paused] .center-copy{display:none}
.root[data-state=paused] .cinema-center-card{background:none;border-color:transparent;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none}
.root[data-state=playing]:is([data-layout=mobile],[data-compact=true]) .center{display:flex;opacity:1;visibility:visible;background:none;backdrop-filter:none;-webkit-backdrop-filter:none}
.root[data-state=playing] .center-copy{display:none}
.root[data-state=playing] .cinema-center-card{background:none;border:0;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none}
.root[data-controls-hidden=true] .center-actions{opacity:0;visibility:hidden;pointer-events:none}
.root .center-actions{transition:opacity 180ms var(--video-ease),visibility 180ms}
.root .center-play{display:inline-flex;align-items:center;justify-content:center;width:64px;height:64px;border-radius:50%;border:1px solid #ffffff50;background:#141a22bc;color:#fff;box-shadow:0 6px 24px #0003;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
.root .center-play .playback-glyph{width:28px;height:28px}
.root .center-play:hover:enabled{background:#29323ee8;transform:none;box-shadow:0 8px 28px #0004}
.root .center-play:active:enabled{scale:.94}
.root .buffering{z-index:3;background:none;pointer-events:none}
.root[data-state=error] .touch-seek,.root[data-state=empty] .touch-seek{display:none}
/* Range paint and native hit area use the same endpoints. */
.root .controls .range-control{--range-fill:0%;--range-buffer:0%;position:relative;min-width:0;cursor:pointer;touch-action:none;display:flex;align-items:center;height:44px;margin-block:0}
.root .controls .range-track{position:relative;width:calc(100% - 12px);margin-inline:6px;height:4px;border-radius:8px;background:#ffffff38;transition:height 140ms var(--video-ease)}
.root .controls .time-range:is(:hover,:focus-within) .range-track{height:6px}
.root .controls :is(.range-fill,.range-buffer){height:100%;border-radius:inherit}
.root .controls .range-thumb{top:50%;left:var(--range-fill);width:12px;height:12px;transform:translate(-50%,-50%);opacity:0;box-shadow:0 1px 6px #0005;transition:opacity 140ms,scale 140ms}
.root .controls .range-control:is(:hover,:focus-within) .range-thumb{opacity:1;scale:1}
.root .range-input{appearance:none;position:absolute;inset:0;width:100%;height:44px;margin:0;padding:0;border:0;transform:none;background:transparent;cursor:inherit;z-index:2;touch-action:none}
.root .range-input::-webkit-slider-runnable-track{height:44px;background:transparent}
.root .range-input::-webkit-slider-thumb{appearance:none;width:12px;height:44px;border:0;background:transparent}
.root .range-input::-moz-range-track{height:44px;background:transparent}
.root .range-input::-moz-range-thumb{width:12px;height:44px;border:0;background:transparent}
.root .range-control[data-disabled]{cursor:default;opacity:.4}
.root .range-control[data-disabled] .range-thumb{opacity:0}
.root .range-preview{position:absolute;bottom:40px;left:clamp(28px,var(--preview-position,50%),calc(100% - 28px));transform:translateX(-50%);padding:4px 8px;border-radius:6px;background:#101419f2;border:1px solid #ffffff24;color:#fff;font:600 12px/20px var(--studio-video-font,system-ui);font-variant-numeric:tabular-nums;pointer-events:none;white-space:nowrap;z-index:3}
.root .video-tooltip{position:absolute;z-index:15;max-width:calc(100% - 16px);padding:6px 10px;border-radius:6px;background:#171b20f5;color:#fff;font:500 12px/18px var(--studio-video-font,system-ui);white-space:normal;overflow-wrap:anywhere;text-align:center;pointer-events:none;box-shadow:0 2px 8px #0003}
.root .video-action-notice{position:absolute;top:100px;left:50%;transform:translateX(-50%);max-width:calc(100% - 32px);margin:0;padding:10px 14px;border:1px solid #ffffff30;border-radius:10px;background:#101419f2;color:#fff;font-size:13px;line-height:1.6;overflow-wrap:anywhere;z-index:16;pointer-events:none}
/* Menus use a visible selection surface, a fixed check slot and restrained motion. */
.root .studio-overlay{border-radius:14px;box-shadow:0 16px 48px #0005;backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}
.root .studio-overlay-panel{scrollbar-width:thin;scroll-padding:8px;min-width:min(280px,calc(100vw - 24px))}
.root .studio-overlay-header{min-height:52px;font-size:14px;font-weight:600;border-bottom:1px solid var(--studio-overlay-border,#ffffff18);margin-bottom:4px}
.root .studio-overlay :is([data-popup-item],.studio-overlay-back,.studio-overlay-close){min-height:44px;transition:background-color 140ms,color 140ms;touch-action:manipulation}
.root .studio-overlay-title{flex:1;min-width:0}
.root .studio-overlay-close{display:grid;place-items:center;width:44px;flex:none;padding:10px;color:inherit;background:none;border:0;border-radius:8px;cursor:pointer}
.root .studio-overlay-close svg{width:20px;height:20px}
.root .studio-overlay-close:hover{background:var(--studio-overlay-hover,#ffffff18)}
.root .studio-overlay-close:focus-visible{outline:2px solid var(--video-focus);outline-offset:-2px}
.root .studio-overlay [data-popup-item][aria-checked=true]{background:color-mix(in srgb,var(--studio-overlay-accent,#fff) 13%,transparent);font-weight:600}
.root .studio-overlay [data-popup-item]:active:enabled{background:var(--studio-overlay-hover,#ffffff18)}
.root .studio-overlay [data-popup-item][role=menuitemradio]::after{height:16px;opacity:0;transition:opacity 140ms,scale 140ms;scale:.8}
.root .studio-overlay [data-popup-item][role=menuitemradio][aria-checked=true]::after{opacity:1;scale:1}
.root .studio-overlay-item-label{overflow-wrap:anywhere}
.root .studio-overlay-item-value{max-width:120px;min-width:0;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.root .studio-overlay-hint:empty{display:none}
.root .studio-overlay [data-sleep-settings]{padding:8px 16px 12px}
.root .video-sleep-status{margin:8px 16px 0;font-size:12px;line-height:1.6;color:var(--studio-overlay-muted,var(--muted))}
.root .video-sleep-status .studio-overlay-item-value{display:block;max-width:none;white-space:normal;padding:0;overflow-wrap:anywhere}
.root .stream-rate-control{display:grid;gap:4px;padding:8px 16px;border-bottom:1px solid var(--studio-overlay-border,#ffffff24)}
.root .stream-rate-current{font-size:18px;font-weight:600;text-align:center}
.root .stream-rate-control input{width:100%;min-width:0;height:44px;margin:0;accent-color:var(--studio-overlay-accent,var(--accent))}
.mediadock-root .stream-rate-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:4px;padding:8px}
.mediadock-root .stream-rate-grid [data-popup-item]{border-radius:8px;padding:8px 12px;gap:4px}
.root .episode-copy{min-width:0;overflow-wrap:anywhere}
.root .episode-row{transition:background-color 160ms,border-color 160ms,box-shadow 160ms}
.root .episode-row:focus-visible{outline-offset:-3px}
.root :is(.center-copy,.cinema-center-copy){min-width:0;max-width:100%;overflow-wrap:anywhere}
.root :is(.center-copy h2,.cinema-center-title){display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.root :is(.host-actions,.statusline){flex-wrap:wrap;min-width:0}
.root .host-actions{max-width:100%}
.root .host-actions:empty{display:none}
.root .host-actions button{min-height:44px;max-width:100%;overflow-wrap:anywhere}
.root :is(.statusline,.error,.closed){overflow-wrap:anywhere}
/* Shared feedback; compact composition lives in styles-mobile.ts. */
.root:not([data-state=empty]):not([data-state=error]):not([data-state=stopped]) .center-copy{display:none}
.root .cinema-center-card{background:none;border:0;box-shadow:none;padding:0;backdrop-filter:none}
.root .controls :is(.time,.cinema-time-display){font-size:13px;font-variant-numeric:tabular-nums;white-space:nowrap}
.root .settings-actions{display:grid;grid-template-columns:1fr;gap:4px;border-top:1px solid var(--border);padding-top:12px}
.root .settings-actions button{display:flex;align-items:center;gap:12px;min-height:44px;width:100%;padding:8px 12px;border-radius:8px;font-size:14px;text-align:left}
.root .settings-actions button:hover{background:var(--soft)}
.root .settings-actions button svg{width:20px;height:20px}
@media(hover:hover){
 .root .screen :is(.icon,.cinema-btn,.stream-btn,.text-control,.pip-control,.fullscreen-control):hover:enabled{background-color:var(--video-control-hover);transform:none}
}
@media(hover:none){.root .controls .range-thumb{opacity:1}}
@container studio-video (max-width:600px){
 .root .closed{flex-direction:column;align-items:flex-start;gap:16px;padding:24px}
 .root .now{flex-wrap:wrap}
}
.root media-container:fullscreen .screen{min-height:0}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
`;
