import { Volume2, PictureInPicture2, RectangleHorizontal, SkipBack, SkipForward, Square } from 'lucide';
import { iconMarkup } from '../icon.js';
import type { SleepTimerController } from '../../sleep-timer/index.js';

/** Skin-independent choices. Layouts may move these controls, but must not change their meaning. */
export const RATE_VALUES = ['0.25', '0.5', '0.75', '1', '1.25', '1.5', '1.75', '2'] as const;
export const rateLabel = (value: number | string): string => Number(value) === 1 ? '1× · 标准' : `${Number(value)}×`;
export const SLEEP_QUICK = [
  ['off', '关闭定时'], ['10', '10 分钟'], ['15', '15 分钟'], ['20', '20 分钟'],
  ['30', '30 分钟'], ['45', '45 分钟'], ['60', '60 分钟'], ['end', '播完本集'],
] as const;

export function applySleepQuick(timer: SleepTimerController, value: string): void {
  if (value === 'off') { timer.cancel(); return; }
  if (!SLEEP_QUICK.some(([key]) => key === value)) return;
  timer.start({ trigger: value === 'end' ? { type: 'current' }
    : { type: 'duration', durationMs: Number(value) * 60000 }, action: 'pause' });
}

export function selectedSleepQuick(timer: SleepTimerController | null): string {
  const state = timer?.snapshot;
  if (!state || state.status !== 'running') return state?.actionPending ? '' : 'off';
  // Custom stop/close rules and non-preset durations must not look like a selected pause preset.
  if (state.action !== 'pause') return '';
  return state.trigger?.type === 'current' ? 'end'
    : state.trigger?.type === 'duration' ? String(state.trigger.durationMs / 60000) : '';
}

export const sleepQuickMarkup = `<div class="video-sleep-quick" role="group" aria-label="快捷睡眠定时">
  <p class="video-settings-hint">快捷设置到时暂停；也可自定义条件与结束动作。</p>
  <div>${SLEEP_QUICK.map(([value, label]) => `<button type="button" data-quick-sleep="${value}" aria-pressed="false">${label}</button>`).join('')}</div>
</div>`;

const settingAction = (action: string, label: string, icon: typeof Volume2) =>
  `<button type="button" data-player-action="${action}" aria-label="${label}">${iconMarkup(icon)}<span data-player-label>${label}</span></button>`;

/** Alternate entrances remain available when compact layouts hide toolbar controls. */
export const playbackSettingsMarkup = `<div class="video-playback-settings">
  <label class="video-volume-setting"><span>音量 <output data-settings-volume-label>100%</output></span><input type="range" data-settings-volume min="0" max="1" step="0.01" value="1" aria-label="播放音量"></label>
  <div class="video-settings-actions">
    ${settingAction('mute', '静音', Volume2)}
    ${settingAction('wide', '宽屏模式', RectangleHorizontal)}
    ${settingAction('pip', '画中画', PictureInPicture2)}
    ${settingAction('previous', '上一集', SkipBack)}
    ${settingAction('next', '下一集', SkipForward)}
    ${settingAction('stop', '停止播放', Square)}
  </div>
  <p class="video-settings-hint" data-display-capability></p>
  <p class="video-settings-hint" data-device-volume hidden>也可使用设备音量键调节音量。</p>
</div>`;

const INFO_FIELDS = [
  ['播放状态', 'status'], ['睡眠定时', 'sleep-status'], ['当前画质', 'quality-info'],
  ['视频分辨率', 'resolution-info'], ['当前码率', 'bitrate-info'], ['可用清晰度', 'qualities-info'],
  ['音轨', 'audio-info'], ['字幕', 'subtitle-info'], ['媒体类型', 'mime-info'],
  ['播放方式', 'transport-info'], ['播放策略', 'strategy-info'],
] as const;
export const infoFactsMarkup = `<dl class="video-info-facts">${INFO_FIELDS.map(([label, key]) =>
  `<div><dt>${label}</dt><dd data-${key}>未知</dd></div>`).join('')}</dl>`;

export function createSettingsContent(document: Document, markup: string): HTMLElement {
  const element = document.createElement('div');
  element.className = 'video-settings-content';
  element.innerHTML = markup;
  return element;
}
