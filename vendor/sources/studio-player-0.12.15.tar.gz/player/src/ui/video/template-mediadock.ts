import { videoMarkup } from './template-stream.js';
import { streamStyles } from './styles-stream.js';
import { mediaDockVideoStyles } from './styles-mediadock.js';
import { mobileVideoStyles } from './styles-mobile.js';

export const mediaDockTemplate = `<style>${streamStyles}\n${mediaDockVideoStyles}\n${mobileVideoStyles}</style>${videoMarkup(true)}`;
