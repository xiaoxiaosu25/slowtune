/** MediaDock 全页舞台：独立圆角容器、标题状态和分组底栏，共用功能样式。 */
export const mediaDockVideoStyles = `
:host { --stream-red:#66c7ae; --stream-loader:#66c7ae; --stream-page-bg:#101918; --stream-page-text:#f3f7f6; --stream-page-muted:#a8bbb5; }
:host([data-palette=studio]) { --stream-red:#ca9872; --stream-loader:#ca9872; }
.mediadock-root { background:transparent; }
.dock-stage { position:fixed; inset:0; margin:auto; padding:24px; width:100vw; height:100dvh; max-width:none; max-height:none; border:0; background:transparent; color:#f3f7f6; overflow:hidden; }
.dock-stage::backdrop { background:rgba(8,14,13,.92); backdrop-filter:blur(16px); }
.dock-stage video-player, .dock-stage media-container, .dock-stage .stream-stage { height:100%; width:100%; }
.dock-stage .stream-stage { border:1px solid #ffffff24; border-radius:20px; box-shadow:0 24px 80px #0008; }
.mediadock-root .dock-stage media-container .screen { height:100%; min-height:0; aspect-ratio:auto; }
.mediadock-root[data-view=wide] .dock-stage { padding:0; }
.mediadock-root[data-view=wide] .stream-stage { border-radius:0; border:0; }
.dock-stage .screen-heading { height:100px; padding:22px 28px; align-items:flex-start; background:linear-gradient(#000b,transparent); }
.dock-stage .screen-title { display:grid; gap:4px; min-width:0; }
.dock-stage .screen-title > span { font-size:20px; font-weight:650; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; }
.dock-stage .screen-title small { color:#c0d2cb; font-size:12px; }
.dock-stage .screen-heading .stream-btn { background:#ffffff12; border:1px solid #ffffff24; border-radius:12px; }
.dock-sleep-badge { font-size:12px; color:#b8d5ca; align-self:center; }
.dock-stage .controls { padding:48px 24px 16px; background:linear-gradient(transparent,#000a); }
.dock-stage .control-row { height:56px; gap:16px; }
.dock-stage .transport { gap:4px; }
.dock-stage .tools { gap:4px; border-left:1px solid #ffffff26; padding-left:12px; }
.dock-stage .stream-btn { border-radius:10px; }
.dock-stage .transport > [data-action=play] { background:var(--timeline); color:#0c1b16; margin-inline:4px; border-radius:14px; }
.mediadock-root .dock-stage .transport > [data-action=play]:hover:enabled { background:color-mix(in srgb,var(--timeline) 85%,white); }
.mediadock-root .dock-stage .transport > [data-action=play]:active:enabled { background:color-mix(in srgb,var(--timeline) 85%,black); }
.dock-stage .center-play { width:76px; height:76px; border-radius:24px; background:#ffffff1c; border:1px solid #ffffff40; }
.dock-stage .now, .dock-stage .statusline, .dock-stage > .error, .dock-stage media-container > .error { display:none; }
.dock-stage .stream-playlist { top:88px; right:20px; bottom:112px; width:min(400px,calc(100% - 40px)); border:1px solid #ffffff2e; border-radius:16px; background:#15211ff5; }
.dock-stage .studio-overlay { color-scheme:dark; --studio-overlay-background:#15211ff5; --studio-overlay-text:#f3f7f6; --studio-overlay-muted:#a8bbb5; --studio-overlay-border:#ffffff2e; --studio-overlay-accent:var(--timeline); --studio-overlay-focus:var(--video-focus); }
.mediadock-root:is([data-layout=mobile],[data-compact=true]) .tools { border:0; padding:0; display:contents; }
.mediadock-root:is([data-layout=mobile],[data-compact=true]) .controls [data-action=episodes] { display:inline-flex; }
.mediadock-root:is([data-layout=mobile],[data-compact=true]) .controls [data-action=previous] { display:none; }
`;
