import { applySleepQuick, selectedSleepQuick } from './settings-content.js';
import { createPlaybackFeedback } from './playback-feedback.js';
import { createCaptionClearance } from '../caption-clearance.js';
import { createControlTooltips } from './control-tooltips.js';
import { createPlayerPreset, type PlayerPresetOptions, type PlayerFeatureOptions } from '../../presets/index.js';
import type { StudioPlayer } from '../../player.js';
import { mountQueuePrefetch, type QueueController, type QueueItem, type QueueOptions, type QueuePrefetchOptions } from '../../queue/index.js';
import type { SleepTimerController } from '../../sleep-timer/index.js';
import type { MediaSessionController } from '../../media-session/index.js';
import type { MainMediaController } from '../../main-media/index.js';
import type { VideoTracksController, VideoTrackOption } from '../../video-tracks/index.js';
import { mountSleepTimerSettings } from '../sleep-settings.js';
import { streamIcon as videoIcon, streamTemplate } from './template-stream.js';
import { createStreamView, type StreamView } from './stream-view.js';
import { resolveVideoControls, type VideoControlsOptions, type VideoControlsPlacement } from './controls.js';
import { createVideoSourceFeatures } from './source-features.js';
export type { VideoControlFeature, VideoControlPlacement, VideoControlPreset, VideoControlsOptions, VideoControlsPlacement } from './controls.js';

export type VideoPlayerTheme = 'auto' | 'light' | 'dark';
export type VideoPlayerLayout = 'auto' | 'desktop' | 'mobile';
export type VideoPlayerView = 'standard' | 'wide';
/** classic / cinema 为旧入口兼容别名，均映射至 Stream。正式设计只有两套。 */
export type VideoPlayerVariant = 'stream' | 'mediadock' | 'classic' | 'cinema';
export interface VideoPlayerTokens {
  background?: string; surface?: string; 'surface-alt'?: string; text?: string; 'text-muted'?: string;
  border?: string; accent?: string; 'on-accent'?: string; focus?: string; error?: string;
  radius?: string; font?: string; shadow?: string; controls?: string; timeline?: string;
}
export interface VideoPlayerAction {
  id: string;
  label: string;
  run(context: { readonly player: StudioPlayer; readonly queue: QueueController; readonly current: Readonly<QueueItem> | null }): unknown | Promise<unknown>;
}
export interface VideoPlayerOptions extends Omit<PlayerPresetOptions, 'features' | 'nativeElementTag'> {
  items?: readonly QueueItem[];
  /** Reuse a queue owned by another public player UI in the same playback session. */
  queueController?: QueueController;
  /** Reuse the existing sleep timer instead of creating a second timer. */
  sleepTimerController?: SleepTimerController | null;
  /** Reuse the existing Media Session controller instead of creating a second one. */
  mediaSessionController?: MediaSessionController | null;
  queue?: QueueOptions;
  features?: Omit<PlayerFeatureOptions, 'queue' | 'videoTracks'>;
  theme?: VideoPlayerTheme;
  tokens?: VideoPlayerTokens;
  layout?: VideoPlayerLayout;
  view?: VideoPlayerView;
  variant?: VideoPlayerVariant;
  controls?: VideoControlsOptions;
  prefetch?: QueuePrefetchOptions;
  /** 两套视频统一默认保留队列；关闭仍通过核心保存断点。 */
  clearQueueOnClose?: boolean;
  /** 来源与宿主支持处理时展示；与 HLS 自适应画质分开。 */
  outputHeights?: readonly number[];
  /** 默认使用上游 hlsjs-video（也播放原生 MP4），需安装该 peer。可注入已注册媒体，套件拥有其生命周期。 */
  createMediaElement?: (document: Document) => HTMLElement;
  onClose?: () => void;
  /** 界面已退出后的保存/释放失败；不能作为新会话的播放错误。 */
  onCloseError?: (error: unknown) => void;
  onError?: (error: unknown) => void;
  onRequestItems?: () => unknown | Promise<unknown>;
  /** 最多三个产品动作，复用当前会话。 */
  actions?: readonly VideoPlayerAction[];
}
export interface VideoPlayerUI {
  readonly element: HTMLElement;
  readonly player: StudioPlayer;
  readonly queue: QueueController;
  readonly videoTracks: VideoTracksController;
  readonly sleepTimer: SleepTimerController | null;
  readonly mediaSession: MediaSessionController | null;
  readonly mainMedia: MainMediaController | null;
  readonly isClosed: boolean;
  readonly isDestroyed: boolean;
  readonly controls: VideoControlsPlacement;
  setTheme(theme: VideoPlayerTheme): void;
  setTokens(tokens: VideoPlayerTokens): void;
  setLayout(layout: VideoPlayerLayout): void;
  setView(view: VideoPlayerView): void;
  setControls(controls: VideoControlsOptions): void;
  importSubtitle(file: File): Promise<void>;
  setItems(items: readonly QueueItem[]): Promise<boolean>;
  open(): void;
  close(): Promise<void>;
  /** Host back: child panel → list → fullscreen → close, without replacing the session. */
  handleBack(): boolean;
  destroy(): void;
}
const tokenNames = ['background', 'surface', 'surface-alt', 'text', 'text-muted', 'border', 'accent', 'on-accent', 'focus', 'error', 'radius', 'font', 'shadow', 'controls', 'timeline'] as const;
let registration: Promise<unknown> | undefined;
function registerElements(): Promise<unknown> {
  return registration ??= Promise.all([
    import('@videojs/html/video/player'), import('@videojs/html/ui/container'),
    import('@videojs/html/i18n/locales/zh/register'),
  ]).catch(error => { registration = undefined; throw error; });
}
function choice<T extends string>(value: T, choices: readonly T[], label: string): void {
  if (!choices.includes(value)) throw new TypeError(`Unknown video ${label}: ${value}`);
}
function time(value: number): string {
  if (!Number.isFinite(value) || value < 0) return '0:00';
  const seconds = Math.floor(value);
  return `${seconds >= 3600 ? Math.floor(seconds / 3600) + ':' : ''}${seconds >= 3600 ? String(Math.floor(seconds / 60) % 60).padStart(2, '0') : Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}
function positiveNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : null;
}
function formatResolution(width: number | undefined, height: number | undefined): string {
  const safeWidth = positiveNumber(width); const safeHeight = positiveNumber(height);
  return safeWidth && safeHeight ? `${safeWidth} × ${safeHeight}` : '未知';
}
function formatBitrate(value: number | undefined): string {
  const bitrate = positiveNumber(value);
  if (!bitrate) return '未知';
  return bitrate >= 1_000_000 ? `${(bitrate / 1_000_000).toFixed(1)} Mbps` : `${Math.round(bitrate / 1000)} kbps`;
}
function formatStrategy(value: string | undefined): string {
  const labels: Record<string, string> = {
    direct: '直连播放', proxy: '代理流', transcode: '实时转码', fallback: '备用源',
  };
  return value ? labels[value] ?? value : '未知';
}
function metadata(item?: Readonly<QueueItem> | null) {
  const input = item?.source;
  const data = input && typeof input === 'object' && 'metadata' in input ? input.metadata ?? {} : {};
  return { title: item?.title || (typeof data.title === 'string' ? data.title : '未命名视频'),
    description: typeof data.description === 'string' ? data.description : '',
    poster: typeof data.poster === 'string' ? data.poster : item?.artwork?.[0]?.src ?? '',
    duration: input && typeof input === 'object' && 'durationSeconds' in input ? input.durationSeconds : undefined };
}
function validateItems(items: readonly QueueItem[]): void {
  for (const item of items) {
    const source = item.source;
    if (source && typeof source === 'object' && (('mediaType' in source && source.mediaType === 'audio')
      || ('type' in source && source.type?.startsWith('audio/')))) throw new TypeError('Video UI expects a video episode list');
  }
}

type PictureMedia = HTMLVideoElement & {
  requestPictureInPicture?: () => Promise<unknown>;
  exitPictureInPicture?: () => Promise<void>;
  isPictureInPicture?: boolean;
  webkitEnterFullscreen?: () => void;
  webkitExitFullscreen?: () => void;
  webkitDisplayingFullscreen?: boolean;
  webkitSupportsPresentationMode?: (mode: string) => boolean;
  webkitSetPresentationMode?: (mode: string) => void;
  webkitPresentationMode?: string;
};

/** 公共视频 UI；不隐式加载、自动播放或创建产品级协调单例。 */
export async function mountVideoPlayer(root: HTMLElement, options: VideoPlayerOptions = {}): Promise<VideoPlayerUI> {
  if (!root?.ownerDocument || typeof root.append !== 'function') throw new TypeError('A video UI mount element is required');
  choice(options.theme ?? 'auto', ['auto', 'light', 'dark'], 'theme');
  choice(options.layout ?? 'auto', ['auto', 'desktop', 'mobile'], 'layout');
  choice(options.view ?? 'standard', ['standard', 'wide'], 'view');
  choice(options.variant ?? 'stream', ['classic', 'cinema', 'stream', 'mediadock'], 'variant');
  const variant = options.variant === 'mediadock' ? 'mediadock' : 'stream';
  const controlsPreset = variant === 'mediadock' ? 'balanced' : 'concentrated';
  let controls = resolveVideoControls(options.controls, controlsPreset);
  if (options.outputHeights?.some(height => !Number.isInteger(height) || height < 0 || height > 4320)) throw new TypeError('Invalid output height');
  if (options.clearQueueOnClose !== undefined && typeof options.clearQueueOnClose !== 'boolean') throw new TypeError('Invalid clearQueueOnClose');
  validateItems(options.items ?? []);
  const actions = options.actions ?? [];
  if (actions.length > 3 || new Set(actions.map(action => action.id)).size !== actions.length
    || actions.some(action => !action.id || !action.label || typeof action.run !== 'function')) throw new TypeError('Provide at most three unique labeled video actions');
  const { items = [], queue: queueOptions, queueController: sharedQueue, sleepTimerController: sharedSleepTimer,
    mediaSessionController: sharedMediaSession, features, theme = 'auto', tokens = {}, layout: initialLayout = 'auto', view: initialView = 'standard', variant: _variant,
    controls: _controls, prefetch, clearQueueOnClose = false, outputHeights = [],
    createMediaElement, onClose, onCloseError, onError, onRequestItems, actions: _actions, ...playerOptions } = options;
  const template = variant === 'mediadock' ? (await import('./template-mediadock.js')).mediaDockTemplate : streamTemplate;
  const renderPlayIcon = (name: 'play' | 'pause') => videoIcon(name);
  const renderMuteIcon = (muted: boolean) => videoIcon(muted ? 'volumeMuted' : 'volume');
  const preset = createPlayerPreset('video', { ...playerOptions, features: {
    ...features,
    queue: sharedQueue ? false : queueOptions ?? true,
    sleepTimer: sharedSleepTimer ? false : features?.sleepTimer,
    mediaSession: sharedMediaSession ? false : features?.mediaSession,
    videoTracks: true,
  } });
  const { player } = preset;
  const ownsPlayer = !playerOptions.player;
  const isMpv = player.instance.backend === 'mpv';
  if (isMpv && variant !== 'stream') {
    preset.destroy();
    throw new TypeError('The mpv backend is supported by the stream video variant only');
  }
  if (isMpv && !player.surfacePort) {
    preset.destroy();
    throw new TypeError('The mpv backend requires a SurfacePort');
  }
  if (!isMpv) {
    await registerElements();
    if (!createMediaElement) await import('@videojs/html/media/hlsjs-video');
  }
  const { videoTracks, mainMedia } = preset.features as typeof preset.features & { videoTracks: VideoTracksController };
  const configuredQueue = sharedQueue ?? preset.features.queue;
  if (!configuredQueue) {
    preset.features.destroy(); if (ownsPlayer) player.destroy();
    throw new TypeError('Video UI requires a queue or an enabled queue feature');
  }
  const queue: QueueController = configuredQueue;
  const sleepTimer = sharedSleepTimer ?? preset.features.sleepTimer;
  const mediaSession = sharedMediaSession ?? preset.features.mediaSession;
  if (sharedQueue && !sharedMediaSession) mediaSession?.setQueue(sharedQueue);
  const document = root.ownerDocument;
  const navigator = document.defaultView?.navigator;
  const deviceVolumeOnly = /iPad|iPhone|iPod/.test(navigator?.userAgent ?? '')
    || (navigator?.platform === 'MacIntel' && (navigator?.maxTouchPoints ?? 0) > 1);
  const element = document.createElement('div'); element.dataset.studioVideo = ''; element.dataset.theme = theme; element.dataset.variant = variant; element.dataset.backend = player.instance.backend;
  const shadow = element.attachShadow({ mode: 'open' }); shadow.innerHTML = template;
  const get = <T extends Element = HTMLElement>(selector: string) => shadow.querySelector<T>(selector)!;
  const all = <T extends Element = HTMLElement>(selector: string) => [...shadow.querySelectorAll<T>(selector)];
  const presentation = get('.root');
  const screen = get('[data-screen]');
  const stageDialog = shadow.querySelector<HTMLDialogElement>('[data-stage-dialog]');
  if (clearQueueOnClose) get('[data-closed-description]').textContent = '选集已清空，重新打开后可添加视频。';
  const preview = document.createElement('span');
  preview.className = 'range-preview'; preview.hidden = true; preview.setAttribute('aria-hidden', 'true');
  get('[data-range-control=time]').append(preview);
  const abort = new AbortController();
  const controlTooltips = createControlTooltips(screen, abort.signal);
  let mediaAbort = new AbortController();
  let closeAbort: AbortController | null = null;
  let closeWork: Promise<void> | null = null;
  const returnFocus = document.activeElement as HTMLElement | null;
  const unsubscribes: Array<() => void> = [];
  let disposed = false, closed = false, buffering = false;
  let layout = initialLayout, view = initialView;
  let revision = 0, lastError: unknown = null;
  let appliedTokens: string[] = [];
  let queueKey = '', poster = '';
  const playbackFeedback = createPlaybackFeedback(shadow, renderPlayIcon);
  const captionClearance = createCaptionClearance(screen, get('[data-controls]'), () => player.element);
  let scrubbing: HTMLInputElement | null = null;
  let hideTimer: ReturnType<typeof setTimeout> | null = null;
  let noticeTimer: ReturnType<typeof setTimeout> | null = null;
  let resize: ResizeObserver | null = null;
  const surfacePort = isMpv ? player.surfacePort : null;
  const surfaceSlot = isMpv ? shadow.querySelector<HTMLElement>('[data-surface-slot="media"]') : null;
  let surfaceLifecycleStarted = false;
  let surfaceCreated = false;
  let surfaceFullscreen = false;
  let sleepSettings: ReturnType<typeof mountSleepTimerSettings> | null = null;
  let restorePipState: (() => void) | null = null;
  let stageScroll: { node: HTMLElement; overflow: string } | null = null;
  let streamView: StreamView | null = null;
  const sourceFeatures = createVideoSourceFeatures(player, videoTracks);
  let warming: ReturnType<typeof mountQueuePrefetch> | null = null;
  function assertLive() { if (disposed) throw new Error('Video UI has been destroyed'); }
  function text(selector: string, value: string) { for (const node of shadow.querySelectorAll(selector)) if (node.textContent !== value) node.textContent = value; }
  function actionControls(action: string) { return all<HTMLButtonElement>(`[data-action=${action}],[data-player-action=${action}]`); }
  function report(error: unknown) {
    if (disposed || (error as Error)?.name === 'AbortError') return;
    playbackFeedback.clear();
    if (lastError !== error) { lastError = error; onError?.(error); }
    render();
  }
  async function perform(action: () => unknown | Promise<unknown>) {
    const current = ++revision; lastError = null;
    try { await action(); } catch (error) { if (current === revision) report(error); }
    render();
  }
  function popupOpen() {
    return Boolean(shadow.querySelector('[data-popup-surface]:not([hidden]), dialog[open]:not([data-stage-dialog])')
      || (presentation.dataset.inlinePlaylist !== 'true' && shadow.querySelector('[data-episodes]:not([hidden]).stream-playlist')));
  }
  function showControls() {
    if (hideTimer) clearTimeout(hideTimer); hideTimer = null;
    presentation.dataset.controlsHidden = 'false';
    captionClearance.schedule();
    if (!player.paused && !closed) hideTimer = setTimeout(() => {
      hideTimer = null;
      const keyboardFocus = shadow.querySelector('[data-controls] :focus-visible, .screen-heading :focus-visible, .center :focus-visible');
      const hovered = shadow.querySelector('[data-controls]:hover, .screen-actions:hover, .center-actions:hover');
      if (!disposed && !player.paused && !scrubbing && !keyboardFocus && !hovered && !popupOpen()) {
        presentation.dataset.controlsHidden = 'true';
        controlTooltips.hide();
        captionClearance.schedule();
      }
    }, 3000);
  }
  function applyLayout() {
    if (disposed) return;
    // 舞台内边距随布局变化；使用舞台本身的宽度，避免断点附近来回切换。
    const width = stageDialog?.open ? stageDialog.getBoundingClientRect().width
      : ownsFullscreen() ? fullscreenTarget().getBoundingClientRect().width : element.getBoundingClientRect().width;
    const viewportHeight = window.visualViewport?.height ?? window.innerHeight;
    const touchWidth = width < 840 || (width < 1200 && viewportHeight <= 540);
    presentation.dataset.layout = layout === 'auto' ? (touchWidth ? 'mobile' : 'desktop') : layout;
    const screenWidth = screen.getBoundingClientRect().width;
    presentation.dataset.compact = String(screenWidth > 0 && screenWidth <= 640);
    presentation.dataset.inlinePlaylist = String(compactLayout() && viewportHeight > width && !ownsFullscreen());
    presentation.dataset.immersive = String(compactLayout() && (viewportHeight <= width || ownsFullscreen()));
    streamView?.setControls(controls, compactLayout(), presentation.dataset.inlinePlaylist === 'true');
    presentation.dataset.view = view;
    for (const wideBtn of actionControls('wide')) {
      wideBtn.setAttribute('aria-pressed', String(view === 'wide'));
      const label = `${view === 'wide' ? '退出' : ''}${variant === 'mediadock' ? '影院模式' : '宽屏模式'}`;
      wideBtn.setAttribute('aria-label', label);
      const textLabel = wideBtn.querySelector('[data-player-label]'); if (textLabel) textLabel.textContent = label;
    }
    showControls();
    render();
  }
  function compactLayout() { return presentation.dataset.layout === 'mobile' || presentation.dataset.compact === 'true'; }
  function surfaceGeometry() {
    if (!surfaceSlot) throw new Error('The stream surface slot is missing');
    const rect = surfaceSlot.getBoundingClientRect();
    const dpr = document.defaultView?.devicePixelRatio ?? 1;
    return {
      rect: {
        x: Math.max(0, rect.left), y: Math.max(0, rect.top),
        width: Math.max(1, rect.width), height: Math.max(1, rect.height),
      },
      devicePixelRatio: Number.isFinite(dpr) && dpr > 0 ? dpr : 1,
    };
  }
  async function ensureSurface(): Promise<void> {
    if (!surfacePort || surfaceCreated) return;
    surfaceLifecycleStarted = true;
    await surfacePort.create(surfaceGeometry());
    surfaceCreated = true;
    await surfacePort.show();
  }
  async function resizeSurface(): Promise<void> {
    if (!surfacePort || !surfaceCreated) return;
    await surfacePort.resize(surfaceGeometry());
  }
  function setTheme(next: VideoPlayerTheme) {
    assertLive();
    choice(next, ['auto', 'light', 'dark'], 'theme');
    element.dataset.theme = next;
    streamView?.applyTheme(next);
    element.dispatchEvent(new CustomEvent('player:theme', { bubbles: true, composed: true, detail: next }));
  }
  function setTokens(next: VideoPlayerTokens) {
    assertLive();
    for (const [key, value] of Object.entries(next)) if (!(tokenNames as readonly string[]).includes(key) || typeof value !== 'string') throw new TypeError(`Unknown or invalid video token: ${key}`);
    for (const key of appliedTokens) element.style.removeProperty(`--studio-video-${key}`);
    appliedTokens = Object.keys(next);
    for (const [key, value] of Object.entries(next)) element.style.setProperty(`--studio-video-${key}`, value);
  }
  function setView(next: VideoPlayerView) {
    assertLive(); choice(next, ['standard', 'wide'], 'view');
    view = next; presentation.dataset.view = view; applyLayout();
  }
  function dismiss() {
    streamView?.dismiss();
  }
  function setControls(next: VideoControlsOptions) {
    assertLive(); const resolved = resolveVideoControls(next, controlsPreset);
    controls = resolved; streamView?.setControls(controls, compactLayout(), presentation.dataset.inlinePlaylist === 'true'); showControls(); render();
  }
  function syncStage() {
    if (!stageDialog || !element.isConnected) return;
    if (closed && stageDialog.open) { stageDialog.close(); unlockStageScroll(); }
    else if (!closed && !stageDialog.open) {
      const scrolling = document.scrollingElement as HTMLElement | null;
      if (scrolling && !stageScroll) { stageScroll = { node: scrolling, overflow: scrolling.style.overflow }; scrolling.style.overflow = 'hidden'; }
      stageDialog.showModal(); screen.focus({ preventScroll: true }); applyLayout();
    }
  }
  function unlockStageScroll() { if (stageScroll) { stageScroll.node.style.overflow = stageScroll.overflow; stageScroll = null; } }
  function fullscreenTarget(): HTMLElement {
    return shadow.querySelector<HTMLElement>('media-container') ?? presentation;
  }
  function fullscreenElement(): Element | null {
    const root = shadow as ShadowRoot & { fullscreenElement?: Element | null };
    return root.fullscreenElement ?? document.fullscreenElement ?? null;
  }
  function ownsFullscreen(): boolean {
    const current = fullscreenElement();
    return Boolean(current && (current === element || shadow.contains(current)));
  }
  function pictureMedia(): PictureMedia | null {
    return player.element as unknown as PictureMedia | null;
  }
  function nativeVideo(): PictureMedia | null {
    const media = player.element as (HTMLElement & { target?: PictureMedia }) | null;
    return (media?.target ?? media) as PictureMedia | null;
  }
  function pictureInPictureElement(): Element | null {
    const media = pictureMedia();
    if (!media) return null;
    const root = media.getRootNode() as (Document | ShadowRoot) & { pictureInPictureElement?: Element | null };
    return root.pictureInPictureElement ?? document.pictureInPictureElement ?? null;
  }
  async function toggleFullscreen(): Promise<void> {
    if (isMpv && surfacePort) {
      surfaceFullscreen = !surfaceFullscreen;
      await surfacePort.requestFullscreen(surfaceFullscreen);
      renderCapabilities();
      return;
    }
    const target = fullscreenTarget();
    const current = fullscreenElement();
    try {
      if (nativeVideo()?.webkitDisplayingFullscreen) nativeVideo()?.webkitExitFullscreen?.();
      else if (current && ownsFullscreen()) await document.exitFullscreen?.();
      else if (!current && document.fullscreenEnabled !== false && typeof target.requestFullscreen === 'function') await target.requestFullscreen();
      else if (typeof nativeVideo()?.webkitEnterFullscreen === 'function') nativeVideo()!.webkitEnterFullscreen!();
      else announce('当前环境不支持全屏，可横屏观看。');
    } catch { announce('暂时无法切换全屏，请重试或使用浏览器的全屏功能。'); }
  }
  function announce(message: string) {
    if (noticeTimer) clearTimeout(noticeTimer);
    const notice = get('[data-action-notice]'); notice.textContent = message; notice.hidden = false;
    noticeTimer = setTimeout(() => { notice.hidden = true; noticeTimer = null; }, 5000);
  }
  async function togglePictureInPicture(): Promise<void> {
    const media = pictureMedia();
    const native = nativeVideo();
    if (native?.webkitSupportsPresentationMode?.('picture-in-picture') && typeof media?.requestPictureInPicture !== 'function') {
      try { native.webkitSetPresentationMode?.(native.webkitPresentationMode === 'picture-in-picture' ? 'inline' : 'picture-in-picture'); }
      catch { announce('暂时无法打开画中画，当前播放会继续。'); }
      return;
    }
    if (!media || typeof media.requestPictureInPicture !== 'function') { announce('当前环境不支持画中画。'); return; }
    if (pictureInPictureElement() !== media && !pictureReady()) return;
    try {
      if (pictureInPictureElement() === media) {
        if (typeof media.exitPictureInPicture === 'function') await media.exitPictureInPicture();
        else await document.exitPictureInPicture?.();
      } else await media.requestPictureInPicture();
    } catch { announce('暂时无法打开画中画，当前播放会继续。'); }
  }
  function pictureReady(): boolean {
    const media = pictureMedia();
    return Boolean(media && !media.disablePictureInPicture && media.readyState > 0 && media.videoWidth > 0 && player.currentPlan && !player.failed && player.state !== 'stopped');
  }
  function renderQueue() {
    const snapshot = queue.snapshot;
    const key = JSON.stringify(snapshot.items);
    if (key !== queueKey) {
      queueKey = key;
      get('[data-episode-list]').replaceChildren(...snapshot.items.map((item, index) => {
        const data = metadata(item); const row = document.createElement('li');
        const button = document.createElement('button'); button.type = 'button'; button.className = 'episode-row'; button.dataset.itemId = item.id;
        button.setAttribute('aria-current', String(item.id === snapshot.current?.id));
        const thumb = document.createElement('span'); thumb.className = 'episode-thumb';
        if (data.poster) { const image = document.createElement('img'); image.src = data.poster; image.alt = ''; image.loading = 'lazy'; image.addEventListener('error', () => image.remove(), { once: true }); thumb.append(image); }
        const number = document.createElement('b');
        number.textContent = String(index + 1).padStart(2, '0');
        thumb.append(number);
        const copy = document.createElement('span'); copy.className = 'episode-copy';
        const title = document.createElement('strong'); title.textContent = data.title;
        const detail = document.createElement('small');
        detail.textContent = `${item.id === snapshot.current?.id ? '当前选择 · ' : ''}${data.duration ? time(data.duration) : '点击观看'}`;
        copy.append(title, detail); button.append(thumb, copy); row.append(button); return row;
      }));
    }
    // Preserve row nodes on selection so focus and selection transitions survive.
    all<HTMLButtonElement>('[data-item-id]').forEach((button, index) => {
      const item = snapshot.items[index];
      if (!item) return;
      const current = item.id === snapshot.current?.id;
      button.setAttribute('aria-current', String(current));
      const data = metadata(item);
      const detail = button.querySelector('small');
      if (detail) detail.textContent = `${current ? '当前选择 · ' : ''}${data.duration ? time(data.duration) : '点击观看'}`;
    });
    text('[data-count]', `${snapshot.items.length} 集`);
    const emptyNotice = shadow.querySelector<HTMLElement>('[data-list-empty]');
    if (emptyNotice) emptyNotice.hidden = snapshot.items.length > 0;
    const autoInput = shadow.querySelector<HTMLInputElement>('[data-setting=autoplay]');
    if (autoInput) autoInput.checked = snapshot.autoAdvance;
    text('[data-autoplay-note]', snapshot.autoAdvance ? '已开启连播，睡眠设置仍优先执行。' : '默认播完当前集后停下。');
  }
  function selectOptions(name: 'subtitle' | 'audio' | 'quality', entries: readonly VideoTrackOption[], value: string, available: boolean, reason: string | null, extra?: [string, string]) {
    const hint = shadow.querySelector<HTMLElement>(`[data-reason=${name}]`);
    if (hint) { hint.hidden = !reason; hint.textContent = reason; }
    streamView?.renderOptions(name, entries, value, extra, available, reason);
  }
  function renderTracks() {
    if (disposed) return;
    const state = videoTracks.snapshot;
    selectOptions('subtitle', state.subtitles, state.subtitle, state.subtitleAvailable, state.subtitleReason, ['off', '关闭字幕']);
    selectOptions('audio', state.audio, state.audioTrack ?? '', state.audioAvailable, state.audioReason);
    selectOptions('quality', state.qualities, state.quality, state.qualityAvailable, state.qualityReason, ['auto', '自动 · 推荐']);
    const captionsButton = shadow.querySelector<HTMLElement>('[data-action=captions]');
    if (captionsButton) {
      captionsButton.setAttribute('aria-pressed', String(state.subtitle !== 'off'));
    }
    renderInfo();
  }
  function renderInfo() {
    const state = videoTracks.snapshot;
    const media = player.element as (HTMLVideoElement & { videoWidth?: number; videoHeight?: number }) | null;
    const mediaWidth = positiveNumber(media?.videoWidth);
    const mediaHeight = positiveNumber(media?.videoHeight);
    const reportedQuality = state.qualities.find(option => option.active);
    const matchingQualities = state.qualities.filter(option => option.width === mediaWidth && option.height === mediaHeight);
    // A requested HLS rendition may already be active while buffered frames still have the old size.
    const activeQuality = mediaWidth && mediaHeight
      ? matchingQualities.find(option => option.active) ?? (matchingQualities.length === 1 ? matchingQualities[0] : undefined)
      : reportedQuality;
    const width = mediaWidth ?? activeQuality?.width;
    const height = mediaHeight ?? activeQuality?.height;
    const resolution = formatResolution(width, height);
    if (width && height) presentation.style.setProperty('--media-ratio', String(width / height));
    const quality = activeQuality?.label ?? (resolution === '未知' ? '未知' : `${height}p${state.qualities.length ? '' : '（固定画质）'}`);
    const qualities = state.qualities.length
      ? state.qualities.map(option => option.label).join(' / ')
      : '固定画质（无可切换档位）';
    const audio = state.audio.length
      ? state.audio.find(option => option.id === state.audioTrack)?.label ?? state.audio[0].label
      : '无音轨信息';
    const subtitle = state.subtitle === 'off'
      ? '关闭'
      : state.subtitles.find(option => option.id === state.subtitle)?.label ?? state.subtitle;
    const transport = player.currentPlan?.transport;
    const mimeType = player.currentPlan?.mimeType;
    text('[data-quality-info]', quality);
    text('[data-resolution-info]', resolution);
    text('[data-bitrate-info]', formatBitrate(activeQuality?.bitrate));
    text('[data-qualities-info]', qualities);
    text('[data-audio-info]', audio);
    text('[data-subtitle-info]', subtitle);
    text('[data-mime-info]', mimeType ?? '未知');
    text('[data-transport-info]', transport === 'hls' ? 'HLS 自适应流' : transport === 'range' ? 'HTTP Range 单文件流' : transport ?? '未知');
    text('[data-strategy-info]', formatStrategy(player.currentPlan?.strategy));
  }
  function updateRange(name: 'time' | 'volume', value: number, max: number, disabled: boolean, valueText: string): void {
    const input = shadow.querySelector<HTMLInputElement>(`input[data-range=${name}]`);
    if (!input) return;
    const safeMax = Number.isFinite(max) && max > 0 ? max : 0;
    const safeValue = safeMax > 0 && Number.isFinite(value) ? Math.min(safeMax, Math.max(0, value)) : 0;
    input.max = String(safeMax);
    input.value = String(safeValue);
    input.disabled = disabled;
    input.setAttribute('aria-valuenow', String(safeValue));
    input.setAttribute('aria-valuetext', valueText);
    const range = input.closest<HTMLElement>('[data-range-control]');
    range?.style.setProperty('--range-fill', `${safeMax > 0 ? (safeValue / safeMax) * 100 : 0}%`);
    range?.toggleAttribute('data-disabled', disabled);
  }
  function updateBufferedRange(duration: number): void {
    const range = shadow.querySelector<HTMLElement>('[data-range-control=time]');
    if (!range) return;
    let bufferedEnd = 0;
    try {
      bufferedEnd = player.buffered.at(-1)?.end ?? 0;
    } catch { bufferedEnd = 0; }
    range.style.setProperty('--range-buffer', `${duration > 0 ? Math.min(100, Math.max(0, bufferedEnd / duration * 100)) : 0}%`);
  }
  function renderCapabilities() {
    if (disposed) return;
    const fullscreenButton = shadow.querySelector<HTMLElement>('[data-action=fullscreen]');
    const fullscreenAvailable = isMpv
      ? Boolean(surfacePort)
      : (document.fullscreenEnabled !== false && typeof fullscreenTarget().requestFullscreen === 'function' && typeof document.exitFullscreen === 'function') || typeof nativeVideo()?.webkitEnterFullscreen === 'function';
    if (fullscreenButton) {
      const active = isMpv ? surfaceFullscreen : ownsFullscreen() || nativeVideo()?.webkitDisplayingFullscreen === true;
      if (fullscreenButton.getAttribute('aria-pressed') !== String(active)) fullscreenButton.innerHTML = videoIcon(active ? 'fullscreenExit' : 'fullscreen');
      fullscreenButton.hidden = !fullscreenAvailable;
      fullscreenButton.setAttribute('aria-pressed', String(active));
      fullscreenButton.setAttribute('aria-label', active ? '退出全屏' : '全屏');
      fullscreenButton.title = active ? '退出全屏' : '全屏';
    }
    const pipButtons = actionControls('pip');
    const media = pictureMedia();
    const native = nativeVideo();
    const pipAvailable = Boolean(media && !media.disablePictureInPicture && ((typeof media.requestPictureInPicture === 'function' && document.pictureInPictureEnabled !== false) || native?.webkitSupportsPresentationMode?.('picture-in-picture')));
    for (const pipButton of pipButtons) {
      const active = Boolean(media && pictureInPictureElement() === media) || native?.webkitPresentationMode === 'picture-in-picture';
      pipButton.hidden = !pipAvailable;
      pipButton.disabled = !active && !pictureReady();
      pipButton.setAttribute('aria-pressed', String(active));
      pipButton.setAttribute('aria-label', active ? '退出画中画' : '画中画');
      pipButton.title = active ? '退出画中画' : '画中画';
      const label = pipButton.querySelector('[data-player-label]');
      if (label) label.textContent = active ? '退出画中画' : '画中画';
    }
    text('[data-display-capability]', [!fullscreenAvailable && '当前环境不支持全屏', !pipAvailable ? '当前视频或浏览器暂不支持画中画' : !pictureReady() && '加载视频画面后可使用画中画'].filter(Boolean).join('；'));
    for (const devVol of all('[data-device-volume]')) devVol.hidden = !compactLayout() && !deviceVolumeOnly;
    controlTooltips.refresh();
  }
  function render() {
    if (disposed) return;
    const snapshot = queue.snapshot;
    const current = snapshot.current ?? snapshot.items[0]; const data = metadata(current);
    const empty = !snapshot.items.length; const error = snapshot.error ?? lastError;
    const busy = snapshot.loading || player.state === 'loading';
    const ended = player.state === 'ended';
    const playing = !ended && !player.paused && !player.failed && player.state !== 'stopped';
    const pending = snapshot.autoplayPending || (player.playbackRequested && busy);
    const pause = playing || pending;
    const state = empty ? 'empty' : error ? 'error' : player.state;
    presentation.dataset.state = state;
    get('[data-surface]').hidden = closed; get('[data-closed]').hidden = !closed;
    get('[data-media-slot]').setAttribute('aria-hidden', String(!snapshot.loaded || closed || player.state === 'stopped'));
    syncStage();
    text('[data-title]', empty ? '片单还是空的' : data.title);
    text('[data-description]', empty ? '添加视频，开启一段观看时光。' : data.description);
    text('[data-screen-title]', empty ? '' : data.title);
    text('[data-episode-number]', `现在观看${current ? ` · ${String(Math.max(0, snapshot.items.indexOf(current)) + 1).padStart(2, '0')} / ${String(snapshot.items.length).padStart(2, '0')}` : ''}`);
    if (poster !== data.poster) { poster = data.poster; if (poster) player.element?.setAttribute('poster', poster); else player.element?.removeAttribute('poster'); }
    playbackFeedback.render(pause, playing && !busy && !buffering, Boolean(error) || empty || closed || ended);
    const playLabel = ended ? '重新播放本集' : player.state === 'stopped' ? '重新播放' : pause ? '暂停' : '播放';
    text('[data-mobile-play-label]', playLabel);
    for (const control of all<HTMLButtonElement>('[data-action=play]')) { control.disabled = empty; control.setAttribute('aria-label', playLabel); control.title = playLabel; }
    const muted = player.muted;
    for (const control of actionControls('mute')) {
      const label = muted ? '取消静音' : '静音';
      if (control.dataset.muted !== String(muted)) { const labelNode = control.querySelector('[data-player-label]'); control.innerHTML = renderMuteIcon(muted); if (labelNode) { labelNode.textContent = label; control.append(labelNode); } } control.dataset.muted = String(muted); control.setAttribute('aria-pressed', String(muted)); control.setAttribute('aria-label', label); control.title = label;
    }
    for (const control of all<HTMLButtonElement>('[data-action=info],[data-popup-target=info]')) control.disabled = empty;
    for (const action of ['previous', 'next', 'next-end', 'backward', 'forward', 'stop']) {
      for (const control of actionControls(action)) control.disabled = action === 'next' || action === 'next-end'
        ? !snapshot.canNext : action === 'previous' ? !snapshot.canPrevious : !snapshot.loaded || player.failed;
    }
    for (const control of all<HTMLInputElement | HTMLButtonElement>('[data-rate-option],[data-popup-panel=rate] [data-popup-value],[data-rate-range]')) control.disabled = player.failed;
    for (const input of all<HTMLInputElement>('[data-settings-volume]')) {
      input.value = String(player.volume); input.disabled = player.failed || deviceVolumeOnly;
      input.setAttribute('aria-valuetext', `${Math.round(player.volume * 100)}%`);
    }
    text('[data-settings-volume-label]', `${Math.round(player.volume * 100)}%`);
    const quick = selectedSleepQuick(sleepTimer);
    for (const control of all<HTMLButtonElement>('[data-quick-sleep]')) {
      control.setAttribute('aria-pressed', String(control.dataset.quickSleep === quick));
      control.disabled = !sleepTimer || (control.dataset.quickSleep === 'end' && (!snapshot.loaded || player.failed));
    }
    text('[data-current-time]', ended && Number.isFinite(player.duration) ? time(player.duration) : time(snapshot.loaded ? player.currentTime : 0));
    text('[data-duration]', player.duration === Infinity ? '直播' : time(snapshot.loaded ? player.duration : data.duration ?? 0));
    const duration = Number.isFinite(player.duration) && player.duration > 0 ? player.duration : 0;
    const currentTime = scrubbing ? scrubbing.valueAsNumber : snapshot.loaded ? player.currentTime : 0;
    updateRange('time', currentTime, duration, !snapshot.loaded || player.failed || player.state === 'stopped' || duration <= 0, `${time(currentTime)} / ${duration ? time(duration) : '0:00'}`);
    if (scrubbing) text('[data-current-time]', time(currentTime));
    updateBufferedRange(duration);
    updateRange('volume', player.volume, 1, player.failed || deviceVolumeOnly, deviceVolumeOnly ? '请使用设备音量键' : `${Math.round(player.volume * 100)}%`);
    renderCapabilities();
    const stopped = player.state === 'stopped';
    const rejected = (error as Error)?.name === 'NotAllowedError';
    text('[data-overlay-kicker]', empty ? '你的观看空间' : stopped ? '稍作停留' : error ? '暂时无法播放' : '随时开始');
    text('[data-overlay-title]', empty ? '片单还是空的' : stopped ? '已停止播放' : rejected ? '点击后继续播放' : error ? '视频加载遇到问题' : player.state === 'ended' ? '本集播放完毕' : data.title);
    text('[data-overlay-description]', stopped ? '选集已保留，可以重新播放。' : error ? rejected ? '浏览器需要一次播放操作。' : '重试，或选择其他视频。' : '');
    const center = get('[data-center]');
    const centerHidden = (busy && !error) || playing || ended || (presentation.dataset.inlinePlaylist === 'true' && !error && !empty && player.state !== 'stopped');
    if (centerHidden && center.contains(shadow.activeElement)) screen.focus({ preventScroll: true });
    center.hidden = centerHidden;
    get('[data-buffering]').hidden = ended || !(busy || buffering) || Boolean(error) || closed;
    const retryBtn = shadow.querySelector<HTMLElement>('[data-action=retry]');
    if (retryBtn) retryBtn.hidden = !error || empty;
    for (const node of all('[data-action=play]')) if (node.classList.contains('center-play')) node.hidden = Boolean(error) || empty;
    const addBtn = shadow.querySelector<HTMLElement>('[data-action=add]');
    if (addBtn) addBtn.hidden = !empty || !onRequestItems;
    const status = empty ? '还没有视频' : error ? rejected ? '播放受限 · 点击重试' : '播放失败 · 可以重试' : busy ? '正在加载…' : buffering ? '正在缓冲…' : stopped ? '已停止 · 选集已保留' : player.state === 'ended' ? '播放完毕' : playing ? '正在播放' : player.state === 'paused' ? '已暂停' : player.state === 'ready' ? '准备就绪 · 点击播放' : '选择一集，开始观看';
    text('[data-status]', status);
    renderInfo();
    get('[data-error]').hidden = !error;
    text('[data-error]', error ? stopped ? '播放已停止，但进度保存未完成。' : rejected ? '浏览器限制了自动播放，请点击重试。' : '这段视频暂时无法播放，请重试或选择其他视频。' : '');
    const timer = sleepTimer?.snapshot;
    const sleepRemaining = timer?.status === 'running' ? `${timer.trigger?.type === 'duration' ? time(Math.ceil(timer.remainingMs / 1000)) : `再播完 ${timer.remainingItems} 集`}后${timer.action === 'close' ? '关闭' : timer.action === 'stop' ? '停止' : '暂停'}` : '';
    const sleepBadge = timer?.status === 'running' ? timer.trigger?.type === 'duration' ? time(Math.ceil(timer.remainingMs / 1000)) : `${timer.remainingItems}集` : '';
    text('[data-sleep-status]', sleepRemaining || '未设置');
    for (const sleepBtn of all('[data-action=sleep]')) sleepBtn.setAttribute('aria-pressed', String(timer?.status === 'running'));
    streamView?.render({ title: data.title, playbackRate: player.playbackRate, sleepRemaining, sleepBadge, sleepRunning: timer?.status === 'running', ended, canNext: snapshot.canNext });
    text('[data-sleep-status]', sleepRemaining || '未设置');
    for (const indicator of all('[data-sleep-indicator]')) {
      indicator.hidden = timer?.status !== 'running';
      indicator.textContent = sleepRemaining ? `睡眠 · ${sleepRemaining}` : '';
    }
    for (const slate of all('[data-end-slate]')) { if (!ended && slate.contains(shadow.activeElement)) screen.focus({ preventScroll: true }); slate.hidden = !ended; }
    text('[data-end-title]', data.title);
    for (const next of actionControls('next-end')) next.hidden = !snapshot.canNext;
    if (player.paused || error || busy) presentation.dataset.controlsHidden = 'false';
    controlTooltips.refresh();
    captionClearance.schedule();
  }
  function togglePlay(feedback = true) {
    if (!queue.snapshot.items.length) return;
    const isPlaying = (!player.paused && !player.failed) || queue.snapshot.autoplayPending || (player.playbackRequested && player.state === 'loading');
    if (feedback) playbackFeedback.request(isPlaying ? 'pause' : 'play');
    else playbackFeedback.clear();
    if (isPlaying) player.pause();
    else return queue.play();
  }
  function finishScrub(commit: boolean) {
    const control = scrubbing;
    if (!control) return;
    const value = control.valueAsNumber;
    preview.hidden = true;
    scrubbing = null;
    if (commit && !control.disabled && Number.isFinite(value)) void perform(() => player.seekAsync(value));
    else render();
    showControls();
  }
  function bindMedia() {
    mediaAbort.abort(); mediaAbort = new AbortController(); buffering = false;
    restorePipState?.(); restorePipState = null;
    const media = player.element;
    if (media) {
      // rc.2 的 PiP 状态只比较 document，无法识别 Shadow DOM 的标准重定向。
      // 为拥有的媒体补齐公开 isPictureInPicture 属性；入口走标准媒体 API。
      const own = Object.getOwnPropertyDescriptor(media, 'isPictureInPicture');
      if (own?.configurable !== false) {
        const original = own?.get ? () => own.get!.call(media)
          : own ? () => own.value : () => Reflect.get(Object.getPrototypeOf(media), 'isPictureInPicture', media);
        Object.defineProperty(media, 'isPictureInPicture', { configurable: true, get: () => {
          const root = media.getRootNode() as (Document | ShadowRoot) & { pictureInPictureElement?: Element | null };
          return root.pictureInPictureElement === media || original() === true;
        } });
        restorePipState = () => { if (own) Object.defineProperty(media, 'isPictureInPicture', own); else Reflect.deleteProperty(media, 'isPictureInPicture'); };
      }
    }
    for (const event of ['waiting', 'stalled']) player.element?.addEventListener(event, () => { buffering = !player.paused; render(); }, { signal: mediaAbort.signal });
    for (const event of ['playing', 'loadedmetadata', 'loadeddata', 'canplay', 'pause', 'emptied', 'enterpictureinpicture', 'leavepictureinpicture']) player.element?.addEventListener(event, () => { buffering = false; render(); }, { signal: mediaAbort.signal });
    for (const event of ['webkitbeginfullscreen', 'webkitendfullscreen', 'webkitpresentationmodechanged']) nativeVideo()?.addEventListener(event, renderCapabilities, { signal: mediaAbort.signal });
    renderCapabilities();
  }
  function exitPresentations() {
    if (nativeVideo()?.webkitDisplayingFullscreen) nativeVideo()?.webkitExitFullscreen?.();
    if (nativeVideo()?.webkitPresentationMode === 'picture-in-picture') nativeVideo()?.webkitSetPresentationMode?.('inline');
    if (isMpv && surfacePort && surfaceFullscreen) {
      surfaceFullscreen = false;
      void Promise.resolve(surfacePort.requestFullscreen(false)).catch(() => {});
    }
    if (ownsFullscreen()) void document.exitFullscreen?.().catch(() => {});
    const media = pictureMedia();
    if (pictureInPictureElement() === media) void (media?.exitPictureInPicture?.() ?? document.exitPictureInPicture?.())?.catch(() => {});
  }
  function finishClose() {
    if (disposed || closed) return;
    ++revision; scrubbing = null; closed = true; sourceFeatures.cancelPending(); dismiss();
    if (hideTimer) clearTimeout(hideTimer); hideTimer = null;
    if (surfacePort) void Promise.resolve(surfacePort.hide()).catch(reportCloseError);
    exitPresentations();
    if (clearQueueOnClose) queue.setItems([]);
    render();
    if (returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
    else get<HTMLButtonElement>('[data-action=reopen]').focus({ preventScroll: true });
    onClose?.();
  }
  function reportCloseError(error: unknown) {
    if ((error as Error)?.name === 'AbortError') return;
    onCloseError?.(error);
    element.dispatchEvent(new CustomEvent('player:closeerror', { bubbles: true, composed: true, detail: error }));
  }
  async function close() {
    assertLive();
    if (closed) return;
    closeAbort?.abort(); closeAbort = new AbortController();
    const work = player.close({ signal: closeAbort.signal });
    // 原生/外部端口尚无 closeintent 时也立即退出；持久化完成仍可通过核心 close 等待。
    finishClose(); closeWork = work;
    void work.catch(reportCloseError).finally(() => { if (closeWork === work) closeWork = null; });
  }
  function open() {
    assertLive(); closeAbort?.abort(); closeAbort = null;
    if (sleepTimer?.snapshot.actionPending && sleepTimer.snapshot.action === 'close') sleepTimer.cancel();
    closed = false; if (surfacePort) void Promise.resolve(surfacePort.show()).catch(report); render(); showControls(); screen.focus();
  }
  const onQueueChange = () => { if (!disposed) { renderQueue(); render(); } };
  const onErrorEvent = (event: Event) => report((event as CustomEvent).detail);
  function destroy() {
    if (disposed) return; disposed = true; revision++; scrubbing = null;
    if (hideTimer) clearTimeout(hideTimer); hideTimer = null;
    if (noticeTimer) clearTimeout(noticeTimer); noticeTimer = null;
    playbackFeedback.destroy();
    captionClearance.destroy();
    sourceFeatures.destroy(); warming?.destroy(); stageDialog?.close(); unlockStageScroll();
    exitPresentations(); closeAbort?.abort(); abort.abort(); mediaAbort.abort(); resize?.disconnect();
    for (const unsubscribe of unsubscribes) unsubscribe();
    queue.removeEventListener('change', onQueueChange); queue.removeEventListener('error', onErrorEvent);
    videoTracks.removeEventListener('change', renderTracks); sleepTimer?.removeEventListener('change', render);
    mediaSession?.removeEventListener('error', onErrorEvent);
    sleepSettings?.destroy(); dismiss(); preset.features.destroy(); if (ownsPlayer) player.destroy(); restorePipState?.(); restorePipState = null;
    if (surfacePort && surfaceLifecycleStarted) void Promise.resolve(surfacePort.destroy()).catch(report);
    element.remove();
  }

  streamView = createStreamView({ shadow, player, videoTracks, sleepTimer, perform, setTheme, showControls, setControls, importSubtitle: sourceFeatures.importSubtitle, outputHeights });
  streamView.setControls(controls, false);

  try {
    if (!sharedQueue) queue.setItems(items); setTokens(tokens);
    root.append(element);
    if (prefetch) warming = mountQueuePrefetch(player, queue, prefetch);
    if (isMpv) {
      await ensureSurface();
    } else {
      const media: HTMLElement = createMediaElement?.(document) ?? document.createElement('hlsjs-video') as unknown as HTMLElement;
      media.setAttribute('playsinline', ''); media.setAttribute('preload', 'metadata');
      get('[data-media-slot]').append(media); player.attach(media);
    }
    if (sleepTimer) sleepSettings = mountSleepTimerSettings(get('[data-sleep-settings]'), sleepTimer, { showLegend: false });
    else {
      for (const sleepButton of actionControls('sleep')) sleepButton.hidden = true;
    }
    for (const action of actions) {
      for (const mount of all('[data-host-actions]')) {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = action.label;
        button.addEventListener('click', () => void perform(() => action.run({ player, queue, current: queue.snapshot.current })), { signal: abort.signal });
        mount.append(button);
      }
    }
    streamView?.bind(abort.signal);
    stageDialog?.addEventListener('cancel', event => { event.preventDefault(); if (popupOpen()) dismiss(); else void perform(close); }, { signal: abort.signal });
    shadow.addEventListener('click', event => {
      const clickTarget = event.target as Element;

      const target = clickTarget.closest<HTMLElement>('[data-action],[data-player-action],[data-item-id],[data-quick-sleep]');
      if (!target || (target as HTMLButtonElement).disabled) return;
      if (target.dataset.itemId) {
        const id = target.dataset.itemId;
        // Stream 的播放器内列表不是浮层核的一部分，先让它按自身规则归还焦点，再统一关闭其它表面。
        streamView?.handleAction('dismiss-episodes');
        dismiss();
        void perform(() => queue.selectId(id));
        return;
      }
      if (target.dataset.quickSleep) {
        if (sleepTimer) { const value = target.dataset.quickSleep; dismiss(); void perform(() => applySleepQuick(sleepTimer, value)); }
        return;
      }
      const action = target.dataset.action ?? target.dataset.playerAction;
      if (target.dataset.playerAction && action !== 'mute') dismiss();

      showControls();
      if (streamView?.handleAction(action)) return;

      if (action === 'wide') { setView(view === 'wide' ? 'standard' : 'wide'); return; }
      if (action === 'reopen') { open(); return; }
      void perform(() => {
        if (action === 'play') return togglePlay(false);
        if (action === 'replay') return player.seekAsync(0).then(() => player.play());
        if (action === 'previous') return queue.previous();
        if (action === 'next' || action === 'next-end') return queue.next();
        if (action === 'backward' || action === 'forward') return player.seekAsync(player.currentTime + (action === 'backward' ? -10 : 10));
        if (action === 'mute') return player.setMuted(!player.muted);
        if (action === 'fullscreen') return toggleFullscreen();
        if (action === 'pip') return togglePictureInPicture();
        if (action === 'retry') return player.state === 'stopped' ? queue.play() : queue.retry();
        if (action === 'stop') { dismiss(); return player.stop(); }
        if (action === 'close') return close();
        if (action === 'add') return onRequestItems?.();
      });
      showControls();
    }, { signal: abort.signal });
    shadow.addEventListener('change', event => {
      const control = event.target as HTMLInputElement;
      if (control.dataset.range === 'time') {
        if (scrubbing) finishScrub(true);
        else if (!control.disabled && Number.isFinite(control.valueAsNumber)) void perform(() => player.seekAsync(control.valueAsNumber));
        return;
      }
      if (control.dataset.setting !== 'autoplay') return;
      void perform(() => queue.setAutoAdvance(control.checked));
    }, { signal: abort.signal });
    shadow.addEventListener('input', event => {
      const control = event.target as HTMLInputElement;
      if (control.dataset.range === 'time') {
        updateRange('time', control.valueAsNumber, Number(control.max), control.disabled, `${time(control.valueAsNumber)} / ${time(Number(control.max))}`);
        text('[data-current-time]', time(control.valueAsNumber));
        showControls();
        return;
      }
      if (control.dataset.range === 'volume' || control.hasAttribute('data-settings-volume')) void perform(() => player.setVolume(control.valueAsNumber));
    }, { signal: abort.signal });
    shadow.addEventListener('pointerdown', event => {
      const control = (event.target as Element).closest<HTMLInputElement>('input[data-range=time]');
      if (control && !control.disabled) { scrubbing = control; showControls(); }
    }, { signal: abort.signal });
    document.addEventListener('pointerup', () => {
      // Native range change fires at release; finish in a microtask if the host did not emit it.
      queueMicrotask(() => { if (!disposed && scrubbing) finishScrub(true); });
    }, { signal: abort.signal });
    document.addEventListener('pointercancel', () => finishScrub(false), { signal: abort.signal });
    document.defaultView?.addEventListener('blur', () => finishScrub(false), { signal: abort.signal });
    const timeline = get('[data-range-control=time]');
    timeline.addEventListener('pointermove', event => {
      const range = get<HTMLInputElement>('input[data-range=time]');
      if (range.disabled) return;
      const rect = get('[data-range-control=time] .range-track').getBoundingClientRect();
      const fraction = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
      preview.style.setProperty('--preview-position', `${6 + fraction * rect.width}px`);
      preview.textContent = time(fraction * Number(range.max));
      preview.hidden = false;
    }, { signal: abort.signal });
    timeline.addEventListener('pointerleave', () => { if (!scrubbing) preview.hidden = true; }, { signal: abort.signal });
    screen.addEventListener('pointermove', event => { if (event.pointerType !== 'touch') showControls(); }, { signal: abort.signal });
    for (const region of all<HTMLElement>('[data-controls], .screen-actions, .center-actions')) {
      region.addEventListener('pointerleave', showControls, { signal: abort.signal });
    }
    screen.addEventListener('click', event => {
      if ((event.target as Element).closest('button,input,select,a,[data-controls],.screen-heading,[data-popup-surface],[data-end-slate]')) return;
      if (popupOpen()) return;
      if ((event as PointerEvent).pointerType === 'touch') {
        if (presentation.dataset.controlsHidden === 'true') showControls();
        else if (!player.paused && !scrubbing) { presentation.dataset.controlsHidden = 'true'; captionClearance.schedule(); }
      }
      else void perform(togglePlay);
    }, { signal: abort.signal });
    shadow.addEventListener('focusout', showControls, { signal: abort.signal });
    shadow.addEventListener('focusin', showControls, { signal: abort.signal });
    shadow.addEventListener('keydown', event => {
      const key = event as KeyboardEvent;
      if (closed || key.defaultPrevented || key.altKey || key.ctrlKey || key.metaKey) return;
      const target = event.composedPath()[0] as HTMLElement;
      if (target.closest('input,select,textarea,[role=slider],[contenteditable]:not([contenteditable=false])') || popupOpen()) return;
      const lower = key.key.toLowerCase();
      if (target.closest('button,a') && lower === ' ') return;
      if (![' ', 'k', 'j', 'l', 'arrowleft', 'arrowright', 'arrowup', 'arrowdown', 'm', 'f', 't', 'i', 'c', 'n'].includes(lower)) return;
      if (lower === 'n' && !key.shiftKey) return;
      if (key.repeat && !['arrowleft', 'arrowright', 'arrowup', 'arrowdown'].includes(lower)) { key.preventDefault(); return; }
      key.preventDefault(); showControls();
      void perform(() => {
        if (lower === ' ' || lower === 'k') return togglePlay();
        if (['arrowleft', 'arrowright', 'j', 'l'].includes(lower)) {
          if (get<HTMLInputElement>('[data-range=time]').disabled) return;
          return player.seekAsync(player.currentTime + ({ arrowleft: -5, arrowright: 5, j: -10, l: 10 }[lower] ?? 0));
        }
        if (lower === 'arrowup' || lower === 'arrowdown') return player.setVolume(player.volume + (lower === 'arrowup' ? .05 : -.05));
        if (lower === 'm') return player.setMuted(!player.muted);
        if (lower === 'f') return toggleFullscreen();
        if (lower === 't') return setView(view === 'wide' ? 'standard' : 'wide');
        if (lower === 'i') return togglePictureInPicture();
        if (lower === 'n' && queue.snapshot.canNext) return queue.next();
        if (lower === 'c' && (videoTracks.snapshot.subtitleAvailable || player.currentPlan)) streamView?.handleAction('captions');
      });
    }, { signal: abort.signal });
    queue.addEventListener('change', onQueueChange); queue.addEventListener('error', onErrorEvent);
    videoTracks.addEventListener('change', renderTracks); sleepTimer?.addEventListener('change', render); mediaSession?.addEventListener('error', onErrorEvent);
    sleepTimer?.addEventListener('error', event => {
      if (sleepTimer.snapshot.action === 'close') reportCloseError((event as CustomEvent).detail);
    }, { signal: abort.signal });
    for (const event of ['statechange', 'timeupdate', 'durationchange', 'pause', 'ended', 'ratechange', 'volumechange', 'seeked'] as const) unsubscribes.push(player.on(event, render));
    unsubscribes.push(player.on('sourcechange', () => { scrubbing = null; render(); renderTracks(); }));
    unsubscribes.push(player.on('mediachange', bindMedia));
    unsubscribes.push(player.on('loadstart', () => { playbackFeedback.clear(); scrubbing = null; lastError = null; buffering = false; closed = false; render(); showControls(); }));
    unsubscribes.push(player.on('playing', () => { if (!closed && !player.paused && player.state === 'playing' && player.currentResourceId) mediaSession?.activate(); render(); showControls(); }));
    unsubscribes.push(player.on('playerror', report));
    unsubscribes.push(player.on('closeintent', finishClose));
    unsubscribes.push(player.on('closerequest', finishClose));
    unsubscribes.push(player.on('destroy', destroy));
    bindMedia();
    const Resize = document.defaultView?.ResizeObserver;
    if (Resize) {
      resize = new Resize(() => { applyLayout(); void resizeSurface().catch(report); });
      resize.observe(element);
      resize.observe(screen);
      if (surfaceSlot) resize.observe(surfaceSlot);
    }
    else document.defaultView?.addEventListener('resize', applyLayout, { signal: abort.signal });
    const onFullscreenChange = () => {
      const isFs = isMpv ? surfaceFullscreen : ownsFullscreen();
      element.dataset.fullscreen = String(isFs);
      presentation.dataset.fullscreen = String(isFs);
      dismiss(); applyLayout(); renderCapabilities();
    };
    document.addEventListener('fullscreenchange', onFullscreenChange, { signal: abort.signal });
    onFullscreenChange();
    setTheme(theme); applyLayout(); renderQueue(); renderTracks(); renderCapabilities(); render();
    return {
      element, player, queue, videoTracks, sleepTimer, mediaSession, mainMedia,
      get isClosed() { return closed; }, get isDestroyed() { return disposed; },
      get controls() { return controls; }, setControls, importSubtitle: sourceFeatures.importSubtitle,
      setTheme, setTokens, setView, setLayout(next) { assertLive(); choice(next, ['auto', 'desktop', 'mobile'], 'layout'); layout = next; applyLayout(); },
      async setItems(next) { assertLive(); validateItems(next); return queue.replaceItems(next); }, open, close, destroy,
      handleBack() {
        assertLive(); if (closed) return false;
        if (streamView?.back()) return true;
        if (ownsFullscreen() || nativeVideo()?.webkitDisplayingFullscreen) { void toggleFullscreen(); return true; }
        void perform(close); return true;
      },
    };
  } catch (error) { destroy(); throw error; }
}
