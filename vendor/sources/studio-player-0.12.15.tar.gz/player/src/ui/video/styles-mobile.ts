/** Selected mobile design: adjacent timeline, icon transport and inline portrait episodes. */
export const mobileVideoStyles = `
.bar-seek,.mobile-context,[data-rate-display]{display:none}
.touch-seek-copy{position:absolute;inset:0;display:grid;place-items:center;font-size:9px;font-weight:650;pointer-events:none}
.root .bar-seek{position:relative}
.root .bar-seek svg,.root .touch-seek svg{width:24px;height:24px}
.root .stream-playlist-header{position:sticky;top:0;background:inherit;z-index:1}
.root .studio-overlay-header{position:sticky;top:0;z-index:2;background:var(--studio-overlay-background,#181818)}
.root .studio-overlay-panel{overscroll-behavior:contain;overflow-x:hidden}
.root .studio-overlay :is(input:not([type=range]),select){font-size:16px}
.root .control-presets{flex-wrap:wrap}
.root .control-placement-panel label{flex-wrap:wrap;gap:8px}
.root .control-placement-panel select{max-width:100%}
.root:is([data-layout=mobile],[data-compact=true]){--picture-height:min(calc(100cqw / var(--media-ratio,1.777778)),max(80px,calc(100dvh - var(--mobile-header) - 320px)),45dvh);--mobile-header:calc(56px + env(safe-area-inset-top));color-scheme:dark}
.root:is([data-layout=mobile],[data-compact=true]) .stream-btn{width:48px;height:48px;min-width:48px;padding:12px;border-radius:50%;background:none;border:0}
.root:is([data-layout=mobile],[data-compact=true]) .stream-btn svg{width:24px;height:24px}
.root:is([data-layout=mobile],[data-compact=true]) button:active:enabled{background-color:#ffffff20}
.root:is([data-layout=mobile],[data-compact=true]) .screen-heading{height:var(--mobile-header);min-height:0;align-items:center;padding:env(safe-area-inset-top) max(12px,env(safe-area-inset-right)) 0 max(16px,env(safe-area-inset-left));gap:8px;font-size:15px}
.root:is([data-layout=mobile],[data-compact=true]) .screen-title>span{display:block;font-size:15px;line-height:1.5;font-weight:550;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.root:is([data-layout=mobile],[data-compact=true]) .screen-title small,.root:is([data-layout=mobile],[data-compact=true]) .dock-sleep-badge{display:none}
.root:is([data-layout=mobile],[data-compact=true]) .screen-actions{gap:0}
.root:is([data-layout=mobile],[data-compact=true]) .controls :is(.volume,[data-action=wide],[data-action=pip],[data-action=previous],[data-action=next]){display:none}
.root:is([data-layout=mobile],[data-compact=true]) .controls [data-action=rate] svg{display:none}
.root:is([data-layout=mobile],[data-compact=true]) [data-rate-display]{display:inline;font-size:13px;font-variant-numeric:tabular-nums}
.root:is([data-layout=mobile],[data-compact=true]) .controls .range-thumb{opacity:1;background:var(--timeline);width:10px;height:10px}
.root:is([data-layout=mobile],[data-compact=true]) .controls .range-fill{background:var(--timeline)}
.root:is([data-layout=mobile],[data-compact=true]) .controls .range-control,.root:is([data-layout=mobile],[data-compact=true]) .range-input{height:48px}
.root:is([data-layout=mobile],[data-compact=true]) .controls .time{font-size:12px;font-variant-numeric:tabular-nums;color:#eee;white-space:nowrap;padding:0 6px}
.root:is([data-layout=mobile],[data-compact=true]) .center{padding:var(--mobile-header) 12px 96px;gap:12px}
.root:is([data-layout=mobile],[data-compact=true]) .center-play{width:64px;height:64px;background:#15151580;border:1px solid #ffffff50;border-radius:50%}
.root:is([data-layout=mobile],[data-compact=true]) .center-play svg{width:32px;height:32px}
.root:is([data-layout=mobile],[data-compact=true]) .touch-seek{display:inline-flex;position:relative;width:48px;height:48px;background:none;border:0;border-radius:50%}
.root:is([data-layout=mobile],[data-compact=true]) .studio-overlay{border-radius:18px;border:1px solid #ffffff26}
.root:is([data-layout=mobile],[data-compact=true]) .studio-overlay-panel{padding-bottom:max(12px,env(safe-area-inset-bottom));min-width:0!important;width:100%}
.root:is([data-layout=mobile],[data-compact=true]) .studio-overlay-header{font-size:16px;padding-inline:8px;min-height:56px}
.root:is([data-layout=mobile],[data-compact=true]) .studio-overlay [data-popup-item]{min-height:52px;font-size:max(15px,.9375rem);line-height:1.5}
.root:is([data-layout=mobile],[data-compact=true]) .studio-overlay-item-value{max-width:42%;font-size:13px}
.root:is([data-layout=mobile],[data-compact=true]) .stream-rate-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
.root:is([data-layout=mobile],[data-compact=true]) .stream-playlist{position:fixed;inset:auto 12px max(12px,env(safe-area-inset-bottom));width:auto;max-height:min(70dvh,560px);margin:0;border:1px solid #ffffff26;border-radius:18px;overflow:hidden;z-index:20;padding-bottom:env(safe-area-inset-bottom);background:#181b20;box-shadow:0 16px 60px #0008}
.mediadock-root:is([data-layout=mobile],[data-compact=true]) .stream-playlist{background:#15211f}
.root:is([data-layout=mobile],[data-compact=true]) .stream-playlist-header{padding:8px 12px 8px 16px}
.root:is([data-layout=mobile],[data-compact=true]) .stream-playlist .episode-list{flex:1;min-height:0;padding:8px}
.root:is([data-layout=mobile],[data-compact=true]) .episode-row{grid-template-columns:80px minmax(0,1fr);gap:12px;min-height:68px;border:1px solid #ffffff10;border-radius:8px;padding:6px;margin-bottom:6px;background:#ffffff04}
.root:is([data-layout=mobile],[data-compact=true]) .episode-thumb{width:80px;border-radius:5px}
.root:is([data-layout=mobile],[data-compact=true]) .episode-copy strong{font-size:14px;line-height:1.5}
.root:is([data-layout=mobile],[data-compact=true]) .episode-row[aria-current=true]{box-shadow:inset 3px 0 var(--timeline);border-color:color-mix(in srgb,var(--timeline) 30%,transparent);background:color-mix(in srgb,var(--timeline) 10%,transparent)}
.root:is([data-layout=mobile],[data-compact=true]) .stream-autoplay{display:flex;align-items:center;justify-content:space-between;min-height:48px;padding:4px 16px;font-size:13px;color:#ccc}
.root:is([data-layout=mobile],[data-compact=true]) .stream-switch-cell{display:inline-flex}
/* Portrait: only the playlist scrolls; the picture and controls keep their position. */
.root[data-inline-playlist=true]{height:100dvh;overflow:hidden}
.root[data-inline-playlist=true] video-player{height:100%;overflow:hidden}
.root[data-inline-playlist=true] media-container{height:100%;display:flex;flex-direction:column;overflow:hidden}
.root[data-inline-playlist=true] .stream-stage{height:auto;flex:1;min-height:0;display:flex;flex-direction:column;border:0;border-radius:0;background:#0f0f0f;box-shadow:none;overflow:hidden}
.root[data-inline-playlist=true] .stream-stage>.screen{height:auto;flex:none;min-height:0;aspect-ratio:auto;padding-top:calc(var(--mobile-header) + var(--picture-height));overflow:visible}
.root[data-inline-playlist=true] .screen{background:#0f0f0f}
.root:is([data-layout=mobile],[data-compact=true]) .transport>[data-action=play]{color:#fff;background:none;flex:0 0 48px;margin:0}
.root[data-inline-playlist=true] .screen-heading{opacity:1;visibility:visible;pointer-events:auto;background:#0f0f0f}
.root[data-inline-playlist=true] .screen-heading [data-action=episodes]{display:none}
.root[data-inline-playlist=true] .media-slot{top:var(--mobile-header);bottom:auto;height:var(--picture-height);overflow:hidden}
.root[data-inline-playlist=true] :is(.center,.buffering,.stream-end-slate){inset:var(--mobile-header) 0 auto;height:var(--picture-height);padding:12px}
.root[data-inline-playlist=true] .center .touch-seek{display:none}
.root[data-inline-playlist=true] .center-copy h2{font-size:16px;margin:0 0 6px}
.root[data-inline-playlist=true] .center-copy :is(.eyebrow,p){display:none}
.root[data-inline-playlist=true] .controls{position:relative;inset:auto;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));padding:0 10px 8px;background:#0f0f0f;opacity:1;visibility:visible;pointer-events:auto}
.root[data-inline-playlist=true] .controls .time-range{grid-column:1/-1;margin-bottom:-8px}
.root[data-inline-playlist=true] :is(.control-row,.transport,.tools){display:contents}
.root[data-inline-playlist=true] .controls .time{grid-column:1/-1;grid-row:2;min-height:24px;height:auto;display:block;margin:0 0 4px}
.root[data-inline-playlist=true] .controls :is([data-action=play],.bar-seek){display:inline-flex;justify-self:start}
.root[data-inline-playlist=true] .controls [data-action=backward]{grid-column:2}
.root[data-inline-playlist=true] .controls [data-action=forward]{grid-column:3}
.root[data-inline-playlist=true] .controls [data-action=rate]{grid-column:4}
.root[data-inline-playlist=true] .controls [data-action=settings]{grid-column:5;justify-self:center}
.root[data-inline-playlist=true] .controls [data-action=fullscreen]{grid-column:6;justify-self:end}
.root[data-inline-playlist=true] .controls [data-action=episodes]{display:none}
.root[data-inline-playlist=true] .stream-playlist{position:relative;inset:auto;width:100%;flex:1;min-height:0;max-height:none!important;margin:0;padding:0 8px max(12px,env(safe-area-inset-bottom));border:0;border-top:1px solid #ffffff15;border-radius:0;box-shadow:none;background:#0f0f0f;animation:none;z-index:auto;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;-webkit-overflow-scrolling:touch}
.root[data-inline-playlist=true] .stream-playlist-header{position:sticky;top:0;flex-shrink:0;background:inherit;border:0;padding:16px 8px 4px}
.root[data-inline-playlist=true] .stream-playlist-heading h2{font-size:16px;font-weight:600}
.root[data-inline-playlist=true] .stream-playlist-actions{display:none}
.root[data-inline-playlist=true] .stream-playlist .episode-list{overflow:visible;flex:none;padding:8px 0}
.root[data-inline-playlist=true] .stream-playlist :is(.stream-autoplay,.stream-note,.stream-empty){flex-shrink:0}
.root[data-inline-playlist=true] .stream-note{padding:4px 8px 8px}
.root[data-inline-playlist=true] .now{display:none}
.root[data-inline-playlist=true] .statusline{padding:8px 16px 12px;flex-shrink:0}
.root[data-inline-playlist=true] .stream-end-card{padding:10px 12px;max-height:100%;overflow:auto}
.root[data-inline-playlist=true] :is(.stream-end-kicker,.stream-end-description){display:none}
.root[data-inline-playlist=true] .stream-end-title{font-size:15px;margin-bottom:8px;-webkit-line-clamp:1}
.mediadock-root:is([data-layout=mobile],[data-compact=true]) .dock-stage{padding:0;height:100dvh;max-height:100dvh;background:#101918}
.mediadock-root[data-inline-playlist=true] :is(video-player,media-container){height:100%;overflow:hidden}
.mediadock-root[data-inline-playlist=true] :is(.stream-stage,.screen,.screen-heading,.controls,.stream-playlist){background:#101918}
.mediadock-root[data-inline-playlist=true] .stream-stage{height:100%;min-height:0}
.mediadock-root[data-inline-playlist=true] .mobile-context{display:flex;flex-wrap:wrap;gap:8px;margin:0;padding:12px 16px;border-top:1px solid #ffffff12;color:#a8bbb5}
.root .mobile-context .eyebrow{font-size:12px;letter-spacing:0;margin:0;line-height:1.5}
/* Landscape/fullscreen: one central transport group and compact edge tools. */
.root[data-immersive=true] .screen{height:100dvh;min-height:0;aspect-ratio:auto;padding:0}
.root[data-immersive=true] :is(.stream-stage,video-player,media-container){height:100%;border-radius:0}
.root[data-immersive=true] .controls{padding:24px max(16px,env(safe-area-inset-right)) max(4px,env(safe-area-inset-bottom)) max(16px,env(safe-area-inset-left));background:linear-gradient(transparent,#000b)}
.root[data-immersive=true] .control-row{display:flex;flex-wrap:nowrap;height:48px;min-height:48px;gap:0}
.root[data-immersive=true] .transport{display:contents}
.root[data-immersive=true] .tools{display:flex;gap:0;height:48px;margin-left:auto;padding:0;border:0;background:none}
.root[data-immersive=true] .time{margin-right:auto;min-width:0;height:auto}
.root[data-immersive=true] .screen-heading{background:linear-gradient(#0009,transparent)}
.root[data-immersive=true] .screen-heading [data-action=episodes]{display:none}
.root[data-immersive=true] .center{padding:var(--mobile-header) 12px 96px}
.root[data-immersive=true] .center-actions{gap:32px}
.root[data-immersive=true] .center .center-play{width:80px;height:80px}
.root[data-immersive=true] .center .center-play svg{width:36px;height:36px;fill:currentColor;stroke-width:1.5}
.root[data-immersive=true] :is(.now,.statusline,.mobile-context){display:none}
.root[data-immersive=true] .controls [data-action=play]{display:none}
.root[data-immersive=true][data-state=playing] .controls [data-action=play]{display:inline-flex;order:-1}
.root[data-immersive=true] .stream-playlist{inset:12px 12px 12px auto;width:min(380px,60vw);max-height:calc(100dvh - 24px)}
.root .studio-overlay[data-touch-sheet=portrait]{border-radius:18px 18px 0 0;border-bottom:0}
.root .studio-overlay[data-touch-sheet=portrait]::before{content:'';display:block;width:32px;height:3px;margin:8px auto 0;border-radius:3px;background:#ffffff50}
@media(orientation:landscape) and (max-height:540px){
 .root[data-immersive=true] .stream-end-slate{padding:56px 16px 100px}
 .root[data-immersive=true] .stream-end-card{padding:10px 12px;max-height:100%;overflow:auto}
 .root[data-immersive=true] :is(.stream-end-kicker,.stream-end-description){display:none}
}
`;
