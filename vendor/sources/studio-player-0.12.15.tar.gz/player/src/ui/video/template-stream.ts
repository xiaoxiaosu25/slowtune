import { streamStyles } from './styles-stream.js';
import { mobileVideoStyles } from './styles-mobile.js';
import {
  Info, Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Captions,
  RectangleHorizontal, Maximize, Minimize, PictureInPicture2, ListVideo, X,
  ChevronRight, ChevronLeft, RotateCcw, RotateCw, Gauge, Layers, Languages,
  Moon, Settings, Sliders,
} from 'lucide';
import { iconMarkup } from '../icon.js';

/**
 * Stream 保真变体（`variant: 'stream'`）的模板与图标集。
 *
 * 度量与颜色来自真实播放器的运行时测量，样式常量维护在 styles-stream.ts；
 * 图标统一由 Lucide 序列化，不复制 Stream 的资产与设计令牌。
 */
const paths = {
  info: Info, play: Play, pause: Pause, next: SkipForward, previous: SkipBack, volume: Volume2, volumeMuted: VolumeX,
  captions: Captions, settings: Settings, theater: RectangleHorizontal,
  fullscreen: Maximize, fullscreenExit: Minimize, pip: PictureInPicture2, playlist: ListVideo, close: X,
  chevronRight: ChevronRight, chevronLeft: ChevronLeft, back: RotateCcw, forward: RotateCw,
  speed: Gauge, quality: Layers, audio: Languages, sleep: Moon, theme: Sliders,
} as const;

/** 保留 Stream 变体的尺寸钩子，但图标来源统一为 Lucide。 */
export function streamIcon(name: keyof typeof paths): string {
  return iconMarkup(paths[name]).replace('class="lucide"', 'class="lucide stream-icon"');
}

const button = (action: string, label: string, icon: keyof typeof paths, extra = '') =>
  `<button type="button" class="stream-btn ${extra}" data-action="${action}" aria-label="${label}" title="${label}">${streamIcon(icon)}</button>`;
const slider = (name: 'time' | 'volume', label: string) =>
  `<div class="range-control ${name}-range" data-range-control="${name}"><div class="range-track" aria-hidden="true">${name === 'time' ? '<span class="range-buffer" data-range-buffer></span>' : ''}<span class="range-fill" data-range-fill></span><span class="range-thumb" data-range-thumb></span></div><input class="range-input" type="range" min="0" max="${name === 'time' ? '0' : '1'}" step="${name === 'time' ? '1' : '0.01'}" value="0" aria-label="${label}" data-range="${name}"${name === 'time' ? ' disabled' : ''}></div>`;

/** 两套布局使用相同语义钩子；模态舞台与内嵌形态在这里明确分开。 */
export function videoMarkup(dock = false): string { return `
<section class="root ${dock ? 'mediadock-root' : 'stream-root'}" data-layout="desktop" data-view="standard" aria-label="视频播放器">
  ${dock ? '<dialog class="dock-stage" data-stage-dialog aria-label="MediaDock 视频舞台">' : ''}<video-player lang="zh" data-surface>
    <media-container tabindex="-1">
      <div class="stream-stage">
        <div class="screen" tabindex="0" aria-label="视频画面，空格播放暂停，左右方向键跳转" data-screen>
          <div class="media-slot" data-media-slot data-surface-slot="media"></div>
          <header class="screen-heading"><div class="screen-title"><span data-screen-title></span>${dock ? '<small data-status role="status"></small>' : ''}</div><div class="screen-actions">
            ${dock ? '<span class="dock-sleep-badge" data-sleep-status data-sleep-indicator hidden></span>' : button('episodes', '播放列表', 'playlist')}
            ${button('close', '关闭播放器', 'close')}
          </div></header>
          <div class="center" data-center>
            <div class="center-copy"><span class="eyebrow" data-overlay-kicker>随时开始</span><h2 data-overlay-title>准备好，开始看</h2><p data-overlay-description></p></div>
            <div class="center-actions">${button('backward', '后退 10 秒', 'back', 'touch-seek').replace('</button>', '<span class="touch-seek-copy" aria-hidden="true">10</span></button>')}${button('play', '播放', 'play', 'center-play')}${button('forward', '前进 10 秒', 'forward', 'touch-seek').replace('</button>', '<span class="touch-seek-copy" aria-hidden="true">10</span></button>')}</div>
            <button type="button" class="stream-text-btn" data-action="retry" hidden>重试播放</button>
            <button type="button" class="stream-text-btn" data-action="add" hidden>选择视频</button>
          </div>
          <div class="stream-end-slate" data-end-slate hidden aria-live="polite">
            <div class="stream-end-card">
              <span class="stream-end-kicker">本集播放完毕</span>
              <h2 class="stream-end-title" data-end-title>本集</h2>
              <p class="stream-end-description">还要继续观看吗？</p>
              <div class="stream-end-actions">
                <button type="button" class="stream-end-btn primary" data-action="replay" aria-label="重新播放本集" title="重新播放本集">${streamIcon('back')}<span>重播本集</span></button>
                <button type="button" class="stream-end-btn" data-action="next-end" aria-label="播放下一集" title="播放下一集">下一集${streamIcon('next')}</button>
              </div>
            </div>
          </div>
          <div class="buffering" data-buffering hidden><span class="spinner" aria-hidden="true"></span></div>
          <p class="video-action-notice" data-action-notice role="status" hidden></p>
          <div class="controls" data-controls>
            ${slider('time', '播放进度')}
            <div class="control-row">
              <div class="transport">
                ${button('previous', '上一集', 'previous')}${button('play', '播放', 'play')}${button('next', '下一集', 'next')}
                ${button('backward', '后退 10 秒', 'back', 'bar-seek').replace('</button>', '<span class="touch-seek-copy" aria-hidden="true">10</span></button>')}${button('forward', '前进 10 秒', 'forward', 'bar-seek').replace('</button>', '<span class="touch-seek-copy" aria-hidden="true">10</span></button>')}
                <div class="volume">${button('mute', '静音', 'volume', 'mute-control')}${slider('volume', '播放音量')}</div>
                <span class="time"><span data-current-time>0:00</span><span class="time-divider"> / </span><span data-duration>0:00</span></span>
              </div>
              <div class="tools">
                ${dock ? button('episodes', '播放列表', 'playlist') : ''}
                <span class="feature-shortcuts" data-feature-shortcuts>
                  ${button('rate', '播放速度', 'speed').replace('</button>', '<span data-rate-display>1.0×</span></button>')}${button('captions', '字幕', 'captions')}${button('audio', '音轨', 'audio')}${button('quality', '画质', 'quality')}${button('sleep', '睡眠定时', 'sleep')}${button('info', '视频信息', 'info')}
                </span>${button('settings', '设置', 'settings')}
                ${button('wide', '影院模式', 'theater')}
                ${button('pip', '画中画', 'pip')}
                ${button('fullscreen', '全屏', 'fullscreen', 'fullscreen-control')}
              </div>
            </div>
          </div>
          ${dock ? '<section class="mobile-context" aria-label="当前视频"><p class="eyebrow" data-episode-number>现在观看</p><span data-sleep-status data-sleep-indicator hidden></span></section>' : ''}
        </div>
        <aside id="stream-playlist" class="stream-playlist" data-episodes hidden aria-label="播放列表">
          <header class="stream-playlist-header">
            <div class="stream-playlist-heading"><h2>选集</h2><span data-count></span></div>
            <div class="stream-playlist-actions">${button('dismiss-episodes', '收起播放列表', 'close')}</div>
          </header>
          <label class="stream-autoplay"><span>自动连播</span><span class="stream-switch-cell"><input type="checkbox" role="switch" data-setting="autoplay" aria-label="自动连播"><span class="stream-switch" aria-hidden="true"></span></span></label>
          <ol class="episode-list" data-episode-list></ol>
          <p class="stream-empty" data-list-empty hidden>添加视频后，播放列表会出现在这里。</p>
          <p class="stream-note" data-autoplay-note>默认播完当前集后停下。</p>
        </aside>
      </div>
      <div class="now"><div class="now-copy"><h2 data-title>准备好，开始看</h2><p class="eyebrow" data-episode-number>现在观看</p><p data-description></p></div><div class="host-actions" data-host-actions></div></div>
      <div class="statusline"><p role="status" data-status>选择一集，开始观看</p><span data-sleep-status data-sleep-indicator hidden></span></div>
      <p class="error" role="alert" data-error hidden></p>
      <!-- 浮层由 packages/audio-video/player/src/ui/overlay 的核构建，面板定义见 stream-view.ts。 -->
    </media-container>
  </video-player>${dock ? '</dialog>' : ''}
  <div class="closed" data-closed hidden><div><span class="eyebrow">稍后再见</span><h2>播放器已关闭</h2><p data-closed-description>选集已保留，重新打开后可继续观看。</p></div><button type="button" class="stream-text-btn primary" data-action="reopen">重新打开</button></div>
</section>`; }

export const streamTemplate = `<style>${streamStyles}\n${mobileVideoStyles}</style>${videoMarkup()}`;
