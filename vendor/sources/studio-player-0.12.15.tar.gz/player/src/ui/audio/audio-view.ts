import { createOverlaySurface, type OverlaySurface } from '../overlay/index.js';

type AudioPanel = 'queue' | 'sleep' | 'settings';

export interface AudioViewContext {
  readonly shadow: ShadowRoot;
}

export interface AudioView {
  readonly isOpen: boolean;
  dismiss(): void;
  /** 触发按钮的入口动作；不是浮层入口时返回 false，交回公共 UI 的默认处理。 */
  handleAction(action: string | undefined, trigger?: HTMLElement): boolean;
  bind(signal: AbortSignal): void;
}

/** 入口 → 面板。三个入口都是独立面板（队列有标签页、设置与睡眠是表单）。 */
const TRIGGERS: ReadonlyArray<readonly [string, AudioPanel]> = [
  ['queue', 'queue'], ['sleep', 'sleep'], ['settings', 'settings'],
];

/**
 * 音频套件接浮层核（方案 P5）。
 *
 * 音频原来有 3 个原生 `<dialog>`（queue/sleep/settings）各自 `showModal()`，带自己的一套
 * 关闭判定、焦点陷阱与定位。现在与视频共用同一个核：一个容器 + 面板栈。
 *
 * 逐个面板按方案 §2.2 的取值表声明语义与模态等级——**这就是"要哪个用哪个"**：
 *   queue    右侧抽屉（drawer）、非模态：队列是列表操作，点外面应当关闭，不该锁住背景
 *   sleep    居中卡片（center）、真模态：表单，需要明确的关闭语义，背景不该被误操作
 *   settings 居中卡片（center）、真模态：同上（倍速/音量/外观/形态 + 动作按钮）
 * 面板内容直接取自模板里的 `<template data-panel=…>`，标记/类名/选择器不变，
 * 队列渲染、标签页切换与表单逻辑都不需要改。窄视口（≤740px）一律转底部抽屉。
 */
export function createAudioView(context: AudioViewContext): AudioView {
  const { shadow } = context;
  const document = shadow.host.ownerDocument;
  const container = shadow.querySelector<HTMLElement>('media-container') ?? shadow.host as HTMLElement;
  /** 把模板里的面板内容搬进容器（一次性，构造期完成）。 */
  const content = (name: AudioPanel): Node[] => {
    const template = shadow.querySelector<HTMLTemplateElement>(`template[data-panel=${name}]`);
    return template ? [...template.content.childNodes] : [];
  };
  const wrap = (name: AudioPanel): HTMLElement => {
    const node = document.createElement('div');
    node.append(...content(name));
    return node;
  };
  let disposed = false;

  const overlay: OverlaySurface = createOverlaySurface({
    document,
    root: container,
    panels: [
      { id: 'queue', label: '播放队列', role: 'dialog', labelledBy: 'queue-title', placement: 'drawer', build: () => wrap('queue') },
      { id: 'sleep', label: '睡眠定时', role: 'dialog', labelledBy: 'sleep-title', placement: 'center', modal: true, build: () => wrap('sleep') },
      { id: 'settings', label: '音频设置', role: 'dialog', labelledBy: 'settings-title', placement: 'center', modal: true, build: () => wrap('settings') },
    ],
  });

  return {
    get isOpen() { return overlay.isOpen; },

    dismiss() { if (!disposed) overlay.close(); },

    handleAction(action, trigger) {
      const entry = TRIGGERS.find(([name]) => name === action);
      if (!entry) return false;
      // 用实际被点击的那个按钮当触发按钮，关闭时焦点才回到原处（同一入口在多种形态下可能出现多次）。
      overlay.toggle(entry[1], trigger);
      return true;
    },

    bind(signal) {
      // 触发按钮的 aria-haspopup / aria-expanded 由核统一维护（方案 S2）。
      for (const [action, panel] of TRIGGERS) {
        for (const button of shadow.querySelectorAll<HTMLElement>(`[data-action=${action}]`)) overlay.bindTrigger(button, panel);
      }
      signal.addEventListener('abort', () => { disposed = true; overlay.destroy(); }, { once: true });
    },
  };
}
