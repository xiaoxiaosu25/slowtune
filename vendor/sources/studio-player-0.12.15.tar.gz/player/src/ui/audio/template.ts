import { audioStyles } from './styles.js';
import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, ListMusic, Moon, ChevronsUp, ChevronDown, X, SlidersHorizontal, Volume2, Ellipsis, Music2 } from 'lucide';
import { iconMarkup } from '../icon.js';

const paths = {
  play: Play, pause: Pause, previous: SkipBack, next: SkipForward, shuffle: Shuffle, repeat: Repeat,
  queue: ListMusic, moon: Moon, expand: ChevronsUp, collapse: ChevronDown, close: X,
  settings: SlidersHorizontal, volume: Volume2, more: Ellipsis, note: Music2,
} as const;
export function audioIcon(name: keyof typeof paths): string {
  return iconMarkup(paths[name]);
}
const button = (action: string, label: string, icon: keyof typeof paths, extra = '') =>
  `<button type="button" class="icon ${extra}" data-action="${action}" aria-label="${label}" title="${label}">${audioIcon(icon)}</button>`;

export const audioTemplate = `
<style>${audioStyles}</style>
<div class="root" data-view="bar" data-layout="desktop" data-state="idle">
  <audio-player lang="zh">
    <media-container>
      <section class="surface" aria-label="音频播放器" data-surface>
        <header class="expanded-header">
          ${button('collapse', '收起播放器', 'collapse')}
          <div class="header-title"><span class="eyebrow">NOW PLAYING</span><strong>正在播放</strong></div>
          ${button('close', '关闭播放器', 'close')}
        </header>
        <section class="empty" data-empty hidden>
          <h3>队列还是空的</h3><p>添加一首音频，开始你的收听时光。</p>
          <button type="button" class="button primary" data-action="add" hidden>添加音频</button>
        </section>
        <div class="playback">
          <button type="button" class="artwork" data-action="expand" aria-label="展开正在播放">
            <span class="placeholder">${audioIcon('note')}</span><img data-cover alt="" hidden>
          </button>
          <div class="info"><span class="eyebrow">YOUR LISTENING SPACE</span><h2 data-title>准备好，开始听</h2><p data-subtitle>选择一首音频</p></div>
          <div class="transport" role="group" aria-label="播放控制">
            ${button('shuffle', '随机播放', 'shuffle')}
            ${button('previous', '上一首', 'previous')}
            ${button('play', '播放', 'play', 'play')}
            ${button('next', '下一首', 'next')}
            <span class="repeat-wrap">${button('repeat', '循环关闭', 'repeat')}<span class="repeat-one" data-repeat-one hidden>1</span></span>
          </div>
          <div class="timeline">
            <span class="time" data-current-time>0:00</span>
            <media-time-slider label="播放进度" step="1" large-step="10">
              <media-slider-track><media-slider-buffer></media-slider-buffer><media-slider-fill></media-slider-fill></media-slider-track>
              <media-slider-thumb></media-slider-thumb>
            </media-time-slider>
            <span class="time" data-duration>0:00</span>
          </div>
          <div class="toolbar" role="group" aria-label="音频功能">
            <button type="button" class="icon" data-action="queue" aria-label="打开播放队列" aria-haspopup="dialog" title="播放队列">${audioIcon('queue')}<span class="badge" data-queue-count>0</span></button>
            <button type="button" class="icon" data-action="sleep" aria-label="睡眠设置" aria-haspopup="dialog" title="睡眠设置">${audioIcon('moon')}<span class="sleep-active" data-sleep-active hidden></span></button>
            <button type="button" class="icon" data-action="settings" aria-label="音频设置" aria-haspopup="dialog" title="音频设置">${audioIcon('settings')}</button>
            ${button('expand', '展开播放器', 'expand')}
            ${button('close', '关闭播放器', 'close', 'bar-close')}
          </div>
        </div>
        <div class="statusline"><p role="status"><span class="status-indicator"></span><span data-status>选择一首，开始收听</span></p><div class="host-actions" data-host-actions></div></div>
        <div class="error" data-error hidden><p role="alert" data-error-text></p><button type="button" class="button" data-action="retry">重试播放</button></div>
      </section>
      <section class="closed" data-closed hidden aria-label="播放器已关闭">
        <div><strong>播放器已关闭</strong><p>队列已保留，重新打开后可继续收听。</p></div><button type="button" class="button primary" data-action="reopen">重新打开</button>
      </section>
      <!-- 浮层面板的内容源：由 packages/audio-video/player/src/ui/overlay 的核在 audio-view.ts 里挂进容器。
           用 <template> 承装，标记、id、类名与选择器保持原样，队列/标签页/渲染逻辑不需要改。 -->
      <template data-panel="queue">
        <header class="dialog-header"><div><h2 id="queue-title">播放队列</h2><p data-queue-description>0 首音频</p></div>${button('dismiss', '关闭队列面板', 'close')}</header>
        <div class="tabs" role="tablist" aria-label="队列与历史">
          <button type="button" role="tab" id="queue-tab" aria-controls="queue-panel" aria-selected="true" data-tab="queue">当前队列</button>
          <button type="button" role="tab" id="history-tab" aria-controls="history-panel" aria-selected="false" tabindex="-1" data-tab="history">会话历史</button>
        </div>
        <div class="dialog-body">
          <section id="queue-panel" role="tabpanel" aria-labelledby="queue-tab" data-tab-panel="queue">
            <ol class="queue-list" data-queue-list></ol><p class="hint" data-queue-empty hidden>这里还没有音频。</p>
            <div class="queue-footer"><button type="button" class="button" data-action="add" hidden>添加音频</button><button type="button" class="button danger" data-action="clear">清空队列</button></div>
          </section>
          <section id="history-panel" role="tabpanel" aria-labelledby="history-tab" data-tab-panel="history" hidden>
            <div class="history-controls"><button type="button" class="button" data-action="back">历史上一首</button><button type="button" class="button" data-action="forward">历史下一首</button></div>
            <ol class="history-list" data-history-list></ol><p class="hint">只记录本次会话真正开始播放的条目，退出页面后不保留。</p>
          </section>
        </div>
      </template>
      <template data-panel="sleep">
        <header class="dialog-header"><div><h2 id="sleep-title">睡眠定时</h2><p>把接下来的时间，留给自己。</p></div>${button('dismiss', '关闭睡眠设置', 'close')}</header>
        <div class="dialog-body" data-sleep-settings></div>
      </template>
      <template data-panel="settings">
        <header class="dialog-header"><h2 id="settings-title">音频设置</h2>${button('dismiss', '关闭音频设置', 'close')}</header>
        <div class="dialog-body settings-grid">
          <label>播放速度<select data-setting="rate"><option value="0.75">0.75×</option><option value="1" selected>1× · 标准</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2×</option></select></label>
          <div><span>播放音量</span><div class="volume-control"><media-mute-button>${audioIcon('volume')}</media-mute-button><media-volume-slider label="播放音量"><media-slider-track><media-slider-fill></media-slider-fill></media-slider-track><media-slider-thumb></media-slider-thumb></media-volume-slider></div><p class="hint" data-volume-unavailable hidden>请使用设备音量键调节音量。</p></div>
          <label>外观<select data-setting="theme"><option value="auto">跟随系统</option><option value="light">明亮</option><option value="dark">深色</option></select></label>
          <label>播放器形态<select data-setting="view"><option value="bar">播放条</option><option value="expanded">展开</option><option value="mini">迷你</option></select></label>
          <div class="settings-actions"><button type="button" class="button" data-action="stop">停止播放</button><button type="button" class="button danger" data-action="close">关闭播放器</button></div>
          <p class="hint">停止会释放播放资源并保留队列；接入进度记忆时保存当前位置。</p>
        </div>
      </template>
      <span class="sr-only" role="status" data-announcement></span>
    </media-container>
  </audio-player>
</div>`;
