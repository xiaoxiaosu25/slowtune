/** 只启用明确配置的可观测阶段；0 和省略表示禁用。 */
export function timeoutMilliseconds(value: number | undefined): number {
  if (value === undefined || value === 0) return 0;
  if (!Number.isFinite(value) || value < 0 || value * 1000 > 2_147_483_647) {
    throw new TypeError('Playback timeout must be finite seconds between 0 and 2147483.647');
  }
  return value * 1000;
}

export function playbackAbortError(): Error {
  const error = new Error('Playback operation was cancelled');
  error.name = 'AbortError';
  return error;
}

/** 取消等待；原 Promise 仍有 rejection handler，迟到资源的释放由拥有者处理。 */
export function waitWithSignal<T>(operation: PromiseLike<T> | T, signal: AbortSignal): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const abort = () => { signal.removeEventListener('abort', abort); reject(signal.reason); };
    Promise.resolve(operation).then(
      value => { signal.removeEventListener('abort', abort); resolve(value); },
      error => { signal.removeEventListener('abort', abort); reject(error); },
    );
    if (signal.aborted) abort();
    else signal.addEventListener('abort', abort, { once: true });
  });
}
