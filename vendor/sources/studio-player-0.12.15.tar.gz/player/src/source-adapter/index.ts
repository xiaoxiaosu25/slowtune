/**
 * packages/audio-video/player/src/source-adapter
 * 导出来源适配器模块
 *
 * 交付描述的公开类型定义在契约层（`contracts/delivery.ts`）；这里只做转发，
 * 不另起第二份定义。根入口同时从契约层导出同一批符号，按同一符号合并。
 *
 * 上游描述结构与等价判定属于后端实现（`backends/`），这里只再导出符号，入口名不变；
 * 后端选择不走公开注入项——核心按进程内的环境信号选择，接缝签名见 packages/audio-video/player/README.md。
 */

export * from './plan-to-source.js';
export * from './source-controller.js';
export * from './browser-media-support.js';
export * from './probed-media.js';

export type { AdaptedSourceResult, DeliveryCarrier, DeliveryTarget } from '../contracts/delivery.js';
export { HLS_MIME_TYPE, HLS_MIME_ALIASES, isHlsIndicator, carrierOf, toVideojsSource, isSameVideojsSource, type VideojsSourceDescription } from '../backends/videojs/source.js';
