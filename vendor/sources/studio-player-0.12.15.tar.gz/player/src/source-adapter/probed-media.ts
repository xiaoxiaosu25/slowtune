import type { BrowserMediaDescription, AudioDecodeTrack, VideoDecodeTrack } from '../contracts/media-support.js';
import { MediaProbeError, type ProbedMedia, type ProbedMediaSelection, type ProbedMediaTrack } from '../contracts/media-probe.js';
type ObjectValue = Record<string, unknown>;
const object = (value: unknown): ObjectValue => value && typeof value === 'object' && !Array.isArray(value) ? value as ObjectValue : {};
const positive = (value: unknown): number | undefined => {
  const number = typeof value === 'number' || typeof value === 'string' && value.trim() ? Number(value) : NaN;
  return Number.isFinite(number) && number > 0 ? number : undefined;
};
const label = (value: unknown): string | undefined => typeof value === 'string' && /^[\w,. -]{1,128}$/.test(value) ? value : undefined;
function extraBytes(value: unknown): number[] {
  if (typeof value !== 'string') return [];
  return value.split('\n').flatMap(line => {
    const hex = /^\s*[0-9a-f]+:\s+((?:[0-9a-f]{2,4}(?: |$))+)/i.exec(line)?.[1]?.replaceAll(' ', '') ?? '';
    return hex.match(/../g)?.map(byte => parseInt(byte, 16)) ?? [];
  });
}
/** EBML header only: DocType cannot be inferred from the shared ffprobe demuxer name. */
function ebmlType(bytes?: Uint8Array): string | undefined {
  if (!bytes || bytes[0] !== 0x1a || bytes[1] !== 0x45 || bytes[2] !== 0xdf || bytes[3] !== 0xa3) return;
  const vint = (offset: number, id: boolean) => {
    const first = bytes[offset]; if (!first) return;
    let length = 1, mask = 0x80;
    while (!(first & mask) && length <= 8) { length++; mask >>= 1; }
    if (length > (id ? 4 : 8) || offset + length > bytes.length) return;
    let value = id ? first : first & (mask - 1);
    for (let i = 1; i < length; i++) value = value * 256 + bytes[offset + i];
    return Number.isSafeInteger(value) ? { value, length } : undefined;
  };
  const header = vint(4, false); if (!header) return;
  const end = Math.min(bytes.length, 4 + header.length + header.value);
  for (let offset = 4 + header.length; offset < end;) {
    const id = vint(offset, true); if (!id) return; offset += id.length;
    const size = vint(offset, false); if (!size) return; offset += size.length;
    if (offset + size.value > end) return;
    if (id.value === 0x4282) return String.fromCharCode(...bytes.subarray(offset, offset + size.value));
    offset += size.value;
  }
}
function codecOf(stream: ObjectValue, container: string): string | undefined {
  const name = stream.codec_name, bytes = extraBytes(stream.extradata);
  const tag = stream.codec_tag_string;
  if (name === 'h264' && bytes.length >= 7 && bytes[0] === 1 && (tag === 'avc1' || tag === 'avc3' || container === 'matroska')) {
    return `${tag === 'avc3' ? tag : 'avc1'}.${bytes.slice(1, 4).map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
  }
  if (name === 'hevc' && ['hvc1', 'hev1'].includes(String(tag)) && bytes.length >= 23 && bytes[0] === 1) {
    let flags = 0;
    for (let bit = 0; bit < 32; bit++) if (bytes[2 + (bit >> 3)] & (0x80 >> (bit % 8))) flags += 2 ** bit;
    const constraints = bytes.slice(6, 12); while (constraints.length && constraints.at(-1) === 0) constraints.pop();
    return `${tag}.${['', 'A', 'B', 'C'][bytes[1] >> 6]}${bytes[1] & 31}.${flags.toString(16).toUpperCase()}.${bytes[1] & 32 ? 'H' : 'L'}${bytes[12]}${constraints.map(byte => '.' + byte.toString(16).toUpperCase()).join('')}`;
  }
  // av1C, with profile/level/tier/bit depth explicitly present. Raw OBU is left unknown.
  if (name === 'av1' && bytes.length >= 4 && bytes[0] === 0x81 && bytes[1] >> 5 <= 2
    && (bytes[1] & 31) <= 23 && (!(bytes[2] & 0x80) || (bytes[1] & 31) >= 8)) {
    const depth = bytes[2] & 0x40 ? bytes[2] & 0x20 ? 12 : 10 : 8;
    return `av01.${bytes[1] >> 5}.${String(bytes[1] & 31).padStart(2, '0')}${bytes[2] & 0x80 ? 'H' : 'M'}.${String(depth).padStart(2, '0')}`;
  }
  if (name === 'vp9') {
    const profile = /^Profile ([0-3])$/.exec(String(stream.profile))?.[1], level = positive(stream.level);
    const depth = bitDepthOf(stream);
    if (profile && level && [10,11,20,21,30,31,40,41,50,51,52,60,61,62].includes(level)
      && (Number(profile) < 2 ? depth === 8 : depth === 10 || depth === 12)) {
      return `vp09.${profile.padStart(2, '0')}.${String(level).padStart(2, '0')}.${String(depth).padStart(2, '0')}`;
    }
  }
  if (name === 'aac' && bytes.length >= 2) {
    const type = bytes[0] >> 3;
    if (type === 2 && stream.profile !== 'LC') return; // Implicit SBR/PS needs additional ASC parsing.
    if ([1, 2, 3, 4, 5, 29].includes(type)) return `mp4a.40.${type}`;
    if (type === 31 && bytes.length >= 3) return `mp4a.40.${32 + ((bytes[0] & 7) << 3 | bytes[1] >> 5)}`;
  }
  if (name === 'mp3') return 'mp3';
  if (name === 'flac') return container === 'mp4' ? 'fLaC' : 'flac';
  if (name === 'opus') return container === 'mp4' ? 'Opus' : 'opus';
  if (name === 'vorbis') return 'vorbis';
  if (name === 'vp8') return 'vp8';
  if (name === 'alac') return 'alac';
  if (name === 'ac3') return 'ac-3';
  if (name === 'eac3') return 'ec-3';
  if (name === 'dts') return ({ DTS: 'dtsc', 'DTS-ES': 'dtsc', 'DTS Express': 'dtse', 'DTS-HD HRA': 'dtsh', 'DTS-HD MA': 'dtsl' } as Record<string, string>)[String(stream.profile)];
  if (container === 'wav' && ['pcm_u8','pcm_s16le','pcm_s24le','pcm_s32le'].includes(String(name))) return '1';
}
function bitDepthOf(stream: ObjectValue): number | undefined {
  const raw = positive(stream.bits_per_raw_sample);
  if (raw && raw <= 32) return raw;
  const format = String(stream.pix_fmt ?? '');
  if (/^(yuv|yuva|gbrp|gray).*?(10|12|16)(le|be)?$/.test(format)) return Number(/(10|12|16)(?:le|be)?$/.exec(format)![1]);
  if (/^(yuv(?:j)?(?:420|422|444)p|gray|gbrp)$/.test(format)) return 8;
}
export interface FfprobeNormalizationOptions {
  /** Successfully probed indexed headers may describe all declared tracks without reading media payload. */
  seekable?: boolean;
  /** At most 4096 bytes already charged to the probe read budget. */
  header?: Uint8Array;
}
/** Neutral facts only; paths, tags, stderr and arbitrary raw metadata are discarded. */
export function normalizeFfprobeMedia(input: unknown, inputComplete = false, options: FfprobeNormalizationOptions = {}): ProbedMedia {
  if (options.header && (!(options.header instanceof Uint8Array) || options.header.length > 4096)) throw new MediaProbeError('invalid-input');
  const root = object(input), format = object(root.format);
  if (!Array.isArray(root.streams) || root.streams.length > 256) throw new MediaProbeError('invalid-media');
  const formatName = label(format.format_name), names = formatName?.split(',') ?? [];
  const brand = String(object(format.tags).major_brand ?? '').trim(), docType = ebmlType(options.header);
  const container = names.includes('mov') ? /^(isom|iso[2-9]|mp4[12]|M4[AVB]|avif)$/.test(brand) ? 'mp4' : brand === 'qt' ? 'mov' : undefined
    : names.includes('matroska') ? docType === 'webm' ? 'webm' : docType === 'matroska' ? 'matroska' : undefined
      : (['mp3','flac','wav','ogg','mpegts'] as const).find(name => names.includes(name));
  const tracks: ProbedMediaTrack[] = [], indices = new Set<number>();
  let complete = inputComplete || Boolean(options.seekable && container && ['mp4','mov','matroska','webm'].includes(container));
  const subtype = container && ({ mp4: 'mp4', mov: 'quicktime', webm: 'webm', matroska: 'x-matroska',
    mp3: 'mpeg', flac: 'flac', wav: 'wav', ogg: 'ogg', mpegts: 'mp2t' } as Record<string, string>)[container];
  for (const value of root.streams) {
    const stream = object(value), disposition = object(stream.disposition);
    if (stream.codec_type === 'video' && disposition.attached_pic === 1) continue;
    if (stream.codec_type !== 'video' && stream.codec_type !== 'audio') {
      if (!['subtitle','data','attachment'].includes(String(stream.codec_type))) complete = false;
      continue;
    }
    if (!Number.isInteger(stream.index) || Number(stream.index) < 0 || indices.has(Number(stream.index))) throw new MediaProbeError('invalid-media');
    const index = Number(stream.index); indices.add(index);
    const kind = stream.codec_type, codec = codecOf(stream, container ?? ''), bitrate = positive(stream.bit_rate), bitDepth = bitDepthOf(stream);
    let decoding: VideoDecodeTrack | AudioDecodeTrack | undefined;
    if (subtype) {
      const common = { mimeType: `${kind}/${subtype}`, ...(codec ? { codec } : {}), ...(bitrate ? { bitrate } : {}) };
      if (kind === 'video') {
        const width = positive(stream.width), height = positive(stream.height);
        const rate = String(stream.avg_frame_rate ?? '').split('/').map(Number);
        const framerate = rate.length === 2 && rate[1] > 0 ? positive(rate[0] / rate[1]) : undefined;
        decoding = { ...common, ...(width ? { width } : {}), ...(height ? { height } : {}), ...(framerate ? { framerate } : {}), ...(bitDepth ? { bitDepth } : {}) };
      } else {
        const channels = positive(stream.channels), samplerate = positive(stream.sample_rate);
        decoding = { ...common, ...(channels && Number.isInteger(channels) ? { channels: String(channels) } : {}), ...(samplerate ? { samplerate } : {}) };
      }
    }
    const level = positive(stream.level);
    tracks.push(Object.freeze({ index, kind, default: disposition.default === 1,
      ...(label(stream.codec_name) ? { codecName: label(stream.codec_name) } : {}),
      ...(label(stream.profile) ? { profile: label(stream.profile) } : {}),
      ...(level ? { level } : {}), ...(label(stream.pix_fmt) ? { pixelFormat: label(stream.pix_fmt) } : {}),
      ...(bitDepth ? { bitDepth } : {}), ...(decoding ? { decoding: Object.freeze(decoding) } : {}) }));
  }
  if (!tracks.length) throw new MediaProbeError('invalid-media');
  const durationSeconds = positive(format.duration), kind = tracks.some(track => track.kind === 'video') ? 'video' : 'audio';
  return Object.freeze({ source: 'ffprobe', tracksComplete: complete, tracks: Object.freeze(tracks),
    ...(formatName ? { format: formatName } : {}), ...(durationSeconds ? { durationSeconds } : {}),
    ...(container && subtype ? { container: Object.freeze({ kind: container, mimeType: `${kind}/${subtype}` }) } : {}) });
}
/** Selection only creates a description; it never switches the player's tracks. */
export function describeProbedMedia(media: ProbedMedia, selection: ProbedMediaSelection = {}): BrowserMediaDescription {
  const select = (kind: 'video' | 'audio') => {
    const index = selection[kind]; if (index === null) return null;
    const tracks = media.tracks.filter(track => track.kind === kind);
    const chosen = index === undefined ? tracks.find(track => track.default) ?? tracks[0] : tracks.find(track => track.index === index);
    if (index !== undefined && !chosen) throw new TypeError('Selected media track does not exist');
    return chosen ? chosen.decoding : media.tracksComplete ? null : undefined;
  };
  return Object.freeze({ transport: 'range', ...(media.container ? { container: media.container } : {}),
    video: select('video'), audio: select('audio') });
}
