const stamp = /^(?:(\d{2,}):)?(\d{2}):(\d{2})[.,](\d{3})$/;
function seconds(value: string): number {
  const match = stamp.exec(value);
  if (!match || Number(match[2]) > 59 || Number(match[3]) > 59) throw new TypeError('Invalid subtitle timestamp');
  return Number(match[1] || 0) * 3600 + Number(match[2]) * 60 + Number(match[3]) + Number(match[4]) / 1000;
}
function format(value: number): string {
  const ms = Math.round(value * 1000);
  return `${String(Math.floor(ms / 3600000)).padStart(2, '0')}:${String(Math.floor(ms / 60000) % 60).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}.${String(ms % 1000).padStart(3, '0')}`;
}
/** 有界 SRT/WebVTT 导入与原始时间轴映射。 */
export function normalizeSubtitles(text: string, offsetSeconds = 0): string {
  if (!Number.isFinite(offsetSeconds) || offsetSeconds < 0 || text.length > 8 * 1024 * 1024) throw new TypeError('Invalid subtitle input');
  const normalized = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').trim();
  const vtt = /^WEBVTT(?:\s|$)/.test(normalized);
  const blocks = normalized.split(/\n{2,}/);
  const result: string[] = []; let cues = 0;
  for (const [index, block] of blocks.entries()) {
    if (vtt && index === 0) continue;
    if (vtt && /^(NOTE|STYLE|REGION)(?:\s|$)/.test(block)) { result.push(block); continue; }
    const lines = block.split('\n');
    const timing = lines.findIndex(line => line.includes('-->'));
    if (timing < 0 || timing > 1 || timing === lines.length - 1) throw new TypeError('Malformed subtitle cue');
    const match = /^(\S+)\s+-->\s+(\S+)(.*)$/.exec(lines[timing]);
    if (!match) throw new TypeError('Malformed subtitle timing');
    const start = seconds(match[1]), end = seconds(match[2]);
    if (end <= start) throw new TypeError('Subtitle end must follow start');
    cues++;
    if (end <= offsetSeconds) continue;
    lines[timing] = `${format(Math.max(0, start - offsetSeconds))} --> ${format(end - offsetSeconds)}${match[3]}`;
    result.push(lines.join('\n'));
  }
  if (!cues) throw new TypeError('No subtitle cues');
  return `WEBVTT\n\n${result.join('\n\n')}\n`;
}

export async function readSubtitleFile(file: Blob, offsetSeconds = 0): Promise<string> {
  if (file.size > 8 * 1024 * 1024) throw new TypeError('Subtitle file exceeds 8 MiB');
  const bytes = await file.arrayBuffer();
  let text: string;
  try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
  catch { text = new TextDecoder('gb18030', { fatal: true }).decode(bytes); }
  return normalizeSubtitles(text, offsetSeconds);
}
