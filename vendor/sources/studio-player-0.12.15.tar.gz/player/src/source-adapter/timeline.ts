import type { PlaybackPlan } from '../contracts/plan.js';

export interface PlaybackRange { readonly start: number; readonly end: number }

export function timelineOffset(plan: PlaybackPlan | null): number {
  return plan?.timeline?.offsetSeconds ?? 0;
}

export function validateTimeline(plan: Pick<PlaybackPlan, 'timeline'>): void {
  if (!plan.timeline) return;
  const { offsetSeconds, durationSeconds } = plan.timeline;
  if (!Number.isFinite(offsetSeconds) || offsetSeconds < 0
    || (durationSeconds !== undefined && (!Number.isFinite(durationSeconds) || durationSeconds <= 0 || offsetSeconds > durationSeconds))) {
    throw new TypeError('Invalid original media timeline');
  }
}

export function originalDuration(plan: PlaybackPlan | null, duration: number): number {
  if (!plan?.timeline) return duration;
  return plan.timeline.durationSeconds ?? plan.durationSeconds ?? (Number.isFinite(duration) ? duration + timelineOffset(plan) : duration);
}

export function originalRanges(ranges: TimeRanges | undefined, plan: PlaybackPlan | null): readonly PlaybackRange[] {
  const result: PlaybackRange[] = [];
  if (ranges) for (let i = 0; i < ranges.length; i++) {
    result.push(Object.freeze({ start: ranges.start(i) + timelineOffset(plan), end: ranges.end(i) + timelineOffset(plan) }));
  }
  return Object.freeze(result);
}
