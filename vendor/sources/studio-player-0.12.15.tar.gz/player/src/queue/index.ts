import type { PlayableInput } from '../contracts/plan.js';
import type { StudioPlayer } from '../player.js';
export { mountQueuePrefetch, type PrefetchLease, type QueuePrefetchOptions } from './prefetch.js';

export interface QueueItem {
  /** 条目 ID 与资源 ID 分离；同一资源可用不同条目 ID 多次入队。 */
  id: string;
  source: PlayableInput;
  title?: string;
  artist?: string;
  album?: string;
  artwork?: readonly MediaImage[];
}

export type QueueOrder = 'sequential' | 'shuffle';
export type QueueRepeat = 'off' | 'one' | 'all';
export interface QueueSnapshot {
  readonly items: readonly Readonly<QueueItem>[];
  readonly index: number;
  readonly current: Readonly<QueueItem> | null;
  readonly order: QueueOrder;
  readonly repeat: QueueRepeat;
  readonly autoAdvance: boolean;
  readonly loading: boolean;
  /** 当前选择已应用于播放器（与正在等待加载的选择区分）。 */
  readonly loaded: boolean;
  readonly autoplayPending: boolean;
  readonly canPrevious: boolean;
  readonly canNext: boolean;
  /** 当前选择实际 play 后才入历史，相邻同条目重播合并。 */
  readonly history: readonly string[];
  readonly historyIndex: number;
  readonly canBack: boolean;
  readonly canForward: boolean;
  readonly upNext: readonly string[];
  readonly error: unknown;
}
export interface QueueOptions {
  autoAdvance?: boolean;
  order?: QueueOrder;
  repeat?: QueueRepeat;
  /** 可注入确定性随机源，返回 [0, 1)；默认 Math.random。 */
  random?: () => number;
}
export interface QueueSelectOptions {
  autoplay?: boolean;
  /** 从头播放并阻止迟到断点恢复；自然循环使用此选项。 */
  restart?: boolean;
}
interface HistoryEntry { key: number; id: string }

/** 复制数据契约，避免调用方在加载期间改变条目身份/地址。 */
function copyData<T>(value: T): T {
  if (Array.isArray(value)) return Object.freeze(value.map(copyData)) as T;
  if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
    return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, copyData(entry)]))) as T;
  }
  return value;
}

export function validateQueueOptions(options: QueueOptions): void {
  if (options.autoAdvance !== undefined && typeof options.autoAdvance !== 'boolean') throw new TypeError('queue.autoAdvance must be a boolean');
  if (options.order !== undefined && !['sequential', 'shuffle'].includes(options.order)) throw new TypeError('Unknown queue order');
  if (options.repeat !== undefined && !['off', 'one', 'all'].includes(options.repeat)) throw new TypeError('Unknown queue repeat');
  if (options.random !== undefined && typeof options.random !== 'function') throw new TypeError('queue.random must be a function');
}

/** 唯一队列决策实现，供 UI、预设和系统控制共用。历史仅在本控制器会话内。 */
export class QueueController extends EventTarget {
  private items: Readonly<QueueItem>[] = [];
  private currentId: string | null = null;
  private order: QueueOrder;
  private repeat: QueueRepeat;
  private autoAdvance: boolean;
  private automaticSelection = -1;
  private readonly random: () => number;
  private history: HistoryEntry[] = [];
  private historyIndex = -1;
  private historySerial = 0;
  private selectionHistoryKey: number | null = null;
  private shuffleRemaining: string[] = [];
  private upNext: string[] = [];
  private error: unknown = null;
  private revision = 0;
  private editRevision = 0;
  private loadedRevision = -1;
  private recordedRevision = -1;
  private autoplayRevision = 0;
  private automaticPlaybackAllowed = false;
  private ownLoad = false;
  private loading = false;
  private pending: Promise<boolean> | null = null;
  private playbackAbort: AbortController | null = null;
  private destroyed = false;
  private readonly subscriptions: Array<() => void>;

  constructor(private readonly player: StudioPlayer, options: QueueOptions = {}) {
    super();
    if (player.isDestroyed) throw new Error('Cannot add a queue to a destroyed player');
    validateQueueOptions(options);
    this.order = options.order ?? 'sequential';
    this.repeat = options.repeat ?? 'off';
    this.autoAdvance = options.autoAdvance ?? true;
    this.random = options.random ?? Math.random;
    this.subscriptions = [
      player.on('loadstart', () => {
        // 只消费本次 load 的第一个同步通知；嵌套外部 load 仍会使选择失效。
        if (this.ownLoad) this.ownLoad = false;
        else this.resetSelection();
      }),
      player.on('pauseintent', () => this.cancelAutoplay()),
      player.on('stop', () => {
        this.revision += 1;
        this.loadedRevision = -1;
        this.cancelAutoplay();
        this.loading = false;
        this.notify();
      }),
      player.on('pause', () => {
        if (!this.loading && player.state !== 'ended' && player.paused && !player.playbackRequested) this.cancelAutoplay();
      }),
      player.on('play', () => {
        if (player.state === 'playing' && !player.paused && player.playbackRequested) {
          this.automaticPlaybackAllowed = true;
        }
      }),
      // 原生 play 可早于数据就绪，playing 或成功的 play() 才证明起播。
      player.on('playing', () => this.recordPlayback()),
      player.on('ended', completion => {
        if (player.currentPlan?.live) return;
        if (player.state !== 'ended' || player.playbackRequested
          || completion.resourceId !== player.currentResourceId || !this.autoAdvance
          || !this.automaticPlaybackAllowed || this.currentId === null) return;
        // beforeended 已完成睡眠决策；单曲循环不限制手动 next。
        const operation = this.repeat === 'one'
          ? this.selectId(this.currentId, { restart: true }) : this.next();
        this.automaticSelection = this.revision;
        void operation.catch(() => { /* 已反馈错误，不自动跳过失败条目。 */ });
      }),
      player.on('error', (error, switched) => {
        if (!switched && this.currentId !== null) { this.cancelAutoplay(); this.reportError(error); }
      }),
      player.on('playerror', error => {
        if (this.currentId !== null) { this.cancelAutoplay(); this.reportError(error); }
      }),
      player.on('detach', () => this.resetSelection()),
      player.on('destroy', () => this.destroy()),
    ];
  }

  get isDestroyed(): boolean { return this.destroyed; }
  get snapshot(): QueueSnapshot {
    const index = this.indexOfCurrent();
    const canBack = this.backIndex() >= 0;
    const canForward = this.forwardIndex() >= 0;
    return {
      items: this.items.slice(), index, current: this.items[index] ?? null,
      order: this.order, repeat: this.repeat, autoAdvance: this.autoAdvance, loading: this.loading,
      loaded: this.loadedRevision === this.revision,
      autoplayPending: this.loading && this.automaticPlaybackAllowed,
      canPrevious: canBack || (this.order === 'sequential' && index > 0),
      canNext: index >= 0 && (this.upNext.length > 0 || canForward || (this.order === 'shuffle'
        ? this.shuffleRemaining.length > 0 || this.repeat === 'all'
        : index < this.items.length - 1 || this.repeat === 'all')),
      history: this.history.map(entry => entry.id), historyIndex: this.historyIndex,
      canBack, canForward, upNext: this.upNext.slice(), error: this.error,
    };
  }

  /** 全量替换开启新的队列历史；兼容旧 API：不加载，也不停止已播放的媒体。 */
  setItems(items: readonly QueueItem[]): void {
    this.assertLive();
    const next = this.validateItems(items);
    this.editRevision += 1;
    this.items = next;
    this.history = [];
    this.historyIndex = -1;
    this.upNext = [];
    this.resetSelection(false);
    this.refillShuffle();
    this.notify();
  }
  /** 用户替换正在使用的整个队列时用此方法：先停止/保存，后重置列表，不起播。 */
  async replaceItems(items: readonly QueueItem[]): Promise<boolean> {
    this.assertLive();
    const next = this.validateItems(items);
    const revision = this.revision + 1; // stop 监听同步增加一次；之后的选择使本次替换失效。
    const edits = this.editRevision;
    const stopping = this.player.stop();
    try { await stopping; }
    catch (error) { if ((error as Error)?.name === 'AbortError') return false; throw error; }
    if (this.destroyed || revision !== this.revision || edits !== this.editRevision) return false;
    this.setItems(next);
    return true;
  }
  setOrder(order: QueueOrder): void {
    this.assertLive();
    validateQueueOptions({ order });
    if (this.order === order) return;
    this.order = order;
    if (order === 'shuffle') this.refillShuffle();
    this.notify();
  }
  setRepeat(repeat: QueueRepeat): void {
    this.assertLive();
    validateQueueOptions({ repeat });
    this.repeat = repeat;
    this.notify();
  }
  /** 视频默认关闭；显式关闭也撤销已经开始等待的自然接续。 */
  setAutoAdvance(enabled: boolean): void {
    this.assertLive();
    validateQueueOptions({ autoAdvance: enabled });
    this.autoAdvance = enabled;
    if (!enabled && this.loading && this.automaticSelection === this.revision) this.player.pause();
    this.notify();
  }

  /** 插入不重载当前来源；条目 ID 必须与整个队列唯一。 */
  add(items: readonly QueueItem[], atIndex = this.items.length): void {
    this.assertLive();
    if (!Number.isInteger(atIndex) || atIndex < 0 || atIndex > this.items.length) throw new RangeError('Queue insertion index is out of range');
    const additions = this.validateItems(items, new Set(this.items.map(item => item.id)));
    this.editRevision += 1;
    this.items.splice(atIndex, 0, ...additions);
    for (const item of additions) this.shuffleRemaining.splice(this.randomIndex(this.shuffleRemaining.length + 1), 0, item.id);
    this.notify();
  }
  /** 新条目按传入顺序优先作为下一项；随机模式也有效。 */
  insertNext(items: readonly QueueItem[]): void {
    this.assertLive();
    const additions = this.validateItems(items, new Set(this.items.map(item => item.id)));
    this.editRevision += 1;
    this.items.splice(this.indexOfCurrent() + 1, 0, ...additions);
    this.upNext.unshift(...additions.map(item => item.id));
    this.shuffleRemaining.push(...additions.map(item => item.id));
    this.notify();
  }
  /** 将已有条目安排为下一首，保留它的条目身份。 */
  enqueueNext(id: string): void {
    this.assertLive();
    const index = this.requireId(id);
    if (id === this.currentId) return;
    this.editRevision += 1;
    const [item] = this.items.splice(index, 1);
    this.items.splice(this.indexOfCurrent() + 1, 0, item);
    this.upNext = [id, ...this.upNext.filter(entry => entry !== id)];
    this.notify();
  }
  move(id: string, toIndex: number, options: { cancelUpNext?: boolean } = {}): void {
    this.assertLive();
    const from = this.requireId(id);
    if (!Number.isInteger(toIndex) || toIndex < 0 || toIndex >= this.items.length) throw new RangeError('Queue move index is out of range');
    this.editRevision += 1;
    const [item] = this.items.splice(from, 1);
    this.items.splice(toIndex, 0, item);
    if (options.cancelUpNext) this.upNext = this.upNext.filter(entry => entry !== id);
    this.notify();
  }

  /** 当前项被删时取原位置后继（末尾取前项）；沿用播放/暂停意图，停止态不加载。 */
  async remove(id: string): Promise<boolean> {
    this.assertLive();
    const index = this.items.findIndex(item => item.id === id);
    if (index < 0) return false;
    this.editRevision += 1;
    const current = this.currentId === id;
    const autoplay = this.automaticPlaybackAllowed && (this.loading || !this.player.paused);
    const stopped = !this.loading && (this.player.state === 'stopped' || this.player.state === 'idle');
    this.items.splice(index, 1);
    this.pruneHistory(id);
    this.upNext = this.upNext.filter(entry => entry !== id);
    this.shuffleRemaining = this.shuffleRemaining.filter(entry => entry !== id);
    if (!current) { this.notify(); return true; }
    if (!this.items.length) {
      this.resetSelection(false);
      const stopping = this.player.stop();
      this.notify();
      try { await stopping; }
      catch (error) { if ((error as Error)?.name === 'AbortError') return false; throw error; }
      return true;
    }
    const replacement = this.items[Math.min(index, this.items.length - 1)];
    if (stopped) {
      this.resetSelection(false);
      this.currentId = replacement.id;
      this.notify();
      return true;
    }
    return this.selectId(replacement.id, { autoplay });
  }
  /** 清空并停止本队列所属媒体；与 setItems 的纯列表替换区分。 */
  async clear(): Promise<void> {
    this.assertLive();
    const owned = this.currentId !== null;
    this.editRevision += 1;
    this.items = []; this.history = []; this.historyIndex = -1; this.upNext = []; this.shuffleRemaining = [];
    this.resetSelection(false);
    const stopping = owned ? this.player.stop() : Promise.resolve();
    this.notify();
    await stopping;
  }

  select(index: number, options: QueueSelectOptions = {}): Promise<boolean> {
    this.assertLive();
    if (!Number.isInteger(index) || index < 0 || index >= this.items.length) return Promise.reject(new RangeError('Queue index is out of range'));
    return this.selectId(this.items[index].id, options);
  }
  selectId(id: string, options: QueueSelectOptions = {}): Promise<boolean> {
    this.assertLive();
    return this.startSelection(this.items[this.requireId(id)], options);
  }
  /** 首次选择、继续、停止后重载共用入口；不重新发起正在加载的选择。 */
  async play(): Promise<boolean> {
    this.assertLive();
    if (this.loading && this.pending) {
      return this.automaticPlaybackAllowed ? this.pending
        : this.startSelection(this.items[this.requireId(this.currentId!)], {}, this.selectionHistoryKey);
    }
    if (this.currentId === null) return this.items.length ? this.select(0) : false;
    if (this.loadedRevision !== this.revision || this.player.failed || this.player.state === 'stopped' || this.player.state === 'ended') {
      return this.selectId(this.currentId, { restart: this.player.state === 'ended' });
    }
    const revision = this.revision;
    this.error = null;
    try {
      await this.playSelected();
      if (!this.destroyed && revision === this.revision) this.recordPlayback();
      return !this.destroyed && revision === this.revision;
    } catch (error) {
      if (this.destroyed || revision !== this.revision || (error as Error)?.name === 'AbortError') return false;
      this.cancelAutoplay();
      if (this.error !== error) this.reportError(error);
      throw error;
    }
  }
  retry(): Promise<boolean> {
    this.assertLive();
    return this.currentId === null ? Promise.resolve(false) : this.selectId(this.currentId);
  }
  next(): Promise<boolean> {
    this.assertLive();
    if (!this.snapshot.canNext) return Promise.resolve(false);
    if (this.upNext.length) return this.selectId(this.upNext[0]);
    const forward = this.forwardIndex();
    if (forward >= 0) return this.selectHistory(forward);
    if (this.order === 'sequential') return this.select((this.indexOfCurrent() + 1) % this.items.length, { restart: true });
    if (!this.shuffleRemaining.length) this.refillShuffle();
    const id = this.shuffleRemaining[0] ?? this.currentId;
    return id ? this.selectId(id, { restart: true }) : Promise.resolve(false);
  }
  /** 查询不消费随机状态；新一轮由 next() 生成。 */
  peekNext(): Readonly<QueueItem> | null {
    if (this.repeat === 'one' || !this.snapshot.canNext) return null;
    const id = this.upNext[0] ?? this.history[this.forwardIndex()]?.id
      ?? (this.order === 'shuffle' ? this.shuffleRemaining[0] : this.items[(this.indexOfCurrent() + 1) % this.items.length]?.id);
    return this.items.find(item => item.id === id) ?? null;
  }
  /** 优先实际历史；顺序模式无历史时兼容相邻项，随机模式绝不猜测上一首。 */
  previous(): Promise<boolean> {
    this.assertLive();
    const previous = this.backIndex();
    if (previous >= 0) return this.selectHistory(previous);
    return this.order === 'sequential' && this.indexOfCurrent() > 0 ? this.select(this.indexOfCurrent() - 1) : Promise.resolve(false);
  }
  back(): Promise<boolean> {
    this.assertLive();
    const index = this.backIndex();
    return index >= 0 ? this.selectHistory(index) : Promise.resolve(false);
  }
  forward(): Promise<boolean> {
    this.assertLive();
    const index = this.forwardIndex();
    return index >= 0 ? this.selectHistory(index) : Promise.resolve(false);
  }
  /** 拆除队列保留当前媒体，撤销尚未完成的队列自动播放。 */
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    for (const unsubscribe of this.subscriptions) unsubscribe();
    this.playbackAbort?.abort();
    this.playbackAbort = null;
    this.items = [];
    this.history = [];
    this.historyIndex = -1;
    this.upNext = [];
    this.shuffleRemaining = [];
    this.resetSelection();
    this.dispatchEvent(new Event('destroy'));
  }

  private startSelection(item: Readonly<QueueItem>, options: QueueSelectOptions, historyKey: number | null = null): Promise<boolean> {
    const revision = ++this.revision;
    this.automaticSelection = -1;
    const autoplayRevision = ++this.autoplayRevision;
    const autoplay = options.autoplay ?? true;
    this.currentId = item.id;
    this.selectionHistoryKey = historyKey;
    this.loadedRevision = -1;
    this.error = null;
    this.automaticPlaybackAllowed = autoplay;
    this.loading = true;
    this.upNext = this.upNext.filter(id => id !== item.id);
    this.shuffleRemaining = this.shuffleRemaining.filter(id => id !== item.id);
    this.notify();
    if (this.destroyed || revision !== this.revision) return Promise.resolve(false);
    const pending = this.loadSelection(item, options, revision, autoplayRevision, autoplay);
    if (revision === this.revision) this.pending = pending;
    return pending;
  }
  private async loadSelection(item: Readonly<QueueItem>, options: QueueSelectOptions, revision: number, autoplayRevision: number, autoplay: boolean): Promise<boolean> {
    try {
      this.ownLoad = true;
      let pending: ReturnType<StudioPlayer['load']>;
      try { pending = this.player.load(item.source, { restart: options.restart }); }
      finally { this.ownLoad = false; }
      // 在等待存储/媒体前争取主媒体归属；被抢占方的 pauseintent 取消这次自动起播。
      if (autoplay && this.automaticPlaybackAllowed && revision === this.revision
        && !this.player.requestPlayback()) this.cancelAutoplay();
      await pending;
      if (this.destroyed || revision !== this.revision) return false;
      this.loadedRevision = revision;
      if (this.player.failed) throw this.error ?? new Error('Queue source could not be loaded');
      if (autoplay && this.automaticPlaybackAllowed && autoplayRevision === this.autoplayRevision) await this.playSelected();
      if (this.destroyed || revision !== this.revision) return false;
      this.recordPlayback();
      return !autoplay || autoplayRevision === this.autoplayRevision;
    } catch (error) {
      if (this.destroyed || revision !== this.revision) return false;
      this.cancelAutoplay();
      if ((error as { name?: string })?.name === 'AbortError') return false;
      if (this.error === null) this.reportError(error);
      throw error;
    } finally {
      if (revision === this.revision) { this.loading = false; this.pending = null; this.notify(); }
    }
  }
  private async playSelected(): Promise<void> {
    const controller = new AbortController();
    this.playbackAbort = controller;
    try { await this.player.play({ signal: controller.signal }); }
    finally { if (this.playbackAbort === controller) this.playbackAbort = null; }
  }
  private recordPlayback(): void {
    if (this.destroyed || this.currentId === null || this.loadedRevision !== this.revision || this.recordedRevision === this.revision
      || this.player.paused || this.player.failed || this.player.state !== 'playing') return;
    this.recordedRevision = this.revision;
    const target = this.history.findIndex(entry => entry.key === this.selectionHistoryKey);
    if (target >= 0) this.historyIndex = target;
    else {
      this.history.splice(this.historyIndex + 1);
      if (this.history[this.historyIndex]?.id !== this.currentId) {
        this.history.push({ key: ++this.historySerial, id: this.currentId });
        this.historyIndex = this.history.length - 1;
      }
    }
    this.selectionHistoryKey = this.history[this.historyIndex]?.key ?? null;
    this.error = null;
    this.notify();
  }
  private selectHistory(index: number): Promise<boolean> {
    const entry = this.history[index];
    return this.startSelection(this.items[this.requireId(entry.id)], {}, entry.key);
  }
  private backIndex(): number {
    const selected = this.history.findIndex(entry => entry.key === this.selectionHistoryKey);
    return selected >= 0 ? selected - 1 : this.historyIndex;
  }
  private forwardIndex(): number {
    const selected = this.history.findIndex(entry => entry.key === this.selectionHistoryKey);
    return selected >= 0 && selected + 1 < this.history.length ? selected + 1 : -1;
  }
  private pruneHistory(id: string): void {
    const beforeCursor = this.history.slice(0, this.historyIndex + 1).filter(entry => entry.id !== id).length;
    this.history = this.history.filter(entry => entry.id !== id);
    this.historyIndex = beforeCursor - 1;
  }
  private refillShuffle(): void {
    this.shuffleRemaining = this.items.filter(item => item.id !== this.currentId).map(item => item.id);
    for (let index = this.shuffleRemaining.length - 1; index > 0; index -= 1) {
      const selected = this.randomIndex(index + 1);
      [this.shuffleRemaining[index], this.shuffleRemaining[selected]] = [this.shuffleRemaining[selected], this.shuffleRemaining[index]];
    }
  }
  private randomIndex(length: number): number {
    const value = this.random();
    if (!Number.isFinite(value) || value < 0 || value >= 1) throw new RangeError('queue.random must return a number in [0, 1)');
    return Math.floor(value * length);
  }
  private validateItems(items: readonly QueueItem[], ids = new Set<string>()): Readonly<QueueItem>[] {
    return items.map(item => {
      if (typeof item.id !== 'string' || !item.id.trim() || ids.has(item.id)) throw new TypeError('Queue item IDs must be non-empty and unique');
      ids.add(item.id);
      return copyData(item);
    });
  }
  private indexOfCurrent(): number { return this.items.findIndex(item => item.id === this.currentId); }
  private requireId(id: string): number {
    const index = this.items.findIndex(item => item.id === id);
    if (index < 0) throw new RangeError(`Unknown queue item: ${id}`);
    return index;
  }
  private cancelAutoplay(): void { this.automaticPlaybackAllowed = false; this.autoplayRevision += 1; }
  private resetSelection(notify = true): void {
    this.revision += 1;
    this.cancelAutoplay();
    this.loading = false;
    this.pending = null;
    this.loadedRevision = -1;
    this.currentId = null;
    this.selectionHistoryKey = null;
    this.error = null;
    if (notify) this.notify();
  }
  private reportError(error: unknown): void {
    this.error = error;
    this.notify();
    this.dispatchEvent(new CustomEvent('error', { detail: error }));
  }
  private notify(): void { this.dispatchEvent(new Event('change')); }
  private assertLive(): void { if (this.destroyed) throw new Error('Queue has been destroyed'); }
}
