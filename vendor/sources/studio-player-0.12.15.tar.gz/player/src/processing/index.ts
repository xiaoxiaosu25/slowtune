import { MediaProcessingError, type MediaProcessingProfile, type MediaProcessingSession, type MediaProcessingState } from '../contracts/media-processing.js';
import type { PlaybackPlan } from '../contracts/plan.js';
import { MediaProbeError, type ProbedMedia } from '../contracts/media-probe.js';
import { normalizeFfprobeMedia } from '../source-adapter/probed-media.js';
import { createSeekableInput } from '../probe/seekable-input.js';
import { prepareProfile, verifyProfile, type ProcessingPolicy, type ProcessingSelection, type ProcessingDegradation } from './profiles.js';
export type { ProcessingPolicy, ProcessingSelection, ProcessingDegradation } from './profiles.js';

export interface ProcessingTool {
  readonly executable: string;
  readonly sha256: string;
  /** Host's acquisition record identifier; does not confer distribution rights. */
  readonly provenance: string;
}
export interface LocalMediaProcessorOptions {
  readonly ffmpeg: ProcessingTool;
  readonly ffprobe: ProcessingTool;
  /** Existing host-authorized directory. Each session gets its own exclusive child directory. */
  readonly outputRoot: string;
  readonly maxConcurrent?: number;
  readonly maxRetainedBytes?: number;
  /** Host-owned URL exposure; must settle and release its resources when cancelled. */
  readonly publishOutput?: (file: string, mimeType: string, signal: AbortSignal) => Promise<{ url: string; release(): Promise<void> }>;
}
export interface LocalMediaProcessingRequest {
  readonly file: string;
  readonly resourceId: string;
  readonly profile: MediaProcessingProfile;
  readonly selection?: ProcessingSelection;
  readonly policy?: ProcessingPolicy;
  readonly signal?: AbortSignal;
  /** Includes tool verification, probe, processing and output verification; cleanup is awaited. Default 30s. */
  readonly timeoutMs?: number;
  /** Cumulative source reads (probe + processing), including repeated ranges. Default 256MiB. */
  readonly maxReadBytes?: number;
  /** Accepted output cap, -fs hint and 20ms size monitoring; transient writes can exceed it. Default 128MiB. */
  readonly maxOutputBytes?: number;
  /** Cumulative stdout/stderr from tools, not retained in diagnostics. Default 2MiB. */
  readonly maxLogBytes?: number;
  /** Required free space in addition to the reserved output cap. Default 64MiB. */
  readonly minimumFreeBytes?: number;
}
export interface LocalProcessingEvidence {
  readonly inputBytesRead: number;
  readonly inputReadOperations: number;
  readonly outputBytes: number;
  readonly logBytes: number;
  readonly elapsedMs: number;
  readonly media: ProbedMedia;
  readonly trackMapping: readonly { readonly inputIndex: number; readonly outputIndex: number }[];
  readonly degradations: readonly ProcessingDegradation[];
  readonly quality?: { readonly codec: 'aac'; readonly profile: 'LC'; readonly bitrate: number; readonly coder: 'twoloop' };
  readonly outputLimit: 'accepted-file-cap-with-monitored-transient-overshoot';
}
export interface LocalMediaProcessingSession extends MediaProcessingSession {
  readonly evidence: LocalProcessingEvidence | undefined;
  /** Authorized Node host only; never included in diagnostics or browser facts. */
  readonly outputFile: string | undefined;
}
const builtin = (name: string): Promise<any> => import(/* @vite-ignore */ `node:${name}`);
const MiB = 1024 * 1024;
const bounded = (value: number | undefined, fallback: number, max: number, allowZero = false) => {
  const number = value ?? fallback;
  if (!Number.isSafeInteger(number) || number < (allowZero ? 0 : 1) || number > max) throw new MediaProcessingError('invalid-input');
  return number;
};
const absolute = (path: any, value: unknown): value is string => typeof value === 'string' && path.isAbsolute(value)
  && !value.includes('\0') && !/^[/\\]{2}/.test(value);
const probeEntries = ['-show_entries', 'format=format_name,duration:format_tags:stream=index,start_time,duration,codec_type,codec_name,codec_tag_string,profile,level,pix_fmt,bits_per_raw_sample,extradata,width,height,avg_frame_rate,bit_rate,channels,channel_layout,sample_rate,color_transfer:stream_tags:stream_disposition:chapter', '-show_data', '-of', 'json'];

class Session implements LocalMediaProcessingSession {
  state: MediaProcessingState = 'preparing';
  ready!: Promise<PlaybackPlan>;
  evidence: LocalProcessingEvidence | undefined;
  outputFile: string | undefined;
  readonly controller = new AbortController();
  cleanup: () => Promise<void> = async () => {};
  private releasing?: Promise<void>;
  constructor(readonly resourceId: string) {}
  async cancel(): Promise<void> {
    if (this.state !== 'preparing') return;
    this.controller.abort(new MediaProcessingError('cancelled'));
    await this.ready.catch(() => {});
  }
  release(): Promise<void> {
    if (this.releasing) return this.releasing;
    this.releasing = (async () => {
      await this.cancel(); await this.ready.catch(() => {});
      try { await this.cleanup(); this.outputFile = undefined; this.state = 'released'; }
      catch { this.releasing = undefined; throw new MediaProcessingError('cleanup-failed'); }
    })();
    return this.releasing;
  }
}

/** Optional Node host adapter. No shell, arbitrary arguments, automatic processing, or decoder distribution. */
export class LocalMediaProcessor {
  private readonly options: LocalMediaProcessorOptions;
  private readonly sessions = new Set<Session>();
  private active = 0;
  private reserved = 0;
  private destroyed = false;
  constructor(options: LocalMediaProcessorOptions) {
    this.options = { ...options, ffmpeg: { ...options.ffmpeg }, ffprobe: { ...options.ffprobe },
      maxConcurrent: bounded(options.maxConcurrent, 1, 4), maxRetainedBytes: bounded(options.maxRetainedBytes, 512 * MiB, 4 * 1024 * MiB) };
  }
  get isDestroyed(): boolean { return this.destroyed; }
  start(request: LocalMediaProcessingRequest): LocalMediaProcessingSession {
    const session = new Session(request.resourceId);
    const copied = { ...request, selection: { ...request.selection }, policy: { ...request.policy,
      discardStreams: request.policy?.discardStreams ? [...request.policy.discardStreams] : undefined } };
    this.sessions.add(session);
    session.ready = this.run(session, copied).then(plan => { session.state = 'ready'; return plan; }, error => {
      session.state = error instanceof MediaProcessingError && error.code === 'cancelled' ? 'cancelled' : 'failed'; throw error;
    });
    void session.ready.catch(() => {});
    return session;
  }
  async stop(): Promise<void> {
    const results = await Promise.allSettled([...this.sessions].map(session => session.release()));
    if (results.some(result => result.status === 'rejected')) throw new MediaProcessingError('cleanup-failed');
  }
  async destroy(): Promise<void> { this.destroyed = true; await this.stop(); }
  private async run(session: Session, request: LocalMediaProcessingRequest): Promise<PlaybackPlan> {
    const controller = session.controller, check = () => { if (controller.signal.aborted) throw controller.signal.reason; };
    const started = performance.now();
    let timer: ReturnType<typeof setTimeout> | undefined, watcher: ReturnType<typeof setInterval> | undefined;
    let handle: any, source: Awaited<ReturnType<typeof createSeekableInput>> | undefined;
    let directory: string | undefined, publication: { url: string; release(): Promise<void> } | undefined;
    let reserved = 0, acquired = false, logBytes = 0, cleanupRoot: string | undefined;
    let polling = Promise.resolve();
    const abort = () => controller.abort(new MediaProcessingError('cancelled'));
    const cleanup = async () => {
      if (publication) { await publication.release(); publication = undefined; }
      if (directory) {
        const [fs,path] = await Promise.all([builtin('fs/promises'),builtin('path')]);
        // Check the final absolute target before recursive Windows removal.
        if (!cleanupRoot || path.dirname(path.resolve(directory)) !== cleanupRoot
          || !path.basename(directory).startsWith('studio-media-')) throw new MediaProcessingError('cleanup-failed');
        await fs.rm(directory, { recursive: true, force: true }); directory = undefined;
      }
      if (reserved) { this.reserved -= reserved; reserved = 0; }
      this.sessions.delete(session);
    };
    session.cleanup = cleanup;
    try {
      const timeout = bounded(request.timeoutMs, 30000, 300000);
      const readBudget = bounded(request.maxReadBytes, 256 * MiB, 4 * 1024 * MiB);
      const outputBudget = bounded(request.maxOutputBytes, 128 * MiB, 1024 * MiB);
      const logBudget = bounded(request.maxLogBytes, 2 * MiB, 8 * MiB);
      const freeReserve = bounded(request.minimumFreeBytes, 64 * MiB, 4 * 1024 * MiB, true);
      if (this.destroyed || request.signal?.aborted) throw new MediaProcessingError('cancelled');
      if (this.active >= this.options.maxConcurrent!) throw new MediaProcessingError('busy');
      if (this.reserved + outputBudget > this.options.maxRetainedBytes!) throw new MediaProcessingError('space-limit');
      this.active++; acquired = true; this.reserved += outputBudget; reserved = outputBudget;
      request.signal?.addEventListener('abort', abort, { once: true });
      timer = setTimeout(() => controller.abort(new MediaProcessingError('timeout')), timeout);
      const [fs,path,cp,http,process,crypto,url] = await Promise.all(['fs/promises','path','child_process','http','process','crypto','url'].map(builtin));
      check();
      if (!absolute(path, request.file) || !absolute(path,this.options.outputRoot) || typeof request.resourceId !== 'string'
        || !request.resourceId.trim() || request.resourceId.length > 512) throw new MediaProcessingError('invalid-input');
      const root = await fs.realpath(this.options.outputRoot); check();
      cleanupRoot = root;
      const rootStat = await fs.stat(root);
      if (!rootStat.isDirectory()) throw new MediaProcessingError('invalid-input');
      const space = await fs.statfs(root); check();
      if (space.bavail * space.bsize < this.reserved + freeReserve) throw new MediaProcessingError('space-limit');
      const execute = (executable: string, args: readonly string[], invalidCode: 'unavailable' | 'invalid-media' | 'processing-failed') =>
        new Promise<string>((resolve,reject) => {
          check(); let text = '', failure: MediaProcessingError | undefined;
          const child = cp.spawn(executable,args,{ shell: false, windowsHide: true, stdio: ['ignore','pipe','pipe'],
            env: { ...process.env, http_proxy:'',HTTP_PROXY:'',https_proxy:'',HTTPS_PROXY:'',all_proxy:'',ALL_PROXY:'',no_proxy:'127.0.0.1',NO_PROXY:'127.0.0.1' } });
          const fail = (error: MediaProcessingError) => { if (!failure) { failure = error; child.kill('SIGKILL'); } };
          const onAbort = () => fail(controller.signal.reason);
          controller.signal.addEventListener('abort',onAbort,{once:true});
          child.on('error',() => fail(new MediaProcessingError('unavailable')));
          const consume = (chunk: any, collect: boolean) => {
            logBytes += chunk.byteLength;
            if (logBytes > logBudget) controller.abort(new MediaProcessingError('log-limit'));
            else if (collect && !failure) text += chunk.toString('utf8');
          };
          child.stdout.on('data',(chunk: any) => consume(chunk,true)); child.stderr.on('data',(chunk: any) => consume(chunk,false));
          child.on('close',(code: number | null) => {
            controller.signal.removeEventListener('abort',onAbort);
            if (failure) reject(failure); else if (code !== 0) reject(new MediaProcessingError(invalidCode)); else resolve(text);
          });
          if (controller.signal.aborted) onAbort();
        });
      // Verify each invocation's exact binaries. No mutable global executable discovery.
      for (const tool of [this.options.ffmpeg,this.options.ffprobe]) {
        if (!absolute(path,tool.executable) || !/^[a-f0-9]{64}$/i.test(tool.sha256 ?? '') || !tool.provenance?.trim()) throw new MediaProcessingError('unavailable');
        let bytes: any;
        try {
          const toolStat = await fs.stat(tool.executable);
          if (!toolStat.isFile() || toolStat.size > 256 * MiB) throw new MediaProcessingError('unavailable');
          bytes = await fs.readFile(tool.executable);
        } catch { throw new MediaProcessingError('unavailable'); }
        check(); if (crypto.createHash('sha256').update(bytes).digest('hex') !== tool.sha256.toLowerCase()) throw new MediaProcessingError('tool-mismatch');
        const version = await execute(tool.executable,['-version'],'unavailable');
        if (!/configuration:/.test(version) || /--enable-(gpl|nonfree|libx264|libx265|libfdk-aac)\b/.test(version)) throw new MediaProcessingError('tool-policy');
      }
      handle = await fs.open(request.file,fs.constants.O_RDONLY | (fs.constants.O_NONBLOCK ?? 0)); check();
      const stat = await handle.stat();
      if (!stat.isFile() || !stat.size || !Number.isSafeInteger(stat.size)) throw new MediaProcessingError('invalid-media');
      const inputFail = (error: MediaProbeError) => controller.abort(new MediaProcessingError(error.code === 'probe-limit' ? 'read-limit' : 'invalid-media'));
      source = await createSeekableInput(http,handle,stat.size,readBudget,controller.signal,inputFail,
        { maxRequests:256, maxOperations:Math.min(131072,Math.ceil(readBudget / 32768) + 256) });
      const inspect = async (endpoint: string) => {
        const json = await execute(this.options.ffprobe.executable,['-v','error','-protocol_whitelist','http,tcp',
          '-format_whitelist','mov,matroska,webm,flac','-probesize',String(Math.min(readBudget,8*MiB)),'-analyzeduration','1000000',...probeEntries,'-i',endpoint],'invalid-media');
        try { return JSON.parse(json); } catch { throw new MediaProcessingError('invalid-media'); }
      };
      const raw = await inspect(source.url); check();
      const prepared = prepareProfile(request.profile,raw,source.snapshot().header!,request.selection,request.policy);
      directory = await fs.mkdtemp(path.join(root,'studio-media-')); check();
      if (path.dirname(await fs.realpath(directory)) !== root) throw new MediaProcessingError('invalid-input');
      const output = path.join(directory,`output.${prepared.extension}`);
      // Private fresh directory + -n: no existing output may be overwritten.
      let monitoring = true;
      watcher = setInterval(() => {
        if (!monitoring) return;
        monitoring = false;
        polling = (async () => {
          try { const current = await fs.stat(output); if (current.size > outputBudget) controller.abort(new MediaProcessingError('output-limit')); }
          catch (error: any) { if (error.code !== 'ENOENT') controller.abort(new MediaProcessingError('processing-failed')); }
          finally { monitoring = true; }
        })();
      },20);
      await execute(this.options.ffmpeg.executable,['-hide_banner','-v','error','-nostdin','-n','-threads','1','-filter_threads','1',
        '-protocol_whitelist','http,tcp','-format_whitelist','mov,matroska,webm','-probesize',String(Math.min(readBudget,8*MiB)),
        '-analyzeduration','1000000',...(request.profile==='h264-ac3-to-aac'?['-drc_scale','0']:[]),
        '-i',source.url,...prepared.args,'-threads','1','-fs',String(outputBudget),output],'processing-failed');
      clearInterval(watcher); watcher = undefined; await polling; check();
      const outputStat = await fs.stat(output);
      if (!outputStat.size || outputStat.size >= outputBudget) throw new MediaProcessingError('output-limit');
      const sourceStats = source.snapshot(); await source.close(); source = undefined;
      const after = await fs.stat(request.file);
      if (after.dev !== stat.dev || after.ino !== stat.ino || after.size !== stat.size || after.mtimeMs !== stat.mtimeMs) throw new MediaProcessingError('invalid-media');
      await handle.close(); handle = undefined;
      // Output inspection has a separate bounded read scope, never feeds an unchecked file URL to ffprobe.
      const outputHandle = await fs.open(output,'r');
      let outputSource: Awaited<ReturnType<typeof createSeekableInput>> | undefined;
      let verified: any, neutral: ProbedMedia;
      try {
        outputSource = await createSeekableInput(http,outputHandle,outputStat.size,Math.min(64*MiB,outputBudget*4),controller.signal,inputFail,
          { maxRequests:64, maxOperations:2048 });
        verified = await inspect(outputSource.url); check();
        neutral = normalizeFfprobeMedia(verified,false,{ seekable:true,header:outputSource.snapshot().header });
        if (neutral.container?.kind !== 'mp4' || !neutral.tracks.length) throw new MediaProcessingError('verification-failed');
        verifyProfile(prepared,raw,verified,request.policy ?? {});
      } finally { await outputSource?.close(); await outputHandle.close(); }
      check();
      publication = this.options.publishOutput ? await this.options.publishOutput(output,prepared.mimeType,controller.signal)
        : { url:url.pathToFileURL(output).href, release:async () => {} };
      check();
      if (!publication || typeof publication.url !== 'string' || !publication.url || typeof publication.release !== 'function') throw new MediaProcessingError('verification-failed');
      session.outputFile = output;
      session.evidence = Object.freeze({ inputBytesRead:sourceStats.bytesRead,inputReadOperations:sourceStats.readOperations,
        outputBytes:outputStat.size,logBytes,elapsedMs:performance.now()-started,media:neutral!,
        trackMapping:Object.freeze(prepared.streams.map((stream,index) => Object.freeze({inputIndex:stream.index,outputIndex:index}))),
        degradations:Object.freeze(prepared.degradations.map(item => Object.freeze({...item}))),quality:prepared.quality,
        outputLimit:'accepted-file-cap-with-monitored-transient-overshoot' });
      return {resourceId:request.resourceId,mediaType:prepared.mediaType,strategy:prepared.lossy?'transcode':'direct',transport:'range',
        playUrl:publication.url,mimeType:prepared.mimeType,durationSeconds:neutral!.durationSeconds,
        processing:{available:true,recommendedMode:request.profile,session} };
    } catch (error) {
      clearInterval(watcher); watcher = undefined; await polling;
      await source?.close(); source = undefined; await handle?.close().catch(() => {}); handle = undefined;
      try { await cleanup(); } catch { throw new MediaProcessingError('cleanup-failed'); }
      if (controller.signal.aborted) throw controller.signal.reason;
      if (error instanceof MediaProcessingError) throw error;
      if (error instanceof MediaProbeError) throw new MediaProcessingError('invalid-media');
      throw new MediaProcessingError('processing-failed');
    } finally {
      clearTimeout(timer); clearInterval(watcher);
      request.signal?.removeEventListener('abort',abort); if (acquired) this.active--;
    }
  }
}
