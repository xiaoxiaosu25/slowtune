/**
 * Video.js 后端：承载元素上的轨道列表读取与选择写入
 *
 * 本模块承载 Video.js 后端的轨道约定：承载元素上的音轨列表与画质（rendition）列表的读取、
 * 条目包装与可用/选中/生效状态的回报、选择写入，以及锁定上游 rc.2 所需的重发原语。核心只按
 * 这里的接口拿结果，不再直接读承载元素上的列表属性。
 *
 * 列表事件的订阅与 rc.2 重发的触发规则仍留核心：本模块除了提供 `TrackPort` 的
 * 音轨/字幕通路，也提供 `audioList()`、`renditionList()`、`dispatchRenditionChange()`
 * 与 `currentTime()` 这些画质兼容原语。
 *
 * 依赖方向是单向的：`video-tracks/index.ts` → 本模块。本模块不导入 `player.ts`，
 * 也不导入 `video-tracks`，不形成循环。
 */

import type { PlayerInstance, TrackPort, TrackPortOption, TrackPortSnapshot } from '../../contracts/ports.js';
import type { SubtitleTrack } from '../../contracts/tracks.js';
import { normalizeSubtitles } from '../../source-adapter/subtitles.js';

/**
 * 包装一个后端已知可用的轨道列表：元素没有对应列表时返回 null。
 *
 * 真实列表对象同时是 `ArrayLike` 与 `EventTarget`；这里只按存在性收窄，不复制列表内容。
 */
function listOf<T>(value: T | null | undefined): (T & ArrayLike<unknown> & EventTarget) | null {
  return value && typeof value === 'object' && 'length' in value ? value as T & ArrayLike<unknown> & EventTarget : null;
}

/**
 * 后端音轨列表里的一条音轨；`raw` 保留底层条目，用于包装身份与选择写入。
 *
 * 字段类型不带 `readonly`：包装对象按底层条目缓存（身份稳定），但取值必须在每次读取时
 * 刷新为**当前状态**，否则上游改写同一条目后核心会读到过期值。对外契约仍是只读的。
 */
export interface EngineAudioTrack {
  id: string;
  label?: string;
  language?: string;
  enabled: boolean;
  raw: unknown;
}

/** 后端画质（rendition）列表里的一档；`selected` 是请求值，`active` 是实际生效值。 */
export interface EngineRendition {
  id: string;
  width?: number;
  height?: number;
  bitrate?: number;
  selected: boolean;
  active: boolean;
  raw: unknown;
}

/** 核心读写后端轨道列表的唯一入口；由 `trackAccessOf()` 按承载元素创建。 */
export interface EngineTrackAccess {
  audio(): readonly EngineAudioTrack[];
  renditions(): readonly EngineRendition[];
  audioList(): EventTarget | null;
  renditionList(): EventTarget | null;
  selectAudio(track: EngineAudioTrack): void;
  renditionSelectedIndex(): number;
  setRenditionSelectedIndex(index: number): void;
  activeRenditionIndex(): number;
  dispatchRenditionChange(): void;
  currentTime(): number;
}

/** 底层条目上可能出现的字段；只读公开列表的约定，不访问引擎私有字段。 */
type RawAudioEntry = { id?: string; label?: string; language?: string; enabled?: boolean };
type RawRenditionEntry = {
  id?: string;
  width?: number;
  height?: number;
  bitrate?: number;
  active?: boolean;
};
type RenditionList = { selectedIndex: number };

const audioAccess = new WeakMap<object, Map<object, EngineAudioTrack>>();
const renditionAccess = new WeakMap<object, Map<object, EngineRendition>>();

/** 取该承载元素上音轨条目的包装缓存；同一底层条目必须每次返回同一个包装对象。 */
function audioCacheFor(media: object): Map<object, EngineAudioTrack> {
  let cache = audioAccess.get(media);
  if (!cache) { cache = new Map(); audioAccess.set(media, cache); }
  return cache;
}

/** 取该承载元素上画质条目的包装缓存；同一底层条目必须每次返回同一个包装对象。 */
function renditionCacheFor(media: object): Map<object, EngineRendition> {
  let cache = renditionAccess.get(media);
  if (!cache) { cache = new Map(); renditionAccess.set(media, cache); }
  return cache;
}

/** 音轨标识：底层 id，缺失时用索引；与今天的 `audioId()` 取值一致。 */
function audioId(entry: RawAudioEntry, index: number): string {
  return entry.id || String(index);
}

/** 画质标识：底层 id，缺失时用索引；与今天的 `qualityId()` 取值一致。 */
function renditionId(entry: RawRenditionEntry, index: number): string {
  return entry.id || String(index);
}

/** 包装一条音轨；缓存按底层条目而非列表，列表被上游整体替换后身份仍稳定。 */
function toAudioTrack(media: HTMLMediaElement, cache: Map<object, EngineAudioTrack>, entry: unknown, index: number): EngineAudioTrack {
  const raw = entry as RawAudioEntry;
  let track = cache.get(raw as object);
  if (!track) {
    track = { id: audioId(raw, index), label: raw.label, language: raw.language, enabled: raw.enabled === true, raw };
    cache.set(raw as object, track);
  }
  // 身份稳定、取值最新：id 由首次见到的索引定下（与今天的 `audioId()` 一致），
  // 其余字段按本次读取的上游状态刷新，避免上游改写同一条目后核心读到过期值。
  track.label = raw.label;
  track.language = raw.language;
  track.enabled = raw.enabled === true;
  return track;
}

/**
 * 包装一档画质。
 *
 * `active` 逐字保留既有判定：底层条目 `active` 为真；或列表内**没有任何** active 项时，
 * 按 `height` 与元素当前 `videoHeight` 相等判定。`height` 与 `videoHeight` 都是真值才成立。
 */
function toRendition(
  media: HTMLMediaElement & { videoHeight?: number },
  cache: Map<object, EngineRendition>,
  entry: unknown,
  index: number,
  selectedIndex: number,
  hasActiveEntry: boolean,
): EngineRendition {
  const raw = entry as RawRenditionEntry;
  let rendition = cache.get(raw as object);
  if (!rendition) {
    rendition = { id: renditionId(raw, index), width: raw.width, height: raw.height, bitrate: raw.bitrate, selected: false, active: false, raw };
    cache.set(raw as object, rendition);
  }
  // 身份稳定、取值最新：请求值来自本次列表的 selectedIndex，生效值来自本次列表的 active 状态。
  rendition.width = raw.width;
  rendition.height = raw.height;
  rendition.bitrate = raw.bitrate;
  rendition.selected = selectedIndex === index;
  rendition.active = raw.active === true
    || (!hasActiveEntry && Boolean(raw.height && raw.height === media.videoHeight));
  return rendition;
}

/** 按承载元素创建一个轨道访问器；同一个元素每次返回同一个实例。 */
function createAccess(media: HTMLMediaElement & { videoHeight?: number }): EngineTrackAccess {
  const audioCache = audioCacheFor(media);
  const renditionCache = renditionCacheFor(media);
  const readAudioList = (): (ArrayLike<unknown> & EventTarget) | null => listOf(
    (media as HTMLMediaElement & { audioTracks?: ArrayLike<unknown> & EventTarget }).audioTracks,
  );
  const readRenditionList = (): ((ArrayLike<unknown> & EventTarget) & RenditionList) | null => listOf(
    (media as HTMLMediaElement & { videoRenditions?: (ArrayLike<unknown> & EventTarget) & RenditionList }).videoRenditions,
  );
  const entriesOf = (list: ArrayLike<unknown> | null): unknown[] => (list ? Array.from(list) : []);
  const selectedIndexOf = (list: ((ArrayLike<unknown> & EventTarget) & RenditionList) | null): number => list?.selectedIndex ?? -1;

  return {
    /** 每次读取当前列表；列表被整体替换后能读到最新内容，包装身份仍按底层条目缓存。 */
    audio(): readonly EngineAudioTrack[] {
      const list = readAudioList();
      return entriesOf(list).map((entry, index) => toAudioTrack(media, audioCache, entry, index));
    },
    /** 每次读取当前列表；`selected` 与 `active` 都取自本次读取的列表状态。 */
    renditions(): readonly EngineRendition[] {
      const list = readRenditionList();
      const entries = entriesOf(list);
      const selectedIndex = selectedIndexOf(list);
      const hasActiveEntry = entries.some(entry => (entry as RawRenditionEntry).active === true);
      return entries.map((entry, index) => toRendition(media, renditionCache, entry, index, selectedIndex, hasActiveEntry));
    },
    /** 原始音轨列表对象；元素未暴露该列表时 null，核心用它做身份比较与事件订阅。 */
    audioList(): EventTarget | null {
      return readAudioList();
    },
    /** 原始画质列表对象；元素未暴露该列表时 null，核心用它做身份比较与事件订阅。 */
    renditionList(): EventTarget | null {
      return readRenditionList();
    },
    /**
     * 选择一条音轨；顺序逐字保留：先启用新轨，再禁用当前列表里其它已启用的轨，
     * 避免浏览器在全部禁用的间隙自动选回默认。比较按底层条目（`raw`）而不是包装对象。
     */
    selectAudio(track: EngineAudioTrack): void {
      const chosen = track.raw as RawAudioEntry;
      if (chosen.enabled !== true) chosen.enabled = true;
      for (const entry of entriesOf(readAudioList())) {
        const other = entry as RawAudioEntry;
        if (other !== chosen && other.enabled === true) other.enabled = false;
      }
    },
    /** 画质请求值；`auto` 仍是 -1。 */
    renditionSelectedIndex(): number {
      return selectedIndexOf(readRenditionList());
    },
    /** 写入画质请求值；`auto` 仍是 -1。 */
    setRenditionSelectedIndex(index: number): void {
      const list = readRenditionList();
      if (list) list.selectedIndex = index;
    },
    /** 当前实际生效的档位索引；没有 active 项时为 -1，供核心拼接重发签名。 */
    activeRenditionIndex(): number {
      const list = readRenditionList();
      return entriesOf(list).findIndex(entry => (entry as RawRenditionEntry).active === true);
    },
    /** 让上游公开列表自己重发一次 `change`；这是锁定 rc.2 所需的重发原语，节流在核心。 */
    dispatchRenditionChange(): void {
      readRenditionList()?.dispatchEvent(new Event('change'));
    },
    /** 元素当前时间；核心用它计算 rc.2 重发签名。 */
    currentTime(): number {
      return media.currentTime;
    },
  };
}

const accessCache = new WeakMap<object, EngineTrackAccess>();

/**
 * 取承载元素上的轨道访问器；`media` 为 `null`/`undefined` 时返回 null。
 *
 * 每个元素一个实例，核心按元素变化重建引用即可。元素没有对应列表时不抛错：
 * `audio()`/`renditions()` 返回空数组，`audioList()`/`renditionList()` 返回 null。
 */
export function trackAccessOf(media: unknown): EngineTrackAccess | null {
  if (!media || typeof media !== 'object') return null;
  const element = media as HTMLMediaElement & { videoHeight?: number };
  let access = accessCache.get(element);
  if (!access) { access = createAccess(element); accessCache.set(element, access); }
  return access;
}

type DisposableTrackPort = TrackPort & { dispose(): void };

/**
 * Video.js 的自定义媒体元素把 light-DOM 的 `<track>` 克隆到真实媒体元素。
 * `textTracks` 代理到这个 target，但 `HTMLTrackElement.track` 仍指向 light-DOM
 * 那一份；默认模式必须写入真实 target，否则 HLS 装载后 target 轨道仍保持 disabled，
 * 浏览器不会解析 cues。
 */
type VideojsMediaElement = HTMLMediaElement & { target?: HTMLMediaElement | null };

function textMediaOf(media: HTMLMediaElement): HTMLMediaElement {
  const target = (media as VideojsMediaElement).target;
  return target && target !== media && typeof target === 'object' ? target : media;
}

const qualityAccessByPort = new WeakMap<object, EngineTrackAccess>();

/**
 * Video.js 的后端中立轨道端口。DOM、外挂字幕节点和上游列表事件都留在这里；
 * `VideoTracksController` 只消费快照、选择方法与变更通知。
 */
export function createVideojsTrackPort(
  media: HTMLMediaElement,
  instance: PlayerInstance,
  getSubtitles: () => readonly SubtitleTrack[],
  getTimelineOffset: () => number = () => 0,
): DisposableTrackPort {
  const access = trackAccessOf(media);
  const textMedia = textMediaOf(media);
  const listeners = new Set<() => void>();
  const cleanups: Array<() => void> = [];
  const owned: HTMLTrackElement[] = [];
  let unavailable: TrackPortOption[] = [];
  let manifestKey = '';
  let defaultSubtitleId: string | null = null;
  let subtitleSelectionTouched = false;
  let disposed = false;
  let audioList: EventTarget | null = null;
  let textList: EventTarget | null = null;
  const subtitleTasks = new Set<AbortController>();
  const subtitleUrls = new Set<string>();

  const caption = (track: TextTrack): boolean => track.kind === 'subtitles' || track.kind === 'captions';
  const textId = (track: TextTrack, index: number): string =>
    track.id || `text:${index}:${track.kind}:${track.language}:${track.label}`;
  const values = <T>(list?: ArrayLike<T> | null): T[] => list ? Array.from(list) : [];
  const notify = () => {
    if (!disposed) for (const listener of [...listeners]) listener();
  };
  const listen = (target: EventTarget | null | undefined, name: string, callback: EventListener, capture = false): void => {
    if (!target?.addEventListener) return;
    target.addEventListener(name, callback, capture);
    cleanups.push(() => target.removeEventListener(name, callback, capture));
  };
  const removeOwned = (): void => {
    for (const task of subtitleTasks) task.abort(); subtitleTasks.clear();
    for (const url of subtitleUrls) URL.revokeObjectURL(url); subtitleUrls.clear();
    for (const track of owned) {
      track.removeEventListener('load', notify);
      track.removeEventListener('error', notify);
      track.track && (track.track.mode = 'disabled');
      const targetTrack = values(textMedia.textTracks).find(item => item.id === track.id);
      if (targetTrack) targetTrack.mode = 'disabled';
      track.remove();
    }
    owned.length = 0;
    unavailable = [];
  };
  const subtitleSupport = (track: SubtitleTrack): string | null => {
    if (!media.ownerDocument || !media.textTracks || typeof (media as any).append !== 'function') {
      return '当前浏览器不支持外挂字幕';
    }
    if ((track.type && track.type !== 'text/vtt') || /.(srt|ass|ssa)(?:[?#]|$)/i.test(track.src)) {
      return '请提供 WebVTT 格式字幕';
    }
    return null;
  };
  const syncNativeDefault = (): void => {
    if (disposed || subtitleSelectionTouched || !defaultSubtitleId) return;
    const targetTrack = values(textMedia.textTracks).find(track => track.id === defaultSubtitleId);
    if (!targetTrack || !caption(targetTrack)) return;
    for (const track of values(textMedia.textTracks).filter(caption)) {
      const mode = track === targetTrack ? 'showing' : 'disabled';
      if (track.mode !== mode) track.mode = mode;
    }
  };
  const syncManifest = (): void => {
    const subtitles = getSubtitles() ?? [];
    const offset = getTimelineOffset();
    const key = JSON.stringify([subtitles, offset]);
    if (key !== manifestKey) {
      removeOwned();
      manifestKey = key;
      defaultSubtitleId = subtitles.find(track => track.default === true
        && (track.kind === undefined || track.kind === 'subtitles' || track.kind === 'captions'))?.id ?? null;
      subtitleSelectionTouched = false;
      for (const track of subtitles) {
        const reason = subtitleSupport(track);
        if (reason) {
          unavailable.push({ id: track.id, label: track.label, language: track.language, selected: false, status: 'unavailable', reason });
          continue;
        }
        const node = media.ownerDocument!.createElement('track');
        node.id = track.id;
        node.kind = track.kind ?? 'subtitles';
        node.label = track.label;
        node.srclang = track.language;
        if (!offset) node.src = track.src;
        else {
          const controller = new AbortController(); subtitleTasks.add(controller);
          const fail = (reason: string): void => {
            if (disposed || !owned.includes(node)) return;
            unavailable.push({ id: track.id, label: track.label, language: track.language, selected: false, status: 'error', reason });
            notify();
          };
          const timer = setTimeout(() => {
            controller.abort();
            fail('字幕请求超时，请重试');
          }, 10000);
          controller.signal.addEventListener('abort', () => clearTimeout(timer), { once: true });
          void fetch(track.src, {signal:controller.signal,credentials:'same-origin'}).then(async response => {
            if (controller.signal.aborted) { void response.body?.cancel().catch(() => {}); return; }
            if (!response.ok) throw new Error('Subtitle request failed');
            if (Number(response.headers.get('Content-Length')) > 8 * 1024 * 1024) throw new Error('Subtitle exceeds limit');
            const reader = response.body?.getReader(); if (!reader) throw new Error('Subtitle body unavailable');
            const chunks: Uint8Array[] = []; let bytes = 0;
            while (true) { const part = await reader.read(); if (part.done) break; bytes += part.value.byteLength; if (bytes > 8 * 1024 * 1024) { await reader.cancel(); throw new Error('Subtitle exceeds limit'); } chunks.push(part.value); }
            const merged = new Uint8Array(bytes); let cursor = 0; for (const chunk of chunks) {merged.set(chunk,cursor);cursor+=chunk.length;}
            const content = normalizeSubtitles(new TextDecoder('utf-8',{fatal:true}).decode(merged),offset);
            if (disposed || controller.signal.aborted || !owned.includes(node)) return;
            const url = URL.createObjectURL(new Blob([content],{type:'text/vtt'})); subtitleUrls.add(url); node.src = url;
          }).catch(() => { if (!controller.signal.aborted) fail('字幕时间轴转换失败'); })
            .finally(() => {clearTimeout(timer);subtitleTasks.delete(controller);});
        }
        node.default = track.default === true;
        node.addEventListener('load', notify);
        node.addEventListener('error', notify);
        media.append(node);
        owned.push(node);
        if (node.id === defaultSubtitleId && node.track) node.track.mode = 'showing';
      }
    }
    // On custom Video.js elements the target track is created from the light-DOM
    // node on a later slot/microtask. Reassert here on each media event until the
    // user makes an explicit subtitle choice.
    syncNativeDefault();
  };
  const syncListListeners = (): void => {
    const nextAudio = access?.audioList() ?? null;
    const nextText = textMedia.textTracks ?? null;
    if (nextAudio === audioList && nextText === textList) return;
    audioList = nextAudio;
    textList = nextText;
    // List objects are replaced by Video.js during source changes. Rebinding the
    // small set of public events is cheaper and safer than keeping old objects alive.
    for (const cleanup of cleanups.splice(0)) cleanup();
    for (const event of ['loadstart', 'loadedmetadata', 'canplay', 'resize', 'playing', 'timeupdate', 'addtrack', 'removetrack', 'change', 'emptied']) {
      listen(media, event, () => { syncManifest(); syncListListeners(); notify(); });
    }
    for (const list of [audioList, textList]) {
      for (const event of ['change', 'addtrack', 'removetrack']) listen(list, event, () => { syncManifest(); syncListListeners(); notify(); });
    }
    // Track load/error do not bubble. Observe the real media's cloned nodes even
    // while playback is paused; the light-DOM nodes never become loaded.
    for (const event of ['load', 'error']) listen(textMedia, event, event => {
      const node = event.target as HTMLTrackElement | null;
      if (node?.tagName === 'TRACK' && owned.some(item => item.id === node.id)) notify();
    }, true);
  };

  // Install the first listener set before the first snapshot. Subsequent source/list
  // changes are rebound by the same adapter and never leak into the controller.
  syncManifest();
  syncListListeners();

  const port: DisposableTrackPort = {
    instance,
    get snapshot(): TrackPortSnapshot {
      syncManifest();
      syncListListeners();
      const subtitles = values(textMedia.textTracks).flatMap((track, index): TrackPortOption[] => {
        if (!caption(track)) return [];
        const node = values(textMedia.querySelectorAll?.('track')).find(item => item.track === track)
          ?? owned.find(item => item.id === track.id || item.track === track);
        const status: TrackPortOption['status'] = node?.readyState === 3
          ? 'error' : node && node.readyState !== 2 ? 'loading' : 'ready';
        return [{
          id: textId(track, index),
          label: track.label || track.language || `字幕 ${index + 1}`,
          language: track.language,
          selected: track.mode === 'showing',
          status,
          ...(status === 'error' ? { reason: '字幕加载失败，请检查文件或换一个字幕。' } : {}),
        }];
      });
      for (const failure of unavailable) {
        const index = subtitles.findIndex(track => track.id === failure.id);
        if (index >= 0) subtitles[index] = failure;
        else subtitles.push(failure);
      }
      const audio = (access?.audio() ?? []).map((track, index): TrackPortOption => ({
        id: track.id,
        label: track.label || track.language || `音轨 ${index + 1}`,
        language: track.language,
        selected: track.enabled,
        status: 'ready',
      }));
      return Object.freeze({
        audio: Object.freeze(audio.map(track => Object.freeze(track))),
        subtitles: Object.freeze(subtitles.map(track => Object.freeze(track))),
        audioTrack: audio.find(track => track.selected)?.id ?? null,
        subtitle: subtitles.find(track => track.selected)?.id ?? 'off',
      });
    },
    selectAudioTrack(id: string): void {
      const track = access?.audio().find(entry => entry.id === id);
      if (!track) {
        const error = new Error('Audio track selection is not available');
        error.name = 'NotSupportedError';
        throw error;
      }
      access!.selectAudio(track);
      notify();
    },
    selectSubtitle(id: string): void {
      syncManifest();
      const tracks = values(textMedia.textTracks).filter(caption);
      if (id !== 'off' && !tracks.some((track, index) => textId(track, index) === id)) {
        const error = new Error('Subtitle is not available');
        error.name = 'NotSupportedError';
        throw error;
      }
      subtitleSelectionTouched = true;
      for (const [index, track] of tracks.entries()) {
        track.mode = id !== 'off' && textId(track, index) === id ? 'showing' : 'disabled';
      }
      notify();
    },
    onChange(listener: () => void): () => void {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    dispose(): void {
      if (disposed) return;
      disposed = true;
      for (const cleanup of cleanups.splice(0)) cleanup();
      removeOwned();
      listeners.clear();
      qualityAccessByPort.delete(port);
    },
  };
  qualityAccessByPort.set(port, access ?? {
    audio: () => [], renditions: () => [], audioList: () => null, renditionList: () => null,
    selectAudio: () => {}, renditionSelectedIndex: () => -1, setRenditionSelectedIndex: () => {},
    activeRenditionIndex: () => -1, dispatchRenditionChange: () => {}, currentTime: () => media.currentTime,
  });
  return port;
}

/** 画质仍是 Video.js 的兼容扩展，不进入 U5-2 定稿的窄 TrackPort。 */
export function qualityAccessOf(port: TrackPort | null): EngineTrackAccess | null {
  if (!port || typeof port !== 'object') return null;
  return qualityAccessByPort.get(port) ?? null;
}
