/**
 * Video.js 后端：承载元素发现与两条交付通路
 *
 * 本模块承载 Video.js 后端的 DOM 约定：承载元素的标签判据、容器名与容器内查找顺序，
 * 以及声明式 `source` 与原生 `src` 两条应用/释放通路。核心只按中立承载方式调用这里，
 * 不再持有任何上游元素标签。
 *
 * 依赖方向是单向的：`player.ts` → 本模块。本模块只从 `contracts/delivery.ts` 取中立
 * 类型、从同目录 `source.ts` 取上游描述组装与等价判定，不反向导入 `player.ts`。
 * 这是 U1 的单后端现状：U2 第 2 步接入 mpv 时没有建立注入点——后端选择走核心内部的
 * 进程环境信号；本模块就是接第二后端时要替换掉的那一层（见 docs/audio-video/player/03 第 3.2 节）。
 */

import type { DeliveryCarrier, DeliveryTarget } from '../../contracts/delivery.js';
import { isSameVideojsSource, toVideojsSource } from './source.js';
import { flvFor, isFlv } from './flv.js';

/**
 * 判断标签名是否本身就是媒体元素。
 *
 * 原生 `video`/`audio`，以及上游各媒体适配器自定义元素（`<hlsjs-video>`、
 * `<dash-video>`、`<shaka-video>`、`<native-hls-video>`、`<mux-audio>` 等，
 * 形如 `*-video` / `*-audio`）。容器元素如 `<video-player>`、`<audio-player>`
 * 以 `-player` 结尾，不会误判为媒体元素。
 */
function isMediaElementTag(tagName: string): boolean {
  return tagName === 'video' || tagName === 'audio' || /-(video|audio)$/.test(tagName);
}

/**
 * 选择实际承载播放的元素；受管（MSE）与原生承载各自优先选择对应元素。
 *
 * **只在本容器内查找，不做页面级兜底**：在宿主页面里抓第一个 `<video>` 会静默
 * 劫持与本播放器无关的元素。找不到时返回 null，由 `attach()` 显式失败。
 *
 * 容器内只查找 `<hlsjs-video>` 与 `video, audio`；使用其它上游媒体元素
 * （如 `<dash-video>`）时请直接把该元素传给 `attach()`。
 */
export function resolveElement(
  element: any,
  carrier: DeliveryCarrier = 'native',
  nativeTag: 'video' | 'audio' = 'video'
): any | null {
  const tagName = String(element?.localName ?? element?.tagName ?? '').toLowerCase();
  if (isMediaElementTag(tagName)) {
    return element;
  }

  if (typeof element?.querySelector === 'function') {
    const hlsElement = element.querySelector('hlsjs-video');
    const nativeElement = element.querySelector(nativeTag)
      ?? element.querySelector('video, audio');

    if (carrier === 'managed') return hlsElement ?? nativeElement ?? null;
    return nativeElement ?? hlsElement ?? null;
  }

  return null;
}

/** 承载元素所在的播放器容器；找不到容器时返回元素自身。 */
export function hostOf(element: any): any {
  return element?.closest?.('video-player, audio-player') ?? element;
}

/**
 * 把中立交付目标写入承载元素，返回本次是否被按等价来源去重。
 *
 * - 声明式通路：元素带 `source` 属性时由上游 setter 加载；与元素上当前的 `source`
 *   等价时上游会去重，此时回报 `deduped: true`，由核心补一次公开 `load()`。
 * - 原生通路：`canPlayType` 拒绝时抛出 `Unsupported media type: <type>`，通过则写
 *   `src` 再 `load()`。
 */
export function applyDelivery(element: any, target: DeliveryTarget, carrier: DeliveryCarrier): { deduped: boolean } {
  const flv = flvFor(element);
  if (isFlv(target)) {
    if (!flv) throw new Error('HTTP FLV adapter is not installed');
    flv.apply(target); return { deduped: false };
  }
  flv?.release();
  if ('source' in element) {
    const previous = element.source;
    const next = toVideojsSource(target, carrier);
    const equivalent = isSameVideojsSource(previous, next);
    // source 是声明式接口：新来源由 setter 加载，等价来源被上游去重。
    element.source = next;
    return { deduped: equivalent };
  }

  const support = typeof element.canPlayType === 'function'
    ? element.canPlayType(target.type ?? '')
    : 'maybe';
  if (target.type && support === '') {
    throw new Error(`Unsupported media type: ${target.type}`);
  }
  element.src = target.src;
  element.load?.();
  return { deduped: false };
}

/** 清空承载元素上的交付来源；两条通路各自的释放写法。 */
export function releaseDelivery(element: any): void {
  flvFor(element)?.release();
  if ('source' in element) {
    // Video.js 10 infers an empty/null source as HLS and creates a new MSE
    // engine. Keep the idle declaration explicitly native, then clear its
    // target after the adapter's queued load. A newer source owns the target.
    if (element.localName === 'hlsjs-video' && element.target?.removeAttribute) {
      const idle = { src: '', type: 'video/mp4', preferPlayback: 'native' };
      element.source = idle;
      element.removeAttribute?.('src');
      const clear = () => {
        if (element.source !== idle) return;
        element.target.pause?.();
        element.target.removeAttribute('src');
        element.target.load?.();
      };
      clear();
      queueMicrotask(clear);
      return;
    }
    element.source = null;
    element.removeAttribute?.('src');
  } else {
    // DOM 的 src 空字符串仍会重新创建来源属性并产生媒体错误。
    // 原生元素移除属性后 load() 即可；非 DOM 端口保留属性清空通路。
    if (typeof element.removeAttribute === 'function') element.removeAttribute('src');
    else if ('src' in element) element.src = '';
    element.load?.();
  }
}
