/**
 * mpv 后端的后端中立轨道端口。
 *
 * 轨道事实只来自 `MpvSession` 最近一次 `track-list` 推送；这里不制造 DOM
 * 或替身媒体元素，VideoTracksController 只看到窄的 TrackPort。
 */

import type { PlayerInstance, TrackPort, TrackPortOption, TrackPortSnapshot } from '../../contracts/ports.js';
import type { MpvSession } from './session.js';

type DisposableTrackPort = TrackPort & { dispose(): void };

function option(track: { id: number; label?: string; language?: string; selected: boolean }, kind: 'audio' | 'subtitle', index: number): TrackPortOption {
  return {
    id: String(track.id),
    label: track.label || track.language || (kind === 'audio' ? `音轨 ${index + 1}` : `字幕 ${index + 1}`),
    language: track.language,
    selected: track.selected,
    status: 'ready',
  };
}

export function createMpvTrackPort(session: MpvSession, instance: PlayerInstance): DisposableTrackPort {
  const listeners = new Set<() => void>();
  let disposed = false;
  const onTrackChange = () => {
    if (!disposed) for (const listener of [...listeners]) listener();
  };
  session.addEventListener('trackchange', onTrackChange);

  const port: DisposableTrackPort = {
    instance,
    get snapshot(): TrackPortSnapshot {
      const audio = session.audioTracks().map((track, index) => option(track, 'audio', index));
      const subtitles = session.subtitleTracks().map((track, index) => option(track, 'subtitle', index));
      return Object.freeze({
        audio: Object.freeze(audio.map(track => Object.freeze(track))),
        subtitles: Object.freeze(subtitles.map(track => Object.freeze(track))),
        audioTrack: audio.find(track => track.selected)?.id ?? null,
        subtitle: subtitles.find(track => track.selected)?.id ?? 'off',
      });
    },
    selectAudioTrack(id: string): Promise<void> {
      const track = session.audioTracks().find(entry => String(entry.id) === id);
      if (!track) {
        const error = new Error('Audio track selection is not available');
        error.name = 'NotSupportedError';
        return Promise.reject(error);
      }
      return session.selectAudioTrack(track.id);
    },
    selectSubtitle(id: string): Promise<void> {
      if (id === 'off') return session.selectSubtitleTrack('off');
      const track = session.subtitleTracks().find(entry => String(entry.id) === id);
      if (!track) {
        const error = new Error('Subtitle is not available');
        error.name = 'NotSupportedError';
        return Promise.reject(error);
      }
      return session.selectSubtitleTrack(track.id);
    },
    onChange(listener: () => void): () => void {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    dispose(): void {
      if (disposed) return;
      disposed = true;
      session.removeEventListener('trackchange', onTrackChange);
      listeners.clear();
    },
  };
  return port;
}
