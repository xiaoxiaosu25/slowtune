/**
 * mpv 后端：会话进程与 JSON IPC 传输
 *
 * 本模块负责启动可追溯的 mpv 进程、连接它的 IPC 端点（`--input-ipc-server`）、下发 JSON 命令
 * 并把回执与推送事件分发出去。命令与事件的**语义**映射留在 `session.ts`，本模块只做传输。
 *
 * 接入模型（已采用）：独立进程 + 本地 IPC。不链接 `libmpv`、不复制或分叉 mpv 源码、不修改其
 * 内部代码。本轮只实现 Windows 命名管道；其它平台的 Unix 域套接字不在本步范围内。
 *
 * Node 内建模块按需动态载入，并且用**计算说明符**而不是字面量，原因有两个：
 * 1. 本包同时面向浏览器与 Node/Electron。以 `platform: 'browser'` 打包的消费者（两个示例、
 *    core-only 打包检查）遇到字面量 `node:*` 说明符会在解析阶段直接失败；计算说明符会被打包器
 *    保留为运行时导入，浏览器侧既不解析也不执行——只有显式选择 mpv 后端的 Node 侧会话才会走到这里。
 * 2. 本包不声明 `@types/node`，字面量说明符会触发 TS2307。
 * `child_process` 与 `net` 是 Node 内建模块，不是包依赖，因此不需要新增依赖声明。
 */

/** mpv 通过 JSON IPC 推送的事件；只保留本后端用到的字段。 */
export interface MpvEvent {
  event: string;
  /** `property-change` 的属性名 */
  name?: string;
  /** `property-change` 的新取值 */
  data?: unknown;
  /** `end-file` 的结束原因（`eof` / `error` / `stop` / `quit` …） */
  reason?: string;
  /** `end-file` 的失败原因 */
  error?: string;
}

/** 连接建立前等待 IPC 端点就绪的间隔与次数：这是握手，不是播放时序上的超时策略。 */
const CONNECT_RETRY_MS = 100;
const CONNECT_ATTEMPTS = 50;
/** 退出收尾的等待上限：超时后强制结束进程，避免释放路径挂住调用方。 */
const QUIT_WAIT_MS = 3000;

interface NodeSocketLike {
  on(event: string, listener: (...args: any[]) => void): void;
  write(chunk: string): unknown;
  destroy(): void;
}

interface NodeChildLike {
  on(event: string, listener: (...args: any[]) => void): void;
  kill(): boolean;
  pid?: number;
}

interface NodeBuiltins {
  spawn(executable: string, args: readonly string[], options: Record<string, unknown>): NodeChildLike;
  connect(path: string): NodeSocketLike;
}

let builtins: Promise<NodeBuiltins> | null = null;

/** 载入 Node 内建模块（`child_process` 与 `net`）；为什么用计算说明符见文件头。 */
function loadNodeBuiltins(): Promise<NodeBuiltins> {
  if (!builtins) {
    builtins = (async () => {
      const specifier = (name: string) => `node:${name}`;
      const childProcess = await import(/* @vite-ignore */ specifier('child_process'));
      const net = await import(/* @vite-ignore */ specifier('net'));
      return { spawn: childProcess.spawn, connect: net.connect } as NodeBuiltins;
    })();
  }
  return builtins;
}

export interface MpvProcessOptions {
  executable: string;
  args: readonly string[];
  /** IPC 端点完整路径（Windows 形如 `\\.\pipe\<名字>`）。 */
  pipePath: string;
  onEvent(event: MpvEvent): void;
  onExit(info: { code: number | null }): void;
  onFailure(error: Error): void;
}

/**
 * 一次 mpv 进程与它的 IPC 连接。
 *
 * 一个实例只服务一个会话：启动、命令回执、事件分发、退出。它不解释任何播放语义，
 * 也不做重试与恢复——失败一律上报给调用方决定。
 */
export class MpvIpcProcess {
  private child: NodeChildLike | null = null;
  private socket: NodeSocketLike | null = null;
  private buffer = '';
  private requestId = 0;
  private readonly pending = new Map<number, { command: string; resolve: (data: unknown) => void; reject: (error: Error) => void }>();
  private exited = false;
  private closing = false;
  private failure: Error | null = null;

  constructor(private readonly options: MpvProcessOptions) {}

  /** 启动进程并连上 IPC 端点；任一步失败都先清理已起的进程再抛出。 */
  async start(): Promise<void> {
    const { spawn, connect } = await loadNodeBuiltins();
    const child = spawn(this.options.executable, [...this.options.args], { stdio: ['ignore', 'ignore', 'ignore'] });
    this.child = child;
    child.on('error', (error: any) => this.reportFailure(new Error(
      `[StudioPlayer] mpv 进程启动失败：${describe(error)}`,
    )));
    child.on('close', (code: number | null) => {
      this.exited = true;
      this.rejectPending(new Error('[StudioPlayer] mpv 会话已结束'));
      this.options.onExit({ code });
    });
    try {
      await this.connectPipe(connect);
    } catch (error) {
      this.dispose();
      throw error;
    }
  }

  /** 下发一条 JSON IPC 命令；回执 `error=success` 时以 `data` 解决，否则以命令名与错误拒绝。 */
  command(command: readonly unknown[]): Promise<unknown> {
    const socket = this.socket;
    if (!socket || this.exited) return Promise.reject(new Error('[StudioPlayer] mpv 会话尚未就绪'));
    const requestId = ++this.requestId;
    return new Promise((resolve, reject) => {
      this.pending.set(requestId, { command: String(command[0]), resolve, reject });
      socket.write(`${JSON.stringify({ command, request_id: requestId })}\n`);
    });
  }

  /** 请求退出并等待进程结束；等待有上限，超时后强制结束。 */
  async quit(): Promise<void> {
    this.closing = true;
    if (!this.exited && this.child) {
      const exited = new Promise<void>(resolve => this.child?.on('close', () => resolve()));
      await this.command(['quit']).catch(() => undefined);
      await Promise.race([exited, new Promise<void>(resolve => setTimeout(resolve, QUIT_WAIT_MS))]);
    }
    this.dispose();
  }

  /** 关闭连接与进程；可重复调用。 */
  dispose(): void {
    this.socket?.destroy();
    this.socket = null;
    this.rejectPending(new Error('[StudioPlayer] mpv 会话已结束'));
    try {
      this.child?.kill();
    } catch {
      /* 进程可能已经退出。 */
    }
    this.child = null;
  }

  private connectPipe(connect: (path: string) => NodeSocketLike): Promise<void> {
    return new Promise((resolve, reject) => {
      let attempt = 0;
      const tryConnect = () => {
        if (this.exited) {
          reject(new Error('[StudioPlayer] mpv 进程在 IPC 连接建立前退出'));
          return;
        }
        const socket = connect(this.options.pipePath);
        let connected = false;
        socket.on('connect', () => {
          connected = true;
          this.socket = socket;
          this.readSocket(socket);
          resolve();
        });
        socket.on('error', (error: any) => {
          if (connected) {
            this.reportFailure(new Error(`[StudioPlayer] mpv IPC 连接错误：${describe(error)}`));
            return;
          }
          socket.destroy();
          attempt += 1;
          if (attempt >= CONNECT_ATTEMPTS) {
            reject(new Error(`[StudioPlayer] 无法连接 mpv 的 IPC 端点 ${this.options.pipePath}：${describe(error)}`));
            return;
          }
          setTimeout(tryConnect, CONNECT_RETRY_MS);
        });
      };
      tryConnect();
    });
  }

  private readSocket(socket: NodeSocketLike): void {
    socket.on('data', (chunk: any) => this.consume(String(chunk)));
    socket.on('close', () => {
      if (!this.closing && !this.exited) this.reportFailure(new Error('[StudioPlayer] mpv IPC 连接已断开'));
    });
  }

  /** mpv 的 JSON IPC 是每行一条消息；半行留在缓冲里等下一块。 */
  private consume(text: string): void {
    this.buffer += text;
    const lines = this.buffer.split('\n');
    this.buffer = lines.pop() ?? '';
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      let message: any;
      try {
        message = JSON.parse(trimmed);
      } catch {
        continue;
      }
      if (message?.event) {
        this.options.onEvent(message as MpvEvent);
        continue;
      }
      if (typeof message?.request_id === 'number') this.settle(message);
    }
  }

  private settle(message: any): void {
    const waiter = this.pending.get(message.request_id);
    if (!waiter) return;
    this.pending.delete(message.request_id);
    if (message.error && message.error !== 'success') {
      waiter.reject(new Error(`[StudioPlayer] mpv 命令失败（${waiter.command}）：${message.error}`));
      return;
    }
    waiter.resolve(message.data);
  }

  private reportFailure(error: Error): void {
    if (this.failure) return;
    this.failure = error;
    this.rejectPending(error);
    this.options.onFailure(error);
  }

  private rejectPending(error: Error): void {
    for (const waiter of this.pending.values()) waiter.reject(error);
    this.pending.clear();
  }
}

function describe(error: any): string {
  return `${error?.code ?? ''} ${error?.message ?? String(error)}`.trim();
}
