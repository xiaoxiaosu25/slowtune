/**
 * mpv 后端：能力声明
 *
 * 声明这个后端支持什么：传输方式、容器、编码与轨道类型。公共层按声明决定可用功能与降级
 * 反馈——声明之外的来源在应用阶段同步拒绝，随后沿用核心既有的"来源拒绝 → 备用源 → error"
 * 规则，不静默降级，也不把来源契约里的类型声明当成真实能力。
 *
 * 清单按 mpv（及其内置 ffmpeg）实际具备的解复用与解码能力给出，只列已实测或上游明确列出的
 * 组合，不把没有实测过的组合写成"已验证"。实测范围与限制见
 * packages/audio-video/player/evidence/u2-mpv-第2步-后端适配与后端选择.md。
 *
 * 依赖方向：本模块只从 `contracts/delivery.ts` 取中立类型，不导入核心、也不导入其它后端。
 */

import type { DeliveryTarget } from '../../contracts/delivery.js';

/** mpv 后端承载的传输方式（取 `PlaybackTransport` 中它真的能处理的取值）。 */
export type MpvTransport = 'range' | 'hls' | 'dash';

/** 轨道类型；mpv 的 `track-list` 用同样的三类。 */
export type MpvTrackKind = 'video' | 'audio' | 'subtitle';

export interface MpvCapabilities {
  readonly backend: 'mpv';
  /** 默认画面落地方式：mpv 独立窗口；宿主可用附加参数覆盖为 native child surface。 */
  readonly output: 'independent-window';
  readonly transports: readonly MpvTransport[];
  /** 明确不承载的传输方式；命中即拒绝。 */
  readonly unsupportedTransports: readonly string[];
  /** 已声明的容器/MIME 类型。 */
  readonly mimeTypes: readonly string[];
  /** 无 MIME 时按它判定的常见扩展名。 */
  readonly extensions: readonly string[];
  readonly codecs: readonly string[];
  readonly trackKinds: readonly MpvTrackKind[];
}

export const MPV_CAPABILITIES: MpvCapabilities = Object.freeze({
  backend: 'mpv',
  output: 'independent-window',
  transports: ['range', 'hls', 'dash'] as const,
  unsupportedTransports: ['webrtc'],
  mimeTypes: [
    'video/mp4', 'audio/mp4', 'application/mp4', 'video/quicktime',
    'video/x-matroska', 'audio/x-matroska', 'video/webm', 'audio/webm',
    'video/mp2t', 'audio/mpeg', 'audio/aac', 'audio/flac', 'audio/wav', 'audio/x-wav',
    'audio/ogg', 'audio/opus',
    'application/vnd.apple.mpegurl', 'application/x-mpegurl', 'audio/mpegurl',
    'application/dash+xml',
  ],
  extensions: ['mp4', 'm4v', 'mov', 'mkv', 'webm', 'ts', 'm2ts', 'mp3', 'm4a', 'aac', 'flac', 'wav', 'ogg', 'oga', 'opus', 'm3u8', 'mpd'],
  codecs: ['h264', 'hevc', 'vp8', 'vp9', 'av1', 'mpeg2video', 'aac', 'mp3', 'opus', 'vorbis', 'flac', 'pcm', 'ac3', 'eac3', 'dts'],
  trackKinds: ['video', 'audio', 'subtitle'] as const,
});

/** 非媒体类型：mpv 后端不承载，命中直接拒绝，不交给 mpv 试。 */
const NON_MEDIA_TYPE_PREFIXES = ['text/', 'image/', 'font/'];
const NON_MEDIA_TYPES = ['application/pdf', 'application/json', 'application/zip'];

export interface MpvSupportVerdict {
  readonly supported: boolean;
  /** 拒绝原因（`supported` 为 false 时给出），会进入核心的来源拒绝文案。 */
  readonly reason?: string;
  /** true 表示类型不在声明清单内、交由 mpv 自行探测；**不是**"已验证支持"。 */
  readonly probed: boolean;
}

/** 按声明判定一个交付目标能否交给 mpv；只比对声明，不启动进程、不访问文件系统。 */
export function mpvSupportsTarget(target: DeliveryTarget): MpvSupportVerdict {
  const transport = (target.transport ?? '').trim().toLowerCase();
  if (MPV_CAPABILITIES.unsupportedTransports.includes(transport)) {
    return { supported: false, probed: false, reason: `不承载 ${transport} 传输` };
  }

  const type = (target.type ?? '').split(';', 1)[0].trim().toLowerCase();
  if (type && MPV_CAPABILITIES.mimeTypes.includes(type)) return { supported: true, probed: false };
  if (type && (NON_MEDIA_TYPES.includes(type) || NON_MEDIA_TYPE_PREFIXES.some(prefix => type.startsWith(prefix)))) {
    return { supported: false, probed: false, reason: `不是媒体类型 ${type}` };
  }
  if (transport === 'hls' || transport === 'dash') return { supported: true, probed: false };

  const extension = extensionOf(target.src);
  if (extension && MPV_CAPABILITIES.extensions.includes(extension)) return { supported: true, probed: false };

  // 既不在支持清单、也不是明确非媒体：没有声明可依据，交给 mpv 自行探测。
  return { supported: true, probed: true };
}

/** 取地址的扩展名；查询串与片段不参与判定。 */
function extensionOf(url: string): string {
  const path = url.split('?')[0].split('#')[0];
  const name = path.slice(path.lastIndexOf('/') + 1);
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
}
