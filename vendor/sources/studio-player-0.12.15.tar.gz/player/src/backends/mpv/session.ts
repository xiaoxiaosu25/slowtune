/**
 * mpv 后端：会话
 *
 * 一个 mpv 会话就是一次独立进程 + 一条 JSON IPC 连接，按《后端与引擎边界》第 4 节承接四件事：
 *
 * | 职责 | 本模块的落点 |
 * | --- | --- |
 * | 能力声明 | `capabilities`（声明表在 `capabilities.ts`），声明之外的来源同步拒绝 |
 * | 会话操作 | `applyDelivery`/`load`/`play`/`pause`/`seekTo`/`setVolume`/`setMuted`/`setPlaybackRate`/`release`/`close` |
 * | 事实反馈 | `currentTime`/`duration`/`paused`/`ended`/`buffered`/`error`，取值全部来自 mpv 的属性推送 |
 * | 输出面与轨道 | `outputMode`（默认独立窗口；宿主可用附加参数改为 native child surface）、`listTracks` 与 `selectAudioTrack`/`selectSubtitleTrack`/`selectVideoTrack` |
 *
 * 它按**媒体面**被核心驱动：核心把它放进媒体槽，像使用媒体元素那样读时间、时长与暂停状态，
 * 监听 `timeupdate`/`pause`/`play`/`ended`/`error` 等事件。它不是 `HTMLMediaElement`：没有 DOM、
 * 没有 MSE、没有 `src` 元素属性，只实现核心真正用到的那一面，取值来自真实 mpv 而不是替身。
 *
 * 取消与新操作替代沿用核心既有规则：核心在换源/停止时先暂停并释放，本模块不做自己的重试或恢复；
 * 会话进程在首次加载来源时启动，`release()` 只释放当前来源，`close()` 才结束进程。
 *
 * 依赖方向：`session.ts` → `capabilities.ts` + `ipc.ts` →（运行时）Node 内建模块。
 * 本模块不导入核心、不导入其它后端。
 */

import type { DeliveryTarget } from '../../contracts/delivery.js';
import { MPV_CAPABILITIES, mpvSupportsTarget, type MpvCapabilities } from './capabilities.js';
import { MpvIpcProcess, type MpvEvent } from './ipc.js';

/** 默认输出面仍是 mpv 独立窗口；宿主可用 `extraArgs` 覆盖为受控 native child surface。 */
export const MPV_OUTPUT_MODE = 'independent-window';
/** 声明的 mpv 最低版本；低于它按不兼容拒绝，不静默降级，也不尝试继续。 */
export const MPV_MINIMUM_VERSION = 'v0.36.0';

/**
 * 观察的属性与它们的必需性。事实反馈的取值全部来自这些推送，不从命令回执里猜。
 * 必需项（`true`）取不到就认为这次会话不成立；可选项（`false`）在该来源不提供时忽略。
 */
const OBSERVED_PROPERTIES: ReadonlyArray<readonly [number, string, boolean]> = [
  [1, 'time-pos', true],
  [2, 'duration', true],
  [3, 'pause', true],
  [4, 'volume', true],
  [5, 'mute', true],
  [6, 'speed', true],
  [7, 'eof-reached', true],
  [8, 'track-list', true],
  [9, 'demuxer-cache-state', false],
  [10, 'cache-buffering-state', false],
];

/** 一条来自 mpv `track-list` 的轨道。 */
export interface MpvTrack {
  readonly id: number;
  readonly kind: 'video' | 'audio' | 'subtitle';
  readonly label?: string;
  readonly language?: string;
  readonly selected: boolean;
  readonly codec?: string;
  readonly width?: number;
  readonly height?: number;
  readonly bitrate?: number;
}

/** 缓冲事实：已缓冲秒数与 mpv 报告的缓冲百分比。 */
export interface MpvBufferedFact {
  readonly seconds: number;
  readonly percent: number;
}

export interface MpvSessionOptions {
  /** 官方 mpv 可执行文件路径；为空时每次加载来源都会被明确拒绝。 */
  executable?: string;
  /** 附加 mpv 参数（验证用、或宿主用来覆盖输出面）。追加在内置参数之后，可覆盖它们。 */
  extraArgs?: readonly string[];
  /** IPC 端点名；默认按进程与实例生成，只有验证与诊断需要固定它。 */
  pipeName?: string;
  /** 宿主为该实例创建的 native child surface HWND（十进制字符串）。 */
  nativeWindowId?: string;
  /** U5 Electron 宿主的固定视频输出。 */
  videoOutput?: 'gpu-next';
  /** U5 Windows Electron 宿主的固定音频输出。 */
  audioOutput?: 'wasapi';
  /** 宿主为该会话单独分配的日志文件。 */
  logFile?: string;
}

let pipeCounter = 0;

/** 默认的 IPC 端点名：同一进程内的多个会话不互相占用。 */
function defaultPipeName(): string {
  pipeCounter += 1;
  const pid = (globalThis as { process?: { pid?: number } }).process?.pid ?? 0;
  return `studio-player-mpv-${pid}-${pipeCounter}`;
}

/** Windows 命名管道的完整路径；本轮只实现 Windows 命名管道。 */
function pipePathOf(name: string): string {
  return `\\\\.\\pipe\\${name}`;
}

/**
 * 一次 mpv 播放会话。
 *
 * 生命周期：构造（同步、不启动进程）→ `applyDelivery`（能力判定并启动/换源）→ 播放控制 → 释放。
 * `release()` 释放当前来源并保留进程；`close()` 结束进程。所有失败经 `error` 事件上报，
 * 由核心既有的错误通道处理（备用源 → 失败终态），本模块不自行重试。
 */
export class MpvSession extends EventTarget {
  /** 内部后端标识：核心据此识别"非 DOM 承载"，不进入任何公开类型。 */
  readonly backendName = 'mpv';
  /** 输出面声明：默认独立窗口；native surface 的创建/销毁不由会话拥有。 */
  readonly outputMode = MPV_OUTPUT_MODE;

  /** 最近一次 mpv 报告的失败；核心的媒体错误通道从这里取错误对象。 */
  error: Error | null = null;
  /** 当前交付地址；与媒体元素的 `src` 对应，只用于诊断。 */
  src = '';
  /** 已加载文件的时长（秒）；未知时为 0，与核心对"时长未知"的处理一致。 */
  duration = 0;
  /** 是否已暂停；取值来自 mpv 的 `pause` 推送。 */
  paused = true;
  /** 是否已播放到结尾；由 `eof-reached` 推送或 `end-file` 的 `eof` 置位。 */
  ended = false;

  /**
   * 是否正在定位。核心用完播判定读它（跳转不算自然完播），所以按媒体面的名字暴露，
   * 值就是本模块的 `seekPending`——不暴露会让核心把它读成 `undefined`。
   */
  get seeking(): boolean {
    return this.seekPending;
  }

  private position = 0;
  private volumeLevel = 1;
  private muteFlag = false;
  private rate = 1;
  private target: DeliveryTarget | null = null;
  private process: MpvIpcProcess | null = null;
  private starting: Promise<void> | null = null;
  private ready = false;
  private metadataAnnounced = false;
  private seekPending = false;
  private version = '';
  private trackSet: MpvTrack[] = [];
  private bufferedFact: MpvBufferedFact = { seconds: 0, percent: 0 };
  private closed = false;
  private readonly executable: string;
  private readonly extraArgs: readonly string[];
  private readonly pipeName: string;
  private readonly nativeWindowId: string | null;
  private readonly videoOutput: 'gpu-next' | null;
  private readonly audioOutput: 'wasapi' | null;
  private readonly logFile: string | null;

  constructor(options: MpvSessionOptions = {}) {
    super();
    if (options.executable !== undefined && typeof options.executable !== 'string') {
      throw new TypeError('mpv executable must be a string');
    }
    if (options.extraArgs !== undefined && (!Array.isArray(options.extraArgs)
      || options.extraArgs.some(argument => typeof argument !== 'string' || argument.includes('\0')))) {
      throw new TypeError('mpv extraArgs must be an array of strings without NUL');
    }
    const extraArgs = [...(options.extraArgs ?? [])];
    if (extraArgs.some(argument => /^--(?:input-ipc-server|wid)(?:=|$)/i.test(argument))) {
      throw new TypeError('mpv IPC endpoint and native window target are owned by the session configuration');
    }
    if (options.pipeName !== undefined && !/^[a-z0-9_-]{1,180}$/i.test(options.pipeName)) {
      throw new TypeError('mpv IPC endpoint name contains unsupported characters');
    }
    if (options.nativeWindowId !== undefined && !isNativeWindowId(options.nativeWindowId)) {
      throw new TypeError('mpv native window target must be a positive decimal HWND');
    }
    if (options.nativeWindowId !== undefined
      && (options.videoOutput !== 'gpu-next' || options.audioOutput !== 'wasapi')) {
      throw new TypeError('native surface sessions require the controlled gpu-next/wasapi outputs');
    }
    if (options.nativeWindowId === undefined
      && (options.videoOutput !== undefined || options.audioOutput !== undefined || options.logFile !== undefined)) {
      throw new TypeError('mpv output and log settings require a native window target');
    }
    if (options.logFile !== undefined && (typeof options.logFile !== 'string' || options.logFile.includes('\0'))) {
      throw new TypeError('mpv logFile must be a string without NUL');
    }
    this.executable = options.executable ?? '';
    this.extraArgs = Object.freeze(extraArgs);
    this.pipeName = options.pipeName ?? defaultPipeName();
    this.nativeWindowId = options.nativeWindowId ?? null;
    this.videoOutput = options.videoOutput ?? null;
    this.audioOutput = options.audioOutput ?? null;
    this.logFile = options.logFile ?? null;
  }

  // —— 会话对外的事实与标识 ——

  /** 后端能力声明；公共层按它决定可用功能与降级反馈。 */
  get capabilities(): MpvCapabilities {
    return MPV_CAPABILITIES;
  }

  /** 实测到的 mpv 版本字符串；会话启动前为空。 */
  get mpvVersion(): string {
    return this.version;
  }

  /** 会话进程是否已在运行。 */
  get running(): boolean {
    return this.process !== null;
  }

  /** 即使尚未启动也能读到的启动参数；供诊断与证据记录，不含媒体路径。 */
  commandLine(): readonly string[] {
    return [this.executable, ...this.launchArgs()];
  }

  // —— 媒体面：核心按这些字段驱动会话，取值来自 mpv 推送 ——

  get currentTime(): number {
    return this.position;
  }

  /** 核心的定位通路：写当前时间即请求一次绝对定位。 */
  set currentTime(seconds: number) {
    this.seekTo(seconds);
  }

  get volume(): number {
    return this.volumeLevel;
  }

  set volume(value: number) {
    this.applyVolume(value);
  }

  get muted(): boolean {
    return this.muteFlag;
  }

  set muted(value: boolean) {
    this.applyMuted(value);
  }

  get playbackRate(): number {
    return this.rate;
  }

  set playbackRate(value: number) {
    this.applyRate(value);
  }

  /** 缓冲事实：已缓冲秒数与缓冲百分比，来自 `demuxer-cache-state` 与 `cache-buffering-state`。 */
  buffered(): MpvBufferedFact {
    return this.bufferedFact;
  }

  // —— 能力声明：声明之外的来源同步拒绝 ——

  /**
   * 把中立交付目标交给会话：先按能力声明判定，再启动/换源。
   *
   * 判定不通过时**同步抛出**，与承载元素路径的"不支持就拒绝"共用核心同一条规则
   * （来源拒绝 → 备用源 → `error`）。判定通过与来源加载是异步的，异步失败经 `error` 事件上报。
   *
   * 返回值与承载元素路径一致：等价来源（同一地址与类型且已就绪）回报 `deduped: true`，
   * 由核心补一次公开 `load()` 重新加载。
   */
  applyDelivery(target: DeliveryTarget): { deduped: boolean } {
    if (this.closed) throw new Error('[StudioPlayer] mpv 会话已关闭，无法再加载来源');
    if (!this.executable) {
      throw new Error('[StudioPlayer] mpv 后端没有可执行文件：请用 STUDIO_PLAYER_MPV_BIN 指向官方 mpv 可执行文件');
    }

    const verdict = mpvSupportsTarget(target);
    if (!verdict.supported) {
      const error = new Error(`[StudioPlayer] mpv 后端不支持该来源：${verdict.reason ?? '未声明的类型'}`);
      error.name = 'NotSupportedError';
      throw error;
    }

    const deduped = this.ready && this.target?.src === target.src && this.target?.type === target.type;
    this.target = target;
    this.src = target.src;
    this.ended = false;
    if (!deduped) this.ready = false;
    // 进程启动与来源加载都不能阻塞核心的应用来源通路：失败经 error 事件走既有错误通道。
    void this.prepare(deduped).catch(error => this.fail(error));
    return { deduped };
  }

  /** 重新加载当前来源；核心在等价来源去重后补一次公开 `load()` 时调用。 */
  async load(): Promise<void> {
    if (this.closed || !this.target) return;
    this.ready = false;
    this.ended = false;
    await this.ensureStarted();
    await this.loadFile();
  }

  // —— 会话操作 ——

  /**
   * 起播：解除 mpv 的暂停，回执成功即认为命令已受理；起播事实仍以 `pause` 推送为准。
   *
   * 播到结尾后再次 `play()` 会先把当前来源重新加载一遍：媒体元素在 `ended` 后重放会回到开头，
   * 会话必须自己完成等价的"回到开头"，否则这条公开行为在 mpv 下会变成一个无声的空操作。
   */
  async play(): Promise<void> {
    if (this.closed) {
      const error = new Error('[StudioPlayer] mpv 会话已关闭');
      error.name = 'InvalidStateError';
      throw error;
    }
    await this.ensureStarted();
    if (this.ended && this.target) {
      this.ended = false;
      this.position = 0;
      await this.loadFile();
    }
    await this.send(['set_property', 'pause', false]);
    // 命令不产生推送时要靠查询校正：完播后 mpv 的 pause 仍是 false，单纯下发命令没有变化可推。
    await this.reconcilePaused();
  }

  /** 暂停：只下发命令，状态由 mpv 的 `pause` 推送确认（无变化时用查询校正）。 */
  pause(): void {
    const process = this.process;
    if (!process) return;
    void process.command(['set_property', 'pause', true])
      .then(() => this.reconcilePaused())
      .catch(error => this.warn('暂停', error));
  }

  /**
   * 按 mpv 的实际取值校正本地的暂停事实。
   *
   * 取值仍来自 mpv（`get_property pause` 的回执），只是用查询确认而不是等推送：当本地事实与
   * mpv 已经一致时（例如完播后本地记 `paused`、mpv 的 `pause` 一直是 false），下发命令不会
   * 产生任何属性变化，也就不会有推送来纠正本地事实。
   */
  private async reconcilePaused(): Promise<void> {
    const process = this.process;
    if (!process) return;
    try {
      const value = await process.command(['get_property', 'pause']);
      if (typeof value === 'boolean') this.applyPaused(value);
    } catch (error) {
      this.warn('校正暂停状态', error);
    }
  }

  /**
   * 释放当前来源：清空已加载的文件与本地事实，**保留会话进程**。
   * 与承载元素路径的释放对应（清 `src`、停下来），进程归 `close()`。
   */
  release(): void {
    this.target = null;
    this.src = '';
    this.ready = false;
    this.metadataAnnounced = false;
    this.ended = false;
    this.paused = true;
    this.position = 0;
    this.duration = 0;
    this.trackSet = [];
    this.bufferedFact = { seconds: 0, percent: 0 };
    this.dispatch('trackchange');
    this.sendIfRunning(['stop'], '释放来源');
  }

  /** 结束会话进程；可重复调用。 */
  async close(): Promise<void> {
    if (this.closed) return;
    this.closed = true;
    this.release();
    const process = this.process;
    this.process = null;
    this.starting = null;
    if (process) await process.quit();
  }

  // —— 轨道：列举与选择，取值来自 mpv 的 `track-list` 推送 ——

  /** 当前轨道列表（mpv `track-list` 的最近一次推送）。 */
  listTracks(): readonly MpvTrack[] {
    return this.trackSet;
  }

  audioTracks(): readonly MpvTrack[] {
    return this.trackSet.filter(track => track.kind === 'audio');
  }

  subtitleTracks(): readonly MpvTrack[] {
    return this.trackSet.filter(track => track.kind === 'subtitle');
  }

  videoTracks(): readonly MpvTrack[] {
    return this.trackSet.filter(track => track.kind === 'video');
  }

  /** 选择音轨：写入 mpv 的 `aid`；生效结果以随后的 `track-list` 推送为准。 */
  async selectAudioTrack(id: number): Promise<void> {
    await this.setTrackProperty('aid', id);
  }

  /** 选择字幕轨，或 `'off'` 关闭字幕：写入 mpv 的 `sid`。 */
  async selectSubtitleTrack(id: number | 'off'): Promise<void> {
    await this.setTrackProperty('sid', id === 'off' ? 'no' : id);
  }

  /** 选择视频轨：写入 mpv 的 `vid`。HLS 的自适应档位不由 mpv 列举，见 README 的限制一节。 */
  async selectVideoTrack(id: number): Promise<void> {
    await this.setTrackProperty('vid', id);
  }

  // —— 内部：会话启动与来源加载 ——

  private ensureStarted(): Promise<void> {
    if (this.closed) return Promise.reject(new Error('[StudioPlayer] mpv 会话已关闭'));
    if (!this.starting) {
      this.starting = this.start().catch(error => {
        this.starting = null;
        throw error;
      });
    }
    return this.starting;
  }

  private async start(): Promise<void> {
    const ipc = new MpvIpcProcess({
      executable: this.executable,
      args: this.launchArgs(),
      pipePath: pipePathOf(this.pipeName),
      onEvent: event => this.onEvent(event),
      onExit: info => this.onExit(info),
      onFailure: error => this.fail(error),
    });
    await ipc.start();
    this.process = ipc;
    this.version = await this.handshake(ipc);
    for (const [id, name, required] of OBSERVED_PROPERTIES) {
      const observe = ipc.command(['observe_property', id, name]);
      if (required) await observe;
      else void observe.catch(() => { /* 该来源不提供的可选属性。 */ });
    }
    // 启动前设置过的音量/静音/倍速不能被 mpv 的默认值覆盖。
    await this.applyLocalControls();
  }

  /** 版本握手：读 `mpv-version`，低于声明的下限按不兼容拒绝。 */
  private async handshake(ipc: MpvIpcProcess): Promise<string> {
    const raw = await ipc.command(['get_property', 'mpv-version']);
    const version = typeof raw === 'string' ? raw.trim() : '';
    const actual = parseVersion(version);
    if (!version || !actual || compareVersions(actual, parseVersion(MPV_MINIMUM_VERSION)! ) < 0) {
      throw new Error(`[StudioPlayer] mpv 版本不兼容：需要 ${MPV_MINIMUM_VERSION} 及以上，实际为 ${version || '未知'}`);
    }
    return version;
  }

  private async prepare(deduped: boolean): Promise<void> {
    await this.ensureStarted();
    // 等价来源由核心补的那次公开 load() 重新加载，这里不重复下发。
    if (deduped) return;
    await this.loadFile();
  }

  private async loadFile(): Promise<void> {
    const target = this.target;
    if (!target) return;
    this.metadataAnnounced = false;
    await this.applyHeaders(target);
    await this.send(['loadfile', target.src, 'replace']);
  }

  /**
   * 请求头注入：mpv 的 `http-header-fields` 列表选项按 `字段: 值` 传入；没有请求头时清空，
   * 避免上一条来源的头带到下一条。**尚未用真实鉴权端点验证**（见证据的限制一节）。
   */
  private async applyHeaders(target: DeliveryTarget): Promise<void> {
    const headers = target.headers;
    const fields = headers ? Object.entries(headers).map(([key, value]) => `${key}: ${value}`) : [];
    await this.sendQuietly(['set_property', 'http-header-fields', fields]);
  }

  private async applyLocalControls(): Promise<void> {
    await this.send(['set_property', 'volume', this.volumeLevel * 100]);
    await this.send(['set_property', 'mute', this.muteFlag]);
    await this.send(['set_property', 'speed', this.rate]);
  }

  private async setTrackProperty(property: 'aid' | 'sid' | 'vid', value: number | 'no'): Promise<void> {
    await this.ensureStarted();
    await this.send(['set_property', property, value]);
  }

  // —— 内部：命令与事件 ——

  private send(command: readonly unknown[]): Promise<unknown> {
    const process = this.process;
    if (!process) return Promise.reject(new Error('[StudioPlayer] mpv 会话尚未启动'));
    return process.command(command);
  }

  private async sendQuietly(command: readonly unknown[]): Promise<void> {
    await this.send(command).catch(error => this.warn(String(command[0]), error));
  }

  /**
   * 命令只在会话已经在跑时下发。没有进程时的设置不是失败：本地事实已经记下，
   * 由 `start()` 的 `applyLocalControls()` 在会话起来后落地（核心的释放路径也会先暂停）。
   */
  private sendIfRunning(command: readonly unknown[], action: string): void {
    if (!this.process) return;
    void this.send(command).catch(error => this.warn(action, error));
  }

  private warn(action: string, error: unknown): void {
    console.warn(`[StudioPlayer] mpv 后端 ${action} 失败：`, error);
  }

  /**
   * mpv 事件的语义映射：事实反馈全部来自这里，不依赖任何 DOM 事件名。
   * 核心按媒体事件名监听会话，因此映射结果以 `play`/`pause`/`timeupdate`/`ended`/`error` 等形式发出。
   */
  private onEvent(event: MpvEvent): void {
    switch (event.event) {
      case 'property-change':
        this.onPropertyChange(event);
        return;
      case 'file-loaded':
        this.ready = true;
        this.ended = false;
        this.announceMetadata();
        return;
      case 'seek':
        this.seekPending = true;
        this.dispatch('seeking');
        return;
      case 'playback-restart':
        if (this.seekPending) {
          this.seekPending = false;
          this.dispatch('seeked');
        }
        return;
      case 'end-file':
        this.onEndFile(event);
        return;
      default:
        return;
    }
  }

  private onPropertyChange(event: MpvEvent): void {
    switch (event.name) {
      case 'time-pos':
        if (typeof event.data === 'number') {
          this.position = event.data;
          this.dispatch('timeupdate');
        }
        return;
      case 'duration':
        if (typeof event.data === 'number' && Number.isFinite(event.data)) {
          this.duration = event.data;
          this.dispatch('durationchange');
          this.announceMetadata();
        }
        return;
      case 'pause':
        if (typeof event.data === 'boolean') this.applyPaused(event.data);
        return;
      case 'volume':
        if (typeof event.data === 'number') {
          this.volumeLevel = clamp01(event.data / 100);
          this.dispatch('volumechange');
        }
        return;
      case 'mute':
        if (typeof event.data === 'boolean') {
          this.muteFlag = event.data;
          this.dispatch('volumechange');
        }
        return;
      case 'speed':
        if (typeof event.data === 'number' && event.data > 0) {
          this.rate = event.data;
          this.dispatch('ratechange');
        }
        return;
      case 'eof-reached':
        if (event.data === true) this.markEnded();
        return;
      case 'track-list':
        this.trackSet = normalizeTracks(event.data);
        this.dispatch('trackchange');
        return;
      case 'demuxer-cache-state':
        if (event.data && typeof event.data === 'object') {
          const seconds = (event.data as Record<string, unknown>)['cache-duration'];
          if (typeof seconds === 'number' && Number.isFinite(seconds)) {
            this.bufferedFact = { seconds, percent: this.bufferedFact.percent };
          }
        }
        return;
      case 'cache-buffering-state':
        if (typeof event.data === 'number' && Number.isFinite(event.data)) {
          this.bufferedFact = { seconds: this.bufferedFact.seconds, percent: event.data };
        }
        return;
      default:
        return;
    }
  }

  /** 暂停状态的推送：核心的播放/暂停事实由它确认，命令回执不算起播事实。 */
  private applyPaused(paused: boolean): void {
    if (this.paused === paused) return;
    this.paused = paused;
    if (paused) {
      this.dispatch('pause');
      return;
    }
    this.ended = false;
    this.dispatch('play');
    this.dispatch('playing');
  }

  /** 播到结尾：先把最后位置报给核心（核心在 ended 之后会忽略位置上报），再发 pause 与 ended。 */
  private markEnded(): void {
    if (this.ended) return;
    if (this.duration > 0) this.position = this.duration;
    this.dispatch('timeupdate');
    this.ended = true;
    this.paused = true;
    this.dispatch('pause');
    this.dispatch('ended');
  }

  private onEndFile(event: MpvEvent): void {
    this.ready = false;
    if (event.reason === 'eof') {
      this.markEnded();
      return;
    }
    // stop/quit/redirect 是本后端自己发起的收尾，不作为播放失败。
    if (event.reason === 'stop' || event.reason === 'quit' || event.reason === 'redirect') return;
    this.fail(new Error(`[StudioPlayer] mpv 播放失败：${event.error ?? event.reason ?? '未知原因'}`));
  }

  /** 元数据就绪：核心按这两个事件进入 ready 并触发一次断点恢复。 */
  private announceMetadata(): void {
    if (this.metadataAnnounced) return;
    this.metadataAnnounced = true;
    this.dispatch('loadedmetadata');
    this.dispatch('canplay');
  }

  private applyVolume(value: number): void {
    const level = clamp01(value);
    if (level === this.volumeLevel) return;
    this.volumeLevel = level;
    this.sendIfRunning(['set_property', 'volume', level * 100], '设置音量');
  }

  private applyMuted(value: boolean): void {
    const muted = Boolean(value);
    if (muted === this.muteFlag) return;
    this.muteFlag = muted;
    this.sendIfRunning(['set_property', 'mute', muted], '设置静音');
  }

  private applyRate(value: number): void {
    if (!Number.isFinite(value) || value <= 0 || value === this.rate) return;
    this.rate = value;
    this.sendIfRunning(['set_property', 'speed', value], '设置倍速');
  }

  private seekTo(seconds: number): void {
    if (!Number.isFinite(seconds)) return;
    const target = Math.max(0, seconds);
    this.position = target;
    this.seekPending = true;
    this.dispatch('seeking');
    const process = this.process;
    if (!process) {
      this.seekPending = false;
      return;
    }
    void process.command(['seek', target, 'absolute']).catch(error => {
      this.seekPending = false;
      this.warn('定位', error);
    });
  }

  /** 会话失败：记下错误对象（核心的错误通道从这里取值）并发出 `error`。 */
  private fail(error: unknown): void {
    const normalized = error instanceof Error ? error : new Error(String(error));
    this.error = normalized;
    this.paused = true;
    this.ready = false;
    if (this.closed) return;
    console.warn('[StudioPlayer] mpv 后端失败：', normalized);
    this.dispatch('error');
  }

  private onExit(info: { code: number | null }): void {
    const wasRunning = this.process !== null;
    this.process = null;
    this.starting = null;
    this.ready = false;
    this.paused = true;
    if (this.closed || !wasRunning) return;
    // 外部结束进程（用户关窗、崩溃、被杀）等于会话终止：如实上报，不静默重开。
    this.fail(new Error(`[StudioPlayer] mpv 进程已退出（退出码 ${info.code ?? 'unknown'}）`));
  }

  private dispatch(type: string): void {
    this.dispatchEvent(new Event(type));
  }

  /**
   * 会话进程参数。媒体路径不在命令行上：来源一律经 IPC 的 `loadfile` 下发，一次会话可换源。
   * 默认不覆盖输出面——画面落在 mpv 自己的独立窗口；`--force-window=no` 只保证空闲与纯音频时
   * 不建空窗口。`extraArgs` 追加在最后，宿主可据此覆盖输出面（例如 `--wid` + `--force-window=yes`
   * 接入 native child surface，或用 `--vo=null` 免打扰）；surface 生命周期仍由宿主端口管理。
   */
  private launchArgs(): string[] {
    return [
      '--no-config',
      '--idle=yes',
      `--force-window=${this.nativeWindowId === null ? 'no' : 'yes'}`,
      '--no-terminal',
      '--pause=yes',
      `--input-ipc-server=${pipePathOf(this.pipeName)}`,
      ...(this.nativeWindowId === null ? [] : [
        `--wid=${this.nativeWindowId}`,
        `--vo=${this.videoOutput}`,
        `--ao=${this.audioOutput}`,
        '--osc=no',
        '--input-default-bindings=no',
        '--title=StudioPlayer-native-surface',
        ...(this.logFile === null ? [] : [`--log-file=${this.logFile}`]),
      ]),
      ...this.extraArgs,
    ];
  }
}

function isNativeWindowId(value: string): boolean {
  if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) return false;
  try {
    const numeric = BigInt(value);
    return numeric > 0n && numeric <= 0xffffffffffffffffn;
  } catch {
    return false;
  }
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 1;
  return Math.max(0, Math.min(1, value));
}

/** 从 `mpv v0.41.0-1023-g69e63f425` 这类字符串里取主次版本号。 */
function parseVersion(value: string): [number, number] | null {
  const match = /(\d+)\.(\d+)/.exec(value ?? '');
  if (!match) return null;
  return [Number(match[1]), Number(match[2])];
}

function compareVersions(left: [number, number], right: [number, number]): number {
  return left[0] - right[0] || left[1] - right[1];
}

/** 把 mpv `track-list` 的原始条目收窄成会话的轨道描述；无法识别的条目丢弃。 */
function normalizeTracks(data: unknown): MpvTrack[] {
  if (!Array.isArray(data)) return [];
  const tracks: MpvTrack[] = [];
  for (const entry of data) {
    const raw = entry as Record<string, unknown>;
    const kind = raw?.type;
    if (kind !== 'video' && kind !== 'audio' && kind !== 'subtitle') continue;
    const id = typeof raw.id === 'number' ? raw.id : Number(raw.id);
    if (!Number.isFinite(id)) continue;
    tracks.push({
      id,
      kind,
      selected: raw.selected === true,
      label: textOf(raw.title) ?? textOf(raw['external-filename']),
      language: textOf(raw.lang),
      codec: textOf(raw.codec),
      width: numberOf(raw['demux-w']),
      height: numberOf(raw['demux-h']),
      bitrate: numberOf(raw['hls-bitrate']) ?? numberOf(raw['demux-bitrate']),
    });
  }
  return tracks;
}

function textOf(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function numberOf(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
