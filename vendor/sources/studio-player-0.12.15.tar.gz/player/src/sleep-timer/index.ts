import type { StudioPlayer, PlaybackCompletion, PlaybackEndAction } from '../player.js';

export interface SleepTimerClock {
  now(): number;
  setTimeout(callback: () => void, delayMs: number): unknown;
  clearTimeout(handle: unknown): void;
}

export interface SleepTimerOptions {
  clock?: SleepTimerClock;
  /** 非浏览器宿主可以注入生命周期事件目标；null 表示不绑定。 */
  visibilityTarget?: EventTarget | null;
  pageTarget?: EventTarget | null;
}

export type SleepTimerTrigger =
  | { readonly type: 'duration'; readonly durationMs: number }
  | { readonly type: 'items'; readonly count: number }
  | { readonly type: 'current' };

export interface SleepTimerRule {
  trigger: SleepTimerTrigger;
  action?: PlaybackEndAction;
}

export interface SleepTimerSnapshot {
  readonly status: 'idle' | 'running' | 'expired';
  readonly deadline: number | null;
  readonly remainingMs: number;
  readonly trigger: Readonly<SleepTimerTrigger> | null;
  readonly action: PlaybackEndAction;
  readonly remainingItems: number | null;
  readonly actionPending: boolean;
  readonly error: unknown;
}

/** 只决定触发条件与动作；停止/关闭由播放器统一执行，界面由接入方处理。 */
export class SleepTimerController extends EventTarget {
  private deadline: number | null = null;
  private status: SleepTimerSnapshot['status'] = 'idle';
  private timeout: unknown = null;
  private trigger: Readonly<SleepTimerTrigger> | null = null;
  private action: PlaybackEndAction = 'pause';
  private remainingItems: number | null = null;
  private actionPending = false;
  private error: unknown = null;
  private revision = 0;
  private actionAbort: AbortController | null = null;
  private destroyed = false;
  private readonly clock: SleepTimerClock;
  private readonly subscriptions: Array<() => void>;
  private readonly visibilityTarget: EventTarget | null;
  private readonly pageTarget: EventTarget | null;
  private readonly onWake = () => this.check();

  constructor(private readonly player: StudioPlayer, options: SleepTimerOptions = {}) {
    super();
    if (player.isDestroyed) throw new Error('Cannot add a timer to a destroyed player');
    this.clock = options.clock ?? {
      now: () => Date.now(),
      setTimeout: (callback, delay) => globalThis.setTimeout(callback, delay),
      clearTimeout: handle => globalThis.clearTimeout(handle as ReturnType<typeof setTimeout>),
    };
    this.visibilityTarget = options.visibilityTarget === undefined
      ? (typeof document === 'undefined' ? null : document) : options.visibilityTarget;
    this.pageTarget = options.pageTarget === undefined
      ? (typeof window === 'undefined' ? null : window) : options.pageTarget;
    this.subscriptions = [
      player.on('loadstart', this.onWake),
      player.on('beforeended', (completion: PlaybackCompletion) => this.onCompletion(completion)),
      player.on('play', this.onWake),
      player.on('stop', () => { if (this.status === 'running') this.cancel(); }),
      player.on('detach', () => this.cancel()),
      player.on('destroy', () => this.destroy()),
    ];
    try {
      this.visibilityTarget?.addEventListener('visibilitychange', this.onWake);
      this.pageTarget?.addEventListener('pageshow', this.onWake);
    } catch (error) {
      this.destroy();
      throw error;
    }
  }

  get isDestroyed(): boolean { return this.destroyed; }

  get snapshot(): SleepTimerSnapshot {
    return {
      status: this.status,
      deadline: this.deadline,
      remainingMs: this.deadline === null ? 0 : Math.max(0, this.deadline - this.clock.now()),
      trigger: this.trigger,
      action: this.action,
      remainingItems: this.remainingItems,
      actionPending: this.actionPending,
      error: this.error,
    };
  }

  /** 数字签名保留倒计时后暂停；规则可配置倒计时、自然完成次数与结束动作。 */
  start(input: number | SleepTimerRule): void {
    if (this.destroyed) throw new Error('Sleep timer has been destroyed');
    const rule = typeof input === 'number' ? { trigger: { type: 'duration' as const, durationMs: input } } : input;
    if (!rule || typeof rule !== 'object' || !rule.trigger || typeof rule.trigger !== 'object') {
      throw new TypeError('A sleep rule requires a trigger');
    }
    const action = rule.action ?? 'pause';
    if (!(['pause', 'stop', 'close'] as const).includes(action)) throw new TypeError('Unknown sleep action');
    const trigger = rule.trigger;
    if (this.player.currentPlan?.live && trigger.type !== 'duration') throw new RangeError('Live playback supports duration sleep only');
    let deadline: number | null = null;
    let remainingItems: number | null = null;
    if (trigger.type === 'duration') {
      deadline = this.clock.now() + trigger.durationMs;
      if (!Number.isFinite(trigger.durationMs) || trigger.durationMs <= 0 || !Number.isFinite(deadline)) {
        throw new RangeError('Sleep duration must be a positive finite number of milliseconds');
      }
    } else if (trigger.type === 'items') {
      if (!Number.isSafeInteger(trigger.count) || trigger.count <= 0) throw new RangeError('Sleep item count must be a positive safe integer');
      remainingItems = trigger.count;
    } else if (trigger.type === 'current') {
      if (!this.player.currentResourceId) throw new Error('Load an item before choosing end of current item');
      remainingItems = 1;
    } else {
      throw new TypeError('Unknown sleep trigger');
    }
    this.clearTask();
    this.invalidateAction();
    this.trigger = Object.freeze({ ...trigger });
    this.action = action;
    this.deadline = deadline;
    this.remainingItems = remainingItems;
    this.error = null;
    this.status = 'running';
    if (deadline !== null) this.check();
    else this.notify();
  }

  cancel(): void {
    this.clearTask();
    this.invalidateAction();
    this.deadline = null;
    this.trigger = null;
    this.remainingItems = null;
    this.error = null;
    this.status = 'idle';
    this.notify();
  }

  /** 恢复前台、宿主唤醒或测试时可主动校正，不依赖 tick 次数。 */
  check(): void {
    if (this.destroyed || this.status !== 'running' || this.deadline === null) return;
    this.clearTask();
    const remaining = this.snapshot.remainingMs;
    if (remaining === 0) {
      this.expire();
      return;
    }
    this.timeout = this.clock.setTimeout(this.onWake, Math.min(remaining, 1000));
    this.notify();
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.cancel();
    this.visibilityTarget?.removeEventListener('visibilitychange', this.onWake);
    this.pageTarget?.removeEventListener('pageshow', this.onWake);
    for (const unsubscribe of this.subscriptions) unsubscribe();
    this.dispatchEvent(new Event('destroy'));
  }

  private onCompletion(completion: PlaybackCompletion): void {
    this.check();
    if (this.destroyed || this.status !== 'running' || !completion.natural || this.remainingItems === null) return;
    this.remainingItems -= 1;
    if (this.remainingItems === 0) this.expire();
    else this.notify();
  }

  private expire(): void {
    this.clearTask();
    this.deadline = null;
    this.status = 'expired';
    this.actionPending = this.action !== 'pause';
    const revision = this.revision;
    const abort = new AbortController();
    this.actionAbort = abort;
    // stop/close 在首次 await 前同步取消接续、释放来源。
    const operation = this.action === 'close' ? this.player.close({ signal: abort.signal })
      : this.action === 'stop' ? this.player.stop() : this.player.pause();
    this.notify();
    this.dispatchEvent(new CustomEvent('expire', { detail: { trigger: this.trigger, action: this.action } }));
    void Promise.resolve(operation).then(() => {
      if (this.destroyed || revision !== this.revision) return;
      this.actionPending = false;
      this.actionAbort = null;
      this.notify();
      this.dispatchEvent(new Event('complete'));
    }, error => {
      if (this.destroyed || revision !== this.revision) return;
      if (error?.name === 'AbortError') { this.cancel(); return; }
      this.actionPending = false;
      this.actionAbort = null;
      this.error = error;
      this.notify();
      this.dispatchEvent(new CustomEvent('error', { detail: error }));
    });
  }

  private invalidateAction(): void {
    this.revision += 1;
    this.actionAbort?.abort();
    this.actionAbort = null;
    this.actionPending = false;
  }

  private notify(): void { this.dispatchEvent(new Event('change')); }

  private clearTask(): void {
    if (this.timeout !== null) this.clock.clearTimeout(this.timeout);
    this.timeout = null;
  }
}
