/**
 * 媒体轨道（音轨与字幕）公共契约
 * 
 * 背景：视频播放计划往往不包含完整外置轨道，需要外挂装配。
 */

export interface SubtitleTrack {
  /** 轨道唯一标识 */
  id: string;
  /** 字幕文件地址；浏览器首版实际装配 WebVTT，其他格式明确降级。 */
  src: string;
  /** 默认 text/vtt；显式其他类型不伪装成可用字幕。 */
  type?: string;
  /** 显示名称（如 "中文 (简体)"、"English"） */
  label: string;
  /** BCP 47 语言代码（如 'zh-CN', 'en-US'） */
  language: string;
  /** 字幕性质 */
  kind?: 'subtitles' | 'captions' | 'descriptions' | 'chapters';
  /** 是否默认启用 */
  default?: boolean;
}

export interface AudioTrack {
  /** server 表示由产品 prepareSource 重新交付，和实际 HLS/原生列表分开。 */
  delivery?: 'server';
  /** 轨道唯一标识 */
  id: string;
  /** 外挂音轨声明；需要宿主合流/交付计划。首版切换媒体实际暴露的原生/HLS 音轨，不并行播放此 URL。 */
  src?: string;
  /** 显示名称（如 "普通话 (原声)"、"英语 (解说)"） */
  label: string;
  /** BCP 47 语言代码 */
  language: string;
  /** 是否默认选择 */
  default?: boolean;
}

/** 媒体外挂轨道清单 */
export interface MediaTracksManifest {
  subtitles?: SubtitleTrack[];
  audio?: AudioTrack[];
}
