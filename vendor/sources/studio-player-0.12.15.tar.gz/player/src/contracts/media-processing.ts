import type { PlaybackPlan } from './plan.js';

export type MediaProcessingProfile = 'h264-aac-mkv-to-mp4' | 'alac-to-flac' | 'h264-ac3-to-aac';
export type MediaProcessingState = 'preparing' | 'ready' | 'failed' | 'cancelled' | 'released';
/** No executable, path, or host runtime in the playback lifecycle contract. */
export interface MediaProcessingSession {
  readonly resourceId: string;
  readonly state: MediaProcessingState;
  readonly ready: Promise<PlaybackPlan>;
  /** Cancels preparation and waits for process/temporary resource termination. */
  cancel(): Promise<void>;
  /** Also removes a successful output. Safe to repeat. */
  release(): Promise<void>;
}
export type MediaProcessingErrorCode = 'invalid-input' | 'unavailable' | 'tool-mismatch' | 'tool-policy'
  | 'busy' | 'timeout' | 'cancelled' | 'read-limit' | 'log-limit' | 'output-limit' | 'space-limit'
  | 'invalid-media' | 'profile-mismatch' | 'lossy-not-allowed' | 'preservation-required'
  | 'processing-failed' | 'verification-failed' | 'cleanup-failed';
export class MediaProcessingError extends Error {
  readonly name = 'MediaProcessingError';
  constructor(public readonly code: MediaProcessingErrorCode) { super(`Media processing failed: ${code}`); }
}
