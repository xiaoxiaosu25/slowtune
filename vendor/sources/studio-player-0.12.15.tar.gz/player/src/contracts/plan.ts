/**
 * 播放计划与媒体来源公共契约
 * 
 * 层次边界：见 packages/audio-video/player/README.md 的"契约层边界"
 * 负责标准化表达：播放策略、传输协议、回退源、超时控制与临时凭据，
 * 彻底切断底层引擎与各产品私有数据结构的耦合。
 */

import type { MediaTracksManifest } from './tracks.js';
import type { MediaProcessingSession } from './media-processing.js';

/** 播放策略：说明当前媒体是以何种方式交付 */
export type PlaybackStrategy =
  | 'direct'      // 直连源：客户端可直接通过 HTTP(S)/本地路径播放
  | 'proxy'       // 后端代理流：由各产品服务端代为拉取并分发（例如绕过防盗链或内网穿透）
  | 'transcode'   // 实时转码：服务端实时推流输出（如 HLS/TS 或 HLS/fMP4）
  | 'fallback';   // 降级回退：主源失败后切换的备用策略

/** 传输协议形式 */
export type PlaybackTransport =
  | 'range'       // 标准 HTTP Range 单文件流式点播 (MP4/MP3/WebM 等)
  | 'hls'         // HTTP Live Streaming 分片流 (MPEG-TS 或 fMP4 切片)
  | 'dash'        // Dynamic Adaptive Streaming over HTTP
  | 'flv'         // HTTP FLV via an explicitly installed MSE adapter
  | 'webrtc';     // 低延迟实时流

/**
 * 播放过程超时配置（单位：秒）。
 *
 * resolve 用于 resolver 等待；initial/stall 用于 Video.js 路径。
 * 省略或 0 禁用；已支持项须为有限非负秒数且不超过 2147483.647。
 * connect/read 尚未消费。mpv 不消费 initial/stall。
 */
export interface PlaybackTimeouts {
  /** 建立连接超时（未消费） */
  connect?: number;
  /** 数据读取与分片等待超时（未消费） */
  read?: number;
  /** resolver 单次取址等待上限；超时保留当前来源，取消请求并报告诊断 */
  resolve?: number;
  /** 有播放意图后等待 playing 的上限（不表示首帧渲染） */
  initial?: number;
  /** 已起播后 waiting/stalled 且时间未推进的等待上限 */
  stall?: number;
}

/** 转码/处理会话信息（服务于实时转码与保活） */
export interface PlaybackProcessing {
  /** 转码服务是否可用 */
  available: boolean;
  /** 推荐处理模式（如 'copy' 流复制 / 'hevc_transcode' / 'aac_transcode'）；已解析、当前未消费 */
  recommendedMode?: string;
  /** 不可用原因说明；已解析、当前未消费（公共层不据此改变播放策略） */
  unavailableReason?: string;
  /** 转码心跳与控制端点 URL（用于心跳保活与释放） */
  sessionEndpoint?: string;
  /** Optional local/host session ownership; never reconstructed from untrusted JSON. */
  session?: MediaProcessingSession;
}

/**
 * 完整备用源描述。
 * `fallbackUrl` 仍保留为同传输类型备用源的简写；需要改变 transport、
 * MIME、请求头或转码会话时使用此结构。
 */
export interface PlaybackFallback {
  playUrl: string;
  transport?: PlaybackTransport;
  mimeType?: string;
  expiresAt?: number;
  /** 仅对 HLS/XHR 链路生效。 */
  headers?: Record<string, string>;
  processing?: PlaybackProcessing;
  /** 备用交付独立的时间轴；省略表示完整原文件（零偏移）。 */
  timeline?: PlaybackPlan['timeline'];
}

/**
 * 标准播放计划（厚契约）
 * 
 * 消化 MediaDock / link-studio 及未来产品的后端调度元数据。
 */
export interface PlaybackPlan {
  /** 媒体资源全局唯一标识符（由宿主/产品分配） */
  resourceId: string;
  /** 媒体基础大类 */
  mediaType: 'audio' | 'video';
  /** A live session has no VOD checkpoint or natural queue completion. */
  live?: boolean;
  /** 播放交付策略 */
  strategy: PlaybackStrategy;
  /** 传输协议 */
  transport: PlaybackTransport;
  /** 主播放地址（绝对 URL、相对路径或 file://） */
  playUrl: string;
  /** 同传输类型备用播放地址；跨传输备用源请使用 fallback */
  fallbackUrl?: string;
  /** 完整备用源；用于备用源与主源具有不同传输元数据的场景 */
  fallback?: PlaybackFallback;
  /** 链接签名过期时间戳（毫秒级 Unix Timestamp，用于防盗链预判刷新） */
  expiresAt?: number;
  /** 明确声明的 MIME 类型（如 'application/vnd.apple.mpegurl'，避免无后缀直链识别错误） */
  mimeType?: string;
  /** 媒体总时长（秒，已知时提供） */
  durationSeconds?: number;
  /** 分段处理输出的零点对应原文件的秒数；所有公共位置仍使用原文件时间轴。 */
  timeline?: { readonly offsetSeconds: number; readonly durationSeconds?: number };
  /** 服务端记录的初始断点恢复秒数（若产品在计划中直接返回）；由 StudioPlayer 起播时读取 */
  resumePositionSeconds?: number;
  /** 各阶段超时配置；支持范围见 PlaybackTimeouts */
  timeouts?: PlaybackTimeouts;
  /** 实时转码与会话控制参数 */
  processing?: PlaybackProcessing;
  /** HLS/XHR 链路的自定义请求头；原生 HTML 媒体路径不能注入任意请求头 */
  headers?: Record<string, string>;
  /**
   * 已解析的外挂音轨与字幕清单；未随计划返回时由产品侧 resolver 获取。
   * video-tracks 消费 WebVTT 字幕；音轨选择使用媒体实际暴露的原生/HLS 列表。
   */
  tracks?: MediaTracksManifest;
  /** 宿主扩展自定义元数据（标题、封面、艺术家等展示字段） */
  metadata?: Record<string, unknown>;
}

/**
 * 简单媒体源输入（薄契约）
 * 
 * 适用于无需复杂后端计划调度的退化场景（如本地选文件直接试听、简单的静态 URL 预览）。
 */
export interface SimpleMediaSource {
  /** 播放源 URL */
  src: string;
  /** 可选的媒体类型（如 'video/mp4'、'audio/mpeg'） */
  type?: string;
  /** 可选的资源标识（若不传则以 src 作为临时标识） */
  resourceId?: string;
  /** 可选标题 */
  title?: string;
  /** HLS/XHR 链路的自定义请求头；原生 HTML 媒体路径不能注入任意请求头 */
  headers?: Record<string, string>;
}

/** 播放器支持的媒体源输入类型联合 */
export interface DeferredMediaSource {
  /** 稳定资源标识，不能使用临时 URL。 */
  resourceId: string;
  /** 首次异步准备的等待上限（秒）；省略或 0 禁用。 */
  resolveTimeoutSeconds?: number;
  prepare(context: { readonly signal: AbortSignal; readonly restart: boolean }): Promise<PlaybackPlan> | PlaybackPlan;
}

export type PlayableInput = PlaybackPlan | SimpleMediaSource | DeferredMediaSource | string;

export function isDeferredMediaSource(input: PlayableInput): input is DeferredMediaSource {
  return typeof input === 'object' && input !== null && 'prepare' in input && typeof input.prepare === 'function';
}

/** 判断输入是否为标准播放计划（类型保护） */
export function isPlaybackPlan(input: PlayableInput): input is PlaybackPlan {
  if (typeof input !== 'object' || input === null) return false;
  const candidate = input as unknown as Record<string, unknown>;
  return typeof candidate.resourceId === 'string'
    && (candidate.mediaType === 'audio' || candidate.mediaType === 'video')
    && typeof candidate.strategy === 'string'
    && typeof candidate.transport === 'string'
    && typeof candidate.playUrl === 'string';
}

/** 判断输入是否为简单对象源 */
export function isSimpleMediaSource(input: PlayableInput): input is SimpleMediaSource {
  return typeof input === 'object'
    && input !== null
    && typeof (input as unknown as Record<string, unknown>).src === 'string';
}
