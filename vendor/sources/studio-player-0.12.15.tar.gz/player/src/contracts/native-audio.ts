import type { DeliveryTarget } from './delivery.js';

export interface NativeAudioLoad {
  readonly playbackId: string;
  readonly source: DeliveryTarget;
  readonly metadata: Readonly<Record<string, unknown>>;
  readonly durationSeconds?: number;
}
export type NativeAudioEvent =
  | { readonly playbackId: string; readonly type: 'progress'; readonly positionSeconds: number; readonly durationSeconds: number; readonly ready: boolean }
  | { readonly playbackId: string; readonly type: 'state'; readonly state: 'playing' | 'paused' | 'buffering' | 'ready' }
  | { readonly playbackId: string; readonly type: 'ended' }
  | { readonly playbackId: string; readonly type: 'error'; readonly error: unknown };

/** 原生服务拥有实际播放、音频焦点、通知及凭据；公共层只发送命令和读取事实。 */
export interface NativeAudioPort {
  load(request: NativeAudioLoad): void;
  play(): void;
  pause(): void;
  seek(positionSeconds: number): void;
  setPreferences(volume: number, muted: boolean, rate: number): void;
  stop(): void;
  subscribe(listener: (event: NativeAudioEvent) => void): () => void;
}
