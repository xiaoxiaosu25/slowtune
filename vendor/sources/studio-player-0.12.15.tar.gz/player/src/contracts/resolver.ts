/**
 * 来源动态取址与生命周期端口
 * 
 * 解决问题：
 * 1. 临时签名 URL 到期前的静默换源（如 AList、云存储临时 STS）
 * 2. 主源失败时向后端重新申请降级/转码源
 * 3. 实时转码会话（Transcode Session）的心跳与关闭通知
 */

import type { PlaybackPlan } from './plan.js';

export type ResolveReason =
  | 'expired'    // 链接已过期或即将到期
  | 'fallback'   // 当前主源致命错误触发自动降级
  | 'retry';     // 网络临时中断后重试

/** 动态取址与流服务控制端口 */
export interface SourceResolverPort {
  /** 可选产品恢复决策；返回 null 进入终态。核心限制尝试次数，禁止产品再平行重试。 */
  recoverSource?(resourceId: string, currentPlan: PlaybackPlan, context: {
    readonly signal: AbortSignal; readonly error: unknown; readonly positionSeconds: number; readonly paused: boolean;
  }): Promise<PlaybackPlan | null> | PlaybackPlan | null;
  /** 显式定位/媒体选项引起的同资源重新准备；迟到会话由核心释放。 */
  prepareSource?(resourceId: string, currentPlan: PlaybackPlan, context: SourcePreparationContext): Promise<PlaybackPlan> | PlaybackPlan;
  /**
   * 动态刷新或重新解析播放地址/计划
   * @param resourceId 资源标识
   * @param currentPlan 当前播放计划
   * @param reason 请求刷新的原因
   * @returns 新的播放 URL 或全新的完整播放计划
   * 返回计划中新增的 sessionEndpoint 将其释放责任交给控制器：即使请求
   * 已被换源或销毁取代，也会关闭未采用的新会话。仍被当前计划使用的端点
   * 不会因此关闭；跨控制器共享会话时，宿主应在端口内管理引用计数。
   */
  resolveUrl?(
    resourceId: string,
    currentPlan: PlaybackPlan,
    reason: ResolveReason,
    /** 换源、卸载或解析超时时取消；旧三参数实现仍兼容。 */
    context?: { readonly signal: AbortSignal }
  ): Promise<string | PlaybackPlan> | string | PlaybackPlan;

  /**
   * 转码或流媒体会话心跳上报
   * @param sessionEndpoint 计划中返回的 session 控制端点
   * @param currentTime 当前播放时间（秒）
   */
  onSessionHeartbeat?(sessionEndpoint: string, currentTime: number): Promise<void> | void;

  /**
   * 计划被替换、播放器销毁或迟到计划被丢弃时释放远端转码会话
   * @param sessionEndpoint 计划中返回的 session 控制端点
   */
  onSessionClose?(sessionEndpoint: string): Promise<void> | void;
}

export interface SourcePreparationContext {
  readonly signal: AbortSignal;
  readonly reason: 'seek' | 'audio-track' | 'output-height';
  readonly positionSeconds: number;
  readonly paused: boolean;
  readonly audioTrackId?: string;
  readonly outputHeight?: number;
}
