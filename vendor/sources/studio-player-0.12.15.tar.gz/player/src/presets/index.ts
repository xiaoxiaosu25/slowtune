import { StudioPlayer, type StudioPlayerOptions } from '../player.js';
import { QueueController, validateQueueOptions, type QueueOptions } from '../queue/index.js';
import { SleepTimerController, type SleepTimerOptions } from '../sleep-timer/index.js';
import { MediaSessionController, type MediaSessionOptions } from '../media-session/index.js';
import { MainMediaCoordinator, type MainMediaController } from '../main-media/index.js';
import { VideoTracksController } from '../video-tracks/index.js';

export type PlayerPresetName = 'preview' | 'audio' | 'video';
export type PlayerFeatureName = 'queue' | 'sleepTimer' | 'mediaSession' | 'videoTracks' | 'mainMedia';

/** 省略沿用场景默认值；false 明确禁用，true 使用默认配置，对象提供具体配置。 */
export interface PlayerFeatureOptions {
  queue?: boolean | QueueOptions;
  sleepTimer?: boolean | SleepTimerOptions;
  /** 队列由装配方接线，避免系统控制连接到另一播放器的队列。 */
  mediaSession?: boolean | Omit<MediaSessionOptions, 'queue'>;
  videoTracks?: boolean;
  /** 必须由消费者显式提供范围；省略不做主媒体互斥。 */
  mainMedia?: false | { scope: MainMediaCoordinator };
}

/** 只拥有这里创建的功能；移除 mainMedia 会暂停并释放归属，但不销毁借用的播放器。 */
export interface PlayerFeatures extends EventTarget {
  readonly queue: QueueController | null;
  readonly sleepTimer: SleepTimerController | null;
  readonly mediaSession: MediaSessionController | null;
  readonly videoTracks: VideoTracksController | null;
  readonly mainMedia: MainMediaController | null;
  readonly isDestroyed: boolean;
  /** 不影响未切换的功能。重新开启时使用装配时的配置，不恢复旧列表或计时。 */
  setEnabled(feature: PlayerFeatureName, enabled: boolean): void;
  destroy(): void;
}

export interface PlayerPresetOptions extends StudioPlayerOptions {
  /** 默认由 progressStorage 的存在决定；false 即使提供了存储也不接入。 */
  progress?: boolean;
  features?: PlayerFeatureOptions;
  /** 复用宿主已创建的播放器/端口实现，用于远程 renderer。 */
  player?: StudioPlayer;
}

export interface PlayerPreset {
  readonly name: PlayerPresetName;
  readonly player: StudioPlayer;
  readonly features: PlayerFeatures;
  /** 结束本次播放，释放播放器及功能；界面的显示/隐藏由调用方负责。 */
  destroy(): void;
}

const featureNames: readonly PlayerFeatureName[] = ['mainMedia', 'queue', 'sleepTimer', 'mediaSession', 'videoTracks'];
type FeatureSettings = {
  queue: QueueOptions;
  sleepTimer: SleepTimerOptions;
  mediaSession: Omit<MediaSessionOptions, 'queue'>;
  mainMedia: MainMediaCoordinator | null;
};

function object(value: unknown, label: string): asserts value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError(`${label} must be an options object`);
  }
}

function keys(value: Record<string, unknown>, allowed: readonly string[], label: string): void {
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) throw new TypeError(`Unknown ${label} option: ${key}`);
  }
}

function methods(value: unknown, names: readonly string[], label: string): void {
  object(value, label);
  for (const name of names) {
    if (typeof value[name] !== 'function') throw new TypeError(`${label}.${name} must be a function`);
  }
}

/** 先完整校验，避免第二个功能的配置错误留下第一个功能的监听。 */
function validateFeatures(options: PlayerFeatureOptions): void {
  object(options, 'features');
  keys(options as Record<string, unknown>, featureNames, 'features');
  for (const name of featureNames) {
    const value = options[name];
    if (name === 'mainMedia') {
      if (value === undefined || value === false) continue;
      object(value, name); keys(value, ['scope'], name);
      if (!(value.scope instanceof MainMediaCoordinator) || value.scope.isDestroyed) throw new TypeError('mainMedia requires a live consumer-provided scope');
      continue;
    }
    if (name === 'videoTracks' && value !== undefined && typeof value !== 'boolean') throw new TypeError('videoTracks must be a boolean');
    if (value === undefined || typeof value === 'boolean') continue;
    object(value, name);
    if (name === 'queue') {
      keys(value, ['autoAdvance', 'order', 'repeat', 'random'], name);
      validateQueueOptions(value);
    } else if (name === 'sleepTimer') {
      keys(value, ['clock', 'visibilityTarget', 'pageTarget'], name);
      if (value.clock !== undefined) methods(value.clock, ['now', 'setTimeout', 'clearTimeout'], 'sleepTimer.clock');
      for (const target of ['visibilityTarget', 'pageTarget']) {
        if (value[target] != null) methods(value[target], ['addEventListener', 'removeEventListener'], `sleepTimer.${target}`);
      }
    } else {
      keys(value, ['session', 'getMetadata', 'createMetadata'], name);
      if (value.session != null) {
        methods(value.session, ['setActionHandler'], 'mediaSession.session');
        const port = value.session as Record<string, unknown>;
        if (port.setPositionState !== undefined && typeof port.setPositionState !== 'function') {
          throw new TypeError('mediaSession.session.setPositionState must be a function');
        }
      }
      for (const callback of ['getMetadata', 'createMetadata']) {
        if (value[callback] !== undefined && typeof value[callback] !== 'function') {
          throw new TypeError(`mediaSession.${callback} must be a function`);
        }
      }
    }
  }
}

class FeatureGroup extends EventTarget implements PlayerFeatures {
  private currentQueue: QueueController | null = null;
  private currentTimer: SleepTimerController | null = null;
  private currentSession: MediaSessionController | null = null;
  private currentTracks: VideoTracksController | null = null;
  private currentMainMedia: MainMediaController | null = null;
  private destroyed = false;
  private readonly settings: FeatureSettings;
  private readonly unsubscribe: () => void;

  constructor(private readonly player: StudioPlayer, options: PlayerFeatureOptions, autoAdvance: boolean) {
    super();
    if (player.isDestroyed) throw new Error('Cannot mount features on a destroyed player');
    validateFeatures(options);
    this.settings = {
      queue: { ...(typeof options.queue === 'object' ? options.queue : {}),
        autoAdvance: typeof options.queue === 'object' ? options.queue.autoAdvance ?? autoAdvance : autoAdvance },
      sleepTimer: { ...(typeof options.sleepTimer === 'object' ? options.sleepTimer : {}) },
      mediaSession: { ...(typeof options.mediaSession === 'object' ? options.mediaSession : {}) },
      mainMedia: options.mainMedia ? options.mainMedia.scope : null,
    };
    this.unsubscribe = player.on('destroy', () => this.destroy());
    try {
      for (const name of featureNames) this.setEnabled(name, Boolean(options[name]));
    } catch (error) {
      this.destroy();
      throw error;
    }
  }

  get queue(): QueueController | null { return this.currentQueue; }
  get sleepTimer(): SleepTimerController | null { return this.currentTimer; }
  get mediaSession(): MediaSessionController | null { return this.currentSession; }
  get videoTracks(): VideoTracksController | null { return this.currentTracks; }
  get mainMedia(): MainMediaController | null { return this.currentMainMedia; }
  get isDestroyed(): boolean { return this.destroyed; }

  setEnabled(feature: PlayerFeatureName, enabled: boolean): void {
    if (this.destroyed) throw new Error('Player features have been destroyed');
    if (!featureNames.includes(feature)) throw new TypeError(`Unknown player feature: ${feature}`);
    if (typeof enabled !== 'boolean') throw new TypeError('Feature enabled must be a boolean');
    if (Boolean(this[feature]) === enabled) return;
    try {
      if (feature === 'queue') {
        // 只更新队列依赖，保留系统会话对象、元数据和活动归属。
        this.currentQueue?.destroy();
        this.currentQueue = enabled ? new QueueController(this.player, this.settings.queue) : null;
        this.currentSession?.setQueue(this.currentQueue ?? undefined);
      } else if (feature === 'sleepTimer') {
        this.currentTimer?.destroy();
        this.currentTimer = enabled ? new SleepTimerController(this.player, this.settings.sleepTimer) : null;
      } else if (feature === 'mediaSession') {
        this.currentSession?.destroy();
        this.currentSession = enabled ? this.createSession() : null;
      } else if (feature === 'videoTracks') {
        this.currentTracks?.destroy();
        this.currentTracks = enabled ? new VideoTracksController(this.player) : null;
      } else {
        if (enabled && !this.settings.mainMedia) throw new TypeError('mainMedia requires a consumer-provided scope');
        this.currentMainMedia?.destroy();
        this.currentMainMedia = enabled ? this.settings.mainMedia!.register(this.player) : null;
      }
      this.dispatchEvent(new Event('change'));
    } catch (error) {
      this.destroy();
      throw error;
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.unsubscribe();
    this.currentMainMedia?.destroy(); this.currentMainMedia = null;
    this.currentTracks?.destroy(); this.currentTracks = null;
    this.currentSession?.destroy();
    this.currentSession = null;
    this.currentTimer?.destroy();
    this.currentTimer = null;
    this.currentQueue?.destroy();
    this.currentQueue = null;
    this.dispatchEvent(new Event('change'));
    this.dispatchEvent(new Event('destroy'));
  }

  private createSession(): MediaSessionController {
    return new MediaSessionController(this.player, { ...this.settings.mediaSession, queue: this.currentQueue ?? undefined });
  }
}

/** 已有播放器的便捷装配入口；默认不启用任何功能，队列开启后默认顺序接续。 */
export function mountPlayerFeatures(player: StudioPlayer, options: PlayerFeatureOptions = {}): PlayerFeatures {
  return new FeatureGroup(player, options, true);
}

/**
 * 场景只决定默认行为，不创建 DOM、读取产品存储、加载来源或自动接管系统媒体。
 * UI 使用上游公开皮肤或自绘；独立模块入口仍可直接使用。
 */
export function createPlayerPreset(name: PlayerPresetName, options: PlayerPresetOptions = {}): PlayerPreset {
  if (!(['preview', 'audio', 'video'] as const).includes(name)) {
    throw new TypeError(`Unknown player preset: ${name}`);
  }
  object(options as unknown, 'preset');
  if (options.progress !== undefined && typeof options.progress !== 'boolean') {
    throw new TypeError('progress must be a boolean');
  }
  const { features = {}, progress, progressStorage, progressPolicy, player: providedPlayer, ...playerOptions } = options;
  validateFeatures(features);
  const remember = progress ?? (progressStorage !== undefined);
  if (remember) methods(progressStorage, ['load', 'save', 'clear'], 'progressStorage');
  else if (progress !== false && progressPolicy !== undefined) {
    throw new TypeError('progressPolicy requires progressStorage');
  }
  // undefined 不覆盖默认值；false 才是显式关闭。
  const selected: PlayerFeatureOptions = {
    queue: features.queue ?? (name !== 'preview'),
    sleepTimer: features.sleepTimer ?? (name !== 'preview'),
    mediaSession: features.mediaSession ?? (name !== 'preview'),
    videoTracks: features.videoTracks ?? (name === 'video'),
    mainMedia: features.mainMedia ?? false,
  };
  const player = providedPlayer ?? new StudioPlayer({
    ...playerOptions,
    nativeElementTag: playerOptions.nativeElementTag ?? (name === 'audio' ? 'audio' : 'video'),
    progressStorage: remember ? progressStorage : undefined,
    progressPolicy: remember ? progressPolicy : undefined,
  });
  try {
    const group = new FeatureGroup(player, selected, name === 'audio');
    return Object.freeze({ name, player, features: group, destroy: () => player.destroy() });
  } catch (error) {
    player.destroy();
    throw error;
  }
}
