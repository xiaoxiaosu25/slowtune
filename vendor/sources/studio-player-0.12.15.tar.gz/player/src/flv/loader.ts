interface Range { from: number; to: number }
interface Source { url: string; cors?: boolean; withCredentials?: boolean }
interface SeekHandler { getConfig(url: string, range: Range): { url: string; headers?: Record<string, string> } }
interface Config { headers?: Record<string, string> }

/** mpegts.js's public customLoader port. Each read keeps its own cancellation
 * signal, including after destroy has detached the engine callbacks. */
export class FlvFetchLoader {
  readonly type = 'studio-flv-fetch';
  readonly needStashBuffer = true;
  status = 0;
  onContentLengthKnown?: (length: number) => void;
  onURLRedirect?: (url: string) => void;
  onDataArrival?: (chunk: ArrayBuffer, start: number, received: number) => void;
  onError?: (type: string, info: { code: number; msg: string }) => void;
  onComplete?: (from: number, to: number) => void;
  private generation = 0;
  private controller?: AbortController;
  private reader?: ReadableStreamDefaultReader<Uint8Array>;
  constructor(private seek: SeekHandler, private config: Config) {}
  isWorking() { return this.status === 1 || this.status === 2; }
  open(source: Source, range: Range) {
    this.abort();
    const generation = this.generation, controller = new AbortController();
    this.controller = controller; this.status = 1;
    void this.read(source, range, controller, generation);
  }
  private async read(source: Source, range: Range, controller: AbortController, generation: number) {
    const active = () => !controller.signal.aborted && generation === this.generation;
    let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
    try {
      const request = this.seek.getConfig(source.url, range);
      const response = await fetch(request.url, { signal: controller.signal,
        headers: { ...request.headers, ...this.config.headers }, mode: source.cors === false ? 'same-origin' : 'cors',
        credentials: source.withCredentials ? 'include' : 'same-origin' });
      if (!active()) { await response.body?.cancel(); return; }
      if (!response.ok || !response.body) {
        await response.body?.cancel(); this.status = 3;
        this.onError?.('HttpStatusCodeInvalid', { code: response.status, msg: 'Live media request failed' }); return;
      }
      reader = response.body.getReader(); this.reader = reader; this.status = 2;
      const expected = Number(response.headers.get('content-length'));
      if (Number.isSafeInteger(expected) && expected > 0) this.onContentLengthKnown?.(expected);
      let received = 0;
      while (active()) {
        const part = await reader.read();
        if (!active()) return;
        if (part.done) {
          if (expected > 0 && received < expected) { this.status = 3; this.onError?.('EarlyEof', { code: -1, msg: 'Live media ended before the declared length' }); }
          else { this.status = 4; this.onComplete?.(range.from, range.from + received - 1); }
          return;
        }
        const bytes = part.value.slice(), start = range.from + received; received += bytes.byteLength;
        this.onDataArrival?.(bytes.buffer, start, received);
      }
    } catch {
      if (active()) { this.status = 3; this.onError?.('Exception', { code: -1, msg: 'Live media connection failed' }); }
    } finally {
      await reader?.cancel().catch(() => {});
      if (generation === this.generation) this.reader = undefined;
    }
  }
  abort() {
    this.generation++; this.controller?.abort(); this.controller = undefined;
    void this.reader?.cancel().catch(() => {}); this.reader = undefined; this.status = 0;
  }
  destroy() {
    this.abort(); this.onContentLengthKnown = this.onURLRedirect = this.onDataArrival = this.onError = this.onComplete = undefined;
  }
}
