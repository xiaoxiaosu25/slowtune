import { registerFlv } from '../backends/videojs/flv.js';
import type { DeliveryTarget } from '../contracts/delivery.js';
import { FlvFetchLoader } from './loader.js';

export interface FlvEngine {
  attachMediaElement(media: HTMLMediaElement): void;
  detachMediaElement(): void;
  load(): void;
  unload(): void;
  destroy(): void;
  on(event: string, listener: (...args: any[]) => void): void;
  off(event: string, listener: (...args: any[]) => void): void;
}
/** Structural port implemented by mpegts.js. The core never imports a decoder runtime. */
export interface FlvRuntime {
  isSupported(): boolean;
  createPlayer(source: { type: string; url: string; isLive: boolean; cors: boolean; withCredentials: boolean }, config: Record<string, unknown>): FlvEngine;
  Events: { ERROR: string };
}

/** Install once on the same native/videojs element already owned by StudioPlayer. */
export function installFlvPlayback(element: HTMLMediaElement & { source?: unknown; target?: HTMLMediaElement }, runtime: FlvRuntime): () => void {
  let generation = 0;
  let engine: FlvEngine | undefined;
  let unlisten: (() => void) | undefined;
  const release = () => {
    generation++;
    const previous = engine; engine = undefined;
    unlisten?.(); unlisten = undefined;
    if (previous) {
      try { previous.unload(); } finally { try { previous.detachMediaElement(); } finally { previous.destroy(); } }
    }
  };
  return registerFlv(element, {
    release,
    apply(target: DeliveryTarget) {
      release();
      if (!runtime.isSupported()) throw new Error('HTTP FLV requires MediaSource support');
      const current = generation;
      // Switch the existing Video.js target to its native delegate first. Its setter
      // schedules a load; our setup follows that microtask, with the same ownership guard.
      const idle = { src: '', type: 'video/mp4', preferPlayback: 'native' };
      if ('source' in element) element.source = idle;
      const failed = () => { if (generation === current) element.dispatchEvent(new Event('error')); };
      queueMicrotask(() => {
        if (generation !== current || ('source' in element && element.source !== idle)) return;
        try {
          const media = element.target ?? element;
          media.removeAttribute('src');
          engine = runtime.createPlayer({ type: 'flv', url: target.src, isLive: target.live === true, cors: true, withCredentials: true }, {
            enableWorker: false, enableStashBuffer: false, lazyLoad: false,
            customLoader: FlvFetchLoader,
            autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: 30, autoCleanupMinBackwardDuration: 15,
            liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 10, liveBufferLatencyMinRemain: 2,
            ...(target.headers ? { headers: target.headers } : {}),
          });
          const active = engine;
          active.on(runtime.Events.ERROR, failed);
          unlisten = () => active.off(runtime.Events.ERROR, failed);
          active.attachMediaElement(media); active.load();
        } catch { failed(); }
      });
    },
  });
}
