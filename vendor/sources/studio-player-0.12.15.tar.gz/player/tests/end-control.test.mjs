import test from 'node:test';
import assert from 'node:assert/strict';
import { QueueController, SleepTimerController, MediaSessionController } from '@studio/player';
import { createPlayerPreset, mountPlayerFeatures } from '@studio/player/presets';
import { Media, Clock, Session, plan, items, settle, deferred, metadataFactory, setup } from './helpers.mjs';

const durationRule = (durationMs, action) => ({ trigger: { type: 'duration', durationMs }, action });
const countRule = (count, action) => ({ trigger: { type: 'items', count }, action });

test('End control: pause keeps the session; stop saves the actual position and releases it without losing the queue', async t => {
  const saved = new Map();
  const closed = [];
  const { player, media } = setup(t, {
    progressStorage: { load: id => saved.get(id), save: (id, position) => saved.set(id, position), clear: id => saved.delete(id) },
    sourceResolver: { onSessionHeartbeat() {}, onSessionClose: endpoint => closed.push(endpoint) },
  });
  const queue = new QueueController(player);
  const port = new Session();
  const session = new MediaSessionController(player, { session: port, queue, createMetadata: metadataFactory });
  queue.setItems([{ id: 'a', source: plan('a', { processing: { sessionEndpoint: '/sessions/a' } }) }, ...items.slice(1)]);
  await queue.select(0);
  session.activate();
  media.currentTime = 37.25; // No timeupdate: stop must capture the current position, not the last tick.
  player.pause();
  assert.equal(player.currentTime, 37.25);
  assert.equal(player.currentResourceId, 'a');
  assert.equal(closed.length, 0);
  assert.equal(session.active, true);
  await player.play();
  await player.stop();
  assert.equal(saved.get('a'), 37.25);
  assert.equal(player.state, 'stopped');
  assert.equal(player.currentResourceId, null);
  assert.equal(player.element, media);
  assert.equal(media.src, '');
  assert.equal(media.listenerCount, 0);
  assert.equal(player.sourceController.heartbeatTimer, null);
  assert.equal(player.sourceController.expiryTimer, null);
  assert.deepEqual(closed, ['/sessions/a']);
  assert.equal(queue.snapshot.index, 0);
  assert.equal(queue.snapshot.items.length, 3);
  assert.equal(session.active, false);
  assert.equal(port.handlers.size, 0);
  await assert.rejects(player.play(), { name: 'InvalidStateError' });
  await queue.select(0);
  await settle();
  assert.equal(player.currentTime, 37.25);
  assert.equal(player.paused, false);
});

test('Sleep: a custom 23-minute countdown pauses at the deadline and keeps the current session', async t => {
  const { player, media } = setup(t);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  await player.load(plan('a'));
  await player.play();
  media.currentTime = 31;
  timer.start(durationRule(23 * 60 * 1000, 'pause'));
  clock.jump(23 * 60 * 1000 - 1);
  assert.equal(player.paused, false);
  assert.equal(timer.snapshot.remainingMs, 1);
  clock.jump(1);
  assert.equal(player.paused, true);
  assert.equal(player.currentTime, 31);
  assert.equal(player.currentResourceId, 'a');
  assert.equal(timer.snapshot.status, 'expired');
  assert.equal(clock.tasks.size, 0);
  await player.play();
  assert.equal(player.paused, false);
});

test('Sleep: three natural completions stop before item four; a manual skip and a stale ended callback do not count', async t => {
  const saved = new Map();
  const { player, media } = setup(t, {
    progressStorage: { load: id => saved.get(id), save: (id, position) => saved.set(id, position), clear: id => saved.delete(id) },
  });
  const queue = new QueueController(player);
  const timer = new SleepTimerController(player);
  queue.setItems(['a', 'b', 'c', 'd', 'e'].map(id => ({ id, source: plan(id) })));
  await queue.select(0);
  timer.start(countRule(3, 'stop'));
  await queue.next();
  assert.equal(timer.snapshot.remainingItems, 3);
  for (const [id, remaining] of [['b', 2], ['c', 1], ['d', 0]]) {
    assert.equal(player.currentResourceId, id);
    const oldEnded = [...media.listeners.get('ended')][0];
    media.finish();
    oldEnded();
    await settle();
    assert.equal(timer.snapshot.remainingItems, remaining);
  }
  assert.equal(player.state, 'stopped');
  assert.equal(media.playCalls, 4);
  assert.equal(queue.snapshot.index, 3);
  assert.equal(queue.snapshot.items.length, 5);
  assert.equal(saved.has('d'), false, 'a completed item must not be saved again by stop');
  assert.equal(timer.snapshot.error, null);
});

test('Sleep: duplicate native ended events count once, while an explicit replay starts a new completion', async t => {
  const { player, media } = setup(t);
  const timer = new SleepTimerController(player);
  await player.load(plan('a'));
  await player.play();
  timer.start(countRule(2, 'stop'));
  media.finish();
  media.trigger('ended');
  assert.equal(timer.snapshot.remainingItems, 1);
  media.currentTime = 0;
  await player.play();
  media.finish();
  await settle();
  assert.equal(timer.snapshot.remainingItems, 0);
  assert.equal(player.state, 'stopped');
});

test('Sleep: jumping to the end does not count; end-of-current follows a manually selected item', async t => {
  const { player, media } = setup(t);
  const queue = new QueueController(player);
  const timer = new SleepTimerController(player);
  let closes = 0;
  player.on('closerequest', () => closes++);
  queue.setItems(items);
  await queue.select(0);
  timer.start({ trigger: { type: 'current' }, action: 'close' });
  player.seek(media.duration);
  media.finish();
  await settle();
  assert.equal(timer.snapshot.remainingItems, 1);
  assert.equal(player.currentResourceId, 'b');
  await queue.select(2);
  assert.equal(timer.snapshot.remainingItems, 1);
  media.finish();
  await settle();
  assert.equal(closes, 1);
  assert.equal(player.state, 'stopped');
  assert.equal(queue.snapshot.index, 2);
});

for (const action of ['pause', 'stop', 'close']) {
  test(`Sleep: ${action} is decided before queue advance in either registration order`, async t => {
    for (const timerFirst of [false, true]) {
      const { player, media } = setup(t);
      let timer = timerFirst ? new SleepTimerController(player) : null;
      const queue = new QueueController(player);
      timer ??= new SleepTimerController(player);
      let closes = 0;
      player.on('closerequest', () => closes++);
      queue.setItems(items);
      await queue.select(0);
      timer.start(countRule(1, action));
      media.finish();
      await settle();
      assert.equal(queue.snapshot.index, 0);
      assert.equal(media.playCalls, 1);
      assert.equal(player.paused, true);
      assert.equal(timer.snapshot.status, 'expired');
      assert.equal(timer.snapshot.actionPending, false);
      assert.equal(closes, action === 'close' ? 1 : 0);
      assert.equal(player.currentResourceId, action === 'pause' ? 'a' : null);
    }
  });
}

test('End control: stop invalidates an already pending queue load while an old progress write is delayed', async t => {
  const gate = deferred();
  let delay = false;
  const { player, media } = setup(t, {
    progressStorage: { load() {}, save: () => delay ? gate.promise : undefined, clear() {} },
  });
  const queue = new QueueController(player);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  queue.setItems(items);
  await queue.select(0);
  delay = true;
  player.progressController.recordProgress('a', 30, 100, false);
  void player.progressController.flush();
  timer.start(durationRule(1000, 'stop'));
  media.finish();
  assert.equal(queue.snapshot.index, 1);
  clock.jump(1000);
  assert.equal(media.src, '');
  assert.equal(player.state, 'stopped');
  gate.resolve();
  await settle();
  assert.equal(media.playCalls, 1);
  assert.equal(player.currentResourceId, null);
  assert.equal(timer.snapshot.error, null);
});

for (const action of ['pause', 'stop', 'close']) {
  test(`End control: a delayed play cannot undo ${action}`, async t => {
    const gate = deferred();
    const { player, media } = setup(t);
    media.play = () => {
      media.playCalls++;
      return gate.promise.then(() => { media.paused = false; media.trigger('play'); });
    };
    const queue = new QueueController(player);
    const clock = new Clock();
    const timer = new SleepTimerController(player, { clock });
    queue.setItems(items);
    const selection = queue.select(0);
    await settle();
    timer.start(durationRule(1000, action));
    clock.jump(1000);
    gate.resolve();
    assert.equal(await selection, false);
    await settle();
    assert.equal(player.paused, true);
    assert.equal(media.playCalls, 1);
    assert.equal(player.state, action === 'pause' ? 'paused' : 'stopped');
  });
}

test('End control: resolving an old play does not pause a newer explicitly started playback', async t => {
  const gate = deferred();
  const { player, media } = setup(t);
  await player.load(plan('a'));
  const originalPlay = media.play.bind(media);
  media.play = () => gate.promise.then(originalPlay);
  const oldPlay = player.play();
  player.pause();
  media.play = originalPlay;
  await player.play();
  gate.resolve();
  await assert.rejects(oldPlay, { name: 'AbortError' });
  assert.equal(player.paused, false);
});

test('End control: a delayed close cannot hide a newly loaded session', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressStorage: { load() {}, save: () => gate.promise, clear() {} } });
  await player.load(plan('a'));
  await player.play();
  media.currentTime = 22;
  let closes = 0;
  player.on('closerequest', () => closes++);
  const closing = player.close();
  const rejected = assert.rejects(closing, { name: 'AbortError' });
  const loading = player.load(plan('b'));
  gate.resolve();
  await Promise.all([rejected, loading]);
  await player.play();
  assert.equal(closes, 0);
  assert.equal(player.currentResourceId, 'b');
  assert.equal(player.paused, false);
});

test('Sleep: cancellation, replacement and removal cancel a close waiting for storage', async t => {
  for (const operation of ['cancel', 'replace', 'destroy']) {
    const gate = deferred();
    const { player, media } = setup(t, { progressStorage: { load() {}, save() {}, clear: () => gate.promise } });
    const clock = new Clock();
    const timer = new SleepTimerController(player, { clock });
    await player.load(plan('a'));
    await player.play();
    let closes = 0;
    player.on('closerequest', () => closes++);
    timer.start({ trigger: { type: 'current' }, action: 'close' });
    media.finish();
    assert.equal(timer.snapshot.actionPending, true);
    if (operation === 'replace') timer.start(5000);
    else timer[operation]();
    gate.resolve();
    await settle();
    assert.equal(closes, 0);
    assert.equal(clock.tasks.size, operation === 'replace' ? 1 : 0);
    assert.equal(timer.snapshot.status, operation === 'replace' ? 'running' : 'idle');
  }
});

test('Sleep: persistence failure is reported after release and does not report a successful close', async t => {
  const failure = new Error('storage unavailable');
  const { player, media } = setup(t, { progressStorage: { load() {}, save: () => Promise.reject(failure), clear() {} } });
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  let observed;
  let closes = 0;
  timer.addEventListener('error', event => { observed = event.detail; });
  player.on('closerequest', () => closes++);
  await player.load(plan('a'));
  await player.play();
  media.currentTime = 24;
  timer.start(durationRule(1000, 'close'));
  clock.jump(1000);
  await settle();
  assert.equal(media.src, '');
  assert.equal(player.state, 'stopped');
  assert.equal(timer.snapshot.error, failure);
  assert.equal(observed, failure);
  assert.equal(closes, 0);
});

test('End control: a refresh arriving after stop is discarded and both processing sessions are released', async t => {
  const gate = deferred();
  const closed = [];
  const { player } = setup(t, {
    sourceOptions: { expiryCheckIntervalMs: 0 },
    sourceResolver: { resolveUrl: () => gate.promise, onSessionClose: endpoint => closed.push(endpoint) },
  });
  await player.load(plan('a', { processing: { sessionEndpoint: '/old' } }));
  await player.play();
  const refresh = player.sourceController.refreshSource('expired');
  await player.stop();
  gate.resolve(plan('a', { playUrl: 'refreshed.mp4', processing: { sessionEndpoint: '/abandoned' } }));
  assert.equal(await refresh, null);
  assert.deepEqual(closed, ['/old', '/abandoned']);
  assert.equal(player.currentResourceId, null);
  assert.equal(player.state, 'stopped');
});

test('Sleep: a failed completion checkpoint clear prevents closing and reports the storage error', async t => {
  const gate = deferred();
  const failure = new Error('completion clear failed');
  const { player, media } = setup(t, {
    progressStorage: { load() {}, save() {}, clear: () => gate.promise },
  });
  const timer = new SleepTimerController(player);
  let closes = 0;
  let observed;
  player.on('closerequest', () => closes++);
  timer.addEventListener('error', event => { observed = event.detail; });
  await player.load(plan('a'));
  await player.play();
  timer.start({ trigger: { type: 'current' }, action: 'close' });
  media.finish();
  assert.equal(player.state, 'stopped');
  assert.equal(timer.snapshot.actionPending, true);
  gate.reject(failure);
  await settle();
  assert.equal(closes, 0);
  assert.equal(timer.snapshot.error, failure);
  assert.equal(observed, failure);
  assert.equal(timer.snapshot.actionPending, false);
});

test('Sleep: invalid rules are atomic; replacement resets counts and manual stop cancels the rule', async t => {
  const { player, media } = setup(t);
  const clock = new Clock();
  const timer = new SleepTimerController(player, { clock });
  assert.throws(() => timer.start({ trigger: { type: 'current' } }));
  timer.start(5000);
  for (const count of [0, -1, 1.5, Infinity, Number.MAX_SAFE_INTEGER + 1]) {
    assert.throws(() => timer.start(countRule(count, 'stop')), RangeError);
    assert.equal(timer.snapshot.deadline, 5000);
  }
  assert.throws(() => timer.start(countRule(1, 'quit')), TypeError);
  await player.load(plan('a'));
  await player.play();
  const rule = countRule(3, 'stop');
  timer.start(rule);
  rule.trigger.count = 20;
  assert.equal(timer.snapshot.trigger.count, 3);
  assert.equal(clock.tasks.size, 0);
  media.finish();
  assert.equal(timer.snapshot.remainingItems, 2);
  timer.start(countRule(5, 'pause'));
  assert.equal(timer.snapshot.remainingItems, 5);
  await player.stop();
  assert.equal(timer.snapshot.status, 'idle');
});

test('Composition: free assembly and all three presets reuse count/stop and keep their other controllers', async t => {
  for (const name of ['free', 'audio', 'video', 'preview']) {
    let player;
    let features;
    if (name === 'free') {
      ({ player } = setup(t));
      features = mountPlayerFeatures(player, { queue: true, sleepTimer: true });
    } else {
      const preset = createPlayerPreset(name, { features: { queue: true, sleepTimer: true, mediaSession: false } });
      ({ player, features } = preset);
      t.after(() => preset.destroy());
    }
    const media = new Media();
    player.attach(media);
    const queue = features.queue;
    queue.setItems(items);
    await queue.select(0);
    features.sleepTimer.start(countRule(1, 'stop'));
    media.finish();
    await settle();
    assert.equal(player.state, 'stopped', name);
    assert.equal(media.playCalls, 1, name);
    assert.equal(features.queue, queue);
    features.setEnabled('sleepTimer', false);
    await queue.select(1);
    assert.equal(player.currentResourceId, 'b');
    assert.equal(player.paused, false);
  }
});

test('Lifecycle: twenty stop/reload cycles retain neither media listeners nor sleep tasks', async t => {
  const { player, media } = setup(t);
  const clock = new Clock();
  const group = mountPlayerFeatures(player, { queue: true, sleepTimer: { clock }, mediaSession: false });
  group.queue.setItems(items);
  let playingListenerCount;
  for (let cycle = 0; cycle < 20; cycle++) {
    await group.queue.select(cycle % items.length);
    playingListenerCount ??= media.listenerCount;
    assert.equal(media.listenerCount, playingListenerCount);
    group.sleepTimer.start(1000);
    await player.stop();
    assert.equal(media.listenerCount, 0);
    assert.equal(clock.tasks.size, 0);
    assert.equal(group.queue.snapshot.items.length, items.length);
  }
});
