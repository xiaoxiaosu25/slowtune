import test from 'node:test';
import assert from 'node:assert/strict';
import { ProgressController } from '@studio/player/progress';
import { setup, plan, deferred, settle } from './helpers.mjs';

test('Close intent exits immediately after silence, while core completion waits for saved progress', async t => {
  const gate = deferred(), events = [];
  const { player, media } = setup(t, { progressPolicy: { startThresholdSeconds: 0 },
    progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  await player.load(plan('one')); await player.play(); media.currentTime = 28;
  player.on('closeintent', () => events.push(['intent', media.paused, media.src]));
  player.on('closerequest', () => events.push(['complete']));
  let complete = false;
  const work = player.close().then(() => { complete = true; });
  assert.deepEqual(events, [['intent', true, '']]);
  await settle(); assert.equal(complete, false);
  assert.equal(await player.progressController.getResumePosition('one', 100), 28);
  gate.resolve(); await work;
  assert.deepEqual(events.at(-1), ['complete']);
});

test('A save rejection cannot prevent close intent or discard the pending checkpoint', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressPolicy: { startThresholdSeconds: 0 },
    progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  await player.load(plan('one')); await player.play(); media.currentTime = 31;
  let intents = 0; player.on('closeintent', () => intents++);
  const work = player.close(); const rejected = assert.rejects(work, /offline/);
  assert.equal(intents, 1); assert.equal(media.paused, true);
  gate.reject(new Error('offline')); await rejected;
  assert.equal(await player.progressController.getResumePosition('one', 100), 31);
});

test('Reopening during a slow save resumes locally; late close completion cannot close the new source', async t => {
  const gate = deferred();
  const { player, media } = setup(t, { progressPolicy: { startThresholdSeconds: 0 },
    progressStorage: { load: () => null, save: () => gate.promise, clear() {} } });
  await player.load(plan('one')); await player.play(); media.currentTime = 24;
  let completes = 0; player.on('closerequest', () => completes++);
  const closing = player.close(); const cancelled = assert.rejects(closing, { name: 'AbortError' });
  await player.load(plan('one')); await settle(); await player.play();
  assert.equal(media.currentTime, 24); assert.equal(media.paused, false);
  gate.resolve(); await cancelled;
  assert.equal(completes, 0); assert.equal(media.paused, false);
});

test('Ordered checkpoints survive an older acknowledgement; a pending reset takes priority', async () => {
  const gates = [deferred(), deferred(), deferred()]; let index = 0, saved = null;
  const storage = { load: () => saved, save: (_id, p) => gates[index++].promise.then(() => { saved = p; }), clear: () => gates[index++].promise.then(() => { saved = null; }) };
  const progress = new ProgressController(storage, { startThresholdSeconds: 0 });
  const first = progress.saveCheckpoint('one', 21, 100), second = progress.saveCheckpoint('one', 37, 100);
  assert.equal(await progress.getResumePosition('one', 100), 37);
  gates[0].resolve(); await first; await settle();
  assert.equal(await progress.getResumePosition('one', 100), 37);
  const reset = progress.clearProgress('one');
  assert.equal(await progress.getResumePosition('one', 100), 0);
  gates[1].resolve(); await second; await settle(); gates[2].resolve(); await reset;
  assert.equal(saved, null); progress.destroy();
});

test('Natural completion takes priority over an older pending checkpoint', async () => {
  const gate = deferred(); let saved = 12;
  const progress = new ProgressController({ load: () => saved, save: (_id, p) => gate.promise.then(() => { saved = p; }), clear: () => { saved = null; } }, { startThresholdSeconds: 0, endThresholdSeconds: 0 });
  const checkpoint = progress.saveCheckpoint('one', 37, 100);
  progress.recordProgress('one', 96, 100, true);
  assert.equal(await progress.getResumePosition('one', 100), 0);
  gate.resolve(); await checkpoint; await progress.flush();
  assert.equal(saved, null); progress.destroy();
});
