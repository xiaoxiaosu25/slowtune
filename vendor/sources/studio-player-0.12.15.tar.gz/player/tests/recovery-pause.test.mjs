import test from 'node:test';
import assert from 'node:assert/strict';
import {setup,plan,deferred,settle} from './helpers.mjs';

for(const explicitPause of [false,true])test(`queued recovery pause preserves ${explicitPause?'the later explicit pause':'playback intent'}`,async t=>{
 const delivery=deferred(),contexts=[];
 const {player,media}=setup(t,{sourceResolver:{recoverSource:(_id,_plan,context)=>{contexts.push(context);return delivery.promise;}}});
 media.pause=()=>{if(media.paused)return;media.paused=true;setImmediate(()=>media.trigger('pause'));};
 await player.load(plan('a'));await player.play();player.seek(40);
 media.trigger('error');await settle();await settle();
 assert.equal(contexts.length,1);assert.equal(contexts[0].paused,false);
 if(explicitPause)player.pause();
 delivery.resolve(plan('a',{playUrl:'recovered.mp4'}));await settle();await settle();
 assert.equal(player.currentTime,40);assert.equal(player.paused,explicitPause);
 assert.equal(media.playCalls,explicitPause?1:2);
 media.trigger('error');assert.equal(player.state,'error');assert.equal(contexts.length,1);
});
