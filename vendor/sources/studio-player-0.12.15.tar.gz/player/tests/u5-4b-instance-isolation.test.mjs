import test from 'node:test';
import assert from 'node:assert/strict';
import { StudioPlayer } from '../dist/player.js';
import { createPlayerInstance, PortContractError } from '../dist/contracts/index.js';

function launchConfiguration(instanceId, windowId, ipcName, overrides = {}) {
  return {
    instanceId,
    executable: 'C:/controlled/mpv/mpv.exe',
    ipcName,
    surfaceTarget: { type: 'native-window', windowId },
    videoOutput: 'gpu-next',
    audioOutput: 'wasapi',
    ...overrides,
  };
}

function surfaceFor(instance) {
  return {
    instance,
    create() {}, resize() {}, show() {}, hide() {}, focus() {}, requestFullscreen() {}, destroy() {},
  };
}

function playerFor(instanceId, windowId, ipcName) {
  const instance = createPlayerInstance(instanceId, 'mpv');
  const player = new StudioPlayer({
    backend: 'mpv',
    instance,
    surfacePort: surfaceFor(instance),
    mpv: launchConfiguration(instanceId, windowId, ipcName),
  });
  player.ensureBackendHandle();
  return player;
}

function environmentSnapshot(keys) {
  return new Map(keys.map(key => [key, process.env[key]]));
}

function restoreEnvironment(previous) {
  for (const [key, value] of previous) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
}

test('U5-4B mixes an explicitly configured mpv instance with Video.js without environment bleed', () => {
  const keys = ['STUDIO_PLAYER_BACKEND', 'STUDIO_PLAYER_MPV_BIN', 'STUDIO_PLAYER_MPV_ARGS'];
  const previous = environmentSnapshot(keys);
  process.env.STUDIO_PLAYER_BACKEND = 'mpv';
  process.env.STUDIO_PLAYER_MPV_BIN = 'C:/wrong/env-mpv.exe';
  process.env.STUDIO_PLAYER_MPV_ARGS = '--wid=999 --input-ipc-server=wrong';

  const videojs = new StudioPlayer({ backend: 'videojs' });
  const mpv = playerFor('mixed-mpv', '31001', 'studio-player-mpv-1001-mixed');
  try {
    assert.equal(videojs.instance.backend, 'videojs');
    assert.equal(videojs.mpvSession, null);
    assert.equal(mpv.instance.backend, 'mpv');
    assert.ok(mpv.mpvSession.commandLine().includes('C:/controlled/mpv/mpv.exe'));
    assert.ok(mpv.mpvSession.commandLine().includes('--wid=31001'));
    assert.ok(mpv.mpvSession.commandLine().some(value => value.endsWith('studio-player-mpv-1001-mixed')));
    assert.ok(!mpv.mpvSession.commandLine().some(value => value.includes('wrong')));
  } finally {
    videojs.destroy();
    mpv.destroy();
    restoreEnvironment(previous);
  }
});

test('U5-4B two mpv instances own different native windows, IPC endpoints, and playback facts', () => {
  const first = playerFor('isolated-mpv-a', '41001', 'studio-player-mpv-2001-a');
  const second = playerFor('isolated-mpv-b', '41002', 'studio-player-mpv-2001-b');
  try {
    const firstArgs = first.mpvSession.commandLine();
    const secondArgs = second.mpvSession.commandLine();
    assert.ok(firstArgs.includes('--wid=41001'));
    assert.ok(secondArgs.includes('--wid=41002'));
    const firstPipe = firstArgs.find(value => value.startsWith('--input-ipc-server='));
    const secondPipe = secondArgs.find(value => value.startsWith('--input-ipc-server='));
    assert.ok(firstPipe && secondPipe);
    assert.notEqual(firstPipe, secondPipe);

    first.mpvSession.onEvent({ event: 'property-change', name: 'pause', data: false });
    first.mpvSession.onEvent({ event: 'property-change', name: 'time-pos', data: 7.25 });
    first.setVolume(0.2);
    second.mpvSession.onEvent({ event: 'property-change', name: 'pause', data: true });
    second.mpvSession.onEvent({ event: 'property-change', name: 'time-pos', data: 2.5 });
    second.setVolume(0.8);

    assert.equal(first.paused, false);
    assert.equal(second.paused, true);
    assert.equal(first.currentTime, 7.25);
    assert.equal(second.currentTime, 2.5);
    assert.equal(first.volume, 0.2);
    assert.equal(second.volume, 0.8);
  } finally {
    first.destroy();
    second.destroy();
  }
});

test('U5-4B rejects missing, overreaching, and cross-instance mpv launch configuration', () => {
  const firstInstance = createPlayerInstance('negative-mpv-a', 'mpv');
  const secondInstance = createPlayerInstance('negative-mpv-b', 'mpv');
  const firstSurface = surfaceFor(firstInstance);
  const good = launchConfiguration('negative-mpv-a', '51001', 'studio-player-mpv-3001-a');

  assert.throws(() => new StudioPlayer({ backend: 'mpv', instance: firstInstance, surfacePort: firstSurface }), /requires a main-process launch configuration/);
  assert.throws(() => new StudioPlayer({
    backend: 'mpv', instance: firstInstance, surfacePort: firstSurface,
    mpv: launchConfiguration('negative-mpv-a', '51001', 'studio-player-mpv-3001-a', { args: ['--script=evil.lua'] }),
  }), /unsupported fields/);
  assert.throws(() => new StudioPlayer({
    backend: 'mpv', instance: secondInstance, surfacePort: surfaceFor(secondInstance), mpv: good,
  }), /belongs to another instance/);
  assert.throws(() => new StudioPlayer({
    backend: 'mpv', instance: secondInstance, surfacePort: firstSurface,
    mpv: launchConfiguration('negative-mpv-b', '51002', 'studio-player-mpv-3001-b'),
  }), error => error instanceof PortContractError && error.code === 'invalid-binding');
  assert.throws(() => new StudioPlayer({
    backend: 'mpv', instance: firstInstance, surfacePort: firstSurface,
    mpv: launchConfiguration('negative-mpv-a', '51001 --wid=51002', 'studio-player-mpv-3001-a'),
  }), /surface target must name one native window/);
  assert.throws(() => new StudioPlayer({
    backend: 'videojs', mpv: good,
  }), /requires the mpv backend/);
});

test('U2 no-argument environment selection remains diagnostic-only compatibility', () => {
  const keys = ['STUDIO_PLAYER_BACKEND', 'STUDIO_PLAYER_MPV_BIN', 'STUDIO_PLAYER_MPV_ARGS'];
  const previous = environmentSnapshot(keys);
  process.env.STUDIO_PLAYER_BACKEND = 'mpv';
  process.env.STUDIO_PLAYER_MPV_BIN = 'C:/diagnostic/mpv.exe';
  process.env.STUDIO_PLAYER_MPV_ARGS = '--vo=null --ao=null';
  const player = new StudioPlayer();
  try {
    assert.equal(player.instance.backend, 'mpv');
    player.ensureBackendHandle();
    assert.ok(player.mpvSession.commandLine().includes('C:/diagnostic/mpv.exe'));
  } finally {
    player.destroy();
    restoreEnvironment(previous);
  }
});
