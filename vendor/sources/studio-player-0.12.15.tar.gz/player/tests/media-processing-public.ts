import { LocalMediaProcessor, type LocalMediaProcessingSession } from '@studio/player/processing';
import { StudioPlayer } from '@studio/player/core';
import type { MediaProcessingSession } from '@studio/player/contracts';
const processor = new LocalMediaProcessor({outputRoot:'D:/approved',
  ffmpeg:{executable:'D:/tools/ffmpeg.exe',sha256:'a'.repeat(64),provenance:'record'},
  ffprobe:{executable:'D:/tools/ffprobe.exe',sha256:'b'.repeat(64),provenance:'record'}});
const session: LocalMediaProcessingSession = processor.start({file:'D:/media.mkv',resourceId:'a',profile:'h264-ac3-to-aac',policy:{allowLossyAudio:true}});
const neutral: MediaProcessingSession = session;
const player = new StudioPlayer();
void player.replaceProcessedSource(neutral);void player.destroyAsync();void processor.destroy();
// @ts-expect-error Arbitrary command lines cannot be supplied by media input.
processor.start({file:'D:/media.mkv',resourceId:'a',profile:'h264-aac-mkv-to-mp4',args:['-y']});
// @ts-expect-error Unimplemented profiles cannot be claimed.
processor.start({file:'D:/media.mkv',resourceId:'a',profile:'video-transcode'});
