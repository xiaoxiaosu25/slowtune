import test from 'node:test';
import assert from 'node:assert/strict';
import { MainMediaCoordinator } from '@studio/player/main-media';
import { MediaSessionController } from '@studio/player/media-session';
import { QueueController } from '@studio/player/queue';
import { SleepTimerController } from '@studio/player/sleep-timer';
import { VideoTracksController } from '@studio/player/video-tracks';
import { Session, settle } from './helpers.mjs';

/**
 * 这是公共控制器的中立事实夹具，不是 mpv 替身验收：它只复现 StudioPlayer
 * 已公开的 facts/events 方法面，并明确没有承载元素。真实 mpv 仍由 mpv-backend.test.mjs
 * 在具备官方可执行文件时单独验证。
 */
class NullElementPlayer {
  element = null;
  trackPort = null;
  isDestroyed = false;
  state = 'idle';
  currentTime = 0;
  duration = 100;
  paused = true;
  playbackRate = 1;
  volume = 1;
  muted = false;
  failed = false;
  playbackRequested = false;
  currentResourceId = null;
  currentPlan = null;
  currentMetadata = null;
  listeners = new Map();

  on(event, listener) {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event).add(listener);
    return () => this.listeners.get(event)?.delete(listener);
  }

  emit(event, ...args) {
    for (const listener of [...(this.listeners.get(event) ?? [])]) listener(...args);
  }

  async load(source, options = {}) {
    this.emit('loadstart', source);
    this.currentResourceId = source.resourceId ?? source.id ?? String(source);
    this.currentPlan = source;
    this.currentMetadata = source.metadata ?? {};
    this.currentTime = options.restart ? 0 : source.resumePositionSeconds ?? 0;
    this.playbackRequested = false;
    this.paused = true;
    this.state = 'loading';
    this.emit('statechange', this.state);
    this.state = 'ready';
    this.emit('statechange', this.state);
    this.emit('sourcechange', source, { source });
    return { source };
  }

  requestPlayback() {
    this.playbackRequested = true;
    this.emit('playintent');
    return true;
  }

  async play() {
    if (!this.playbackRequested) this.requestPlayback();
    this.paused = false;
    this.state = 'playing';
    this.emit('statechange', this.state);
    this.emit('play');
    this.emit('playing');
  }

  pause() {
    this.playbackRequested = false;
    this.emit('pauseintent');
    this.paused = true;
    if (this.state !== 'ended' && this.state !== 'stopped') this.state = 'paused';
    this.emit('statechange', this.state);
    this.emit('pause');
  }

  seek(seconds) {
    this.currentTime = Math.max(0, Math.min(this.duration, seconds));
    this.emit('seeked');
  }

  setVolume(value) { this.volume = Math.max(0, Math.min(1, value)); }
  setMuted(value) { this.muted = Boolean(value); }
  setPlaybackRate(value) { this.playbackRate = value; }

  async stop() {
    this.playbackRequested = false;
    this.paused = true;
    this.state = 'stopped';
    this.currentResourceId = null;
    this.emit('stop', { resourceId: null });
  }

  async close() {
    await this.stop();
    this.emit('closerequest');
  }

  finish({ natural = true } = {}) {
    const completion = Object.freeze({
      resourceId: this.currentResourceId,
      positionSeconds: this.duration,
      durationSeconds: this.duration,
      natural,
    });
    this.currentTime = this.duration;
    this.paused = true;
    this.playbackRequested = false;
    this.state = 'ended';
    this.emit('statechange', this.state);
    this.emit('beforeended', completion);
    this.emit('ended', completion);
  }

  destroy() {
    if (this.isDestroyed) return;
    this.isDestroyed = true;
    this.emit('destroy');
    this.listeners.clear();
  }
}

class MemoryTrackPort {
  instance = { instanceId: 'null-element-fixture', backend: 'mpv' };
  listeners = new Set();
  audio = [
    { id: 'a1', label: 'English', language: 'en', selected: true, status: 'ready' },
    { id: 'a2', label: '中文', language: 'zh', selected: false, status: 'ready' },
  ];
  subtitles = [
    { id: 's1', label: 'English', language: 'en', selected: false, status: 'ready' },
  ];

  get snapshot() {
    return {
      audio: this.audio,
      subtitles: this.subtitles,
      audioTrack: this.audio.find(track => track.selected)?.id ?? null,
      subtitle: this.subtitles.find(track => track.selected)?.id ?? 'off',
    };
  }

  selectAudioTrack(id) {
    for (const track of this.audio) track.selected = track.id === id;
    this.notify();
  }

  selectSubtitle(id) {
    for (const track of this.subtitles) track.selected = id !== 'off' && track.id === id;
    this.notify();
  }

  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify() { for (const listener of [...this.listeners]) listener(); }
}

test('U5-3: queue continuation and end control consume neutral completion facts without an element', async t => {
  const player = new NullElementPlayer();
  const queue = new QueueController(player);
  t.after(() => { queue.destroy(); player.destroy(); });
  queue.setItems([
    { id: 'first', source: { resourceId: 'first', playUrl: 'first.mp4' } },
    { id: 'second', source: { resourceId: 'second', playUrl: 'second.mp4' } },
  ]);
  await queue.select(0);
  assert.equal(player.element, null);
  player.finish();
  await settle();
  assert.equal(queue.snapshot.current?.id, 'second');
  assert.equal(player.currentResourceId, 'second');

  const closingPlayer = new NullElementPlayer();
  const closingQueue = new QueueController(closingPlayer);
  const timer = new SleepTimerController(closingPlayer);
  t.after(() => { timer.destroy(); closingQueue.destroy(); closingPlayer.destroy(); });
  closingQueue.setItems([{ id: 'only', source: { resourceId: 'only', playUrl: 'only.mp4' } }]);
  await closingQueue.select(0);
  timer.start({ trigger: { type: 'current' }, action: 'close' });
  closingPlayer.finish();
  await settle();
  assert.equal(closingPlayer.element, null);
  assert.equal(closingPlayer.state, 'stopped');
  assert.equal(timer.snapshot.status, 'expired');
  assert.equal(closingQueue.snapshot.index, 0);
});

test('U5-3: MediaSession and main-media use neutral playback facts when element is null', async t => {
  const session = new Session();
  const player = new NullElementPlayer();
  const mediaSession = new MediaSessionController(player, { session, getMetadata: () => ({ title: 'Null element' }) });
  const scope = new MainMediaCoordinator();
  const first = scope.register(player);
  const secondPlayer = new NullElementPlayer();
  const second = scope.register(secondPlayer);
  t.after(() => {
    mediaSession.destroy(); scope.destroy(); player.destroy(); secondPlayer.destroy();
  });

  await player.load({ resourceId: 'null-media', playUrl: 'null-media.mp4' });
  mediaSession.activate();
  player.currentTime = 12.5;
  await player.play();
  assert.equal(player.element, null);
  assert.equal(first.active, true);
  assert.equal(session.playbackState, 'playing');
  assert.deepEqual(session.position, { duration: 100, playbackRate: 1, position: 12.5 });

  await secondPlayer.load({ resourceId: 'other', playUrl: 'other.mp4' });
  await secondPlayer.play();
  assert.equal(first.active, false);
  assert.equal(second.active, true);
  assert.equal(player.paused, true);
});

test('U5-3: VideoTracksController consumes a narrow TrackPort for audio/subtitles without an element', async t => {
  const player = new NullElementPlayer();
  await player.load({
    resourceId: 'tracks',
    playUrl: 'tracks.mp4',
    tracks: { subtitles: [] },
  });
  const port = new MemoryTrackPort();
  const tracks = new VideoTracksController(player, { trackPort: port });
  t.after(() => { tracks.destroy(); player.destroy(); });

  assert.equal(player.element, null);
  assert.deepEqual(tracks.snapshot.audio.map(track => track.id), ['a1', 'a2']);
  assert.deepEqual(tracks.snapshot.subtitles.map(track => track.id), ['s1']);
  tracks.selectAudioTrack('a2');
  tracks.selectSubtitle('s1');
  await settle();
  assert.equal(tracks.snapshot.audioTrack, 'a2');
  assert.equal(tracks.snapshot.subtitle, 's1');
});
