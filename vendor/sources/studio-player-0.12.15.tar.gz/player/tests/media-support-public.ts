import { assessBrowserMedia } from '@studio/player/source-adapter';
import { LocalMediaProbe } from '@studio/player/probe';
import { describeProbedMedia } from '@studio/player/source-adapter';
import type { BrowserMediaDescription, BrowserMediaSupport } from '@studio/player/contracts';

const media: BrowserMediaDescription = { transport: 'range', video: null, audio: { mimeType: 'audio/mpeg', codec: 'mp3' } };
const assessment: Promise<BrowserMediaSupport> = assessBrowserMedia(media, { signal: new AbortController().signal });
// @ts-expect-error 判断结果不包含凭据或来源地址。
assessment.then(result => result.url);
// @ts-expect-error 不允许将 mpv 当作浏览器交付协议。
assessBrowserMedia({ transport: 'mpv', video: null, audio: null });
// @ts-expect-error 结果证据不可变。
assessment.then(result => result.evidence.push({}));

const probe = new LocalMediaProbe({ executable: '/host/ffprobe' });
probe.inspect('/media/file.mp4', { maxReadBytes: 1024 }).then(result => assessBrowserMedia(describeProbedMedia(result.media)));
probe.inspect('/media/file.mp4', { readMode: 'seekable' }).then(result => result.ranges[0]?.offset);
void probe.stop(); void probe.destroy();
void assessBrowserMedia({ ...media, transport: 'hls', route: 'mse-hls',
  container: { mimeType: 'audio/mp4' }, mseContainer: { mimeType: 'audio/mp4' } }, {
  environment: { hlsAdapter: () => true, isTypeSupported: () => true },
}).then(result => result.checks.map(check => check.target));
// @ts-expect-error 网络 URL 与任意额外命令参数不通过配置提供。
new LocalMediaProbe({ executable: '/host/ffprobe', args: ['-i', 'http://remote'] });
