import test from 'node:test';
import assert from 'node:assert/strict';
import { StudioPlayer } from '@studio/player/core';
import { SourceController } from '@studio/player/source-adapter';
import { PlaybackTimeoutError } from '@studio/player/contracts';
import { QueueController } from '@studio/player/queue';
import { Media, plan, deferred, settle, setup } from './helpers.mjs';

function clock(t) { t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000 }); }
class WaitingMedia extends Media {
  gate = deferred();
  play() { this.playCalls++; this.paused = false; this.trigger('play'); return this.gate.promise; }
  start() { this.paused = false; this.trigger('playing'); this.gate.resolve(); }
}
function waiting(t, options) {
  const player = new StudioPlayer(options), media = new WaitingMedia(), diagnostics = [];
  player.attach(media); player.on('diagnostic', event => diagnostics.push(event));
  t.after(() => player.destroy());
  return { player, media, diagnostics };
}

test('resolve deadline cancels the resolver, settles promptly and releases a late session without secrets', async t => {
  clock(t);
  const gate = deferred(), closed = [], diagnostics = []; let signal;
  const controller = new SourceController({ expiryCheckIntervalMs: 0, resolver: {
    resolveUrl(_id, _plan, _reason, context) { signal = context.signal; return gate.promise; },
    onSessionClose: endpoint => closed.push(endpoint),
  } });
  t.after(() => controller.destroy()); controller.onDiagnostic(event => diagnostics.push(event));
  controller.loadInput(plan('secret-resource', { playUrl: 'https://host/media?token=secret-token', headers: { Authorization: 'secret-header' }, timeouts: { resolve: 2 } }));
  const request = controller.refreshSource('expired');
  t.mock.timers.tick(2000);
  assert.equal(await request, null); assert.equal(signal.aborted, true);
  assert.ok(signal.reason instanceof PlaybackTimeoutError);
  assert.equal(controller.getCurrentResourceId(), 'secret-resource');
  assert.equal(diagnostics.at(-1).code, 'resolve-timeout'); assert.equal(diagnostics.at(-1).elapsedMs, 2000);
  assert.doesNotMatch(JSON.stringify(diagnostics), /secret|https|Authorization/);
  gate.resolve(plan('secret-resource', { processing: { sessionEndpoint: '/late' } }));
  await settle(); assert.deepEqual(closed, ['/late']);
});

test('resolver failures are observable and three-argument resolvers stay compatible', async t => {
  const diagnostics = [], controller = new SourceController({ expiryCheckIntervalMs: 0, resolver: {
    resolveUrl() { throw new Error('https://private/?token=credential'); },
  } });
  t.after(() => controller.destroy()); controller.onDiagnostic(event => diagnostics.push(event));
  controller.loadInput(plan('a')); assert.equal(await controller.refreshSource('retry'), null);
  assert.equal(diagnostics.at(-1).code, 'resolve-failed');
  assert.doesNotMatch(JSON.stringify(diagnostics), /private|credential/);
});

test('replacement cancels a hung resolver and a late result cannot replace the new source', async t => {
  const gate = deferred(); let signal;
  const controller = new SourceController({ expiryCheckIntervalMs: 0, resolver: {
    resolveUrl(_id, _plan, _reason, context) { signal = context.signal; return gate.promise; },
  } });
  t.after(() => controller.destroy()); controller.loadInput(plan('a'));
  const request = controller.refreshSource('retry'); controller.loadInput(plan('b'));
  assert.equal(await request, null); assert.equal(signal.aborted, true);
  gate.resolve(plan('a')); await settle(); assert.equal(controller.getCurrentResourceId(), 'b');
});

test('configured initial timeout starts at playback intent, rejects a hung play and reaches error', async t => {
  clock(t); const { player, media, diagnostics } = waiting(t); let failures = 0, playErrors = 0;
  player.on('error', () => failures++); player.on('playerror', () => playErrors++);
  await player.load(plan('a', { timeouts: { initial: 2 } }));
  t.mock.timers.tick(5000); assert.equal(player.failed, false);
  const outcome = assert.rejects(player.play(), error => error.name === 'TimeoutError' && error.phase === 'initial');
  t.mock.timers.tick(2000); await outcome;
  assert.equal(player.state, 'error'); assert.equal(media.src, ''); assert.equal(failures, 1); assert.equal(playErrors, 0);
  assert.equal(diagnostics.filter(d => d.code === 'initial-timeout').length, 1);
  media.start(); await settle(); assert.equal(media.paused, true);
});

test('unconfigured and zero deadlines leave pending playback unchanged', async t => {
  clock(t);
  for (const timeouts of [undefined, { initial: 0, stall: 0, connect: 0.01, read: 0.01 }]) {
    const { player, media, diagnostics } = waiting(t);
    await player.load(plan('a', { timeouts })); const request = player.play();
    t.mock.timers.tick(100_000); assert.equal(player.failed, false);
    media.start(); await request; media.trigger('waiting'); t.mock.timers.tick(100_000);
    assert.equal(player.failed, false); assert.equal(diagnostics.length, 0); player.destroy();
  }
});

test('playing clears initial deadline even before a play promise settles', async t => {
  clock(t); const { player, media, diagnostics } = waiting(t);
  await player.load(plan('a', { timeouts: { initial: 1 } })); const request = player.play();
  t.mock.timers.tick(400); media.trigger('playing'); t.mock.timers.tick(3000);
  assert.equal(player.failed, false); assert.equal(diagnostics.at(-1).code, 'playback-started');
  assert.equal(diagnostics.at(-1).elapsedMs, 400); media.gate.resolve(); await request;
});

for (const action of ['pause', 'stop', 'detach', 'destroy', 'load']) {
  test(`${action} promptly cancels a pending play and its old deadline`, async t => {
    clock(t); const { player, media, diagnostics } = waiting(t);
    await player.load(plan('a', { timeouts: { initial: 1 } }));
    const outcome = assert.rejects(player.play(), { name: 'AbortError' });
    if (action === 'load') await player.load(plan('b')); else await player[action]();
    await outcome; t.mock.timers.tick(5000);
    assert.equal(player.failed, false); assert.equal(diagnostics.some(d => d.code === 'initial-timeout'), false);
    media.start(); await settle(); assert.equal(media.paused, true);
  });
}

test('stall deadline is not extended by repeated events; progress and pause cancel it', async t => {
  clock(t); const { player, media } = setup(t); const diagnostics = [];
  player.on('diagnostic', event => diagnostics.push(event));
  await player.load(plan('a', { timeouts: { initial: 1, stall: 2 } })); await player.play();
  media.trigger('waiting'); t.mock.timers.tick(1000); media.currentTime = 1; media.trigger('timeupdate');
  t.mock.timers.tick(3000); assert.equal(player.failed, false);
  assert.equal(diagnostics.at(-1).code, 'buffering-ended');
  media.trigger('waiting'); player.pause(); t.mock.timers.tick(3000); assert.equal(player.failed, false);
  await player.play(); media.trigger('waiting'); t.mock.timers.tick(1000); media.trigger('stalled');
  t.mock.timers.tick(1000); assert.equal(player.failed, true);
  assert.equal(diagnostics.filter(d => d.code === 'stall-timeout').length, 1);
});

test('timeout uses one existing fallback budget, preserves position and stops on exhausted fallback', async t => {
  clock(t); const { player, media } = setup(t);
  await player.load(plan('a', { fallbackUrl: 'backup.mp4', timeouts: { initial: 1, stall: 1 } }));
  await player.play(); media.currentTime = 24; media.trigger('timeupdate'); media.trigger('waiting');
  t.mock.timers.tick(1000); await settle();
  assert.equal(media.src, 'backup.mp4'); assert.equal(media.currentTime, 24); assert.equal(media.paused, false);
  media.trigger('waiting'); t.mock.timers.tick(1000);
  assert.equal(player.failed, true); assert.equal(player.canFallback, false); assert.equal(media.src, '');
});

test('a pause from a timeout diagnostic prevents fallback and respects user intent', async t => {
  clock(t); const { player } = waiting(t);
  player.on('diagnostic', event => { if (event.code === 'initial-timeout') player.pause(); });
  await player.load(plan('a', { fallbackUrl: 'backup.mp4', timeouts: { initial: 1 } }));
  const outcome = assert.rejects(player.play(), { name: 'AbortError' }); t.mock.timers.tick(1000); await outcome;
  assert.equal(player.failed, false); assert.equal(player.currentPlan.strategy, 'direct'); assert.equal(player.paused, true);
});

test('initial timeout with a working fallback does not leave the queue in error', async t => {
  clock(t);
  class FallbackMedia extends WaitingMedia {
    play() { return this.src === 'backup.mp4' ? Media.prototype.play.call(this) : super.play(); }
  }
  const player = new StudioPlayer(), media = new FallbackMedia(), queue = new QueueController(player);
  t.after(() => player.destroy()); player.attach(media);
  queue.setItems([{ id: 'a', source: plan('a', { fallbackUrl: 'backup.mp4', timeouts: { initial: 1 } }) }]);
  const request = queue.play(); await settle(); t.mock.timers.tick(1000); await request; await settle();
  assert.equal(media.src, 'backup.mp4'); assert.equal(media.paused, false);
  assert.equal(player.failed, false); assert.equal(queue.snapshot.error, null);
  media.gate.resolve(); await settle(); assert.equal(media.paused, false);
});
