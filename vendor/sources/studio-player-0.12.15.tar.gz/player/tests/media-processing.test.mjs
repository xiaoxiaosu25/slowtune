import test from 'node:test';
import assert from 'node:assert/strict';
import { LocalMediaProcessor } from '@studio/player/processing';
import { SourceController } from '@studio/player/source-adapter';
import { MediaProcessingError } from '@studio/player/contracts';
import { prepareProfile, verifyProfile } from '../dist/processing/profiles.js';
import { plan, deferred, settle, setup } from './helpers.mjs';

const header = new Uint8Array([0x1a,0x45,0xdf,0xa3,0x8b,0x42,0x82,0x88,...Buffer.from('matroska')]);
const video = {index:0,codec_type:'video',codec_name:'h264',profile:'Main',level:31,pix_fmt:'yuv420p',width:320,height:180,
  codec_tag_string:'avc1',extradata:'\n00000000: 014d 401f ffe1 0031  .M@....1\n'};
const audio = {index:1,codec_type:'audio',codec_name:'aac',profile:'LC',channels:1,sample_rate:'48000',extradata:'\n00000000: 1188 56e5 00  ....\n'};
const raw = streams => ({format:{format_name:'matroska,webm'},streams,chapters:[]});
const error = code => value => value instanceof MediaProcessingError && value.code === code;

test('profiles require observed configuration and explicit lossy consent; no channel mixing',()=>{
  assert.throws(()=>prepareProfile('h264-ac3-to-aac',raw([video,{...audio,codec_name:'ac3'}]),header),error('lossy-not-allowed'));
  const result=prepareProfile('h264-ac3-to-aac',raw([video,{...audio,codec_name:'ac3'}]),header,{}, {allowLossyAudio:true});
  assert.ok(result.args.includes('copy'));assert.ok(result.args.includes('aac'));assert.equal(result.quality.bitrate,96000);
  assert.throws(()=>prepareProfile('h264-aac-mkv-to-mp4',raw([{...video,extradata:undefined},audio]),header),error('profile-mismatch'));
  assert.throws(()=>prepareProfile('h264-ac3-to-aac',raw([video,{...audio,codec_name:'ac3',channels:6}]),header,{}, {allowLossyAudio:true}),error('profile-mismatch'));
});
test('unselected compatible AAC survives; subtitle loss requires exact approval; chosen audio maps first',()=>{
  const multi=raw([video,audio,{...audio,index:2},{index:3,codec_type:'subtitle',codec_name:'subrip'}]);
  assert.throws(()=>prepareProfile('h264-aac-mkv-to-mp4',multi,header,{audio:2}),error('preservation-required'));
  const result=prepareProfile('h264-aac-mkv-to-mp4',multi,header,{audio:2},{discardStreams:[3]});
  assert.deepEqual(result.streams.map(stream=>stream.index),[0,2,1]);
  assert.deepEqual(result.degradations,[{kind:'stream',streamIndex:3}]);
  assert.throws(()=>prepareProfile('h264-aac-mkv-to-mp4',multi,header,{audio:2},{discardStreams:[2,3]}),error('invalid-input'));
});
test('metadata mismatch rejects by default and becomes a reported degradation only with policy',()=>{
  const source=raw([video,{...audio,tags:{title:'Required label'}}]), result=prepareProfile('h264-aac-mkv-to-mp4',source,header);
  assert.throws(()=>verifyProfile(result,source,raw([video,audio]),{}),error('preservation-required'));
  const permitted=prepareProfile('h264-aac-mkv-to-mp4',source,header);
  verifyProfile(permitted,source,raw([video,audio]),{allowMetadataLoss:true});
  assert.deepEqual(permitted.degradations,[{kind:'metadata',streamIndex:1,fields:['title']}]);
});
function session(id) {
  const ready=deferred(),closing=deferred();let releases=0,state='preparing';
  const value={resourceId:id,get state(){return state;},ready:ready.promise,
    cancel:async()=>{state='cancelled';ready.reject(new MediaProcessingError('cancelled'));},
    release:async()=>{releases++;state='released';ready.reject(new MediaProcessingError('cancelled'));await closing.promise;}};
  return {value,closing,get releases(){return releases;},ready:()=>{state='ready';ready.resolve(plan(id,{playUrl:'processed.mp4',processing:{available:true,session:value}}));}};
}
test('explicit processed replacement preserves paused continuity and stop waits for release',async t=>{
  const {player,media}=setup(t);await player.load(plan('a'));player.seek(23);player.setVolume(.4);player.setPlaybackRate(1.5);
  const s=session('a'), replacing=player.replaceProcessedSource(s.value);s.ready();await replacing;await settle();
  assert.equal(media.currentTime,23);assert.equal(media.paused,true);assert.equal(media.volume,.4);assert.equal(media.playbackRate,1.5);
  let stopped=false;const stopping=player.stop().then(()=>{stopped=true;});await settle();assert.equal(stopped,false);assert.equal(s.releases,1);
  s.closing.resolve();await stopping;assert.equal(stopped,true);await player.destroyAsync();
});
for(const operation of ['load','stop','destroyAsync'])test(`${operation} cancels pending processing and waits for temporary cleanup`,async t=>{
  const {player}=setup(t);await player.load(plan('a'));const s=session('a');
  const failure=assert.rejects(player.replaceProcessedSource(s.value));
  let completed=false;
  const work=(operation==='load'?player.load(plan('b')):player[operation]()).then(()=>{completed=true;});
  await settle();assert.equal(s.releases,1);assert.equal(completed,false);
  s.closing.resolve();await failure;await work;assert.equal(completed,true);
});
test('invalid new replacement keeps current source, and cleanup errors remain observable',async t=>{
  const {player}=setup(t);await player.load(plan('a'));const s=session('b');
  await assert.rejects(player.replaceProcessedSource(s.value),TypeError);assert.equal(player.currentResourceId,'a');
  s.closing.resolve();await player.sourceController.flushProcessing();
  const ready=session('a');ready.value.release=async()=>{throw new MediaProcessingError('cleanup-failed');};
  const replace=player.replaceProcessedSource(ready.value);ready.ready();await replace;
  await assert.rejects(player.stop(),error('cleanup-failed'));await player.destroyAsync();
});
test('optional host adapter rejects absent tool configuration without exposing paths',async()=>{
  const processor=new LocalMediaProcessor({ffmpeg:{},ffprobe:{},outputRoot:'relative'});
  const session=processor.start({file:'private-path',resourceId:'a',profile:'alac-to-flac'});
  await assert.rejects(session.ready,value=>error('invalid-input')(value)&&!value.message.includes('private-path'));
  await session.release();await session.release();await processor.destroy();
});
test('a late resolver plan releases an abandoned local session',async()=>{
  const gate=deferred(),controller=new SourceController({resolver:{resolveUrl:()=>gate.promise},expiryCheckIntervalMs:0});
  controller.loadInput(plan('a'));const refresh=controller.refreshSource('retry');controller.loadInput(plan('b'));await refresh;
  const abandoned=session('a');abandoned.ready();gate.resolve(await abandoned.value.ready);await settle();
  assert.equal(abandoned.releases,1);abandoned.closing.resolve();await controller.flushProcessing();controller.destroy();
});

test('old cleanup failure is observable without releasing the installed replacement', async t => {
  const { player } = setup(t); await player.load(plan('a'));
  const old = session('a');
  old.value.release = async () => { throw new MediaProcessingError('cleanup-failed'); };
  const first = player.replaceProcessedSource(old.value); old.ready(); await first;
  const next = session('a'); next.closing.resolve();
  const replacement = player.replaceProcessedSource(next.value); next.ready();
  await assert.rejects(replacement, error('cleanup-failed'));
  assert.equal(player.currentPlan.processing.session, next.value);
  assert.equal(next.value.state, 'ready'); assert.equal(next.releases, 0);
  await player.stop(); assert.equal(next.releases, 1);
});

test('known container and stream timelines reject partial success and missing output duration', () => {
  const source = { ...raw([video, audio]), format: { format_name: 'matroska,webm', duration: '4.021' } };
  const prepared = prepareProfile('h264-aac-mkv-to-mp4', source, header);
  for (const duration of ['2.478', undefined, 'NaN']) {
    assert.throws(() => verifyProfile(prepared, source, { ...source, format: { duration } }, {}), error('verification-failed'));
  }
  verifyProfile(prepared, source, { ...source, format: { duration: '4.05' } }, {});
  const tracked = raw([video, { ...audio, tags: { DURATION: '00:00:04.021000000' } }]);
  const profile = prepareProfile('h264-aac-mkv-to-mp4', tracked, header);
  assert.throws(() => verifyProfile(profile, tracked, raw([video, { ...audio, duration: '2.478' }]), {}), error('verification-failed'));
  verifyProfile(profile, tracked, raw([video, { ...audio, duration: '4.021' }]), {});
});

test('audio default selection retains accessibility flags and reports unsupported preservation', () => {
  const source = raw([video, { ...audio, disposition: { default: 0, visual_impaired: 1 } },
    { ...audio, index: 2, disposition: { default: 1, hearing_impaired: 1 } }]);
  const prepared = prepareProfile('h264-aac-mkv-to-mp4', source, header, { audio: 1 });
  assert.ok(prepared.args.includes('+default')); assert.ok(prepared.args.includes('-default'));
  const output = raw([video, { ...source.streams[1], disposition: { default: 1, visual_impaired: 1 } },
    { ...source.streams[2], disposition: { default: 0, hearing_impaired: 1 } }]);
  verifyProfile(prepared, source, output, {});
  output.streams[1].disposition.visual_impaired = 0;
  assert.throws(() => verifyProfile(prepared, source, output, {}), error('preservation-required'));
  const permitted = prepareProfile('h264-aac-mkv-to-mp4', source, header, { audio: 1 });
  verifyProfile(permitted, source, output, { allowMetadataLoss: true });
  assert.deepEqual(permitted.degradations, [{ kind: 'metadata', streamIndex: 1, fields: ['disposition.visual_impaired'] }]);
});
