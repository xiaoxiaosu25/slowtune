import { StudioPlayer } from '@studio/player/core';

export class Media extends EventTarget {
  localName = 'video';
  src = '';
  currentTime = 0;
  duration = 100;
  paused = true;
  ended = false;
  playbackRate = 1;
  volume = 1;
  muted = false;
  playCalls = 0;
  listeners = new Map();
  addEventListener(type, listener, options) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(listener);
    super.addEventListener(type, listener, options);
  }
  removeEventListener(type, listener, options) {
    this.listeners.get(type)?.delete(listener);
    super.removeEventListener(type, listener, options);
  }
  get listenerCount() { return [...this.listeners.values()].reduce((n, listeners) => n + listeners.size, 0); }
  trigger(type) { this.dispatchEvent(new Event(type)); }
  canPlayType(type) { return /mp4|mpeg|wav/.test(type) ? 'probably' : ''; }
  load() {
    this.currentTime = 0; this.paused = true; this.ended = false;
    if (this.src) queueMicrotask(() => this.trigger('loadedmetadata'));
  }
  play() {
    this.playCalls += 1;
    this.paused = false; this.ended = false; this.trigger('play'); this.trigger('playing');
    return Promise.resolve();
  }
  pause() {
    if (!this.paused) {
      this.paused = true;
      this.trigger('pause');
    }
  }
  finish() {
    this.currentTime = this.duration; this.ended = true; this.paused = true;
    this.trigger('timeupdate'); this.trigger('pause'); this.trigger('ended');
  }
  removeAttribute(name) { if (name === 'src') this.src = ''; }
}

export class Clock {
  time = 0;
  tasks = new Map();
  nextId = 0;
  now = () => this.time;
  setTimeout = (fn, delay) => {
    const id = ++this.nextId;
    this.tasks.set(id, { fn, at: this.time + delay });
    return id;
  };
  clearTimeout = id => this.tasks.delete(id);
  jump(ms, run = true) {
    this.time += ms;
    if (run) {
      for (const [id, task] of [...this.tasks]) {
        if (task.at <= this.time) { this.tasks.delete(id); task.fn(); }
      }
    }
  }
}

export class Session {
  metadata = null;
  playbackState = 'none';
  handlers = new Map();
  position = undefined;
  setActionHandler(action, handler) {
    if (handler) this.handlers.set(action, handler);
    else this.handlers.delete(action);
  }
  setPositionState(state) { this.position = state; }
  invoke(action, details = {}) { this.handlers.get(action)?.({ action, ...details }); }
}

export const plan = (id, extra = {}) => ({
  resourceId: id, mediaType: 'video', strategy: 'direct', transport: 'range',
  playUrl: id + '.mp4', metadata: { title: 'Title ' + id, artist: 'Studio' }, ...extra,
});
export const items = ['a', 'b', 'c'].map(id => ({ id, source: plan(id), title: id }));
export const settle = () => new Promise(resolve => setImmediate(resolve));
export const deferred = () => {
  let resolve;
  let reject;
  const promise = new Promise((r, fail) => { resolve = r; reject = fail; });
  return { promise, resolve, reject };
};
export const metadataFactory = data => ({ title: '', artist: '', album: '', artwork: [], ...data });

export function setup(t, options) {
  const player = new StudioPlayer(options);
  const media = new Media();
  player.attach(media);
  t.after(() => player.destroy());
  return { player, media };
}
