import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveVideoControls, VIDEO_CONTROL_FEATURES } from '../dist/ui/video/controls.js';

test('video control presets expand to independent immutable placements', () => {
  const concentrated = resolveVideoControls();
  assert.ok(VIDEO_CONTROL_FEATURES.every(name => concentrated[name] === 'settings'));
  const balanced = resolveVideoControls({ preset: 'balanced' });
  assert.deepEqual(VIDEO_CONTROL_FEATURES.filter(name => balanced[name] === 'toolbar'), ['rate', 'subtitle', 'sleep']);
  const custom = resolveVideoControls({ preset: 'custom', placement: { info: 'toolbar', subtitle: 'toolbar' } });
  assert.equal(custom.info, 'toolbar'); assert.equal(custom.rate, 'settings'); assert.equal(concentrated.info, 'settings');
  assert.throws(() => { custom.info = 'settings'; }, TypeError);
});
test('invalid video control config fails before a UI is mounted', () => {
  for (const input of [{ preset: 'other' }, { placement: { rate: 'outside' } }, { placement: { unknown: 'toolbar' } }]) assert.throws(() => resolveVideoControls(input), TypeError);
  assert.equal(resolveVideoControls({}, 'balanced').rate, 'toolbar');
});
