import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import {
  PLAYER_CLEANUP_ORDER,
  PLAYER_CLEANUP_TRIGGERS,
  PLAYER_PLAYBACK_CHANNEL,
  PLAYER_SURFACE_CHANNEL,
  SURFACE_GEOMETRY_LIMITS,
  SurfaceCommandGate,
  PortContractError,
  assertPlayerPorts,
  cleanupOrderFor,
  createPlayerInstance,
  createPlayerInstanceId,
  createSurfaceSenderId,
  parsePlaybackRequest,
  parseSurfaceRequest,
  validateSurfaceGeometry,
} from '../dist/contracts/index.js';

const packageRoot = join(import.meta.dirname, '..');
const geometry = {
  rect: { x: 10, y: 20, width: 640, height: 360 },
  devicePixelRatio: 1.25,
};

function errorCode(run) {
  assert.throws(run, error => {
    assert.ok(error instanceof PortContractError);
    return true;
  });
  try { run(); } catch (error) { return error.code; }
  throw new Error('预期调用应失败');
}

function assertErrorCode(run, code) {
  assert.equal(errorCode(run), code);
}

test('U5-2 port contract: explicit instance binding and fixed operation allowlists', () => {
  const mpv = createPlayerInstance('player-1', 'mpv');
  const videojs = createPlayerInstance('player-2', 'videojs');
  const sender = createSurfaceSenderId('renderer-1');
  const secondSender = createSurfaceSenderId('renderer-2');
  assert.equal(createPlayerInstanceId('player-1'), mpv.instanceId);
  assert.equal(parseSurfaceRequest({
    channel: PLAYER_SURFACE_CHANNEL,
    operation: 'create',
    instanceId: 'player-1',
    geometry,
  }).geometry.devicePixelRatio, 1.25);
  assert.equal(parsePlaybackRequest({
    channel: PLAYER_PLAYBACK_CHANNEL,
    operation: 'setMuted',
    instanceId: 'player-1',
    muted: true,
  }).operation, 'setMuted');

  assertErrorCode(() => parsePlaybackRequest({
    channel: PLAYER_PLAYBACK_CHANNEL,
    operation: 'execute',
    instanceId: 'player-1',
    command: ['quit'],
  }), 'unknown-operation');
  assertErrorCode(() => parseSurfaceRequest({
    channel: PLAYER_SURFACE_CHANNEL,
    operation: 'create',
    instanceId: 'player-1',
    geometry,
    hwnd: 123,
  }), 'invalid-request');
  assertErrorCode(() => parseSurfaceRequest({
    channel: PLAYER_SURFACE_CHANNEL,
    operation: 'pause',
    instanceId: 'player-1',
  }), 'unknown-operation');

  const playback = { instance: mpv };
  const surface = { instance: mpv };
  const videoPlayback = { instance: videojs };
  const videoTracks = { instance: videojs };
  assert.doesNotThrow(() => assertPlayerPorts({ instance: mpv, playback, surface }));
  assert.doesNotThrow(() => assertPlayerPorts({ instance: videojs, playback: videoPlayback }));
  assertErrorCode(() => assertPlayerPorts({ instance: videojs, playback: videoPlayback, surface: { instance: videojs } }), 'invalid-binding');
  assertErrorCode(() => assertPlayerPorts({ instance: videojs, playback, surface }), 'invalid-binding');
  assertErrorCode(() => assertPlayerPorts({ instance: mpv, playback }), 'invalid-binding');
  assertErrorCode(() => assertPlayerPorts({ instance: mpv, playback: { instance: videojs }, surface }), 'invalid-binding');
  assertErrorCode(() => assertPlayerPorts({ instance: mpv, playback, surface, tracks: videoTracks }), 'invalid-binding');
});

test('U5-2 surface gate: owner, instance, call order and idempotent destroy', () => {
  const gate = new SurfaceCommandGate();
  const sender = createSurfaceSenderId('renderer-1');
  const secondSender = createSurfaceSenderId('renderer-2');
  gate.register('player-1', 'renderer-1');
  gate.register('player-2', 'renderer-2');
  assert.equal(gate.size, 2);

  const request = (operation, instanceId = 'player-1', extra = {}) => ({
    channel: PLAYER_SURFACE_CHANNEL, operation, instanceId, ...extra,
  });
  assertErrorCode(() => gate.dispatch('renderer-1', request('resize', 'player-1', { geometry })), 'invalid-lifecycle');
  assertErrorCode(() => gate.dispatch('renderer-1', request('create', 'player-2', { geometry })), 'sender-mismatch');
  assertErrorCode(() => gate.dispatch('renderer-9', request('create', 'player-1', { geometry })), 'sender-mismatch');
  assertErrorCode(() => gate.dispatch('renderer-1', request('create', 'player-9', { geometry })), 'unregistered-instance');

  assert.equal(gate.dispatch(sender, request('create', 'player-1', { geometry })).lifecycle, 'active');
  assertErrorCode(() => gate.release('player-1', 'renderer-1'), 'invalid-lifecycle');
  assert.equal(gate.dispatch(sender, request('resize', 'player-1', { geometry })).idempotent, false);
  assert.equal(gate.dispatch(sender, request('show')).operation, 'show');
  assert.equal(gate.dispatch(sender, request('focus')).operation, 'focus');
  assert.equal(gate.dispatch(sender, request('requestFullscreen', 'player-1', { enabled: true })).operation, 'requestFullscreen');
  assert.equal(gate.dispatch(sender, request('hide')).operation, 'hide');
  assert.equal(gate.dispatch(sender, request('destroy')).lifecycle, 'destroyed');
  assert.equal(gate.dispatch(sender, request('destroy')).idempotent, true);
  assertErrorCode(() => gate.dispatch(sender, request('resize', 'player-1', { geometry })), 'invalid-lifecycle');
  assert.doesNotThrow(() => gate.release('player-1', 'renderer-1'));

  gate.dispatch(secondSender, request('destroy', 'player-2'));
  gate.release('player-1', 'renderer-1');
  gate.release('player-2', 'renderer-2');
  gate.release('player-2', 'renderer-2');
  assert.equal(gate.size, 0, '销毁并释放后不得残留实例所有权记录');
  assertErrorCode(() => gate.dispatch(sender, request('destroy')), 'unregistered-instance');
});

test('U5-2 geometry validation rejects invalid rectangles and DPI', () => {
  const invalid = [
    { rect: { x: -1, y: 0, width: 10, height: 10 }, devicePixelRatio: 1 },
    { rect: { x: 0, y: 0, width: 0, height: 10 }, devicePixelRatio: 1 },
    { rect: { x: 0, y: 0, width: 10, height: 10 }, devicePixelRatio: 0 },
    { rect: { x: Number.NaN, y: 0, width: 10, height: 10 }, devicePixelRatio: 1 },
    { rect: { x: 0, y: 0, width: SURFACE_GEOMETRY_LIMITS.maxDimension + 1, height: 10 }, devicePixelRatio: 1 },
    { rect: { x: SURFACE_GEOMETRY_LIMITS.maxCoordinate, y: 0, width: 1, height: 1 }, devicePixelRatio: 1 },
    { rect: { x: 0, y: 0, width: 10, height: 10 }, devicePixelRatio: 5 },
  ];
  for (const value of invalid) assertErrorCode(() => validateSurfaceGeometry(value), 'invalid-geometry');
  assert.deepEqual(validateSurfaceGeometry(geometry), geometry);
  assertErrorCode(() => validateSurfaceGeometry({ ...geometry, command: 'execute' }), 'invalid-request');
});

test('U5-2 cleanup triggers all use one ordered, repeatable sequence', () => {
  const expected = [
    'stop-playback',
    'destroy-playback',
    'release-ipc',
    'destroy-surface',
    'clear-renderer-listeners',
  ];
  assert.deepEqual([...PLAYER_CLEANUP_ORDER], expected);
  for (const trigger of PLAYER_CLEANUP_TRIGGERS) {
    assert.deepEqual([...cleanupOrderFor(trigger)], expected, trigger);
  }
});

test('U5-2 package boundary: no Electron entry and UI has no host imports', () => {
  const manifest = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  assert.equal(Object.prototype.hasOwnProperty.call(manifest.exports ?? {}, './electron'), false);
  const exportTargets = Object.values(manifest.exports ?? {})
    .flatMap(entry => (typeof entry === 'string' ? [entry] : Object.values(entry ?? {})))
    .map(String);
  assert.equal(exportTargets.some(target => target.includes('/electron')), false);

  const uiRoot = join(packageRoot, 'src', 'ui');
  const files = [];
  const walk = directory => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const absolute = join(directory, entry.name);
      if (entry.isDirectory()) walk(absolute);
      else if (/\.(?:ts|tsx|js|mjs)$/.test(entry.name)) files.push(absolute);
    }
  };
  walk(uiRoot);
  const forbiddenImport = /(?:from\s+|import\s*\(|require\s*\()(['"])(?:electron|node:[^'"]+|child_process|net|fs|path)(?:['"])/i;
  const violations = files.flatMap(file => {
    const text = readFileSync(file, 'utf8');
    return forbiddenImport.test(text) || /link-studio|projects[\\/]link-studio|HWND/i.test(text) ? [file] : [];
  });
  assert.deepEqual(violations, []);
});
