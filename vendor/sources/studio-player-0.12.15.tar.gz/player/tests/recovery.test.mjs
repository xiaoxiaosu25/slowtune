import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PlaybackRecoveryController} from '../dist/recovery/index.js';
const gate=()=>{let release;return {promise:new Promise(resolve=>release=resolve),release:()=>release()};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
class Player {
  currentResourceId='one';currentPlan={expiresAt:1};currentTime=120;state='playing';playbackRequested=true;paused=false;failed=true;canPrepareSource=true;events=new Map();calls=0;cancels=0;
  sourceController={cancelSourcePreparation:()=>this.cancels++};
  on(type,fn){const listeners=this.events.get(type)??new Set();listeners.add(fn);this.events.set(type,listeners);return ()=>listeners.delete(fn);}
  emit(type){for(const fn of this.events.get(type)??[])fn();}
  pause(){this.paused=true;this.playbackRequested=false;this.emit('pauseintent');}
  requestPlayback(){this.playbackRequested=true;this.emit('playintent');}
  async prepareSource(context){this.calls++;this.position=context.positionSeconds;await this.wait?.promise;}
}
test('public recovery retains a nonzero checkpoint and honors the latest pause while preparing',async()=>{
  const p=new Player(),events=[],controller=new PlaybackRecoveryController(p,new EventTarget(),{observe:e=>events.push(e),nextOperationId:()=> 'temporary-1'});p.wait=gate();
  controller.capture(120,false);controller.capture(0,false);const restoring=controller.retry(new AbortController().signal);await tick();p.pause();p.wait.release();await restoring;
  assert.equal(p.position,120);assert.equal(p.playbackRequested,false);assert(events.some(e=>e.code==='source-applied'&&e.positionSeconds===120&&e.paused===true));controller.dispose();
});
test('environment signals coalesce and selection or disposal cancels old work without selecting a new resource',async()=>{
  const p=new Player(),controller=new PlaybackRecoveryController(p,new EventTarget());p.wait=gate();controller.capture(120,false);
  const one=controller.environmentChanged(),two=controller.environmentChanged();await tick();assert.equal(p.calls,1);p.emit('loadstart');p.currentResourceId='two';p.wait.release();await assert.rejects(one,{name:'AbortError'});await two;assert.equal(p.cancels,1);
  controller.dispose();assert.equal(controller.retry(new AbortController().signal),undefined);await controller.environmentChanged();assert.equal(p.calls,1);
});
test('observers cannot control recovery and explicit paused checkpoints remain silent',async()=>{
  const p=new Player(),controller=new PlaybackRecoveryController(p,new EventTarget(),{observe(){throw Error('observer');}});p.pause();controller.capture(120,true);
  assert.equal(await controller.environmentChanged(),false);assert.equal(p.calls,0);await controller.retry(new AbortController().signal);assert.equal(p.position,120);assert.equal(p.playbackRequested,false);controller.dispose();
});
