import test from 'node:test';
import assert from 'node:assert/strict';
import { QueueController, SleepTimerController } from '@studio/player';
import { setup, items, plan, settle } from './helpers.mjs';

for (const origin of ['native', 'command']) {
  for (const updates of ['seeking', 'seeked', 'repeated']) {
    test(`completion: ${origin} jump to end with ${updates} timeupdate does not consume sleep count`, async t => {
      const { player, media } = setup(t);
      const queue = new QueueController(player);
      const timer = new SleepTimerController(player);
      const completions = [];
      player.on('beforeended', event => completions.push(event.natural));
      queue.setItems(items);
      await queue.select(0);
      timer.start({ trigger: { type: 'items', count: 2 }, action: 'pause' });
      if (origin === 'command') player.seek(media.duration);
      else media.currentTime = media.duration;
      media.seeking = true;
      media.trigger('seeking');
      if (updates !== 'seeked') media.trigger('timeupdate');
      media.seeking = false;
      media.trigger('seeked');
      if (updates !== 'seeking') media.trigger('timeupdate');
      if (updates === 'repeated') media.trigger('timeupdate');
      media.finish();
      await settle();
      assert.deepEqual(completions, [false]);
      assert.equal(timer.snapshot.remainingItems, 2);
      assert.equal(player.currentResourceId, 'b', 'queue still advances after a skipped ending');
      media.finish();
      await settle();
      assert.deepEqual(completions, [false, true]);
      assert.equal(timer.snapshot.remainingItems, 1);
    });
  }
}

for (const position of [20, 99.9]) {
  test(`completion: natural playback after seeking to ${position} counts even without an intermediate timeupdate`, async t => {
    const { player, media } = setup(t);
    const timer = new SleepTimerController(player);
    await player.load(plan('a'));
    await player.play();
    timer.start({ trigger: { type: 'items', count: 1 }, action: 'pause' });
    player.seek(position);
    media.seeking = true;
    media.trigger('seeking');
    media.trigger('timeupdate');
    media.seeking = false;
    media.trigger('seeked');
    media.finish();
    media.trigger('ended');
    await settle();
    assert.equal(timer.snapshot.remainingItems, 0);
    assert.equal(timer.snapshot.status, 'expired');
  });
}

test('completion: a paused jump stays non-natural and a later backward seek permits natural completion', async t => {
  const { player, media } = setup(t);
  const completions = [];
  player.on('beforeended', event => completions.push(event.natural));
  await player.load(plan('a'));
  await player.play();
  player.pause();
  player.seek(media.duration);
  media.trigger('seeking');
  media.trigger('timeupdate');
  media.trigger('seeked');
  media.finish();
  assert.deepEqual(completions, [false]);
  player.seek(40);
  media.trigger('seeking');
  media.trigger('timeupdate');
  media.trigger('seeked');
  await player.play();
  media.finish();
  assert.deepEqual(completions, [false, true]);
});
