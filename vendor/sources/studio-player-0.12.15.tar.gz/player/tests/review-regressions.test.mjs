import test from 'node:test';
import assert from 'node:assert/strict';
import { createVideojsTrackPort } from '../dist/backends/videojs/tracks.js';
import { Media, plan, deferred, settle, setup } from './helpers.mjs';

const ranges = end => ({ length: end ? 1 : 0, start: () => 0, end: () => end });

for (const offset of [0, 100]) {
  test(`resume waits for seekable coverage at offset ${offset} and reads storage once`, async t => {
    const stored = deferred(); let reads = 0;
    const { player, media } = setup(t, { progressStorage: {
      load: () => { reads++; return stored.promise; }, save() {}, clear() {},
    } });
    media.seekable = ranges(0);
    const resumed = []; player.on('resume', position => resumed.push(position));
    await player.load(plan('resume', offset ? { timeline: { offsetSeconds: offset, durationSeconds: 300 } } : {}));
    media.trigger('canplay'); stored.resolve(offset + 40); await settle();
    media.seekable = ranges(10); media.trigger('canplay'); await settle();
    assert.equal(media.currentTime, 0); assert.equal(reads, 1);
    media.seekable = ranges(100); media.trigger('progress'); await settle();
    assert.equal(media.currentTime, 40); assert.deepEqual(resumed, [offset + 40]);
    media.trigger('canplay'); assert.deepEqual(resumed, [offset + 40]);
  });
}

for (const action of ['seek', 'stop', 'replace']) {
  test(`${action} supersedes a resume waiting for seekable`, async t => {
    const { player, media } = setup(t); media.seekable = ranges(0);
    const resumed = []; player.on('resume', position => resumed.push(position));
    await player.load(plan('resume', { resumePositionSeconds: 40 })); await settle();
    if (action === 'seek') player.seek(15);
    if (action === 'stop') await player.stop();
    if (action === 'replace') await player.load(plan('other'));
    media.seekable = ranges(100); media.trigger('canplay'); await settle();
    assert.deepEqual(resumed, []);
    assert.equal(media.currentTime, action === 'seek' ? 15 : 0);
  });
}

for (const fallbackOffset of [undefined, 0, 120]) {
  test(`fallback uses its own ${fallbackOffset ?? 'implicit zero'} offset and preserves pending continuity`, async t => {
    const saved = [];
    const { player, media } = setup(t, { progressStorage: { load: () => null, save: (...args) => saved.push(args), clear() {} } });
    media.duration = 300; media.seekable = ranges(300);
    await player.load(plan('fallback', { timeline: { offsetSeconds: 100, durationSeconds: 400 },
      fallback: { playUrl: 'fallback.mp4', ...(fallbackOffset === undefined ? {} : { timeline: { offsetSeconds: fallbackOffset, durationSeconds: 400 } }) },
    }));
    player.seek(150); player.setVolume(.3); player.setPlaybackRate(1.5); await player.play();
    media.seekable = ranges(0); assert.equal(player.switchToFallback(), true); await settle();
    assert.equal(media.currentTime, 0);
    media.seekable = ranges(300); media.trigger('canplay'); await settle();
    assert.equal(media.currentTime, 150 - (fallbackOffset ?? 0)); assert.equal(player.currentTime, 150);
    assert.equal(player.paused, false); assert.equal(player.volume, .3); assert.equal(player.playbackRate, 1.5);
    await player.stop(); assert.equal(saved.at(-1)[1], 150);
  });
}

test('fallbackUrl shorthand retains the same delivery timeline', async t => {
  const { player, media } = setup(t); media.seekable = ranges(100);
  await player.load(plan('same', { timeline: { offsetSeconds: 100, durationSeconds: 300 }, fallbackUrl: 'mirror.mp4' }));
  player.seek(150); player.switchToFallback(); await settle();
  assert.equal(media.currentTime, 50); assert.equal(player.currentTime, 150);
});

test('invalid fallback timeline is rejected before loading the main source', async t => {
  const { player } = setup(t);
  await assert.rejects(player.load(plan('invalid', { fallback: { playUrl: 'bad.mp4', timeline: { offsetSeconds: -1 } } })), /timeline/);
});

function subtitlePort(t) {
  const media = new Media(); const nodes = [];
  media.textTracks = [];
  media.ownerDocument = { createElement: () => Object.assign(new EventTarget(), {
    readyState: 0, track: { mode: 'disabled' },
    remove() { nodes.splice(nodes.indexOf(this), 1); media.textTracks.splice(media.textTracks.indexOf(this.track), 1); },
  }) };
  media.append = node => { Object.assign(node.track, { id: node.id, kind: node.kind, label: node.label, language: node.srclang }); nodes.push(node); media.textTracks.push(node.track); };
  media.querySelectorAll = () => nodes;
  let manifest = [{ id: 'zh', src: '/captions.vtt', label: '中文', language: 'zh' }];
  const port = createVideojsTrackPort(media, { backend: 'videojs' }, () => manifest, () => 100);
  t.after(() => port.dispose());
  return { port, media, replace: () => { manifest = []; media.trigger('loadstart'); } };
}

for (const phase of ['fetch', 'body']) test(`subtitle timeout during ${phase} publishes an error once`, async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const pending = deferred(); let signal;
  t.mock.method(globalThis, 'fetch', (_url, init) => {
    signal = init.signal;
    return phase === 'fetch' ? pending.promise : Promise.resolve(new Response(new ReadableStream({ pull: () => pending.promise })));
  });
  const { port } = subtitlePort(t); await settle();
  let changes = 0; port.onChange(() => changes++);
  assert.equal(port.snapshot.subtitles[0].status, 'loading');
  t.mock.timers.tick(10000); await settle();
  assert.equal(signal.aborted, true); assert.equal(port.snapshot.subtitles[0].status, 'error');
  assert.match(port.snapshot.subtitles[0].reason, /超时/); assert.equal(changes, 1);
  pending.reject(new Error('late abort rejection')); await settle(); assert.equal(changes, 1);
});

for (const action of ['replace', 'dispose']) test(`subtitle ${action} cancels silently`, async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const pending = deferred(); let signal;
  t.mock.method(globalThis, 'fetch', (_url, init) => { signal = init.signal; return pending.promise; });
  const { port, replace } = subtitlePort(t);
  let changes = 0; port.onChange(() => changes++);
  if (action === 'replace') replace(); else port.dispose();
  const before = changes; assert.equal(signal.aborted, true);
  t.mock.timers.tick(10000); pending.reject(new Error('cancelled')); await settle();
  assert.equal(changes, before);
  if (action === 'replace') assert.deepEqual(port.snapshot.subtitles, []);
});
