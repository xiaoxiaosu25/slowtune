import test from 'node:test';
import assert from 'node:assert/strict';
import { StudioPlayer } from '@studio/player/core';
import { QueueController, mountQueuePrefetch } from '@studio/player/queue';
import { normalizeSubtitles, readSubtitleFile } from '@studio/player/video-tracks';
import { Media, plan, deferred, settle, setup } from './helpers.mjs';

test('deferred initial source: latest queue selection wins and abandoned remote session closes once', async t => {
  const late=deferred(),closed=[],ctx=[];
  const {player}=setup(t,{sourceResolver:{onSessionClose:id=>closed.push(id)}});
  const queue=new QueueController(player);t.after(()=>queue.destroy());
  queue.setItems([{id:'old',source:{resourceId:'old',prepare:context=>{ctx.push(context);return late.promise;}}},{id:'new',source:plan('new')}]);
  const old=queue.select(0);await settle();await queue.select(1);
  assert.equal(ctx[0].signal.aborted,true);late.resolve(plan('old',{processing:{available:true,sessionEndpoint:'abandoned'}}));
  await old;await settle();assert.equal(player.currentResourceId,'new');assert.deepEqual(closed,['abandoned']);assert.deepEqual(queue.snapshot.history,['new']);
});
test('stop during initial preparation cancels without reviving or applying a fake URL', async t=>{
  const late=deferred(),closed=[];const {player,media}=setup(t,{sourceResolver:{onSessionClose:id=>closed.push(id)}});
  const loading=player.load({resourceId:'a',prepare:()=>late.promise});await settle();await player.stop();
  await assert.rejects(loading,{name:'AbortError'});late.resolve(plan('a',{processing:{available:true,sessionEndpoint:'late'}}));await settle();
  assert.equal(media.src,'');assert.equal(player.state,'stopped');assert.deepEqual(closed,['late']);
});
test('initial preparation timeout aborts the request and releases an ignored late session',async t=>{
  const late=deferred(),closed=[];let signal;
  const {player}=setup(t,{sourceResolver:{onSessionClose:id=>closed.push(id)}});
  await assert.rejects(player.load({resourceId:'a',resolveTimeoutSeconds:.01,prepare:ctx=>{signal=ctx.signal;return late.promise;}}),{name:'TimeoutError'});
  assert.equal(signal.aborted,true);assert.equal(player.state,'error');
  late.resolve(plan('a',{processing:{available:true,sessionEndpoint:'timed-out'}}));await settle();assert.deepEqual(closed,['timed-out']);
});
test('initial preparation rejects cross-resource and invalid timeline plans and releases ownership',async t=>{
  const closed=[];const {player}=setup(t,{sourceResolver:{onSessionClose:id=>closed.push(id)}});
  await assert.rejects(player.load({resourceId:'a',prepare:()=>plan('b',{processing:{available:true,sessionEndpoint:'invalid'}})}),/resourceId/);
  assert.deepEqual(closed,['invalid']);assert.equal(player.state,'error');
  await assert.rejects(player.load({resourceId:'a',prepare:()=>plan('a',{timeline:{offsetSeconds:-1}})}),/timeline/);
});
test('original timeline maps seek, events, buffered ranges, duration and stored checkpoint',async t=>{
  const records=[];const {player,media}=setup(t,{progressStorage:{load:()=>null,save:(...args)=>records.push(args),clear:()=>{}}});
  media.buffered={length:2,start:i=>[0,30][i],end:i=>[20,60][i]};
  await player.load(plan('a',{timeline:{offsetSeconds:120,durationSeconds:300},resumePositionSeconds:125}));await settle();
  assert.equal(media.currentTime,5);assert.equal(player.currentTime,125);assert.equal(player.duration,300);
  assert.deepEqual(player.buffered,[{start:120,end:140},{start:150,end:180}]);
  player.seek(160);assert.equal(media.currentTime,40);let event;player.on('timeupdate',(...args)=>event=args);media.trigger('timeupdate');
  assert.deepEqual(event,[160,300]);await player.stop();assert.equal(records.at(-1)[1],160);assert.equal(records.at(-1)[2],300);
});
test('out-of-window seek prepares same resource and retains paused intent and controls',async t=>{
  const calls=[];const {player,media}=setup(t,{sourceResolver:{prepareSource:(id,current,context)=>{calls.push(context);return plan(id,{timeline:{offsetSeconds:context.positionSeconds,durationSeconds:500}});}}});
  await player.load(plan('a',{timeline:{offsetSeconds:120,durationSeconds:500}}));player.setVolume(.3);player.setPlaybackRate(1.5);
  await player.seekAsync(30);await settle();assert.equal(calls[0].positionSeconds,30);assert.equal(calls[0].paused,true);
  assert.equal(player.currentTime,30);assert.equal(media.currentTime,0);assert.equal(player.paused,true);assert.equal(player.volume,.3);assert.equal(player.playbackRate,1.5);
});
test('late asynchronous seek and output selection cannot overwrite newer resource',async t=>{
  const late=deferred(),closed=[];const {player}=setup(t,{sourceResolver:{prepareSource:()=>late.promise,onSessionClose:id=>closed.push(id)}});
  await player.load(plan('a',{timeline:{offsetSeconds:100,durationSeconds:300}}));const seek=player.seekAsync(5);await settle();await player.load(plan('b'));
  await assert.rejects(seek,{name:'AbortError'});late.resolve(plan('a',{processing:{available:true,sessionEndpoint:'stale'}}));await settle();
  assert.equal(player.currentResourceId,'b');assert.deepEqual(closed,['stale']);
});
test('explicit stopAndReset clears saved checkpoint while ordinary stop preserves it',async t=>{
  const stored=new Map();const {player}=setup(t,{progressStorage:{load:id=>stored.get(id),save:(id,position)=>stored.set(id,position),clear:id=>stored.delete(id)}});
  await player.load(plan('a'));player.seek(40);await player.stop();assert.equal(stored.get('a'),40);
  await player.load(plan('a'));await settle();await player.stopAndReset();assert.equal(stored.has('a'),false);
  await player.load(plan('a',{resumePositionSeconds:40}));await settle();assert.equal(player.currentTime,0,'reset also suppresses the stale server checkpoint on the next load');
});
test('reset requests an original beginning from a deferred delivery rather than replaying its old offset',async t=>{
  const contexts=[];const {player}=setup(t);const source={resourceId:'a',prepare:ctx=>{contexts.push(ctx);return plan('a',{timeline:{offsetSeconds:ctx.restart?0:100,durationSeconds:500}});}};
  await player.load(source);await player.stopAndReset();await player.load(source);await settle();assert.equal(contexts[1].restart,true);assert.equal(player.currentTime,0);
});
test('restart of a static offset plan prepares the original beginning, and refuses an unavailable reconstruction',async t=>{
  const calls=[];const {player}=setup(t,{sourceResolver:{prepareSource:(id,current,context)=>{calls.push(context);return plan(id,{timeline:{offsetSeconds:0,durationSeconds:500}});}}});
  await player.load(plan('a',{timeline:{offsetSeconds:100,durationSeconds:500}}),{restart:true});await settle();assert.equal(calls[0].positionSeconds,0);assert.equal(player.currentTime,0);
  const unsupported=setup(t).player;await assert.rejects(unsupported.load(plan('a',{timeline:{offsetSeconds:100,durationSeconds:500}}),{restart:true}),/source preparation/);
});
test('optional recovery uses one budget, deduplicates error events and preserves original position',async t=>{
  const next=deferred(),calls=[];const {player,media}=setup(t,{sourceResolver:{recoverSource:(_id,_plan,ctx)=>{calls.push(ctx);return next.promise;}}});
  await player.load(plan('a'));await player.play();player.seek(40);media.trigger('error');media.trigger('error');assert.equal(calls.length,0);await settle();assert.equal(calls.length,1);
  assert.equal(calls[0].positionSeconds,40);next.resolve(plan('a',{playUrl:'recovered.mp4'}));await settle();await settle();
  assert.equal(player.currentTime,40);assert.equal(player.paused,false);media.trigger('error');assert.equal(player.state,'error');assert.equal(calls.length,1);
});
test('pause during recovery wins over earlier playback intent',async t=>{
  const next=deferred();const {player,media}=setup(t,{sourceResolver:{recoverSource:()=>next.promise}});
  await player.load(plan('a'));await player.play();media.trigger('error');await settle();player.pause();next.resolve(plan('a',{playUrl:'recovered.mp4'}));await settle();await settle();assert.equal(player.paused,true);
});
test('a null recovery decision is terminal even when a larger attempt budget is configured',async t=>{
  let calls=0;const {player,media}=setup(t,{sourceOptions:{maxFallbackAttempts:3},sourceResolver:{recoverSource:()=>{calls++;return null;}}});
  await player.load(plan('a'));await player.play();media.trigger('error');await settle();await settle();assert.equal(calls,1);assert.equal(player.state,'error');assert.equal(player.paused,true);
});
test('a cancelled recovery cannot suppress errors or overwrite recovery on the next resource',async t=>{
  const old=deferred(),latest=deferred(),calls=[];const {player,media}=setup(t,{sourceResolver:{recoverSource:id=>{calls.push(id);return id==='a'?old.promise:latest.promise;}}});
  await player.load(plan('a'));await player.play();media.trigger('error');await settle();
  await player.load(plan('b'));await player.play();media.trigger('error');await settle();assert.deepEqual(calls,['a','b']);
  old.resolve(plan('a',{playUrl:'old.mp4'}));latest.resolve(plan('b',{playUrl:'new.mp4'}));await settle();await settle();
  assert.equal(player.currentResourceId,'b');assert.equal(media.src,'new.mp4');assert.equal(player.paused,false);
});
test('a local seek cancels older out-of-window preparation rather than jumping back on completion',async t=>{
  const late=deferred();const {player,media}=setup(t,{sourceResolver:{prepareSource:()=>late.promise}});
  await player.load(plan('a',{timeline:{offsetSeconds:100,durationSeconds:500}}));
  const previous=player.seekAsync(10);await settle();player.seek(140);await assert.rejects(previous,{name:'AbortError'});
  late.resolve(plan('a',{timeline:{offsetSeconds:10,durationSeconds:500}}));await settle();assert.equal(player.currentTime,140);assert.equal(media.currentTime,40);
});
test('prefetch waits for actual buffer, never consumes shuffle, and releases late lease on next/stop',async t=>{
  const late=deferred(),calls=[],released=[];const {player,media}=setup(t);
  const queue=new QueueController(player,{order:'shuffle',random:()=>.4});t.after(()=>queue.destroy());queue.setItems(['a','b','c'].map(id=>({id,source:plan(id)})));
  await queue.selectId('a');const next=queue.peekNext();assert.ok(next);assert.equal(queue.peekNext().id,next.id);
  const warming=mountQueuePrefetch(player,queue,{prepare:(item,context)=>{calls.push([item.id,context]);return late.promise;}});t.after(()=>warming.destroy());
  media.buffered={length:1,start:()=>0,end:()=>10};media.trigger('timeupdate');await settle();assert.equal(calls.length,0);
  media.buffered={length:1,start:()=>0,end:()=>70};media.trigger('timeupdate');await settle();assert.equal(calls[0][0],next.id);assert.equal(queue.peekNext().id,next.id);
  await player.stop();assert.equal(calls[0][1].signal.aborted,true);late.resolve({release:()=>released.push('lease')});await settle();assert.deepEqual(released,['lease']);
});
test('subtitle conversion preserves identifiers/settings, shifts and clips original times, rejects malformed/oversized input',async()=>{
  const vtt=normalizeSubtitles('1\n00:00:01,000 --> 00:00:03,000\nhello\n\n2\n00:00:06,000 --> 00:00:07,000\nworld',2);
  assert.match(vtt,/00:00:00.000 --> 00:00:01.000/);assert.match(vtt,/00:00:04.000 --> 00:00:05.000/);
  assert.match(normalizeSubtitles('WEBVTT\n\ncue\n00:00:01.000 --> 00:00:02.000 align:start\nhello'),/align:start/);
  assert.throws(()=>normalizeSubtitles('1\n00:00:02,000 --> 00:00:01,000\nx'));
  await assert.rejects(readSubtitleFile(new Blob([new Uint8Array(8*1024*1024+1)])),/8 MiB/);
});
test('native audio consumes truthful service facts, rejects stale IDs and releases service subscription',async()=>{
  let listener,request,unsubscribed=false;const commands=[];
  const port={load:value=>request=value,play:()=>commands.push('play'),pause:()=>commands.push('pause'),seek:value=>commands.push(['seek',value]),setPreferences:()=>{},stop:()=>commands.push('stop'),subscribe:fn=>{listener=fn;return()=>unsubscribed=true;}};
  const player=new StudioPlayer({backend:'native-audio',nativeAudioPort:port});
  try {
    await player.load(plan('audio',{mediaType:'audio',timeline:{offsetSeconds:100,durationSeconds:200}}));assert.equal(player.element,null);assert.equal(player.paused,true);
    listener({type:'progress',playbackId:request.playbackId,positionSeconds:5,durationSeconds:100,ready:true});assert.equal(player.currentTime,105);
    const playing=player.play();assert.equal(player.paused,true);listener({type:'state',playbackId:request.playbackId,state:'playing'});await playing;assert.equal(player.paused,false);
    listener({type:'progress',playbackId:'stale',positionSeconds:80,durationSeconds:100,ready:true});assert.equal(player.currentTime,105);
    await player.stop();listener({type:'state',playbackId:request.playbackId,state:'playing'});assert.equal(player.state,'stopped');assert.equal(player.paused,true);
  } finally {player.destroy();}assert.equal(unsubscribed,true);
});
