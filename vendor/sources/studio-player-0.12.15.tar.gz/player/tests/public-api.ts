// 编译消费者代码，使用 package exports 和 dist 声明，不走 src 路径。
import { PlaybackAudioAnalysis } from '@studio/player/analysis';
import { PlaybackRecoveryController } from '@studio/player/recovery';
declare const analysisMedia: HTMLMediaElement;
void new PlaybackAudioAnalysis(analysisMedia).dispose();
void new PlaybackRecoveryController(new RootPlayer(),analysisMedia,{enabled:false}).dispose();
import { StudioPlayer as RootPlayer, QueueController as RootQueue } from '@studio/player';
import { StudioPlayer, type PlayerPlayOptions } from '@studio/player/core';
import type {
  PlayerBackend,
  PlayerInstance,
  PlayerLifecycleState,
  PlayerPorts,
  PlaybackPort,
  ProgressStoragePort,
  PlayableInput,
  SurfaceGeometry,
  SurfacePort,
  TrackPort,
} from '@studio/player/contracts';
import { inferMediaMimeType } from '@studio/player/source-adapter';
import * as progress from '@studio/player/progress';
import { QueueController, type QueueItem, type QueueSnapshot } from '@studio/player/queue';
import { SleepTimerController } from '@studio/player/sleep-timer';
import { MediaSessionController } from '@studio/player/media-session';
import { createPlayerPreset, mountPlayerFeatures } from '@studio/player/presets';
import { mountSleepTimerSettings } from '@studio/player/ui/sleep-settings';
import { mountAudioPlayer, type AudioPlayerOptions, type AudioPlayerTokens, type AudioPlayerUI } from '@studio/player/ui/audio';
import { MainMediaCoordinator, type MainMediaController } from '@studio/player/main-media';
import { VideoTracksController, type VideoTracksSnapshot } from '@studio/player/video-tracks';
import { mountVideoPlayer, type VideoPlayerOptions, type VideoPlayerTokens, type VideoPlayerUI } from '@studio/player/ui/video';
import { mountMediaDockAudioPlayer, mountMediaDockVideoPlayer, type MediaDockPlayerOptions } from '@studio/player/ui/mediadock';
import { mountQueuePrefetch } from '@studio/player/queue';
import { normalizeSubtitles, readSubtitleFile } from '@studio/player/video-tracks';
import type { NativeAudioPort, DeferredMediaSource } from '@studio/player/contracts';

declare const nativeAudioPort: NativeAudioPort;
const nativeConsumer = new StudioPlayer({backend:'native-audio',nativeAudioPort});
const deferredSource: DeferredMediaSource = {resourceId:'prepared',resolveTimeoutSeconds:30,prepare:async({signal,restart})=>{
  signal.throwIfAborted();return {resourceId:'prepared',mediaType:'audio',strategy:'direct',transport:'range',playUrl:'/audio.mp3',resumePositionSeconds:restart?0:20};
}};
void nativeConsumer.load(deferredSource);
void nativeConsumer.load({resourceId:'fallback-timeline',mediaType:'audio',strategy:'transcode',transport:'hls',playUrl:'/segment.m3u8',timeline:{offsetSeconds:100},fallback:{playUrl:'/full.mp3',transport:'range',timeline:{offsetSeconds:0}}});
void nativeConsumer.seekAsync(20);
void nativeConsumer.stopAndReset();
const dockOptions: MediaDockPlayerOptions = {palette:'studio',layout:'mobile',view:'expanded',items:[{id:'prepared',source:deferredSource}]};
void [mountMediaDockAudioPlayer,mountMediaDockVideoPlayer,dockOptions,mountQueuePrefetch,normalizeSubtitles,readSubtitleFile];

declare const portInstance: PlayerInstance;
declare const playbackPort: PlaybackPort;
declare const trackPort: TrackPort;
declare const surfacePort: SurfacePort;
const diagnosticConsumer = new StudioPlayer();
diagnosticConsumer.on('diagnostic', diagnostic => {
  const code: string = diagnostic.code;
  // @ts-expect-error 诊断不得泄露来源 URL。
  diagnostic.url;
  void code;
});
const hostPorts: PlayerPorts = { instance: portInstance, playback: playbackPort, tracks: trackPort, surface: surfacePort };
const backend: PlayerBackend = portInstance.backend;
const lifecycle: PlayerLifecycleState = 'active';
const surfaceGeometry: SurfaceGeometry = {
  rect: { x: 0, y: 0, width: 640, height: 360 },
  devicePixelRatio: 1.25,
};
// @ts-expect-error 未验证的平台不能成为当前后端选择。
const invalidBackend: PlayerBackend = 'tauri';
void [hostPorts, backend, lifecycle, surfaceGeometry, invalidBackend];

// 判据2 负向断言：断言落在 `StudioPlayer.load()` 的返回类型上，不用 any 绕开。
// 两条 `@ts-expect-error` 只有在核心公开负载上**读不到**这些字段时才算"被使用"；交付描述
// 中立化（`contracts/delivery.ts`）之后它们已被使用，本文件因此 exit 0。谁把这些引擎字段
// 加回公开负载，这里会立刻报 TS2578（未使用的指令）。
type Loaded = Awaited<ReturnType<StudioPlayer['load']>>;
// @ts-expect-error requiresMse 属于引擎约定，不得出现在核心公开负载上
type LeakMse = Loaded['requiresMse'];
// @ts-expect-error preferPlayback 属于上游 Video.js 描述，不得出现在核心公开负载上
type LeakPrefer = Loaded['source']['preferPlayback'];

export async function consumer(root: HTMLElement, storage: ProgressStoragePort): Promise<AudioPlayerUI> {
  const source: PlayableInput = { src: '/episode.mp3', type: inferMediaMimeType('episode.mp3'), resourceId: 'episode-1' };
  const items: readonly QueueItem[] = [{ id: 'entry-1', source, title: 'Episode', artist: 'Studio', artwork: [{ src: '/cover.svg' }] }];
  const player: RootPlayer = new StudioPlayer({ progressStorage: storage });
  player.attach(document.createElement('audio'));
  const queue: RootQueue = new QueueController(player, { order: 'shuffle', repeat: 'all', random: () => 0.5 });
  queue.setItems(items);
  queue.add([{ ...items[0], id: 'entry-2' }]);
  queue.insertNext([{ ...items[0], id: 'entry-3' }]);
  queue.enqueueNext('entry-2'); queue.move('entry-3', 1);
  queue.move('entry-2', 2, { cancelUpNext: true });
  // @ts-expect-error 优先安排的撤销选项只接受布尔值。
  queue.move('entry-2', 2, { cancelUpNext: 'yes' });
  await queue.selectId('entry-1', { autoplay: false, restart: true });
  const playbackOptions: PlayerPlayOptions = { signal: new AbortController().signal };
  await player.play(playbackOptions);
  await queue.play(); await queue.previous(); await queue.next(); await queue.back(); await queue.forward();
  await queue.retry(); await queue.remove('entry-2');
  const snapshot: QueueSnapshot = queue.snapshot;
  const history: readonly string[] = snapshot.history;
  // @ts-expect-error 快照不可被消费者写入。
  snapshot.items.push(items[0]);
  // @ts-expect-error 随机源仅接受函数。
  new QueueController(player, { random: 0.5 });
  // @ts-expect-error 模式为明确枚举。
  queue.setRepeat('forever');
  const timer = new SleepTimerController(player);
  timer.start({ trigger: { type: 'items', count: 2 }, action: 'stop' });
  const settings = mountSleepTimerSettings(root, timer);
  settings.destroy(); timer.destroy();
  const session = new MediaSessionController(player, { queue });
  session.activate(); session.destroy();
  const features = mountPlayerFeatures(player, { queue: { order: 'shuffle' }, sleepTimer: true });
  features.destroy();
  const preset = createPlayerPreset('audio', { progressStorage: storage, features: { queue: { repeat: 'one' }, mediaSession: false } });
  preset.destroy();
  await queue.replaceItems(items); await queue.clear(); queue.destroy(); player.destroy();
  const tokens: AudioPlayerTokens = { accent: '#43846a', 'on-accent': '#fff', radius: '10px' };
  const options: AudioPlayerOptions = {
    items, queue: { order: 'sequential', repeat: 'all' }, progressStorage: storage,
    theme: 'dark', layout: 'auto', view: 'expanded', density: 'compact', tokens, nativeElementTag: 'video', mediaView: 'video',
    features: { sleepTimer: true, mediaSession: false },
    actions: [{ id: 'details', label: 'Details', run: context => { const id: string | undefined = context.current?.id; return id; } }],
    onRequestItems: () => {}, onClose: () => {}, onError: error => { void error; },
  };
  const ui = await mountAudioPlayer(root, options);
  ui.setTheme('auto'); ui.setLayout('mobile'); ui.setView('mini'); ui.setTokens({});
  ui.setDensity('comfortable'); ui.setDensity('compact');
  // @ts-expect-error Density is a presentation choice, not a custom stylesheet.
  ui.setDensity('custom');
  ui.setMediaView('audio'); ui.setMediaView('video');
  // @ts-expect-error Presentation does not claim to extract an audio track.
  ui.setMediaView('extract-audio');
  await ui.setItems(items); await ui.close(); ui.open();
  const samePlayer: StudioPlayer = ui.player;
  const sameQueue: QueueController = ui.queue;
  // @ts-expect-error UI 必须保留队列，附加功能不能禁用它。
  const invalidFeatures: AudioPlayerOptions = { features: { queue: false } };
  // @ts-expect-error 只提供公开样式变量，不开放任意内部结构改写。
  ui.setTokens({ selector: '.transport' });
  // @ts-expect-error 不存在的布局不能通过公开类型。
  ui.setLayout('tablet');
  void [progress, history, samePlayer, sameQueue, invalidFeatures];
  return ui;
}

export async function videoConsumer(root: HTMLElement, storage: ProgressStoragePort): Promise<VideoPlayerUI> {
  const scope = new MainMediaCoordinator();
  const source: PlayableInput = { resourceId: 'episode-1', mediaType: 'video', strategy: 'direct', transport: 'hls', playUrl: '/master.m3u8',
    tracks: { subtitles: [{ id: 'zh', src: '/zh.vtt', type: 'text/vtt', language: 'zh', label: '中文', default: true }] } };
  const standalone = new StudioPlayer(); standalone.attach(document.createElement('video'));
  const coordination: MainMediaController = scope.register(standalone);
  const tracks = new VideoTracksController(standalone);
  await standalone.load(source); standalone.requestPlayback();
  standalone.replaceSource({ ...source, playUrl: '/renewed.m3u8' });
  tracks.selectSubtitle('zh'); tracks.selectSubtitle('off'); tracks.selectAudioTrack('0'); tracks.selectQuality('auto');
  const snapshot: VideoTracksSnapshot = tracks.snapshot;
  const height: number | undefined = snapshot.qualities[0]?.height;
  // @ts-expect-error 能力快照只读。
  snapshot.qualities[0].selected = true;
  // @ts-expect-error 列表由实际来源产生，不能直接追加静态菜单项。
  snapshot.subtitles.push({ id: 'fake' });
  coordination.activate(); coordination.release(); coordination.destroy(); tracks.destroy(); standalone.destroy();
  const tokens: VideoPlayerTokens = { accent: '#ae6828', timeline: '#ffc17b', 'on-accent': '#fff', radius: '6px' };
  const options: VideoPlayerOptions = {
    items: [{ id: 'episode-1', source, title: 'Episode' }], progressStorage: storage,
    queue: { autoAdvance: false }, features: { mainMedia: { scope }, sleepTimer: true, mediaSession: false },
    theme: 'light', layout: 'auto', view: 'wide', variant: 'mediadock', tokens,
    controls: { preset: 'custom', placement: { rate: 'toolbar', subtitle: 'settings' } }, clearQueueOnClose: false, outputHeights: [0, 720],
    createMediaElement: document => document.createElement('video'),
    actions: [{ id: 'info', label: 'Details', run: ({ player, queue, current }) => { void [player.currentResourceId, queue.snapshot, current?.id]; } }],
  };
  const ui = await mountVideoPlayer(root, options);
  const sameTracks: VideoTracksController = ui.videoTracks;
  const sameScope: MainMediaController | null = ui.mainMedia;
  ui.queue.setAutoAdvance(true); ui.sleepTimer?.start({ trigger: { type: 'items', count: 2 }, action: 'close' });
  ui.setTheme('dark'); ui.setTokens({}); ui.setLayout('mobile'); ui.setView('standard');
  ui.setControls({ preset: 'balanced' });
  const ratePlacement: 'toolbar' | 'settings' = ui.controls.rate;
  // @ts-expect-error 无效的按钮位置必须被拒绝。
  ui.setControls({ placement: { rate: 'outside' } });
  // @ts-expect-error 配置快照不可修改。
  ui.controls.rate = 'settings';
  void ratePlacement;
  await ui.setItems([]); await ui.close(); ui.open();
  // @ts-expect-error 不接受未实现的设计。
  const invalidVariant: VideoPlayerOptions = { variant: 'danmaku' };
  // @ts-expect-error 主媒体协调必须显式注入消费者范围。
  createPlayerPreset('video', { features: { mainMedia: true } });
  // @ts-expect-error 视频 UI 依赖同一轨道实现，不允许用关闭能力来伪造菜单。
  const disabledTracks: VideoPlayerOptions = { features: { videoTracks: false } };
  // @ts-expect-error 快照不能代替队列命令。
  ui.queue.snapshot.autoAdvance = false;
  // @ts-expect-error 仅允许公开主题变量。
  ui.setTokens({ css: '.screen { display:none }' });
  // @ts-expect-error 视频布局形态有明确范围。
  ui.setView('mini');
  void [height, sameTracks, sameScope, disabledTracks, invalidVariant];
  return ui;
}
import { mountPreviewPlayer, type PreviewPlayerUI } from '@studio/player/ui/preview';
const previewUI: PreviewPlayerUI = mountPreviewPlayer(document.createElement('div'), { media: { source: { src: '/clip.mp4', resourceId: 'clip' }, title: 'Clip' }, view: 'mini', hoverPreview: true });
previewUI.setView('card'); previewUI.setTheme('auto'); previewUI.setTokens({ accent: '#f00' });
void previewUI.setMedia(null); void previewUI.play(); void previewUI.close(); previewUI.open(); previewUI.destroy();
// @ts-expect-error Preview has no implicit queue or system controls
mountPreviewPlayer(document.createElement('div'), { queue: true });
