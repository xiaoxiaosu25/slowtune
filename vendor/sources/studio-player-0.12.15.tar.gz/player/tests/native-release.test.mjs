import test from 'node:test';
import assert from 'node:assert/strict';
import { releaseDelivery } from '../dist/backends/videojs/element.js';

test('native release loads without recreating a source attribute', () => {
  let attribute = 'media.mp4', loads = 0;
  const media = {
    get src() { return attribute ?? ''; },
    set src(value) { attribute = value; },
    removeAttribute(name) { if (name === 'src') attribute = null; },
    load() { loads++; assert.equal(attribute, null, 'An empty src still requests source selection'); },
  };
  releaseDelivery(media);
  assert.equal(loads, 1);
  assert.equal(attribute, null);
});

test('native release retains the non-DOM media port fallback', () => {
  const media = { src: 'media.mp4', loads: 0, load() { this.loads++; } };
  releaseDelivery(media);
  assert.equal(media.src, '');
  assert.equal(media.loads, 1);
});

test('HLS element release prevents empty-source MSE inference and clears the adapter target', async () => {
  let src = 'blob:old', paused = 0, loads = 0;
  const target = { pause() { paused++; }, removeAttribute() { src = null; }, load() { loads++; assert.equal(src, null); } };
  const element = { localName: 'hlsjs-video', target, _source: { src: 'old.m3u8' },
    get source() { return this._source; }, set source(value) { this._source = value; queueMicrotask(() => { src = value.preferPlayback === 'native' ? '' : 'blob:unwanted'; }); }, removeAttribute() {} };
  releaseDelivery(element); await Promise.resolve();
  assert.equal(element.source.preferPlayback, 'native'); assert.equal(src, null); assert.equal(paused, 2); assert.equal(loads, 2);
});

test('deferred HLS idle cleanup cannot clear a newer delivery', async () => {
  const target = { src: 'old', pause() {}, removeAttribute() { this.src = null; }, load() {} };
  const element = { localName: 'hlsjs-video', target, source: { src: 'old.m3u8' }, removeAttribute() {} };
  releaseDelivery(element);
  element.source = { src: 'new.m3u8' }; target.src = 'new';
  await Promise.resolve(); assert.equal(target.src, 'new');
});
