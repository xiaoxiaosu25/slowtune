// U1 判据1（源码约定）与判据3 的声明图闭包、peer 清单断言。
// 口径见 docs/audio-video/player/03-后端与引擎边界.md 第 6、7 节。
// 本文件只做检查，不改实现；失败输出必须能定位到「哪个文件、哪个标记、哪一行」。
//
// 判据3 的闭包断言读 `packages/audio-video/player/dist/**` 的类型声明，**必须在重建 dist 之后运行**
// （`npm.cmd --prefix packages/audio-video/player run build`）；不重建则闭包反映的是上一版声明。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, relative, sep } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const packageRoot = dirname(here);

/**
 * 判据1 的核心模块清单：只扫这些（文件或整目录）。
 * - `src/ui/` 不在此列：上游控件与元素名属 U5。
 * - `src/backends/` 不在此列：后端实现里出现引擎约定是预期的（判据1 要的是核心不出现它们），
 *   因此后端模块从这里移出去之后不再回到本清单。
 */
const CORE_SCOPE = [
  'src/player.ts',
  'src/contracts',
  'src/source-adapter',
  'src/video-tracks',
];

/** 引擎约定标记；按原文匹配，不剥离注释——注释里出现同样算命中。 */
const ENGINE_MARKERS = [
  'hlsjs-video',
  'video-player',
  'audio-player',
  'preferPlayback',
  'requiresMse',
  'audioTracks',
  'videoRenditions',
];

const SOURCE_EXTENSIONS = ['.ts', '.mts', '.cts', '.tsx', '.js', '.mjs', '.cjs', '.json'];
const SKIP_DIRECTORIES = new Set(['node_modules', 'dist', '.git']);

function statSyncSafe(absolute) {
  try {
    return statSync(absolute);
  } catch {
    return null;
  }
}

function readDirectory(absolute) {
  return readdirSync(absolute, { withFileTypes: true });
}

function toPackagePath(absolute) {
  return relative(packageRoot, absolute).split(sep).join('/');
}

function matchesExtension(name) {
  return SOURCE_EXTENSIONS.some(extension => name.endsWith(extension));
}

/** 展开清单项：文件取自身，目录递归取全部源文件；按包内路径排序，保证输出稳定。 */
function collectFiles(scope) {
  const files = [];
  const walk = absolute => {
    const stats = readDirectory(absolute);
    for (const entry of stats) {
      if (entry.isDirectory()) {
        if (!SKIP_DIRECTORIES.has(entry.name)) walk(join(absolute, entry.name));
      } else if (entry.isFile() && matchesExtension(entry.name)) {
        files.push(join(absolute, entry.name));
      }
    }
  };
  for (const entry of scope) {
    const absolute = join(packageRoot, entry);
    const stats = statSyncSafe(absolute);
    if (!stats) throw new Error(`判据1 的扫描清单项不存在：${entry}`);
    if (stats.isDirectory()) walk(absolute);
    else files.push(absolute);
  }
  return [...new Set(files)].sort((left, right) => toPackagePath(left).localeCompare(toPackagePath(right)));
}

/** 逐行做原文子串匹配，返回命中清单（文件 + 标记 + 行号 + 行文本）。 */
function findMarkerHits(files, markers) {
  const hits = [];
  for (const file of files) {
    const lines = readFileSync(file, 'utf8').split(/\r?\n/);
    lines.forEach((line, index) => {
      for (const marker of markers) {
        if (line.includes(marker)) hits.push({ file: toPackagePath(file), line: index + 1, marker, text: line.trim() });
      }
    });
  }
  return hits;
}

function formatHits(hits) {
  return hits.map(hit => `${hit.file}:${hit.line} [${hit.marker}] ${hit.text}`).join('\n');
}

/** 按文件归并命中，打印「哪个文件还剩哪些标记」。 */
function formatHitsByFile(hits) {
  const byFile = new Map();
  for (const hit of hits) {
    if (!byFile.has(hit.file)) byFile.set(hit.file, new Map());
    const byMarker = byFile.get(hit.file);
    if (!byMarker.has(hit.marker)) byMarker.set(hit.marker, []);
    byMarker.get(hit.marker).push(hit.line);
  }
  const blocks = [];
  for (const [file, byMarker] of byFile) {
    blocks.push(`${file}`);
    for (const [marker, lines] of byMarker) blocks.push(`  - ${marker}（第 ${lines.join('、')} 行）`);
  }
  return blocks.join('\n');
}

test('判据1 源码约定：核心模块清单内不出现引擎约定标记', () => {
  const files = collectFiles(CORE_SCOPE);
  assert.ok(files.length > 0, '判据1 扫描清单为空，清单或路径有误');
  const hits = findMarkerHits(files, ENGINE_MARKERS);
  if (hits.length > 0) {
    const remaining = new Set(hits.map(hit => hit.file)).size;
    console.error(
      `\n判据1 未通过：${files.length} 个核心源文件中仍有 ${hits.length} 处引擎约定标记，分布在 ${remaining} 个文件。`
      + '\n剩余范围（按文件）：\n' + formatHitsByFile(hits)
      + '\n\n逐条命中（文件:行 [标记] 原文）：\n' + formatHits(hits) + '\n',
    );
  }
  assert.equal(hits.length, 0, `判据1：核心模块清单内仍有 ${hits.length} 处引擎约定标记，见上方逐条命中；范围为 ${CORE_SCOPE.join('、')}`);
});

test('判据3 清单：@videojs/html 是可选 peer', () => {
  const manifest = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  const actual = manifest.peerDependenciesMeta?.['@videojs/html']?.optional;
  if (actual !== true) {
    console.error(
      `\n判据3 清单未通过：packages/audio-video/player/package.json 的 peerDependenciesMeta["@videojs/html"].optional 为 ${JSON.stringify(actual)}，要求为 true（第 6 步转绿）。\n`,
    );
  }
  assert.equal(actual, true, '判据3：@videojs/html 必须声明为可选 peer（peerDependenciesMeta["@videojs/html"].optional === true）');
});

// ---------------------------------------------------------------------------
// U2 第 2 步的公开入口断言
//
// `BASELINE` 的已采用边界写的是"mpv 后端已接入代码、**未从任何公开入口导出**"。
// 这条结论此前只靠人工核对，没有检查；下面两项把它固定下来：
//   1. `package.json` 的 `exports` 里不得出现指向 `backends/` 的入口；
//   2. 该路径必须真的解析不到（按包自引用解析，不是相对路径绕过）。
// 注意这里断言的是**入口**，不是产物内容：核心的构建产物仍静态引用后端模块的**实现**，
// 这与"不从公开入口导出"并不矛盾（见 docs/audio-video/player/03-后端与引擎边界.md 第 7 节）。
// ---------------------------------------------------------------------------

test('U2：mpv 后端不在包的公开入口上', async () => {
  const manifest = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  const targets = Object.values(manifest.exports ?? {})
    .flatMap(entry => (typeof entry === 'string' ? [entry] : Object.values(entry ?? {})))
    .map(String);
  const leaked = targets.filter(target => target.includes('backends'));
  assert.deepEqual(leaked, [], `U2：公开 exports 不得指向 backends/，实际命中 ${leaked.join('、')}`);

  await assert.rejects(
    () => import('@studio/player/backends/mpv'),
    error => error?.code === 'ERR_PACKAGE_PATH_NOT_EXPORTED' || /not exported|not defined by "exports"/.test(String(error?.message ?? '')),
    'U2：mpv 后端不得能从包的公开入口导入（应报 ERR_PACKAGE_PATH_NOT_EXPORTED）',
  );
});

// ---------------------------------------------------------------------------
// 判据3 的声明图闭包断言
//
// 2026-09-16 实测：`moduleResolution: NodeNext` 下用 `paths` 把 `@videojs/*` 指向不存在的
// 路径**不阻断** node_modules 回落。因此「只取 core 与 contracts 的消费者不必安装引擎」
// 不能靠路径映射证明，改为按声明图的**相对导入闭包**判定：从 dist 的两个公开声明入口出发，
// 只沿相对说明符（含 `./x/index.js` 形式）递归，把闭包内出现的所有裸说明符收集起来。
// 这是本机可判定、也不依赖上游包是否恰好安装的检查。
// 未采用 `noResolve`：它会连相对导入一起关掉，闭包无法建立（见 04 第 3 节的遗留二）。
// ---------------------------------------------------------------------------

/** 判据3 的两个公开声明入口。 */
const DECLARATION_ENTRIES = [
  'dist/player.d.ts',
  'dist/contracts/index.d.ts',
];

/** 闭包内不得出现的裸说明符前缀。 */
const FORBIDDEN_BARE_PREFIX = '@videojs/';

/**
 * 从一段声明文本里收集模块说明符：`import` / 副作用导入 / `export ... from` /
 * 动态 `import()` / 三斜线 `reference types=`。前导分隔符按「行首或非标识符字符」判定，
 * 不依赖前面的语句恰好独占一行——上游声明把多条语句压在一行时也要认得出来。
 * 声明文件里的注释举例不参与——注释不影响解析，但为简单起见不做注释剥离。
 */
function collectModuleSpecifiers(text) {
  const specifiers = new Set();
  const patterns = [
    /(?:^|[^\w$])(?:import|export)\s+(?:type\s+)?(?:[^'";]*?\sfrom\s*)?['"]([^'"]+)['"]/g,
    /(?:^|[^\w$])(?:import|export)\s+(?:type\s+)?(?:\*|\{[^}]*\})\s*from\s*['"]([^'"]+)['"]/g,
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) specifiers.add(match[1]);
  }
  for (const match of text.matchAll(/<reference\s+types\s*=\s*['"]([^'"]+)['"]/g)) specifiers.add(match[1]);
  return [...specifiers];
}

function isRelativeSpecifier(specifier) {
  return specifier.startsWith('./') || specifier.startsWith('../');
}

/**
 * 把相对说明符映射到磁盘上的声明文件：`.js` → 同名 `.d.ts`，
 * 无扩展名 → `.d.ts` 或 `<dir>/index.d.ts`（后两者覆盖 `'./x/index.js'` 与 `'./x'`）。
 */
function resolveRelativeDeclaration(fromAbsolute, specifier) {
  const base = specifier.split('?')[0].split('#')[0];
  const absoluteBase = join(dirname(fromAbsolute), base);
  const candidates = /\.js$/.test(base)
    ? [absoluteBase.replace(/\.js$/, '.d.ts')]
    : [base.endsWith('.d.ts') ? absoluteBase : `${absoluteBase}.d.ts`, join(absoluteBase, 'index.d.ts')];
  for (const candidate of candidates) {
    const stats = statSyncSafe(candidate);
    if (stats?.isFile()) return candidate;
  }
  return null;
}

/** 从入口出发按相对导入递归，返回闭包文件集合与逐条「文件 → 说明符」边。 */
function collectDeclarationClosure(entries) {
  const visited = new Set();
  const bare = [];
  const edges = [];
  const queue = [];
  for (const entry of entries) {
    const absolute = join(packageRoot, entry);
    if (!statSyncSafe(absolute)?.isFile()) {
      throw new Error(`判据3 的声明入口不存在：${entry}（先重建 dist：npm.cmd --prefix packages/audio-video/player run build）`);
    }
    visited.add(absolute);
    queue.push(absolute);
  }
  while (queue.length > 0) {
    const current = queue.shift();
    const text = readFileSync(current, 'utf8');
    for (const specifier of collectModuleSpecifiers(text)) {
      edges.push({ file: toPackagePath(current), specifier });
      if (isRelativeSpecifier(specifier)) {
        const resolved = resolveRelativeDeclaration(current, specifier);
        if (resolved && !visited.has(resolved)) {
          visited.add(resolved);
          queue.push(resolved);
        }
      } else {
        bare.push({ file: toPackagePath(current), specifier });
      }
    }
  }
  return { files: visited, bare, edges };
}

test('判据3 闭包：dist 的类型声明闭包内不出现 @videojs/ 裸说明符', () => {
  const { files, bare, edges } = collectDeclarationClosure(DECLARATION_ENTRIES);

  // 防止检查名存实亡：闭包必须真的从两个入口长出来。
  assert.ok(files.size > 0, '判据3 闭包为空：检查没有生效，先重建 dist 再跑');
  const closedPaths = new Set([...files].map(toPackagePath));
  for (const entry of DECLARATION_ENTRIES) {
    assert.ok(closedPaths.has(entry), `判据3 闭包不包含起点文件 ${entry}：检查已经名存实亡，先重建 dist 再跑`);
  }
  assert.ok(edges.length > 0, `判据3 闭包没有解析到任何模块说明符：检查已经名存实亡。起点为 ${DECLARATION_ENTRIES.join('、')}`);

  const forbidden = bare.filter(entry => entry.specifier.startsWith(FORBIDDEN_BARE_PREFIX));
  if (forbidden.length > 0) {
    const chain = forbidden
      .map(entry => `${entry.file} → ${entry.specifier}`)
      .join('\n');
    console.error(
      `\n判据3 闭包未通过：声明图闭包内有 ${forbidden.length} 处 ${FORBIDDEN_BARE_PREFIX} 裸说明符。`
      + `\n闭包规模：${files.size} 个声明文件，共 ${edges.length} 条说明符边。`
      + '\n文件 → 说明符：\n' + chain + '\n',
    );
  }
  assert.equal(forbidden.length, 0,
    `判据3：只取 core 与 contracts 的类型图不得引用 ${FORBIDDEN_BARE_PREFIX}*（闭包 ${files.size} 个文件，见上方「文件 → 说明符」链路）`);
});
