# 第三方来源与工具

版本：v0.3 · 2026-10-05

B 站请求、WBI、扫码会话、匿名访客与中立结果映射由平台独立实现；协议以平台端点的真实响应核对，成功登录尚待本人验收。NoxPlayer、azusa-player-mobile、BBPlayer 等完整应用只作功能与职责参考；没有复制或改写它们的应用源码，也没有将应用列为运行依赖。

[YouTube.js](https://github.com/LuanRT/YouTube.js) 作为可选 peer，通过公开 SDK 包装视频目录；本轮安装包的 LICENSE 为 MIT，Copyright (c) 2021 LuanRT。[Hono](https://github.com/honojs/hono) 用于可选服务包装，LICENSE 为 MIT。取得和分发这些依赖时保留其完整许可声明。固定安装版本及传递依赖以 [package-lock.json](package-lock.json) 为准；平台没有维护上游分叉。

[yt-dlp](https://github.com/yt-dlp/yt-dlp#license) 为宿主工具，源码和 PyInstaller 制品的许可条件分别核查。当前对照取得 PyPI 源码 wheel 及默认 EJS 依赖，运行于工作区 local 的隔离 Python 环境，并显式提供 Node runtime；取得记录见[证据](evidence/acceptance-2026-10-03.md)。工具、运行时和 EJS 未随公共包分发。

Music 当前出口明确受地区限制；原 SDK 直接播放解析未通过，改进的目录候选与有界脚本执行试验仅留在 labs。正式包不执行该候选的播放器脚本。Cookie 认证方案依据上游 [SDK 文档](https://ytjs.dev/guide/authentication)和 [yt-dlp 文档](https://github.com/yt-dlp/yt-dlp/wiki/Extractors#exporting-youtube-cookies)，工具输入包装独立实现。来源内部接口可能变化；当前真实验证限定匿名样本，不构成平台官方开放 SDK、媒体内容授权或公开产品分发许可结论。

本页的 package-lock.json 与 evidence 链接用于平台源码工作区核对，这些文件不随运行制品分发。安装用户可读取随包提供的本页、package.json、消费者锁文件及依赖自身的完整许可；上游网页用于来源查询，工具仍由宿主提供。
