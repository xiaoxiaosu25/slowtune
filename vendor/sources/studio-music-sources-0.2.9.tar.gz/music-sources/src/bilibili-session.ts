import {randomBytes} from 'node:crypto';
import {fail,resourceId,type ProviderContext,type LibraryRequest,type Account,type LoginStatus,type LoginChallenge} from './contracts.js';
import {boundedJson} from './util.js';
const token=()=>randomBytes(24).toString('base64url');
const HEADERS={'User-Agent':'Mozilla/5.0',Referer:'https://www.bilibili.com/'};
const PASSPORT='https://passport.bilibili.com/x/passport-login/web/qrcode/';
interface Session { ref:string; key:string; until:number; next:number; busy:boolean; stop:AbortController; work?:Promise<LoginStatus> }
export class BilibiliSessions {
  private sessions=new Map<string,Session>();
  private disposed=false;
  private prune(now:number){for(const[id,s]of this.sessions)if(s.until<=now){s.stop.abort();this.sessions.delete(id);}}
  async begin(c:ProviderContext):Promise<LoginChallenge>{
    if(this.disposed)fail('disposed','bilibili');
    if(!c.credentialRef||!c.host.credentials?.write)fail('unsupported','bilibili');
    this.prune(c.host.now());if(this.sessions.size>=4)fail('busy','bilibili');
    const data=await boundedJson(await c.host.fetch(PASSPORT+'generate',{headers:HEADERS,signal:c.signal}));
    if(data.code!==0||typeof data.data?.qrcode_key!=='string'||typeof data.data?.url!=='string')fail('upstream','bilibili');
    const url=new URL(data.data.url);if(url.protocol!=='https:'||!['passport.bilibili.com','account.bilibili.com'].includes(url.hostname))fail('upstream','bilibili');
    c.signal.throwIfAborted();if(this.disposed)fail('disposed','bilibili');
    for(const[id,s]of this.sessions)if(s.ref===c.credentialRef)await this.cancel(id,c);
    const id=token(),until=c.host.now()+180000;
    this.sessions.set(id,{ref:c.credentialRef,key:data.data.qrcode_key,until,next:0,busy:false,stop:new AbortController()});
    return{id,method:'qr',url:url.href,expiresAt:until,intervalMs:2000};
  }
  async poll(id:string,c:ProviderContext):Promise<LoginStatus>{
    if(this.disposed)fail('disposed','bilibili');
    const s=this.sessions.get(id);if(!s||s.ref!==c.credentialRef)fail('expired','bilibili');
    if(s.until<=c.host.now()){s.stop.abort();this.sessions.delete(id);return{state:'expired'};}
    if(s.busy||s.next>c.host.now())fail('busy','bilibili');s.busy=true;s.next=c.host.now()+2000;
    c={...c,signal:AbortSignal.any([c.signal,s.stop.signal])};
    const work=this.performPoll(id,s,c);s.work=work;try{return await work;}finally{s.work=undefined;}
  }
  private async performPoll(id:string,s:Session,c:ProviderContext):Promise<LoginStatus>{
    try{
      const response=await c.host.fetch(PASSPORT+'poll?qrcode_key='+encodeURIComponent(s.key),{headers:HEADERS,signal:c.signal});
      const cookies=response.headers.getSetCookie?.()??[];
      const result=await boundedJson(response);if(result.code!==0||typeof result.data?.code!=='number')fail('upstream','bilibili');
      if(this.sessions.get(id)!==s||this.disposed||c.signal.aborted)fail('cancelled','bilibili');
      const code=result.data.code;
      if(code===86101)return{state:'pending'};
      if(code===86090)return{state:'scanned'};
      if(code===86038){this.sessions.delete(id);return{state:'expired'};}
      if(code!==0)fail('upstream','bilibili',String(code));
      const allowed=new Set(['SESSDATA','bili_jct','DedeUserID','DedeUserID__ckMd5','sid']);
      const values=new Map();for(const raw of cookies){const first=raw.split(';',1)[0];const split=first.indexOf('=');if(split<1)continue;const name=first.slice(0,split);if(allowed.has(name)&&!/[\r\n]/.test(first))values.set(name,first.slice(split+1));}
      if(!values.get('SESSDATA')||!values.get('bili_jct'))fail('upstream','bilibili','missing-session-cookie');
      const cookie=[...values].map(([k,v])=>k+'='+v).join('; ');
      // Verify the new session before handing it to the host. SSO redirects are not followed.
      const credential={revision:token(),provider:'bilibili' as const,cookie};
      const account=await bilibiliAccount({...c,credential});
      c.signal.throwIfAborted();if(this.sessions.get(id)!==s||this.disposed)fail('cancelled','bilibili');
      if(!c.host.credentials?.write)fail('unsupported','bilibili');
      await c.host.credentials.write(s.ref,credential,c.signal);
      this.sessions.delete(id);return{state:'authenticated',account};
    }catch(e){if(s.stop.signal.aborted)fail('cancelled','bilibili');throw e;}finally{s.busy=false;}
  }
  async cancel(id:string,c:ProviderContext){const s=this.sessions.get(id);if(s&&s.ref!==c.credentialRef)fail('authentication','bilibili');this.sessions.delete(id);s?.stop.abort();await s?.work?.catch(()=>{});}
  forget(ref:string){for(const[id,s]of this.sessions)if(s.ref===ref){s.stop.abort();this.sessions.delete(id);}}
  diagnostics(){return{sessions:this.sessions.size,disposed:this.disposed};}
  dispose(){this.disposed=true;for(const s of this.sessions.values())s.stop.abort();this.sessions.clear();}
}
async function api(path:string,c:ProviderContext){
  const r=await boundedJson(await c.host.fetch('https://api.bilibili.com'+path,{headers:{...HEADERS,...(c.credential?.cookie?{Cookie:c.credential.cookie}:{})},signal:c.signal}));
  if(r.code===-101)fail('authentication','bilibili');
  if(r.code!==0)fail([-403,-352].includes(r.code)?'restricted':'upstream','bilibili',String(r.code));
  if(!r.data||typeof r.data!=='object')fail('upstream','bilibili');return r.data;
}
export async function bilibiliAccount(c:ProviderContext):Promise<Account>{
  if(!c.credential?.cookie)fail('authentication','bilibili');
  const d=await api('/x/web-interface/nav',c);
  if(d.isLogin!==true)fail('authentication','bilibili');
  if(!Number.isInteger(d.mid)||typeof d.uname!=='string')fail('upstream','bilibili');
  return{provider:'bilibili',id:String(d.mid),name:d.uname,...(typeof d.face==='string'?{artwork:d.face}:{})};
}
export async function bilibiliLibrary(request:LibraryRequest,c:ProviderContext,page=1){
  const account=await bilibiliAccount(c);
  const size=request.limit??20;if(!Number.isInteger(size)||size<1||size>50)fail('invalid-input','bilibili');
  const d=await api(`/x/v3/fav/folder/created/list?up_mid=${account.id}&pn=${page}&ps=${size}`,c);
  if(!Array.isArray(d.list))fail('upstream','bilibili');
  const items=d.list.map((x:any)=>{if(!Number.isInteger(x.id)||typeof x.title!=='string')fail('upstream','bilibili');const ref={provider:'bilibili' as const,kind:'playlist' as const,id:'fav:'+x.id};return{ref,resourceId:resourceId(ref),title:x.title,url:`https://www.bilibili.com/medialist/detail/ml${x.id}`,...(x.cover?{artwork:x.cover}:{})};});
  return{items,hasMore:d.has_more===true||d.has_more===1};
}
