import { MusicSourceError, resourceId, type MusicEntry, type MusicHost, type ProviderContext } from './contracts.js';
import { signWbi, wbiMixinKey } from './bilibili.js';
import { SharedWork } from './shared-work.js';
import { boundedJson } from './util.js';

export type CatalogueRow = Record<string, any>;
export const cleanCatalogueText = (value: unknown): string => typeof value === 'string' ? value.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>') : '';
function cover(value: unknown): string | undefined { try { if(typeof value!=='string'||!value)return;const url=new URL(value.startsWith('//')?'https:'+value:value);if(!['http:','https:'].includes(url.protocol))return;url.protocol='https:';return url.href; } catch { return; } }
/** Actual directory facts only; classification and language policy stay with the host. */
export function bilibiliCatalogueEntry(r: CatalogueRow): MusicEntry {
  const first=Array.isArray(r.pages)?r.pages[0]:undefined,cid=first?.cid??r.cid??r.ugc?.first_cid;
  const ref={provider:'bilibili' as const,kind:'video' as const,id:r.bvid,...(cid&&/^\d+$/.test(String(cid))?{part:String(cid)}:{})};
  const author=typeof r.author==='object'?r.author:r.owner??r.upper,duration=first?.duration??r.duration;
  const category=[r.tname,r.tname_v2].filter(v=>typeof v==='string'&&v.trim()).map(cleanCatalogueText);
  const tags=Array.isArray(r.tags)?r.tags.filter(v=>typeof v==='string'&&v.trim()):typeof r.tag==='string'?r.tag.split(',').filter(Boolean):undefined;
  return {ref,resourceId:resourceId(ref),title:cleanCatalogueText(r.title??r.music_title),url:`https://www.bilibili.com/video/${r.bvid}`,artwork:cover(r.pic)??cover(r.cover),durationSeconds:typeof duration==='number'?duration:typeof duration==='string'&&/^\d+:\d+(?::\d+)?$/.test(duration)?duration.split(':').reduce((n,s)=>n*60+Number(s),0):undefined,
    ...(author?.name?{uploader:{name:cleanCatalogueText(author.name),...(author.mid!==undefined?{id:String(author.mid)}:{})}}:typeof r.author==='string'&&!r.music_title?{uploader:{name:cleanCatalogueText(r.author),...(r.mid!==undefined?{id:String(r.mid)}:{})}}:{}),
    ...(r.music_title&&typeof r.author==='string'?{artists:r.author.split(',').filter(Boolean)}:{}),...(tags?{tags}:{}),
    ...(category.length?{categories:category}:{}),...(Number.isSafeInteger(r.tid)?{board:String(r.tid)}:{}),...(typeof r.pubdate==='number'&&r.pubdate>0?{publishedAt:r.pubdate*1000}:{}),
  };
}

/** Narrow protocol client; no implicit discovery, account store, or music rules. */
export class BilibiliCatalogue {
  private keys=new Map<string,{key:string;until:number}>();
  private shared=new SharedWork();
  async json(path: string, params: Record<string,string>, c: ProviderContext, signed=false): Promise<CatalogueRow> {
    if(!['/x/web-interface/nav','/x/web-interface/wbi/index/top/feed/rcmd','/x/web-interface/view','/x/web-interface/region/feed/rcmd','/x/centralization/interface/new/music','/x/copyright-music-publicity/toplist/all_period','/x/copyright-music-publicity/toplist/music_list'].includes(path))throw new MusicSourceError({code:'invalid-input',provider:'bilibili',retryable:false});
    let query=new URLSearchParams(params).toString();
    if(signed){
      const key=await this.shared.run('wbi:'+c.scope,c.signal,async signal=>{
        let cached=this.keys.get(c.scope);if(cached&&cached.until>c.host.now())return cached.key;
        const nav=await this.json('/x/web-interface/nav',{}, {...c,signal});
        if(nav.isLogin!==true)throw new MusicSourceError({code:'authentication',provider:'bilibili',retryable:false});
        if(typeof nav.wbi_img?.img_url!=='string'||typeof nav.wbi_img?.sub_url!=='string')throw new MusicSourceError({code:'upstream',provider:'bilibili',retryable:true});
        cached={key:wbiMixinKey(nav.wbi_img.img_url,nav.wbi_img.sub_url),until:c.host.now()+3600000};
        if(this.keys.size>=8)this.keys.delete(this.keys.keys().next().value!);this.keys.set(c.scope,cached);return cached.key;
      });
      if(!c.host.md5)throw new MusicSourceError({code:'unsupported',retryable:false});query=await signWbi(params,key,c.host.now(),c.host.md5);
    }
    const response=await c.host.fetch('https://api.bilibili.com'+path+'?'+query,{headers:{'User-Agent':'Mozilla/5.0',Referer:path.includes('toplist')?'https://music.bilibili.com/':'https://www.bilibili.com/',...(c.credential?.cookie?{Cookie:c.credential.cookie}:{})},signal:c.signal});
    if(!response.ok){await response.body?.cancel();throw new MusicSourceError({code:response.status===429?'rate-limited':[403,412].includes(response.status)?'restricted':'upstream',provider:'bilibili',retryable:true});}
    const value=await boundedJson(response);c.signal.throwIfAborted();
    if(value.code!==0||value.data?.v_voucher){if(signed&&[-403,-352].includes(value.code))this.keys.delete(c.scope);throw new MusicSourceError({code:value.code===-101?'authentication':[-403,-10403,-352,-412].includes(value.code)||value.data?.v_voucher?'restricted':value.code===-509?'rate-limited':'upstream',provider:'bilibili',retryable:value.code!==-101});}
    if(!value.data||typeof value.data!=='object')throw new MusicSourceError({code:'upstream',provider:'bilibili',retryable:true});return value.data;
  }
  forgetScope(prefix:string){for(const key of this.keys.keys())if(key.startsWith(prefix))this.keys.delete(key);this.shared.cancelWhere(key=>key.startsWith('wbi:'+prefix));}
  async dispose(){await this.shared.dispose();this.keys.clear();}
}

export interface ChartPeriod {id:number;number:number;publishedAt:number}
export interface BilibiliChart {shelf:{id:string;title:string;kind:'chart';page:{items:MusicEntry[]}};periods:ChartPeriod[];period:ChartPeriod;sourceUrl:string;fetchedAt:number}
export class BilibiliCharts {
  private catalogue=new BilibiliCatalogue();
  private periods?:{items:ChartPeriod[];until:number};
  private charts=new Map<number,{items:MusicEntry[];fetchedAt:number;until:number}>();
  async read(host:MusicHost,signal:AbortSignal,periodId?:number):Promise<BilibiliChart>{
    const c={host,signal,scope:'anonymous'};
    if(!this.periods||this.periods.until<=host.now()){
      const data=await this.catalogue.json('/x/copyright-music-publicity/toplist/all_period',{list_type:'1'},c);
      if(!data.list||typeof data.list!=='object')throw new MusicSourceError({code:'upstream',provider:'bilibili',retryable:true});
      const items=Object.values(data.list).flat().filter((r:any)=>Number.isSafeInteger(r?.ID)&&r.ID>0&&Number.isSafeInteger(r.priod)&&r.priod>0&&typeof r.publish_time==='number'&&r.publish_time>0).map((r:any)=>({id:r.ID,number:r.priod,publishedAt:r.publish_time*1000})).sort((a,b)=>b.publishedAt-a.publishedAt);
      if(!items.length)throw new MusicSourceError({code:'upstream',provider:'bilibili',retryable:true});this.periods={items,until:host.now()+60000};
    }
    const periods=this.periods.items,period=periodId===undefined?periods[0]:periods.find(p=>p.id===periodId);
    if(!period)throw new MusicSourceError({code:'not-found',provider:'bilibili',retryable:false});
    let chart=this.charts.get(period.id);
    if(!chart||chart.until<=host.now()){
      const data=await this.catalogue.json('/x/copyright-music-publicity/toplist/music_list',{list_id:String(period.id)},c);
      if(!Array.isArray(data.list))throw new MusicSourceError({code:'upstream',provider:'bilibili',retryable:true});
      const items:MusicEntry[]=data.list.slice(0,100).flatMap((r:any)=>{
        const mv=/^BV[a-zA-Z0-9]{10}$/.test(r?.mv_bvid),id=mv?r.mv_bvid:r?.creation_bvid;
        if(!/^BV[a-zA-Z0-9]{10}$/.test(id)||typeof r.music_title!=='string')return [];
        const cid=!mv&&r.creation_first_cid,ref={provider:'bilibili' as const,kind:'video' as const,id,...(Number.isSafeInteger(cid)&&cid>0?{part:String(cid)}:{})};
        return [{ref,resourceId:resourceId(ref),title:r.music_title,artists:typeof r.singer==='string'?r.singer.split(',').filter(Boolean):[],url:'https://www.bilibili.com/video/'+id,artwork:cover(r.mv_cover)??cover(r.creation_cover),...(!mv&&typeof r.creation_duration==='number'?{durationSeconds:r.creation_duration}:{})}];
      });
      chart={items,fetchedAt:host.now(),until:host.now()+(period.id===periods[0].id?60000:3600000)};if(this.charts.size>=12)this.charts.delete(this.charts.keys().next().value!);this.charts.set(period.id,chart);
    }
    signal.throwIfAborted();return {shelf:{id:'hot-chart',title:'B站热歌榜',kind:'chart',page:{items:structuredClone(chart.items)}},periods:structuredClone(periods),period:{...period},sourceUrl:'https://music.bilibili.com/pc/rank?list_type=1&list_id='+period.id,fetchedAt:chart.fetchedAt};
  }
}
export interface PublicPlaylist {id:string;title:string}
export function parseYoutubeMusicCatalogue(data:unknown):PublicPlaylist[]{
  const playlists=new Map<string,PublicPlaylist>();let visited=0;
  function walk(value:unknown,depth:number){if(!value||typeof value!=='object')return;if(++visited>50000||depth>60)throw new MusicSourceError({code:'upstream',provider:'youtube',retryable:true});const node=value as CatalogueRow,lockup=node.lockupViewModel;
    if(lockup&&['LOCKUP_CONTENT_TYPE_STATION','LOCKUP_CONTENT_TYPE_PLAYLIST','LOCKUP_CONTENT_TYPE_ALBUM'].includes(lockup.contentType)){const id=lockup.contentId,title=lockup.metadata?.lockupMetadataViewModel?.title?.content;if(typeof id==='string'&&/^[\w-]{10,128}$/.test(id)&&typeof title==='string'&&title.trim()&&playlists.size<120)playlists.set(id,{id,title:title.trim().slice(0,300)});}
    for(const child of Object.values(node))walk(child,depth+1);
  }walk(data,0);return [...playlists.values()];
}
export function createYoutubeCatalogueLoader(host:Pick<MusicHost,'fetch'>,channel='UC-9-kyTW8ZkZNDHQJ6FgpwQ'){
  return async(region:string,signal:AbortSignal):Promise<unknown>=>{
    if(!/^[A-Z]{2}$/.test(region)||!/^UC[\w-]{22}$/.test(channel))throw new MusicSourceError({code:'invalid-input',provider:'youtube',retryable:false});
    const {Innertube}=await import('youtubei.js');
    const client=await Innertube.create({retrieve_player:false,enable_session_cache:false,generate_session_locally:false,lang:'zh-CN',location:region,fetch:(input,init)=>host.fetch(input,{...init,signal})});
    const response=await client.actions.execute('/browse',{browseId:channel});signal.throwIfAborted();return response.data;
  };
}
