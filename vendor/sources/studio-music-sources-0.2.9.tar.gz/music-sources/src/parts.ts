import { fail, resourceId, validateRef, type CallOptions, type EntryRef, type MusicApi, type MusicEntry } from './contracts.js';

export type MusicPartSelection =
  | { mode: 'single'; part?: string }
  | { mode: 'selected'; parts: readonly string[] }
  | { mode: 'all' }
  | { mode: 'from'; part: string };

/** Select from one metadata snapshot. No requests or playback/collection side effects. */
export function selectMusicParts(entry: MusicEntry, selection: MusicPartSelection): MusicEntry[] {
  validateRef(entry?.ref);
  if (entry.ref.kind !== 'video' || !selection || !['single', 'selected', 'all', 'from'].includes(selection.mode)) fail('invalid-input');
  const source = entry.parts ?? [entry];
  if (!Array.isArray(source) || !source.length || source.length > 1000) fail('upstream');
  const known = new Set<string>();
  const parts = source.map(value => {
    validateRef(value?.ref);
    if (value.ref.provider !== entry.ref.provider || value.ref.kind !== 'video' || value.ref.id !== entry.ref.id || (value.ref.provider === 'bilibili' ? !value.ref.part || value.ref.part === '0' : value.ref.part !== undefined)) fail('protocol');
    const id = resourceId(value.ref); if (known.has(id)) fail('protocol'); known.add(id);
    const { parts: _nested, ...item } = value;
    return structuredClone({ ...item, resourceId: id });
  });
  if (selection.mode === 'all') return parts;
  if (selection.mode === 'selected') {
    if (entry.ref.provider !== 'bilibili' || !Array.isArray(selection.parts) || !selection.parts.length || selection.parts.length > 1000 || new Set(selection.parts).size !== selection.parts.length || selection.parts.some(part => typeof part !== 'string' || !/^[1-9]\d*$/.test(part))) fail('invalid-input');
    const selected = new Set(selection.parts);
    if (selection.parts.some(part => !parts.some(value => value.ref.part === part))) fail('not-found', entry.ref.provider);
    return parts.filter(value => selected.has(value.ref.part!));
  }
  const part = selection.part ?? (selection.mode === 'single' ? entry.ref.part : undefined);
  if (selection.mode === 'from' && part === undefined) fail('invalid-input');
  if (part !== undefined && (typeof part !== 'string' || !/^[1-9]\d*$/.test(part))) fail('invalid-input');
  if (entry.ref.provider === 'youtube') {
    if (selection.mode !== 'single' || part !== undefined) fail('unsupported', entry.ref.provider);
    return parts;
  }
  const index = part === undefined ? 0 : parts.findIndex(value => value.ref.part === part);
  if (index < 0) fail('not-found', entry.ref.provider);
  return selection.mode === 'from' ? parts.slice(index) : [parts[index]];
}

export async function resolveMusicParts(api: Pick<MusicApi, 'metadata'>, ref: EntryRef, selection: MusicPartSelection, options: CallOptions = {}): Promise<MusicEntry[]> {
  validateRef(ref); if (options.signal?.aborted) fail('cancelled');
  ref = { ...ref }; selection = structuredClone(selection);
  const entry = await api.metadata(ref, options); if (options.signal?.aborted) fail('cancelled');
  if (entry.ref.provider !== ref.provider || entry.ref.id !== ref.id || (ref.part && entry.ref.part !== ref.part)) fail('protocol');
  return selectMusicParts(entry, selection);
}

/** Resolve a batch using one metadata read per video, preserving input order and duplicates. */
export async function resolveMusicEntries(api: Pick<MusicApi, 'metadata'>, refs: readonly EntryRef[], options: CallOptions = {}): Promise<MusicEntry[]> {
  if (!Array.isArray(refs) || !refs.length || refs.length > 1000) fail('invalid-input');
  const input = refs.map(ref => { validateRef(ref); if (ref.kind !== 'video' || (ref.provider === 'youtube' && ref.part !== undefined)) fail('invalid-input'); return { ...ref }; });
  const metadata = new Map<string, MusicEntry>(), result: MusicEntry[] = [];
  for (const ref of input) {
    if (options.signal?.aborted) fail('cancelled');
    const videoRef: EntryRef = { provider: ref.provider, kind: 'video', id: ref.id }, key = resourceId(videoRef);
    let entry = metadata.get(key);
    if (!entry) {
      entry = await api.metadata(videoRef, options); if (options.signal?.aborted) fail('cancelled');
      if (entry.ref.provider !== ref.provider || entry.ref.id !== ref.id) fail('protocol'); metadata.set(key, entry);
    }
    result.push(selectMusicParts(entry, { mode: 'single', ...(ref.part ? { part: ref.part } : {}) })[0]);
  }
  return result;
}
