import { fail, MusicSourceError, type MusicHost, type PreparedPlayback, type CallOptions } from './contracts.js';
import { opaqueToken } from './node.js';
import { readDelivery } from './delivery-read.js';
import { emitDiagnostic } from './util.js';
import { HlsDelivery, readPlaylist } from './hls-delivery.js';
interface Lease { playback:PreparedPlayback; until:number; options:CallOptions; revision?:string; reads:Set<AbortController>;done:Set<Promise<void>>;hls?:HlsDelivery }
export class MediaDelivery {
  private leases=new Map<string,Lease>(); private disposed=false; private active=0;private pending=new Set<Promise<void>>();
  private sequence = 0;
  constructor(private host:MusicHost,private options:{ttlMs?:number;maxLeases?:number;maxReads?:number;readTimeoutMs?:number;maxCandidates?:number}={}) {for(const [k,v]of Object.entries(options))if(!Number.isInteger(v)||v<1||v>(k==='ttlMs'||k==='readTimeoutMs'?3600000:k==='maxCandidates'?8:1024))fail('invalid-input');}
  private get(id:string) { if(this.disposed) fail('disposed');this.prune();const lease=this.leases.get(id);if(!lease)fail('expired');return lease; }
  private prune() { for(const [id,l]of this.leases)if(l.until<=this.host.now() || (l.playback.delivery.expiresAt ?? Infinity)<=this.host.now())this.release(id); }
  private owner(l:Lease,options?:CallOptions){if(options && l.options.credentialRef!==options.credentialRef)fail('authentication');}
  provider(id:string){this.prune();return this.leases.get(id)?.playback.entry.ref.provider;}
  async revoke(credentialRef:string){await Promise.all([...this.leases].filter(([,l])=>l.options.credentialRef===credentialRef).map(([id])=>this.release(id)));}
  async publish(playback:PreparedPlayback,baseUrl:string,options:CallOptions={}):Promise<PreparedPlayback> {
    if(this.disposed)fail('disposed'); this.prune(); if(this.leases.size >= (this.options.maxLeases??64))fail('busy');
    options.signal?.throwIfAborted();
    const revision=options.credentialRef ? (await this.host.credentials?.read(options.credentialRef,options.signal??new AbortController().signal))?.revision : undefined;
    if(options.credentialRef && (!revision || playback.delivery.credentialRevision!==revision))fail('authentication'); options.signal?.throwIfAborted();
    if((playback.delivery.expiresAt??Infinity)<=this.host.now())fail('expired');
    playback = structuredClone(playback);
    const id=opaqueToken();this.leases.set(id,{playback,until:this.host.now()+(this.options.ttlMs??300000),options:{credentialRef:options.credentialRef},revision,reads:new Set(),done:new Set(),
      ...(playback.delivery.hls?{hls:new HlsDelivery(playback,id)}:{})});
    return structuredClone({...playback,leaseId:id,delivery:{url:new URL(`/v1/media/${id}`,baseUrl).href,requiresHost:false,
      ...(playback.delivery.transport?{transport:playback.delivery.transport}:{}),expiresAt:Math.min(this.host.now()+(this.options.ttlMs??300000),playback.delivery.expiresAt??Infinity)}});
  }
  async touch(id:string,options?:CallOptions) {const l=this.get(id);this.owner(l,options);l.until=this.host.now()+(this.options.ttlMs??300000);}
  async release(id:string,options?:CallOptions) {const l=this.leases.get(id);if(!l)return;this.owner(l,options);this.leases.delete(id);for(const a of l.reads)a.abort();await Promise.all([...l.done]);}
  async read(id:string,request:Request,options?:CallOptions,resource?:string,timeouts?:{connectMs?:number;firstByteMs?:number;idleMs?:number;totalMs?:number}):Promise<Response> {
    if(timeouts)for(const [key,value]of Object.entries(timeouts))if(!['connectMs','firstByteMs','idleMs','totalMs'].includes(key)||typeof value!=='number'||!Number.isInteger(value)||value<1||value>3600000)fail('invalid-input');
    const l=this.get(id);this.owner(l,options);if(this.active >= (this.options.maxReads??8))fail('busy');
    if (!['GET', 'HEAD'].includes(request.method)) fail('invalid-input');
    const range=request.headers.get('range');if(range && !/^bytes=(\d+-\d*|-\d+)$/.test(range))return new Response(null,{status:416});
    const abort=new AbortController();l.reads.add(abort);this.active++;
    let resolveDone!:()=>void;const done=new Promise<void>(resolve=>{resolveDone=resolve;});l.done.add(done);this.pending.add(done);
    const signal=AbortSignal.any([abort.signal,request.signal,...(options?.signal?[options.signal]:[])]);
    // Legacy callers retain their total lifetime. Explicit policies distinguish
    // upstream inactivity from downstream backpressure; total lifetime is optional.
    let waiting:ReturnType<typeof setTimeout>|undefined,total:ReturnType<typeof setTimeout>|undefined;
    const timeout=()=>abort.abort(new DOMException('Media read timed out','TimeoutError'));
    const clearWaiting=()=>{clearTimeout(waiting);waiting=undefined;};
    const wait=(ms:number)=>{clearWaiting();waiting=setTimeout(timeout,ms);};
    const totalMs=timeouts?timeouts.totalMs:this.options.readTimeoutMs??120000;
    if(totalMs)total=setTimeout(timeout,totalMs);
    if(timeouts)wait(timeouts.connectMs??30000);
    const diagnostic={requestId:'media-'+ ++this.sequence,timestamp:this.host.now()};
    const report=(code:'complete'|'failure'|'cancelled',errorCode?:'protocol'|'network'|'timeout'|'cancelled')=>emitDiagnostic(this.host,{...diagnostic,timestamp:this.host.now(),elapsedMs:this.host.now()-diagnostic.timestamp,operation:'media',provider:l.playback.entry.ref.provider,code,errorCode});
    let streamController:ReadableStreamDefaultController<Uint8Array>|undefined,consumerCancelled=false;
    const abortError=()=>new MusicSourceError({code:signal.reason?.name==='TimeoutError'?'timeout':'cancelled',retryable:signal.reason?.name==='TimeoutError'});
    let complete=false,finishing=false;let cancelling:Promise<void>|undefined; let reader:ReadableStreamDefaultReader<Uint8Array>|undefined;
    const finish=()=>{if(complete||finishing)return;finishing=true;clearWaiting();clearTimeout(total);const finalized=()=>{complete=true;signal.removeEventListener('abort',onAbort);l.reads.delete(abort);l.done.delete(done);this.pending.delete(done);this.active--;resolveDone();};if(cancelling)void cancelling.then(finalized);else finalized();};
    const onAbort=()=>{if(reader){if(!consumerCancelled){try{streamController?.error(abortError());}catch{}report(signal.reason?.name==='TimeoutError'?'failure':'cancelled',signal.reason?.name==='TimeoutError'?'timeout':'cancelled');}cancelling??=reader.cancel().catch(()=>{});void cancelling.then(finish);}};signal.addEventListener('abort',onAbort,{once:true});
    try {
      if(l.options.credentialRef) {const current=await this.host.credentials?.read(l.options.credentialRef,signal);if(!current || current.revision!==l.revision){void this.release(id);fail('authentication');}}
      signal.throwIfAborted();
      if(l.hls&&!resource){const manifest=l.hls.master();report('complete');finish();return new Response(request.method==='HEAD'?null:manifest,{headers:{'Content-Type':'application/vnd.apple.mpegurl','Cache-Control':'private, no-store'}});}
      const child=resource?l.hls?.get(resource):undefined;if(resource&&!child)fail('not-found');
      if(child?.playlist&&range){finish();return new Response(null,{status:416});}
      const target=child?{...l.playback,delivery:{...l.playback.delivery,url:child.url,alternatives:undefined}}:l.playback;
      const {response,status}=await readDelivery(this.host,target,request,signal,this.options.maxCandidates??3,diagnostic);
      clearWaiting();
      if(child?.playlist&&request.method!=='HEAD'){
        const text=l.hls!.rewrite(await readPlaylist(response,signal,timeouts?()=>wait(timeouts.idleMs??120000):undefined,timeouts?()=>wait(timeouts.firstByteMs??30000):undefined),response.url||child.url);signal.throwIfAborted();report('complete');finish();
        return new Response(text,{headers:{'Content-Type':'application/vnd.apple.mpegurl','Cache-Control':'private, no-store'}});
      }
      const headers=new Headers({'Content-Type':child?(child.playlist?'application/vnd.apple.mpegurl':response.headers.get('content-type')||'application/octet-stream'):l.playback.format.mimeType,'Cache-Control':'private, no-store','Accept-Ranges':'bytes'});
      for(const key of ['content-length','content-range']) {const v=response.headers.get(key);if(v&&!child?.playlist)headers.set(key,v);}
      if(request.method==='HEAD' || response.status===416 || !response.body) {await response.body?.cancel();report('complete');finish();return new Response(null,{status,headers});}
      reader=response.body.getReader();
      let received=0,first=true;const length=response.headers.get('content-length');const expected=length && /^\d+$/.test(length) ? Number(length) : undefined;
      const stream=new ReadableStream<Uint8Array>({
        start(controller){streamController=controller;if(signal.aborted)onAbort();},
        async pull(controller) {try{if(timeouts&&!waiting)wait(first?timeouts.firstByteMs??30000:timeouts.idleMs??120000);const result=await reader!.read();if(signal.aborted){finish();return;}if(result.done){if(expected!==undefined && received!==expected)throw new MusicSourceError({code:'protocol',retryable:false});controller.close();report('complete');finish();}else{if(result.value.length){first=false;clearWaiting();}received+=result.value.length;if(expected!==undefined&&received>expected)throw new MusicSourceError({code:'protocol',retryable:false});controller.enqueue(result.value);}}catch(e){if(!signal.aborted){const failure=e instanceof MusicSourceError?e:new MusicSourceError({code:'network',retryable:true});controller.error(failure);report('failure',failure.code==='protocol'?'protocol':'network');cancelling??=reader!.cancel().catch(()=>{});}finish();}},
        async cancel(){consumerCancelled=true;report('cancelled','cancelled');abort.abort();await(cancelling??=reader!.cancel().catch(()=>{}));finish();}
      });
      return new Response(stream,{status,headers});
    }catch(e){const error=e instanceof MusicSourceError?e:signal.aborted?abortError():e;if(signal.aborted)report(signal.reason?.name==='TimeoutError'?'failure':'cancelled',signal.reason?.name==='TimeoutError'?'timeout':'cancelled');abort.abort();finish();throw error;}
  }
  diagnostics(){this.prune();return{leases:this.leases.size,activeReads:this.active,disposed:this.disposed};}
  async dispose(){this.disposed=true;await Promise.all([...this.leases.keys()].map(id=>this.release(id)));await Promise.all([...this.pending]);}
}
