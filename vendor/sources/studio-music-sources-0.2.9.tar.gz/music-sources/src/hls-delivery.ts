import { fail, type PreparedPlayback } from './contracts.js';
import { opaqueToken } from './node.js';

export interface HlsResource { url: string; playlist: boolean }
/** A narrow VOD delivery map. Upstream addresses never become client-controlled proxy inputs. */
export class HlsDelivery {
  private resources = new Map<string, HlsResource>();
  private ids = new Map<string, string>();
  constructor(private playback: PreparedPlayback, private lease: string) {}
  get(id: string) { const resource = this.resources.get(id); if (!resource) fail('not-found'); return resource; }
  private reference(value: string, base: string, playlist: boolean): string {
    let url: URL; try { url = new URL(value, base); } catch { return fail('protocol'); }
    if (url.protocol !== 'https:' || url.username || url.password || url.port || !url.hostname.endsWith('.googlevideo.com')) fail('restricted', 'youtube');
    const key = JSON.stringify([url.href, playlist]); let id = this.ids.get(key);
    if (!id) {
      if (this.resources.size >= 8192) fail('busy');
      id = opaqueToken(); this.ids.set(key, id); this.resources.set(id, { url: url.href, playlist });
    }
    return `/v1/media/${this.lease}/${id}`;
  }
  master() {
    const source = this.playback.delivery.hls; if (!source) fail('protocol');
    if (this.playback.entry.ref.provider !== 'youtube') fail('unsupported');
    const video = this.reference(source.video, source.video, true), audio = this.reference(source.audio, source.audio, true);
    const bandwidth = Math.max(1, Math.ceil(this.playback.format.bitrate || 1000000));
    // Both real playlists are selected by the source adapter. Codec declarations are
    // omitted when the upstream did not provide them; hls.js inspects the media itself.
    return `#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="Original",DEFAULT=YES,AUTOSELECT=YES,URI="${audio}"\n#EXT-X-STREAM-INF:BANDWIDTH=${bandwidth},AUDIO="audio"\n${video}\n`;
  }
  rewrite(text: string, base: string) {
    if (!text.trimStart().startsWith('#EXTM3U') || text.includes('\u0000') || /#EXT-X-(?:DEFINE|CONTENT-STEERING):/.test(text)) fail('unsupported');
    if (text.includes('#EXTINF:') && !text.includes('#EXT-X-ENDLIST')) fail('unsupported');
    let variant = false;
    return text.split(/\r?\n/).map(line => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (!trimmed.startsWith('#')) { const url = this.reference(trimmed, base, variant); variant = false; return url; }
      if (trimmed.startsWith('#EXT-X-STREAM-INF:')) variant = true;
      if (!/\bURI=/.test(line)) return line;
      const playlist = /^#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF):/.test(trimmed);
      if (!/^#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF|KEY|SESSION-KEY|MAP):/.test(trimmed)) fail('unsupported');
      let replaced = false;
      const result = line.replace(/\bURI="([^"\r\n]+)"/g, (_all, value: string) => { replaced = true; return `URI="${this.reference(value, base, playlist)}"`; });
      if (!replaced) fail('protocol');
      return result;
    }).join('\n');
  }
}
export async function readPlaylist(response: Response, signal: AbortSignal,progress?:()=>void,start?:()=>void): Promise<string> {
  if (!response.body) fail('protocol');
  const reader = response.body.getReader(); const chunks: Uint8Array[] = []; let size = 0;
  let cancelling: Promise<void> | undefined;
  const cancel = () => cancelling ??= reader.cancel().catch(() => {});
  const onAbort = () => { void cancel(); };
  signal.addEventListener('abort', onAbort, { once: true });
  try {
    start?.();
    while (true) {
      signal.throwIfAborted(); const { done, value } = await reader.read(); if (done) break;
      size += value.length; if (size > 4 * 1024 * 1024) fail('upstream'); if(value.length)progress?.();chunks.push(value);
    }
    signal.throwIfAborted();
    return Buffer.concat(chunks).toString('utf8');
  } finally { signal.removeEventListener('abort', onAbort); await cancel(); }
}
