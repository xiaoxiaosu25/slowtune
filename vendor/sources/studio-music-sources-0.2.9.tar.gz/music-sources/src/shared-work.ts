/** Share in-flight work, while each caller owns its cancellation and result. */
export class SharedWork {
  private jobs = new Map<string, { abort: AbortController; task: Promise<unknown>; callers: number }>();
  private pending = new Set<Promise<unknown>>();
  run<T>(key: string, signal: AbortSignal, start: (signal: AbortSignal) => Promise<T>): Promise<T> {
    signal.throwIfAborted();
    let job = this.jobs.get(key);
    if (!job || job.abort.signal.aborted) {
      const abort = new AbortController();
      const task = Promise.resolve().then(() => { abort.signal.throwIfAborted(); return start(abort.signal); });
      job = { abort, task, callers: 0 }; this.jobs.set(key, job); this.pending.add(task);
      const current = job;
      const finish = () => { this.pending.delete(task); if (this.jobs.get(key) === current) this.jobs.delete(key); };
      task.then(finish, finish);
    }
    const current = job; current.callers++;
    return new Promise<T>((resolve, reject) => {
      let settled = false;
      const leave = () => { settled = true; current.callers--; signal.removeEventListener('abort', cancel); };
      const cancel = () => {
        if (settled) return;
        leave();
        if (current.callers) reject(signal.reason);
        else {
          current.abort.abort(signal.reason);
          // The final caller waits for physical cleanup of the work it owned.
          current.task.then(() => reject(signal.reason), () => reject(signal.reason));
        }
      };
      signal.addEventListener('abort', cancel, { once: true });
      current.task.then(value => {
        if (settled) return; leave();
        try { resolve(structuredClone(value) as T); } catch (error) { reject(error); }
      }, error => { if (!settled) { leave(); reject(error); } });
      if (signal.aborted) cancel();
    });
  }
  async dispose(): Promise<void> {
    for (const job of this.jobs.values()) job.abort.abort();
    await Promise.allSettled([...this.pending]); this.jobs.clear();
  }
  cancelWhere(match: (key: string) => boolean): void { for (const [key, job] of this.jobs) if (match(key)) job.abort.abort(); }
}
