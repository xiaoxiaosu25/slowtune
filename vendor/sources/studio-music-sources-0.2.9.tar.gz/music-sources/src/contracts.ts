export type ProviderId = 'bilibili' | 'youtube';
export const MUSIC_PROTOCOL=2;
export interface EntryRef { provider: ProviderId; kind: 'video' | 'playlist'; id: string; part?: string }
export interface MusicEntry {
  ref: EntryRef; resourceId: string; title: string; url: string;
  artwork?: string; durationSeconds?: number;
  uploader?: { id?: string; name: string }; artists?: string[];
  /** Only tags actually returned by the platform; missing is different from an empty tag list. */
  tags?: string[];
  categories?: string[];
  board?: string;
  publishedAt?: number;
  parts?: MusicEntry[];
}
export interface Page<T> { items: T[]; nextCursor?: string }
export interface Shelf { id: string; title: string; kind: 'recommendation' | 'chart' | 'new'; page?: Page<MusicEntry>; error?: ErrorData }
export interface Capabilities { provider: ProviderId; operations: readonly string[]; anonymous: boolean; limitations: readonly string[] }
export interface CallOptions { signal?: AbortSignal; credentialRef?: string }
export interface SearchRequest { query: string; cursor?: string; limit?: number; mode?: 'music' | 'video' }
export interface ListRequest { ref: EntryRef; cursor?: string; limit?: number }
export interface LibraryRequest { cursor?: string; limit?: number }
export interface ShelfRequest { id: string; cursor?: string; limit?: number }
export interface Account { provider: ProviderId; id: string; name: string; artwork?: string }
export interface LoginChallenge { id: string; method: 'qr'; url: string; expiresAt: number; intervalMs: number }
export interface LoginStatus { state: 'pending' | 'scanned' | 'expired' | 'authenticated'; account?: Account }
export interface AudioFormat { id: string; mimeType: string; codec: string; container: string; bitrate?: number; byteLength?: number; sampleRate?: number; channels?: number; width?: number; height?: number; audioCodec?: string; hasAudio?: boolean }
export interface PreparedPlayback {
  resourceId: string; entry: MusicEntry; format: AudioFormat;
  delivery: { url: string; headers?: Record<string, string>; expiresAt?: number; alternatives?: string[]; requiresHost: boolean; credentialRevision?:string;
    transport?: 'range' | 'hls'; hls?: { video: string; audio: string } };
  /** A host-owned temporary handle, never a resource identity. */
  leaseId?: string;
}
export type AudioQuality = 'highest' | 'lowest' | 'lossless';
export interface PrepareRequest { ref: EntryRef; codecs?: string[]; formatId?: string; quality?: AudioQuality; media?: 'audio' | 'video' }
export type ErrorCode = 'invalid-input' | 'not-found' | 'authentication' | 'restricted' | 'rate-limited' | 'network' | 'upstream' | 'unsupported' | 'cancelled' | 'timeout' | 'disposed' | 'busy' | 'stale-cursor' | 'expired' | 'protocol';
export interface ErrorData { code: ErrorCode; provider?: ProviderId; retryable: boolean; upstreamCode?: string; retryAfterMs?: number }
export class MusicSourceError extends Error {
  readonly code: ErrorCode; readonly provider?: ProviderId; readonly retryable: boolean; readonly upstreamCode?: string; readonly retryAfterMs?: number;
  constructor(data: ErrorData) { super(`Music source: ${data.code}`); this.name = data.code === 'cancelled' ? 'AbortError' : 'MusicSourceError'; Object.assign(this, data); this.code = data.code; this.retryable = data.retryable; }
  toJSON(): ErrorData { return { code: this.code, provider: this.provider, retryable: this.retryable, upstreamCode: this.upstreamCode, ...(this.retryAfterMs !== undefined ? { retryAfterMs: this.retryAfterMs } : {}) }; }
}
export function fail(code: ErrorCode, provider?: ProviderId, upstreamCode?: string): never { throw new MusicSourceError({ code, provider, upstreamCode, retryable: ['network','rate-limited','timeout','busy'].includes(code) }); }
export interface MusicApi {
  capabilities(provider: ProviderId): Capabilities;
  metadata(ref: EntryRef, options?: CallOptions): Promise<MusicEntry>;
  discover(provider: ProviderId, options?: CallOptions): Promise<Shelf[]>;
  search(provider: ProviderId, request: SearchRequest, options?: CallOptions): Promise<Page<MusicEntry>>;
  list(request: ListRequest, options?: CallOptions): Promise<Page<MusicEntry>>;
  prepare(request: PrepareRequest, options?: CallOptions): Promise<PreparedPlayback>;
  /** Format facts only: no delivery URLs, headers, credentials or leases. */
  formats?(ref: EntryRef, options?: CallOptions): Promise<AudioFormat[]>;
  account?(provider: ProviderId, options?: CallOptions): Promise<Account>;
  library?(provider: ProviderId, request: LibraryRequest, options?: CallOptions): Promise<Page<MusicEntry>>;
  shelf?(provider: ProviderId, request: ShelfRequest, options?: CallOptions): Promise<Page<MusicEntry>>;
  beginLogin?(provider: ProviderId, options?: CallOptions): Promise<LoginChallenge>;
  pollLogin?(provider: ProviderId, id: string, options?: CallOptions): Promise<LoginStatus>;
  cancelLogin?(provider: ProviderId, id: string, options?: CallOptions): Promise<void>;
  disconnect?(provider: ProviderId, options?: CallOptions): Promise<void>;
  release?(leaseId: string): Promise<void>;
  touch?(leaseId: string): Promise<void>;
}
export interface Credential { revision: string; provider?: ProviderId; cookie?: string }
export interface MusicHost {
  fetch: typeof fetch;
  now: () => number;
  /** Optional synchronous observer. Observer errors never change an operation. */
  onDiagnostic?: (event: SourceDiagnostic) => void;
  /** Host explicitly supplies MD5 for Bilibili's WBI protocol. */
  md5?: (text: string) => string | Promise<string>;
  credentials?: {
    read(ref: string, signal: AbortSignal): Promise<Credential>;
    write?(ref: string, credential: Credential, signal: AbortSignal): Promise<void>;
    remove?(ref: string, signal: AbortSignal): Promise<void>;
  };
  /** Optional host cache; only neutral metadata is eligible. Playback URLs are never stored here. */
  cache?: { get(key: string): Promise<MusicEntry | undefined>; set(key: string, entry: MusicEntry, ttlMs: number): Promise<void> };
}
export interface ProviderContext { host: MusicHost; signal: AbortSignal; credential?: Credential; credentialRef?: string; scope: string }
export interface MusicProvider {
  capabilities: Capabilities;
  metadata(ref: EntryRef, context: ProviderContext): Promise<MusicEntry>;
  discover(context: ProviderContext): Promise<Shelf[]>;
  search(request: SearchRequest, context: ProviderContext): Promise<Page<MusicEntry>>;
  list(request: ListRequest, context: ProviderContext): Promise<Page<MusicEntry>>;
  prepare(request: PrepareRequest, context: ProviderContext): Promise<PreparedPlayback>;
  formats?(ref: EntryRef, context: ProviderContext): Promise<AudioFormat[]>;
  account?(context: ProviderContext): Promise<Account>;
  library?(request: LibraryRequest, context: ProviderContext): Promise<Page<MusicEntry>>;
  shelf?(request: ShelfRequest, context: ProviderContext): Promise<Page<MusicEntry>>;
  beginLogin?(context: ProviderContext): Promise<LoginChallenge>;
  pollLogin?(id: string, context: ProviderContext): Promise<LoginStatus>;
  cancelLogin?(id: string, context: ProviderContext): Promise<void> | void;
  forgetCredentials?(ref: string): void;
  dispose?(): Promise<void>;
}
/** Deliberately excludes media URLs, credentials, resource identity and error text. */
export interface SourceDiagnostic {
  requestId: string; provider?: ProviderId; operation: 'metadata' | 'prepare' | 'formats' | 'media';
  code: 'start' | 'headers' | 'complete' | 'failure' | 'fallback' | 'cancelled';
  timestamp: number; elapsedMs?: number; attempt?: number; upstreamHost?: string;
  status?: number; range?: string; errorCode?: ErrorCode;
}
export function resourceId(ref: EntryRef): string {
  validateRef(ref);
  return `${ref.provider}:${ref.kind}:${encodeURIComponent(ref.id)}${ref.part ? ':' + encodeURIComponent(ref.part) : ''}`;
}
export function validateRef(ref: EntryRef): void {
  if (!ref || !['bilibili','youtube'].includes(ref.provider) || !['video','playlist'].includes(ref.kind) || typeof ref.id !== 'string' || !ref.id || ref.id.length > 200 || (ref.part !== undefined && (typeof ref.part !== 'string' || !/^\d+$/.test(ref.part)))) fail('invalid-input');
  if (ref.kind === 'video' && !(ref.provider === 'bilibili' ? /^BV[a-zA-Z0-9]{10}$/.test(ref.id) : /^[a-zA-Z0-9_-]{11}$/.test(ref.id))) fail('invalid-input');
}
export function identify(input: string): EntryRef {
  if (typeof input !== 'string' || input.length > 4096) fail('invalid-input');
  input = input.trim();
  if (/^BV[a-zA-Z0-9]{10}$/.test(input)) return { provider: 'bilibili', kind: 'video', id: input };
  let url: URL; try { url = new URL(input); } catch { return fail('invalid-input'); }
  const domain = url.hostname;
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port) fail('invalid-input');
  if (domain === 'space.bilibili.com') {
    const owner = url.pathname.match(/^\/(\d+)\/(?:favlist|lists|channel\/(?:collectiondetail|seriesdetail))(?:\/|$)/)?.[1];
    const favorite = url.searchParams.get('fid'), season = url.searchParams.get('sid');
    if (owner && favorite && /^[1-9]\d*$/.test(favorite)) return { provider: 'bilibili', kind: 'playlist', id: `fav:${favorite}` };
    if (owner && season && /^[1-9]\d*$/.test(season) && url.pathname.includes('collectiondetail')) return { provider: 'bilibili', kind: 'playlist', id: `season:${owner}:${season}` };
  }
  if (domain === 'www.bilibili.com' || domain === 'bilibili.com') {
    const id = url.pathname.match(/^\/video\/(BV[a-zA-Z0-9]{10})(?:\/|$)/)?.[1];
    // p is an ordinal, not cid; select the part from metadata before preparation.
    if (id) return { provider: 'bilibili', kind: 'video', id };
  }
  if (['www.youtube.com','youtube.com','music.youtube.com','youtu.be'].includes(domain)) {
    const id = domain === 'youtu.be' ? url.pathname.slice(1) : url.searchParams.get('v');
    if (id && /^[a-zA-Z0-9_-]{11}$/.test(id)) return { provider: 'youtube', kind: 'video', id };
    const list = url.searchParams.get('list'); if (list) return { provider: 'youtube', kind: 'playlist', id: list };
  }
  return fail('invalid-input');
}
