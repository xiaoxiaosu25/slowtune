import { createHash, randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { fail, MusicSourceError, resourceId, validateRef, type MusicHost, type ProviderContext, type PreparedPlayback, type PrepareRequest, type MusicEntry, type EntryRef, type AudioFormat } from './contracts.js';
import { obj, array, str, number, imageUrl, selectFormat, expires } from './util.js';
import {toolCookie} from './tool-cookie.js';
export function createNodeHost(options: Pick<MusicHost,'fetch'> & Partial<Omit<MusicHost,'fetch'>>): MusicHost {
  return { now: Date.now, md5: v => createHash('md5').update(v).digest('hex'), ...options };
}
/** No shell, config files, browser cookies, implicit downloads, or inherited proxy variables. */
export interface ToolOptions { executable: string; prefixArgs?: string[]; nodeRuntime?: string; proxy?: string; env?: Record<string,string>; timeoutMs?: number; maxOutputBytes?: number; cookieDirectory?: string; reuseMs?:number }
interface ToolFormat {format:AudioFormat;url:string;headers?:Record<string,string>;hls?:{video:string;audio:string}}
export class YtDlpResolver {
  private active = new Set<Promise<unknown>>(); private stop = new AbortController();
  private recent=new Map<string,{until:number;cookie?:string;rows:ToolFormat[]}>();
  constructor(private options: ToolOptions) {if(options.reuseMs!==undefined&&(!Number.isInteger(options.reuseMs)||options.reuseMs<0||options.reuseMs>10000))fail('invalid-input');}
  private run(url: string, signal: AbortSignal, cookiePath?:string): Promise<any> {
    if (this.stop.signal.aborted) fail('disposed');
    const combined = AbortSignal.any([signal,this.stop.signal,AbortSignal.timeout(this.options.timeoutMs ?? 45000)]);
    combined.throwIfAborted();
    const args = [...(this.options.prefixArgs ?? []),'--ignore-config','--no-cache-dir','--no-playlist','--skip-download','--dump-single-json','--no-warnings','--socket-timeout','15','--retries','0',
      ...(this.options.nodeRuntime ? ['--js-runtimes',`node:${this.options.nodeRuntime}`] : []), ...(this.options.proxy ? ['--proxy',this.options.proxy] : ['--proxy','']), ...(cookiePath?['--cookies',cookiePath]:[]), url];
    const work = new Promise<any>((resolve,reject) => {
      const env = { SystemRoot: process.env.SystemRoot ?? '', PATH: '', ...this.options.env };
      const child = spawn(this.options.executable,args,{ shell:false,windowsHide:true,env,detached:process.platform!=='win32',stdio:['ignore','pipe','pipe'] });
      let bytes = 0; const stdout: Buffer[] = []; const stderr: Buffer[] = []; let stderrSize = 0; let aborted = false; let oversized = false;
      let termination:Promise<void>|undefined;
      const terminate=()=>{if(termination)return;if(process.platform==='win32' && child.pid){termination=new Promise<void>(resolve=>{const killer=spawn(`${env.SystemRoot}\\System32\\taskkill.exe`,['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore'});killer.once('close',()=>{child.kill();resolve();});killer.once('error',()=>{child.kill();resolve();});});}else{try{if(child.pid)process.kill(-child.pid,'SIGKILL');}catch{child.kill();}termination=Promise.resolve();}};
      const cancel = () => { aborted = true; terminate(); }; combined.addEventListener('abort',cancel,{once:true});
      child.stdout.on('data',(b: Buffer) => { bytes += b.length; if (bytes > (this.options.maxOutputBytes ?? 4 * 1024 * 1024)) { oversized = true; terminate(); } else stdout.push(b); });
      child.stderr.on('data',(b: Buffer) => { stderrSize += b.length; if (stderrSize <= 65536) stderr.push(b); else { oversized = true; terminate(); } });
      child.once('error',() => { combined.removeEventListener('abort',cancel); reject(new MusicSourceError({code:'unsupported',retryable:false})); });
      child.once('close',async code => {
        await termination;
        combined.removeEventListener('abort',cancel);
        if (aborted) return reject(new MusicSourceError({code:combined.reason?.name === 'TimeoutError' ? 'timeout' : 'cancelled',retryable:false}));
        if (oversized) return reject(new MusicSourceError({code:'upstream',retryable:false}));
        if (code !== 0) {
          const error = Buffer.concat(stderr).toString();
          const category = /Sign in|login|cookies/i.test(error) ? 'authentication' : /403|blocked|not available|country/i.test(error) ? 'restricted' : /429|rate limit/i.test(error) ? 'rate-limited' : /not found|removed|unavailable/i.test(error) ? 'not-found' : /timed out|connection|network/i.test(error) ? 'network' : 'upstream';
          return reject(new MusicSourceError({code:category,retryable:['network','rate-limited'].includes(category)}));
        }
        try { resolve(JSON.parse(Buffer.concat(stdout).toString())); } catch { reject(new MusicSourceError({code:'upstream',retryable:false})); }
      });
      if (combined.aborted) cancel();
    });
    return work;
  }
  resolve(request: PrepareRequest, entry: MusicEntry, c: ProviderContext): Promise<PreparedPlayback> {
    validateRef(request?.ref);request=structuredClone(request);
    return this.owned(request.ref, entry, c, async context => {
      const formats = await this.readFormats(request.ref, context, request.media);
      const selected = selectFormat(formats,request.codecs,request.formatId,request.quality);
      context.signal.throwIfAborted();
      const expiration = 'hls' in selected && selected.hls ? Math.min(expires(selected.hls.video) ?? Infinity, expires(selected.hls.audio) ?? Infinity) : expires(selected.url);
      return {resourceId:resourceId(request.ref),entry,format:selected.format,delivery:{url:selected.url,headers:selected.headers,expiresAt:expiration === Infinity ? undefined : expiration,requiresHost:true,
        ...('hls' in selected && selected.hls ? { transport: 'hls' as const, hls: selected.hls } : {})}};
    });
  }
  formats(ref: EntryRef, entry: MusicEntry, c: ProviderContext) {
    return this.owned(ref, entry, c, async context => (await this.readFormats(ref, context)).map(value => ({ ...value.format })));
  }
  private owned<T>(ref: EntryRef, entry: MusicEntry, c: ProviderContext, run: (context: ProviderContext) => Promise<T>): Promise<T> {
    validateRef(ref);if(ref.provider!=='youtube'||ref.kind!=='video'||resourceId(ref)!==resourceId(entry.ref))fail('invalid-input','youtube');
    if(this.stop.signal.aborted)fail('disposed','youtube');if(this.active.size>=2)fail('busy','youtube');
    const signal=AbortSignal.any([c.signal,this.stop.signal,AbortSignal.timeout(this.options.timeoutMs??45000)]);
    signal.throwIfAborted();
    const work=run({...c,signal});this.active.add(work);work.then(()=>this.active.delete(work),()=>this.active.delete(work));return work;
  }
  private async readFormats(ref:EntryRef,c:ProviderContext,media:'audio'|'video'='audio'):Promise<ToolFormat[]>{
    const key=JSON.stringify([ref,c.scope,c.credentialRef,c.credential?.revision,c.credential?.provider,media]);
    const cached=this.recent.get(key);c.signal.throwIfAborted();
    if(cached&&cached.until>c.host.now()&&cached.cookie===c.credential?.cookie)return structuredClone(cached.rows);
    this.recent.delete(key);
    const cookies=c.credential?.cookie?await toolCookie(c.credential.cookie,this.options.cookieDirectory,c.signal):undefined;
    try {
    const r = obj(await this.run(`https://www.youtube.com/watch?v=${ref.id}`,c.signal,cookies?.path));
    if (r.is_live || r.live_status === 'is_live') fail('unsupported', 'youtube');
    const formats = array(r.formats).filter(f => !f.has_drm && (media === 'video' ? f.vcodec && f.vcodec !== 'none' : f.vcodec === 'none') && f.acodec && f.acodec !== 'none' && typeof f.url === 'string' && /^https?:$/.test(new URL(f.url).protocol) && ['https','http'].includes(f.protocol)).map(f => {
      const container = str(f.ext); const mimeType = `${media}/${container === 'm4a' ? 'mp4' : container === 'mp3' ? 'mpeg' : container}`;
      return { format: { id:str(f.format_id),codec:str(media === 'video' ? f.vcodec : f.acodec),container:container === 'm4a' ? 'mp4' : container,mimeType,bitrate:(media === 'video' ? f.tbr : f.abr) ? number(media === 'video' ? f.tbr : f.abr) * 1000 : undefined,byteLength:f.filesize,sampleRate:f.asr,channels:f.audio_channels,
        ...(media === 'video' ? { audioCodec: str(f.acodec), width: f.width, height: f.height } : {}) }, url:str(f.url),headers:obj(f.http_headers ?? r.http_headers ?? {}) as Record<string,string> };
    });
    c.signal.throwIfAborted();
    if (media === 'video') {
      const raw = array(r.formats);
      // The extractor identifies actual audio renditions. Pair their VOD playlists with
      // video playlists; never pass a video-only format off as a complete video.
      const audio = raw.filter(f => f.protocol === 'm3u8_native' && f.vcodec === 'none' && f.audio_ext && f.audio_ext !== 'none' && !f.has_drm && f.url)
        .sort((a, b) => (Number.isFinite(b.source_preference) ? b.source_preference : 0) - (Number.isFinite(a.source_preference) ? a.source_preference : 0))[0];
      const hls = audio ? raw.filter(f => f.protocol === 'm3u8_native' && f.vcodec && f.vcodec !== 'none' && !f.has_drm && f.url).map(f => ({
        format: { id: `hls-${str(f.format_id)}`, codec: str(f.vcodec), container: 'hls', mimeType: 'application/vnd.apple.mpegurl', hasAudio: true,
          bitrate: f.tbr ? number(f.tbr) * 1000 : undefined, width: f.width, height: f.height },
        url: str(f.url), headers: obj(f.http_headers ?? r.http_headers ?? {}) as Record<string, string>, hls: { video: str(f.url), audio: str(audio.url) },
      })) : [];
      return this.retain(key,c,[...formats,...hls]);
    }
    return this.retain(key,c,formats);
    }finally{await cookies?.cleanup();}
  }
  private retain<T extends ToolFormat[]>(key:string,c:ProviderContext,rows:T):T{
    c.signal.throwIfAborted();
    if(this.options.reuseMs&&!this.stop.signal.aborted){
      const now=c.host.now(),expiration=Math.min(...rows.flatMap(row=>[row.url,...(row.hls?[row.hls.video,row.hls.audio]:[])]).map(url=>expires(url)??-Infinity));
      const until=Math.min(now+this.options.reuseMs,expiration-1000);
      for(const [id,value]of this.recent)if(value.until<=now)this.recent.delete(id);
      if(rows.length&&until>now){while(this.recent.size>=8)this.recent.delete(this.recent.keys().next().value!);this.recent.set(key,{until,cookie:c.credential?.cookie,rows:structuredClone(rows)});}
    }
    return rows;
  }
  diagnostics() { return { active: this.active.size, disposed: this.stop.signal.aborted }; }
  async dispose() { this.stop.abort();this.recent.clear(); await Promise.allSettled([...this.active]); }
}

export function opaqueToken() { return randomBytes(24).toString('base64url'); }
