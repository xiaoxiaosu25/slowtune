import { fail, MusicSourceError, validateRef, resourceId, type MusicApi, type MusicHost, type MusicProvider, type ProviderId, type CallOptions, type ProviderContext, type EntryRef, type SearchRequest, type ListRequest, type LibraryRequest, type ShelfRequest, type PrepareRequest } from './contracts.js';
import { limit, normalizeError, emitDiagnostic, formatFacts } from './util.js';
import { SharedWork } from './shared-work.js';
export class MusicSources implements MusicApi {
  private shutdown = new AbortController();
  private pending = new Set<Promise<unknown>>();
  private counts = new Map<ProviderId, number>();
  private shared = new SharedWork();
  private diagnosticSequence = 0;
  constructor(private host: MusicHost, private providers: Partial<Record<ProviderId, MusicProvider>>, private timeoutMs = 30_000) {
    if (!host.fetch || !host.now || !Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) fail('invalid-input');
  }
  capabilities(provider: ProviderId) { return this.provider(provider).capabilities; }
  private provider(id: ProviderId) { if (this.shutdown.signal.aborted) fail('disposed');if(!['bilibili','youtube'].includes(id))fail('invalid-input'); const p = Object.hasOwn(this.providers,id)?this.providers[id]:undefined; if (!p) fail('unsupported', id); return p; }
  private async call<T>(id: ProviderId, options: CallOptions = {}, run: (provider: MusicProvider, context: ProviderContext) => Promise<T>, readCredential = true): Promise<T> {
    const provider = this.provider(id); if ((this.counts.get(id) ?? 0) >= 4) fail('busy', id);
    const signal = AbortSignal.any([this.shutdown.signal, AbortSignal.timeout(this.timeoutMs), ...(options.signal ? [options.signal] : [])]);
    if (signal.aborted) fail('cancelled', id);
    if(options.credentialRef !== undefined && (typeof options.credentialRef !== 'string' || !options.credentialRef || options.credentialRef.length>200))fail('invalid-input',id);
    this.counts.set(id, (this.counts.get(id) ?? 0) + 1);
    const context: ProviderContext = { host: this.host, signal, credentialRef: options.credentialRef, scope: options.credentialRef ? JSON.stringify([options.credentialRef,'login']) : 'anonymous' };
    const work = (async () => {
      try {
        if (options.credentialRef && readCredential) {
          if (!this.host.credentials) fail('authentication', id);
          context.credential = await this.host.credentials.read(options.credentialRef, signal);
          if(!context.credential||typeof context.credential.revision!=='string'||!context.credential.revision||context.credential.revision.length>200||(context.credential.cookie!==undefined&&(typeof context.credential.cookie!=='string'||context.credential.cookie.length>65536||/[\r\n]/.test(context.credential.cookie))))fail('authentication',id);
          if(context.credential.provider && context.credential.provider!==id)fail('authentication',id);
          context.scope = JSON.stringify([options.credentialRef, context.credential.revision]);
        }
        signal.throwIfAborted(); const result = await run(provider, context); signal.throwIfAborted(); return result;
      } catch (e) { const error = normalizeError(e, context); throw new MusicSourceError({ ...error.toJSON(), provider: id }); }
    })();
    this.pending.add(work);
    try { return await work; } finally { this.pending.delete(work); this.counts.set(id, (this.counts.get(id) ?? 1) - 1); }
  }
  metadata(ref: EntryRef, options?: CallOptions) {
    validateRef(ref); ref = { ...ref }; return this.call(ref.provider, options, async (p,c) => {
      const key = `music-metadata:v2:${c.scope}:${resourceId(ref)}`;
      return this.shared.run(key, c.signal, signal => this.observe('metadata', ref.provider, async () => {
        const cached = await this.host.cache?.get(key); signal.throwIfAborted(); if (cached) return cached;
        const entry = await p.metadata(ref, { ...c, signal }); signal.throwIfAborted();
        await this.host.cache?.set(key, entry, 60_000); return entry;
      }));
    });
  }
  private async observe<T>(operation: 'metadata' | 'prepare' | 'formats', provider: ProviderId, run: () => Promise<T>): Promise<T> {
    const requestId = `source-${++this.diagnosticSequence}`, start = this.host.now();
    emitDiagnostic(this.host, { requestId, operation, provider, code: 'start', timestamp: start });
    try { const result = await run(); emitDiagnostic(this.host, { requestId, operation, provider, code: 'complete', timestamp: this.host.now(), elapsedMs: this.host.now() - start }); return result; }
    catch (error) { const code = error instanceof MusicSourceError ? error.code : undefined; emitDiagnostic(this.host, { requestId, operation, provider, code: code === 'cancelled' ? 'cancelled' : 'failure', timestamp: this.host.now(), elapsedMs: this.host.now() - start, errorCode: code }); throw error; }
  }
  discover(provider: ProviderId, options?: CallOptions) { return this.call(provider, options, (p,c) => p.discover(c)); }
  search(provider: ProviderId, request: SearchRequest, options?: CallOptions) {
    if (!request || typeof request.query !== 'string' || !request.query.trim() || request.query.length > 512 || (request.mode !== undefined && !['music','video'].includes(request.mode))) fail('invalid-input'); limit(request.limit);
    return this.call(provider, options, (p,c) => p.search(request,c));
  }
  list(request: ListRequest, options?: CallOptions) { validateRef(request?.ref); limit(request.limit); return this.call(request.ref.provider,options,(p,c) => p.list(request,c)); }
  prepare(request: PrepareRequest, options?: CallOptions) {
    if (request?.media !== undefined && !['audio', 'video'].includes(request.media)) fail('invalid-input');
    validateRef(request?.ref); if (request.ref.kind !== 'video' || (request.codecs && (!Array.isArray(request.codecs) || request.codecs.length > 20 || request.codecs.some(v => typeof v !== 'string' || !v || v.length > 80))) || (request.formatId !== undefined && (typeof request.formatId !== 'string' || !request.formatId || request.formatId.length > 200)) || (request.quality !== undefined && !['highest', 'lowest', 'lossless'].includes(request.quality))) fail('invalid-input');
    request = structuredClone(request);
    return this.call(request.ref.provider,options,async(p,c) => this.observe('prepare', request.ref.provider, async () => {const result=await p.prepare(request,c);return {...result,delivery:{...result.delivery,...(c.credential?{credentialRevision:c.credential.revision}:{})}};}));
  }
  formats(ref: EntryRef, options?: CallOptions) {
    validateRef(ref); if (ref.kind !== 'video') fail('invalid-input'); ref = { ...ref };
    return this.call(ref.provider, options, (p, c) => this.observe('formats', ref.provider, async () => { if (!p.formats) fail('unsupported', ref.provider); const formats=await p.formats(ref, c);if(!Array.isArray(formats)||formats.length>200)fail('upstream',ref.provider);return formats.map(formatFacts); }));
  }
  account(id: ProviderId, options?: CallOptions) { return this.call(id,options,(p,c)=>{if(!p.account)fail('unsupported',id);return p.account(c);}); }
  library(id: ProviderId, request: LibraryRequest = {}, options?: CallOptions) { limit(request.limit);return this.call(id,options,(p,c)=>{if(!p.library)fail('unsupported',id);return p.library(request,c);}); }
  shelf(id: ProviderId, request: ShelfRequest, options?: CallOptions) { if(!request||typeof request.id!=='string'||!request.id||request.id.length>200)fail('invalid-input');limit(request.limit);return this.call(id,options,(p,c)=>{if(!p.shelf)fail('unsupported',id);return p.shelf(request,c);}); }
  beginLogin(id: ProviderId, options?: CallOptions) { return this.call(id,options,(p,c)=>{if(!p.beginLogin)fail('unsupported',id);return p.beginLogin(c);},false); }
  pollLogin(id: ProviderId, session: string, options?: CallOptions) { if(!/^[\w-]{32}$/.test(session))fail('invalid-input');return this.call(id,options,(p,c)=>{if(!p.pollLogin)fail('unsupported',id);return p.pollLogin(session,c);},false); }
  cancelLogin(id: ProviderId, session: string, options?: CallOptions) { if(!/^[\w-]{32}$/.test(session))fail('invalid-input');return this.call(id,options,async(p,c)=>{if(!p.cancelLogin)fail('unsupported',id);await p.cancelLogin(session,c);},false); }
  disconnect(id: ProviderId, options?: CallOptions) { return this.call(id,options,async(p,c)=>{if(!c.credentialRef||!c.host.credentials?.remove)fail('unsupported',id);let credential;try{credential=await c.host.credentials.read(c.credentialRef,c.signal);}catch(e){if(!(e instanceof MusicSourceError)||e.code!=='authentication')throw e;}c.signal.throwIfAborted();if(credential?.provider&&credential.provider!==id)fail('authentication',id);p.forgetCredentials?.(c.credentialRef);await c.host.credentials.remove(c.credentialRef,c.signal);},false); }
  diagnostics() { return { disposed: this.shutdown.signal.aborted, pending: this.pending.size }; }
  async dispose() { this.shutdown.abort(); await Promise.allSettled([...this.pending]); await this.shared.dispose(); await Promise.all(Object.values(this.providers).map(p => p.dispose?.())); }
}
