import type { DeferredMediaSource, PlaybackPlan, SourceResolverPort } from '@studio/player/contracts';
import { fail, type MusicApi, type EntryRef, type CallOptions, type PreparedPlayback, type PrepareRequest } from './contracts.js';
export interface PlayerBridgeOptions { options?:Omit<CallOptions,'signal'>; codecs?:string[]; formatId?:PrepareRequest['formatId']; quality?:PrepareRequest['quality']; media?:PrepareRequest['media']; publish?:(playback:PreparedPlayback,signal:AbortSignal)=>Promise<PreparedPlayback>; release?:(id:string)=>Promise<void>; touch?:(id:string)=>Promise<void> }
/** Own the bridge alongside one player. Player's existing retry/position logic remains authoritative. */
export class MusicPlayerBridge {
  private refs=new Map<string,{ref:EntryRef;options:Omit<CallOptions,'signal'>}>();private leases=new Set<string>();private ended=false;private shutdown=new AbortController();private bound=false;private credentialRef?:string;
  constructor(private api:MusicApi,private options:PlayerBridgeOptions={}) {if(options.publish && !options.release && !api.release)fail('invalid-input');}
  private async prepare(ref:EntryRef,signal:AbortSignal,options:Omit<CallOptions,'signal'>):Promise<PlaybackPlan> {
    if(this.ended)fail('disposed');
    signal=AbortSignal.any([signal,this.shutdown.signal]);
    let p=await this.api.prepare({ref,codecs:this.options.codecs,formatId:this.options.formatId,quality:this.options.quality,media:this.options.media},{...options,signal});
    if(this.options.publish)p=await this.options.publish(p,signal);
    if(p.leaseId)this.leases.add(p.leaseId);
    if(signal.aborted || this.ended){if(p.leaseId)await this.close(p.leaseId);fail('cancelled');}
    if(p.delivery.requiresHost || Object.keys(p.delivery.headers??{}).length){if(p.leaseId)await this.close(p.leaseId);fail('unsupported');}
    return {resourceId:p.resourceId,mediaType:this.options.media==='video'||p.format.mimeType.startsWith('video/')?'video':'audio',strategy:p.leaseId?'proxy':'direct',transport:p.delivery.transport??'range',playUrl:p.delivery.url,mimeType:p.format.mimeType,expiresAt:p.delivery.expiresAt,durationSeconds:p.entry.durationSeconds,
      ...(p.leaseId?{processing:{available:false,sessionEndpoint:p.leaseId}}:{}),metadata:{title:p.entry.title,artwork:p.entry.artwork,format:p.format}};
  }
  async source(ref:EntryRef,options:CallOptions={}):Promise<DeferredMediaSource> {
    if(this.ended)fail('disposed');const call={...this.options.options,credentialRef:options.credentialRef??this.options.options?.credentialRef??this.credentialRef};
    if(this.bound&&this.credentialRef!==call.credentialRef)fail('invalid-input');this.bound=true;this.credentialRef=call.credentialRef;
    const signal=AbortSignal.any([this.shutdown.signal,...(options.signal?[options.signal]:[])]);const entry=await this.api.metadata(ref,{...call,signal});signal.throwIfAborted();if(this.refs.size>=64)this.refs.delete(this.refs.keys().next().value!);this.refs.set(entry.resourceId,{ref:entry.ref,options:call});
    return {resourceId:entry.resourceId,resolveTimeoutSeconds:30,prepare:({signal})=>this.prepare(entry.ref,signal,call)};
  }
  private async close(id:string){await (this.options.release?.(id)??this.api.release?.(id));this.leases.delete(id);}
  readonly resolver:SourceResolverPort={
    resolveUrl:(id,_plan,_reason,c)=>{const descriptor=this.refs.get(id);if(!descriptor)fail('not-found');return this.prepare(descriptor.ref,c?.signal??new AbortController().signal,descriptor.options);},
    recoverSource:(id,_plan,c)=>{const descriptor=this.refs.get(id);return descriptor?this.prepare(descriptor.ref,c.signal,descriptor.options):null;},
    onSessionHeartbeat:id=>this.options.touch?.(id)??this.api.touch?.(id),
    onSessionClose:id=>this.close(id)
  };
  diagnostics(){return{leases:this.leases.size,resources:this.refs.size,disposed:this.ended};}
  async dispose(){this.ended=true;this.shutdown.abort();await Promise.all([...this.leases].map(id=>this.close(id)));this.refs.clear();}
}
