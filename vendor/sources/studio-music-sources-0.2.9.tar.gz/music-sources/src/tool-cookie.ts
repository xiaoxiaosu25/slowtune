import {mkdtemp,writeFile,unlink,rmdir} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {fail} from './contracts.js';
/** An explicitly supplied YouTube Cookie header becomes a private, short-lived tool input. */
export async function toolCookie(cookie:string,directory:string|undefined,signal:AbortSignal){
  if(!directory||!isAbsolute(directory))fail('unsupported','youtube');
  if(typeof cookie!=='string'||cookie.length>65536||/[\r\n\t]/.test(cookie))fail('invalid-input','youtube');
  const pairs=cookie.split(';').map(x=>x.trim()).filter(Boolean).map(x=>{const split=x.indexOf('=');if(split<1||!/^[!#$%&'*+.^_`|~\w-]+$/.test(x.slice(0,split)))fail('invalid-input','youtube');return[x.slice(0,split),x.slice(split+1)];});
  if(!pairs.length||pairs.length>256)fail('invalid-input','youtube');
  signal.throwIfAborted();const dir=await mkdtemp(join(directory,'music-yt-'));const path=join(dir,'cookies.txt');
  const cleanup=async()=>{await unlink(path).catch((e:NodeJS.ErrnoException)=>{if(e.code!=='ENOENT')throw e;});await rmdir(dir);};
  try{await writeFile(path,'# Netscape HTTP Cookie File\n'+pairs.map(([name,value])=>`.youtube.com\tTRUE\t/\tTRUE\t0\t${name}\t${value}`).join('\n')+'\n',{mode:0o600,flag:'wx'});signal.throwIfAborted();return{path,cleanup};}
  catch(e){await cleanup();throw e;}
}
