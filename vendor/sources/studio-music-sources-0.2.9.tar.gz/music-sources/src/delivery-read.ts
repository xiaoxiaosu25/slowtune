import { fail, MusicSourceError, type PreparedPlayback, type MusicHost, type SourceDiagnostic } from './contracts.js';
import { emitDiagnostic, retryAfter } from './util.js';

export function deliveryStatus(response: Response, range: string | null): number {
  const status = response.status, contentRange = response.headers.get('content-range');
  if (![200, 206, 416].includes(status)) {
    const code = status === 401 ? 'authentication' : [403, 412].includes(status) ? 'restricted' : status === 429 ? 'rate-limited' : [404, 410].includes(status) ? 'not-found' : 'upstream';
    throw new MusicSourceError({ code, retryable: status === 429 || status >= 500, upstreamCode: String(status), ...(status === 429 ? { retryAfterMs: retryAfter(response.headers) } : {}) });
  }
  if (range && [200, 206].includes(status)) {
    const match = contentRange?.match(/^bytes (\d+)-(\d+)\/(\d+)$/); if (!match) fail('protocol');
    const start = Number(match[1]), end = Number(match[2]), total = Number(match[3]);
    const requested = range.slice(6).split('-');
    const expectedStart = requested[0] ? Number(requested[0]) : Math.max(0, total - Number(requested[1]));
    const expectedEnd = requested[0] && requested[1] ? Math.min(Number(requested[1]), total - 1) : total - 1;
    if (![start, end, total, expectedStart, expectedEnd].every(Number.isSafeInteger) || start !== expectedStart || end !== expectedEnd || end < start || end >= total) fail('protocol');
    const length = response.headers.get('content-length');
    if (length !== null && (!/^\d+$/.test(length) || Number(length) !== end - start + 1)) fail('protocol');
    return 206;
  }
  if (status === 206 && (!contentRange || !/^bytes \d+-\d+\/(\d+|\*)$/.test(contentRange))) fail('protocol');
  return status;
}
function allowed(url: URL, provider: string): boolean {
  return url.protocol === 'https:' && !url.username && !url.password && !url.port && (provider === 'youtube' ? url.hostname.endsWith('.googlevideo.com') : ['.bilivideo.com', '.bilivideo.cn', '.bilivideo.net'].some(s => url.hostname.endsWith(s)));
}
/** Only retry before a Response is handed to the consumer. Never splice media bytes. */
export async function readDelivery(host: MusicHost, playback: PreparedPlayback, request: Request, signal: AbortSignal, maxCandidates: number, diagnostic: Pick<SourceDiagnostic, 'requestId' | 'timestamp'>) {
  const range = request.headers.get('range'), primary = new URL(playback.delivery.url);
  const candidates = [...new Set([playback.delivery.url, ...(playback.delivery.alternatives ?? [])])].slice(0, maxCandidates);
  for (let index = 0; index < candidates.length; index++) {
    let url:URL;try{url=new URL(candidates[index]);}catch{return fail('protocol');}
    const report = (code: SourceDiagnostic['code'], extra: Partial<SourceDiagnostic> = {}) => emitDiagnostic(host, { requestId: diagnostic.requestId, timestamp: host.now(), elapsedMs: host.now() - diagnostic.timestamp, operation: 'media', provider: playback.entry.ref.provider, code, attempt: index + 1, upstreamHost: url.hostname, ...(range ? { range } : {}), ...extra });
    if (index && !allowed(url, playback.entry.ref.provider)) fail('restricted');
    const headers: Record<string, string> = { ...playback.delivery.headers, ...(range ? { Range: range } : {}), 'Accept-Encoding': 'identity' };
    const removeCredentials = () => { for (const key of Object.keys(headers)) if (['cookie', 'authorization'].includes(key.toLowerCase())) delete headers[key]; };
    if (url.hostname !== primary.hostname) removeCredentials();
    report(index ? 'fallback' : 'start');
    let response: Response | undefined;
    try {
      for (let redirects = 0; ; redirects++) {
        signal.throwIfAborted();
        response = await host.fetch(url.href, { method: request.method, headers, signal, redirect: 'manual' });
        if (signal.aborted) { await response.body?.cancel(); signal.throwIfAborted(); }
        if (![301, 302, 303, 307, 308].includes(response.status)) break;
        const location = response.headers.get('location'); await response.body?.cancel(); response = undefined;
        if (!location || redirects >= 3) fail('protocol');
        const next = new URL(location, url); if (!allowed(next, playback.entry.ref.provider)) fail('restricted');
        if (next.hostname !== url.hostname) removeCredentials(); url = next;
      }
      const status = deliveryStatus(response!, range); report('headers', { status });
      return { response: response!, status, attempt: index + 1, upstreamHost: url.hostname };
    } catch (error) {
      await response?.body?.cancel(); if (signal.aborted) throw error;
      const failure = error instanceof MusicSourceError ? error : new MusicSourceError({ code: 'network', retryable: true });
      report('failure', { errorCode: failure.code, ...(failure.upstreamCode && /^\d{3}$/.test(failure.upstreamCode) ? { status: Number(failure.upstreamCode) } : {}) });
      const recoverable = ['network', 'protocol', 'not-found'].includes(failure.code) || (failure.code === 'upstream' && ['500', '502', '503', '504'].includes(failure.upstreamCode ?? ''));
      if (!recoverable || index + 1 >= candidates.length) throw failure;
    }
  }
  return fail('upstream');
}
