import { identify, fail, validateRef, type EntryRef, type MusicApi, type CallOptions } from './contracts.js';

/** Normalize a supported link; the network is used only to resolve a video part. */
export async function normalizeMusicInput(api: Pick<MusicApi, 'metadata'>, input: string, options: CallOptions = {}): Promise<EntryRef> {
  if(options.signal?.aborted)fail('cancelled');
  const ref = identify(input); validateRef(ref);
  if (ref.kind === 'playlist') return ref;
  let ordinal = 1;
  if (ref.provider === 'bilibili') {
    try {
      const value = new URL(input.trim()).searchParams.get('p');
      if (value !== null) { if (!/^[1-9]\d*$/.test(value)) fail('invalid-input'); ordinal = Number(value); }
    } catch (error) { if ((error as { code?: string }).code) throw error; }
  }
  const entry = await api.metadata(ref, options); if(options.signal?.aborted)fail('cancelled');
  validateRef(entry.ref);if(entry.ref.provider!==ref.provider||entry.ref.id!==ref.id)fail('protocol');
  if (ref.provider !== 'bilibili') return entry.ref;
  const selected = entry.parts?.[ordinal - 1] ?? (ordinal === 1 ? entry : undefined);
  if (!selected?.ref.part || selected.ref.id !== ref.id || selected.ref.provider !== ref.provider) fail('invalid-input');
  validateRef(selected.ref); return { ...selected.ref };
}
