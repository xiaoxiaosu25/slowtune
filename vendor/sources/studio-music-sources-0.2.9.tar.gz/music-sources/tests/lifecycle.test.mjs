import test from 'node:test';
import assert from 'node:assert/strict';
import {MusicSources,MusicSourceError,identify,resourceId,MUSIC_PROTOCOL} from '../dist/index.js';
import {BilibiliProvider} from '../dist/bilibili.js';
import {createNodeHost,YtDlpResolver} from '../dist/node.js';
import {MediaDelivery,createMusicService} from '../dist/service.js';
import {MusicClient} from '../dist/client.js';
import {MusicPlayerBridge} from '../dist/player.js';
const ref={provider:'bilibili',kind:'video',id:'BV1NPtC6qEeA',part:'123'};
const entry={ref,resourceId:resourceId(ref),title:'A & B',url:'https://www.bilibili.com/video/'+ref.id};
const playback={entry,resourceId:entry.resourceId,format:{id:'aac',mimeType:'audio/mp4',codec:'mp4a.40.2',container:'mp4'},delivery:{url:'https://cdn.example/audio',headers:{Referer:'https://www.bilibili.com/',Cookie:'secret'},requiresHost:true}};
function provider(overrides={}){return{capabilities:{provider:'bilibili',operations:['metadata','prepare'],anonymous:true,limitations:[]},metadata:async()=>entry,prepare:async()=>playback,discover:async()=>[],search:async()=>({items:[]}),list:async()=>({items:[]}),...overrides};}
test('Stable identity does not depend on address and rejects spoofed source links',()=>{assert.equal(identify(entry.url).id,ref.id);assert.throws(()=>identify('https://www.bilibili.com.evil/video/'+ref.id),{code:'invalid-input'});assert.equal(resourceId(ref),'bilibili:video:BV1NPtC6qEeA:123');});
test('Imports cause no request; cancellation ends host fetch and dispose waits',async()=>{
  let calls=0;const host=createNodeHost({fetch:async(_u,{signal})=>{calls++;return new Promise((_,reject)=>signal.addEventListener('abort',()=>reject(signal.reason),{once:true}));}});
  const api=new MusicSources(host,{bilibili:provider({search:async(_r,c)=>c.host.fetch('https://upstream.test',{signal:c.signal})})});assert.equal(calls,0);
  const work=api.search('bilibili',{query:'music'});const rejected=assert.rejects(work,{code:'cancelled'});await api.dispose();await rejected;assert.deepEqual(api.diagnostics(),{disposed:true,pending:0});
});
test('Timeout cancels upstream rather than retaining an uncounted request',async()=>{
  const api=new MusicSources(createNodeHost({fetch}),{bilibili:provider({search:async(_r,c)=>new Promise((_,reject)=>c.signal.addEventListener('abort',()=>reject(c.signal.reason),{once:true}))})},15);
  const keepAlive=setTimeout(()=>{},100);try{await assert.rejects(api.search('bilibili',{query:'x'}),{code:'timeout'});assert.equal(api.diagnostics().pending,0);}finally{clearTimeout(keepAlive);await api.dispose();}
});
test('Empty results remain successful; source errors never become empty arrays',async()=>{
  const api=new MusicSources(createNodeHost({fetch}),{bilibili:provider()});assert.deepEqual(await api.search('bilibili',{query:'none'}),{items:[]});await api.dispose();
  const bad=new MusicSources(createNodeHost({fetch}),{bilibili:provider({search:async()=>{throw new MusicSourceError({code:'rate-limited',retryable:true,upstreamCode:'429'});}})});await assert.rejects(bad.search('bilibili',{query:'x'}),{code:'rate-limited'});await bad.dispose();
});
test('Bilibili shelf failures are independent and wind-control voucher is explicit',async()=>{
  const host=createNodeHost({fetch:async u=>new Response(JSON.stringify(String(u).includes('hot/rank')?{code:0,data:{v_voucher:'challenge'}}:{code:0,data:{archives:[],list:[]}}))});
  const api=new MusicSources(host,{bilibili:new BilibiliProvider()});const result=await api.discover('bilibili');assert.equal(result[0].page.items.length,0);assert.equal(result[1].error.code,'restricted');assert.equal(result[2].page.items.length,0);await api.dispose();
});
test('Bilibili paging binds query, size and credential revision',async()=>{
  let revision='one';const host=createNodeHost({fetch:async u=>{
    const data=String(u).includes('/spi')?{b_3:'visitor3',b_4:'visitor4'}:{result:[{bvid:ref.id,title:'x',duration:'1:20',author:'UP'}],numPages:2};
    return new Response(JSON.stringify({code:0,data}));
  },credentials:{read:async()=>({revision})}});
  const api=new MusicSources(host,{bilibili:new BilibiliProvider()});const a=await api.search('bilibili',{query:'x',limit:3},{credentialRef:'test'});assert.equal(a.items[0].durationSeconds,80);
  assert.match(a.nextCursor,/^[\w-]{32}$/);assert(!a.nextCursor.includes('test'));
  await assert.rejects(api.search('bilibili',{query:'y',limit:3,cursor:a.nextCursor},{credentialRef:'test'}),{code:'stale-cursor'});revision='two';await assert.rejects(api.search('bilibili',{query:'x',limit:3,cursor:a.nextCursor},{credentialRef:'test'}),{code:'stale-cursor'});await api.dispose();
});
test('Bilibili missing independent audio rejects muxed durl',async()=>{
  const host=createNodeHost({fetch:async u=>new Response(JSON.stringify(String(u).includes('/view?')?{code:0,data:{bvid:ref.id,title:'x',pages:[{cid:123,part:'x',duration:2}]}}:String(u).includes('/nav')?{code:-101,data:{wbi_img:{img_url:'https://i.test/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.png',sub_url:'https://i.test/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.png'}}}:{code:0,data:{durl:[{url:'https://cdn.test/video'}]}}))});
  const api=new MusicSources(host,{bilibili:new BilibiliProvider()});await assert.rejects(api.prepare({ref}),{code:'unsupported'});await api.dispose();
});
test('HTTP and direct operations agree; CDN cookies remain at the host',async()=>{
  const host=createNodeHost({fetch:async(_u,options)=>{assert.equal(options.headers.Cookie,'secret');assert.equal(options.headers.Range,'bytes=0-2');return new Response(new Uint8Array([1,2,3]),{status:206,headers:{'Content-Range':'bytes 0-2/3','Content-Length':'3'}});}});
  const api=new MusicSources(host,{bilibili:provider()});const delivery=new MediaDelivery(host);const app=createMusicService(api,delivery,{baseUrl:'http://test.local',providers:['bilibili']});
  const client=await MusicClient.connect('http://test.local',{fetch:async(u,o)=>app.request(u,o)});assert.deepEqual(await client.metadata(ref),await api.metadata(ref));
  const p=await client.prepare({ref});assert.equal(p.delivery.headers,undefined);assert(!JSON.stringify(p).includes('secret'));assert.equal(p.delivery.requiresHost,false);
  const r=await app.request(p.delivery.url,{headers:{Range:'bytes=0-2'}});assert.equal(r.status,206);assert.deepEqual([...new Uint8Array(await r.arrayBuffer())],[1,2,3]);await client.release(p.leaseId);assert.equal(delivery.diagnostics().leases,0);await api.dispose();await delivery.dispose();
});
test('Lease expiry and credential rotation invalidate old media handles',async()=>{
  let now=0,revision='one';const host=createNodeHost({fetch,now:()=>now,credentials:{read:async()=>({revision})}});const delivery=new MediaDelivery(host,{ttlMs:20});
  const a=await delivery.publish({...playback,delivery:{...playback.delivery,credentialRevision:'one'}},'http://test.local',{credentialRef:'account'});revision='two';await assert.rejects(delivery.read(a.leaseId,new Request(a.delivery.url)),{code:'authentication'});assert.equal(delivery.diagnostics().activeReads,0);
  const b=await delivery.publish(playback,'http://test.local');now=21;await assert.rejects(delivery.read(b.leaseId,new Request(b.delivery.url)),{code:'expired'});await delivery.dispose();
});
test('Ignored Range, malformed Content-Range and truncation are delivery failures',async()=>{
  for(const response of [new Response('abc'),new Response('abc',{status:206,headers:{'Content-Range':'wrong'}}),new Response('abc',{status:206,headers:{'Content-Range':'bytes 0-4/5','Content-Length':'5'}})]){
    const d=new MediaDelivery(createNodeHost({fetch:async()=>response}));const p=await d.publish(playback,'http://test.local');
    await assert.rejects(async()=>{const r=await d.read(p.leaseId,new Request(p.delivery.url,{headers:{Range:'bytes=0-4'}}));await r.arrayBuffer();},{code:'protocol'});await d.dispose();
  }
});
test('Cancelling a streamed reader cancels upstream and releases counters',async()=>{
  let cancelled=false;const d=new MediaDelivery(createNodeHost({fetch:async()=>new Response(new ReadableStream({pull(c){c.enqueue(new Uint8Array([1]));},cancel(){cancelled=true;}}))}));const p=await d.publish(playback,'http://test.local');const r=await d.read(p.leaseId,new Request(p.delivery.url));const reader=r.body.getReader();await reader.read();await reader.cancel();assert(cancelled);assert.equal(d.diagnostics().activeReads,0);await d.dispose();
});
test('Bridge refresh keeps identity; late host lease is released on cancellation',async()=>{
  let released=[];let sequence=0;const api={...provider(),release:async id=>released.push(id),prepare:async()=>({...playback,leaseId:'lease-'+(++sequence),delivery:{url:'http://host.test/media/'+sequence,requiresHost:false}})};
  const bridge=new MusicPlayerBridge(api);const source=await bridge.source(ref);const controller=new AbortController();const a=await source.prepare({signal:controller.signal,restart:false});const b=await bridge.resolver.resolveUrl(a.resourceId,a,'expired',{signal:controller.signal});assert.equal(a.resourceId,b.resourceId);assert.notEqual(a.playUrl,b.playUrl);
  const abort=new AbortController();abort.abort();await assert.rejects(source.prepare({signal:abort.signal,restart:false}),{code:'cancelled'});assert(released.includes('lease-3'));await bridge.dispose();assert.equal(bridge.diagnostics().leases,0);
});
test('HTTP protocol mismatch and malformed calls do not invoke adapters',async()=>{
  let called=0;const host=createNodeHost({fetch});const api=new MusicSources(host,{bilibili:provider({prepare:async()=>{called++;return playback;}})});const d=new MediaDelivery(host);const app=createMusicService(api,d,{baseUrl:'http://test.local',providers:['bilibili']});
  const r=await app.request('/v1/call/prepare',{method:'POST',body:JSON.stringify({protocol:MUSIC_PROTOCOL+1,request:{ref}})});assert.equal((await r.json()).error.code,'protocol');assert.equal(called,0);const bad=await app.request('/v1/call/prepare',{method:'POST',body:'{}'});assert.notEqual(bad.status,200);await api.dispose();await d.dispose();
});
test('Validated CDN 200 ranges normalize; unrelated redirects remain failures',async()=>{
  const d=new MediaDelivery(createNodeHost({fetch:async()=>new Response('abc',{status:200,headers:{'Content-Range':'bytes 0-2/3','Content-Length':'3'}})}));const p=await d.publish(playback,'http://test.local');const r=await d.read(p.leaseId,new Request(p.delivery.url,{headers:{Range:'bytes=0-'}}));assert.equal(r.status,206);assert.equal(await r.text(),'abc');await d.dispose();
  const bad=new MediaDelivery(createNodeHost({fetch:async()=>new Response(null,{status:302,headers:{Location:'https://unrelated.example/redirect'}})}));const b=await bad.publish(playback,'http://test.local');await assert.rejects(bad.read(b.leaseId,new Request(b.delivery.url)),{code:'restricted'});await bad.dispose();
});
test('Closing a lease awaits physical reader cancellation',async()=>{
  let cancelled=false;const d=new MediaDelivery(createNodeHost({fetch:async()=>new Response(new ReadableStream({pull(c){c.enqueue(new Uint8Array([1]));},async cancel(){await new Promise(r=>setTimeout(r,15));cancelled=true;}}))}));const p=await d.publish(playback,'http://test.local');const r=await d.read(p.leaseId,new Request(p.delivery.url));const reader=r.body.getReader();await reader.read();await d.release(p.leaseId);assert(cancelled);assert.equal(d.diagnostics().activeReads,0);await d.dispose();
});
test('Credential change between resolution and publication rejects the old result',async()=>{
  const d=new MediaDelivery(createNodeHost({fetch,credentials:{read:async()=>({revision:'new'})}}));await assert.rejects(d.publish({...playback,delivery:{...playback.delivery,credentialRevision:'old'}},'http://test.local',{credentialRef:'account'}),{code:'authentication'});assert.equal(d.diagnostics().leases,0);await d.dispose();
});
test('Host tool output budget and cancellation terminate the owned process',async()=>{
  const ref={provider:'youtube',kind:'video',id:'jNQXAC9IVRw'},entry={ref,resourceId:resourceId(ref),title:'Tool fixture',url:'https://www.youtube.com/watch?v=jNQXAC9IVRw'};
  const c={host:createNodeHost({fetch}),signal:new AbortController().signal,scope:'anonymous'};
  const budget=new YtDlpResolver({executable:process.execPath,prefixArgs:['-e',"process.stdout.write('x'.repeat(10000));setInterval(()=>{},1000)",'--'],maxOutputBytes:1024});await assert.rejects(budget.resolve({ref},entry,c),{code:'upstream'});assert.equal(budget.diagnostics().active,0);await budget.dispose();
  const abort=new AbortController();const slow=new YtDlpResolver({executable:process.execPath,prefixArgs:['-e','setInterval(()=>{},1000)','--']});const timer=setTimeout(()=>abort.abort(),100);try{await assert.rejects(slow.resolve({ref},entry,{...c,signal:abort.signal}),{code:'cancelled'});assert.equal(slow.diagnostics().active,0);}finally{clearTimeout(timer);await slow.dispose();}
});
