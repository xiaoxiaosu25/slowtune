import test from 'node:test';
import assert from 'node:assert/strict';
import {MusicSources,fail} from '../dist/index.js';
import {createNodeHost,YtDlpResolver} from '../dist/node.js';
import {BilibiliProvider} from '../dist/bilibili.js';
import {YoutubeProvider} from '../dist/youtube.js';
import {MediaDelivery,createMusicService} from '../dist/service.js';
import {MusicClient} from '../dist/client.js';
import {MusicPlayerBridge} from '../dist/player.js';
import {mkdtemp,readdir,rmdir} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const json=(d,cookies=[])=>{const headers=new Headers();for(const c of cookies)headers.append('Set-Cookie',c);return new Response(JSON.stringify(d),{headers});};
test('HTTP QR keeps host credentials private, binds owner and enables account/library before disconnect',async()=>{
  const store=new Map();const credentials={read:async ref=>{if(!store.has(ref))fail('authentication');return store.get(ref);},write:async(ref,c)=>store.set(ref,c),remove:async ref=>{store.delete(ref);}};
  const fetch=async u=>String(u).includes('/generate')?json({code:0,data:{qrcode_key:'key',url:'https://account.bilibili.com/scan?key=key'}}):String(u).includes('/poll')?json({code:0,data:{code:0}},['SESSDATA=test; Secure','bili_jct=csrf; Secure']):String(u).includes('/nav')?json({code:0,data:{isLogin:true,mid:42,uname:'Test'}}):json({code:0,data:{list:[{id:100,title:'Private test'}],has_more:false}});
  const host=createNodeHost({fetch,credentials}),api=new MusicSources(host,{bilibili:new BilibiliProvider()}),delivery=new MediaDelivery(host);
  const app=createMusicService(api,delivery,{baseUrl:'http://test.local',providers:['bilibili'],context:async r=>({credentialRef:r.headers.get('x-test-user')})});
  const client=await MusicClient.connect('http://test.local',{fetch:(u,o)=>app.request(u,o),headers:{'x-test-user':'A'}});
  const other=await MusicClient.connect('http://test.local',{fetch:(u,o)=>app.request(u,o),headers:{'x-test-user':'B'}});
  try{
    const q=await client.beginLogin('bilibili');await assert.rejects(other.pollLogin('bilibili',q.id),{code:'expired'});
    const result=await client.pollLogin('bilibili',q.id);assert.equal(result.state,'authenticated');assert(!JSON.stringify(result).includes('SESSDATA'));
    assert.equal((await client.account('bilibili')).id,'42');const page=await client.library('bilibili',{limit:3});assert.equal(page.items[0].ref.id,'fav:100');
    assert.equal(store.get('A').provider,'bilibili');await assert.rejects(api.account('youtube',{credentialRef:'A'}),{code:'unsupported'});
    await client.disconnect('bilibili');assert.equal(store.size,0);await assert.rejects(client.account('bilibili'),{code:'authentication'});
  }finally{client.dispose();other.dispose();await delivery.dispose();await api.dispose();}
});
test('Media ownership blocks another account and revocation waits for active stream cancellation',async()=>{
  let cancelled=false;const host=createNodeHost({fetch:async()=>new Response(new ReadableStream({pull(c){c.enqueue(new Uint8Array([1]));},async cancel(){await new Promise(r=>setTimeout(r,10));cancelled=true;}})),credentials:{read:async()=>({revision:'one'})}});
  const delivery=new MediaDelivery(host),ref={provider:'youtube',kind:'video',id:'jNQXAC9IVRw'},entry={ref,resourceId:'youtube:video:jNQXAC9IVRw',title:'Test',url:'https://www.youtube.com/watch?v=jNQXAC9IVRw'};
  try{const p=await delivery.publish({entry,resourceId:entry.resourceId,format:{id:'1',codec:'mp4a',mimeType:'audio/mp4',container:'mp4'},delivery:{url:'https://example.googlevideo.com/audio',requiresHost:true,credentialRevision:'one'}},'http://test.local',{credentialRef:'A'});
    await assert.rejects(delivery.read(p.leaseId,new Request(p.delivery.url),{credentialRef:'B'}),{code:'authentication'});await assert.rejects(delivery.touch(p.leaseId,{credentialRef:'B'}),{code:'authentication'});await assert.rejects(delivery.release(p.leaseId,{credentialRef:'B'}),{code:'authentication'});
    const response=await delivery.read(p.leaseId,new Request(p.delivery.url),{credentialRef:'A'});await response.body.getReader().read();await delivery.revoke('A');assert(cancelled);assert.equal(delivery.diagnostics().leases,0);assert.equal(delivery.diagnostics().activeReads,0);
  }finally{await delivery.dispose();}
});
test('Player bridge keeps a per-source credential reference for initial preparation and refresh',async()=>{
  const calls=[],ref={provider:'bilibili',kind:'video',id:'BV1NPtC6qEeA'},entry={ref,resourceId:'bilibili:video:BV1NPtC6qEeA',title:'Test',url:'https://www.bilibili.com/video/BV1NPtC6qEeA'};
  const api={metadata:async(_ref,o)=>{calls.push(o.credentialRef);return entry;},prepare:async(_request,o)=>{calls.push(o.credentialRef);return{entry,resourceId:entry.resourceId,format:{codec:'mp4a',mimeType:'audio/mp4',container:'mp4'},delivery:{url:'http://test.local/media',requiresHost:false}};}};
  const bridge=new MusicPlayerBridge(api);try{const source=await bridge.source(ref,{credentialRef:'A'});const plan=await source.prepare({signal:new AbortController().signal});await bridge.resolver.resolveUrl(entry.resourceId,plan,'expired',{signal:new AbortController().signal});await bridge.source(ref);assert.deepEqual(calls,['A','A','A','A']);await assert.rejects(bridge.source(ref,{credentialRef:'B'}),{code:'invalid-input'});}finally{await bridge.dispose();}
});
test('Upstream stream socket errors remain structured network failures and release active readers',async()=>{
  const host=createNodeHost({fetch:async()=>new Response(new ReadableStream({start(c){c.error(new TypeError('socket terminated'));}}))});const delivery=new MediaDelivery(host),ref={provider:'youtube',kind:'video',id:'jNQXAC9IVRw'},entry={ref,resourceId:'youtube:video:jNQXAC9IVRw',title:'Test',url:'https://www.youtube.com/watch?v=jNQXAC9IVRw'};
  try{const p=await delivery.publish({entry,resourceId:entry.resourceId,format:{id:'1',codec:'mp4a',mimeType:'audio/mp4',container:'mp4'},delivery:{url:'https://example.googlevideo.com/audio',requiresHost:true}},'http://test.local');const r=await delivery.read(p.leaseId,new Request(p.delivery.url));await assert.rejects(r.arrayBuffer(),{code:'network'});assert.equal(delivery.diagnostics().activeReads,0);}finally{await delivery.dispose();}
});
test('YouTube personal playlists and recommendation cursors map neutral identities and bind account revision',async()=>{
  const playlist=id=>({type:'GridPlaylist',id,title:'List '+id});const video=id=>({type:'Video',id,title:'Track',duration:{seconds:10}});
  const feed={playlists:[playlist('PL_one'),playlist('PL_two')],videos:[video('jNQXAC9IVRw'),video('kK0CRZ0wvvc')],has_continuation:false};
  class Candidate extends YoutubeProvider {async run(c,fn){return fn({getPlaylists:async()=>feed,getHomeFeed:async()=>feed,account:{getInfo:async()=>[{is_selected:true,is_disabled:false,channel_handle:'@test',account_name:'Test'}]}});}}
  let revision='one';const host=createNodeHost({fetch,credentials:{read:async()=>({provider:'youtube',revision,cookie:'SID=test'})}}),tool=new YtDlpResolver({executable:process.execPath}),p=new Candidate({resolver:'yt-dlp',tool}),api=new MusicSources(host,{youtube:p});
  try{const options={credentialRef:'test'};assert.equal((await api.account('youtube',options)).id,'@test');const page=await api.library('youtube',{limit:1},options);assert.equal(page.items[0].ref.kind,'playlist');assert(page.nextCursor);const next=await api.library('youtube',{limit:1,cursor:page.nextCursor},options);assert.equal(next.items[0].ref.id,'PL_two');
    const home=await api.shelf('youtube',{id:'youtube-home',limit:1},options);assert(home.nextCursor);const more=await api.shelf('youtube',{id:'youtube-home',limit:1,cursor:home.nextCursor},options);assert.equal(more.items[0].ref.id,'kK0CRZ0wvvc');
    revision='two';await assert.rejects(api.library('youtube',{limit:1,cursor:page.nextCursor},options),{code:'stale-cursor'});await assert.rejects(api.discover('youtube'),{code:'authentication'});
  }finally{await api.dispose();}
});
test('Authenticated tool invocation owns private Cookie file through success, cancellation and disposal',async()=>{
  const directory=await mkdtemp(join(tmpdir(),'music-tool-auth-test-'));
  const ref={provider:'youtube',kind:'video',id:'jNQXAC9IVRw'},entry={ref,resourceId:'youtube:video:jNQXAC9IVRw',title:'test',url:'https://www.youtube.com/watch?v=jNQXAC9IVRw'};
  const code="const fs=require('node:fs');const args=process.argv;const path=args[args.indexOf('--cookies')+1];if(!fs.readFileSync(path,'utf8').includes('SID\\ttest=='))process.exit(3);console.log(JSON.stringify({formats:[{format_id:'140',vcodec:'none',acodec:'mp4a.40.2',protocol:'https',ext:'m4a',url:'https://example.googlevideo.com/audio'}]}));";
  const c={host:createNodeHost({fetch}),signal:new AbortController().signal,scope:'test',credential:{revision:'1',cookie:'SID=test=='}};
  const tool=new YtDlpResolver({executable:process.execPath,prefixArgs:['-e',code,'--'],cookieDirectory:directory});
  try{const p=await tool.resolve({ref},entry,c);assert.equal(p.format.id,'140');assert(!JSON.stringify(p).includes('SID'));assert.deepEqual(await readdir(directory),[]);}
  finally{await tool.dispose();}
  const delayed=new YtDlpResolver({executable:process.execPath,prefixArgs:['-e',"setInterval(()=>{},1000)",'--'],cookieDirectory:directory});
  try{const pending=delayed.resolve({ref},entry,c);const rejected=assert.rejects(pending,{code:'cancelled'});await new Promise(r=>setTimeout(r,80));await delayed.dispose();await rejected;assert.equal(delayed.diagnostics().active,0);assert.deepEqual(await readdir(directory),[]);}
  finally{await delayed.dispose();await rmdir(directory);}
});

test('Malformed QR challenge URLs remain protocol failures at the HTTP client',async()=>{
  const host=createNodeHost({fetch});const p={capabilities:{provider:'bilibili',operations:['qr-login'],anonymous:true,limitations:[]},beginLogin:async()=>({id:'x'.repeat(32),method:'qr',url:'bad url',expiresAt:Date.now()+1000,intervalMs:2000})};
  const api=new MusicSources(host,{bilibili:p}),d=new MediaDelivery(host),app=createMusicService(api,d,{baseUrl:'http://test.local',providers:['bilibili']});const client=await MusicClient.connect('http://test.local',{fetch:(u,o)=>app.request(u,o)});
  try{await assert.rejects(client.beginLogin('bilibili'),{code:'protocol'});}finally{client.dispose();await d.dispose();await api.dispose();}
});

test('Concurrent anonymous search cancellation does not cancel another visitor request',async()=>{
  const visitors=[];const host=createNodeHost({fetch:async(u,options)=>{
    if(String(u).includes('/spi'))return new Promise((resolve,reject)=>{visitors.push({resolve:()=>resolve(json({code:0,data:{b_3:'fresh3',b_4:'fresh4'}}))});options.signal.addEventListener('abort',()=>reject(options.signal.reason),{once:true});});
    assert.equal(options.headers.Cookie,'buvid3=fresh3; buvid4=fresh4');return json({code:0,data:{result:[],numPages:0}});
  }});const api=new MusicSources(host,{bilibili:new BilibiliProvider()}),abort=new AbortController();
  try{const first=api.search('bilibili',{query:'one'},{signal:abort.signal});const rejected=assert.rejects(first,{code:'cancelled'});const second=api.search('bilibili',{query:'two'});await new Promise(r=>setImmediate(r));assert.equal(visitors.length,1);abort.abort();visitors[0].resolve();await rejected;assert.deepEqual(await second,{items:[]});assert.equal(api.diagnostics().pending,0);}finally{await api.dispose();}
});

test('HTTP source ownership is derived from the operation identity before resolving host credentials',async()=>{
  let called=0;const host=createNodeHost({fetch}),api=new MusicSources(host,{bilibili:new BilibiliProvider()}),d=new MediaDelivery(host);const app=createMusicService(api,d,{baseUrl:'http://test.local',providers:['bilibili'],context:async()=>{called++;return{};}});
  try{for(const provider of ['youtube','invalid']){const r=await app.request('/v1/call/metadata',{method:'POST',body:JSON.stringify({protocol:2,provider,ref:{provider:'bilibili',kind:'video',id:'BV1NPtC6qEeA'}})});assert.equal((await r.json()).error.code,'invalid-input');}assert.equal(called,0);}finally{await d.dispose();await api.dispose();}
});

test('Disconnect cannot remove a credential bound to another provider',async()=>{
  let removed=false;const host=createNodeHost({fetch,credentials:{read:async()=>({provider:'youtube',revision:'test',cookie:'SID=test'}),remove:async()=>{removed=true;}}}),api=new MusicSources(host,{bilibili:new BilibiliProvider()});
  try{await assert.rejects(api.disconnect('bilibili',{credentialRef:'youtube-test'}),{code:'authentication'});assert.equal(removed,false);}finally{await api.dispose();}
});
