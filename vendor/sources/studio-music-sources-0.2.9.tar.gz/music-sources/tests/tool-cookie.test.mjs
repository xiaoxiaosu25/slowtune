import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,readdir,rmdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {toolCookie} from '../dist/tool-cookie.js';
test('YouTube Cookie tool input preserves values and is removed before ownership ends',async()=>{
  const root=await mkdtemp(join(tmpdir(),'music-cookie-test-'));
  try{const input=await toolCookie('SID=test==; __Secure-3PAPISID=other',root,new AbortController().signal);const text=await readFile(input.path,'utf8');assert(text.includes('.youtube.com\tTRUE\t/\tTRUE\t0\tSID\ttest=='));assert.equal((await readdir(root)).length,1);await input.cleanup();assert.deepEqual(await readdir(root),[]);await assert.rejects(toolCookie('SID=bad\nvalue',root,new AbortController().signal),{code:'invalid-input'});}
  finally{await rmdir(root);}
});
