import test from 'node:test';
import assert from 'node:assert/strict';
import {BilibiliSessions,bilibiliAccount,bilibiliLibrary} from '../dist/bilibili-session.js';
const json=(x,values)=>{const headers=new Headers();for(const[k,v]of Object.entries(values??{}))for(const item of Array.isArray(v)?v:[v])headers.append(k,item);return new Response(JSON.stringify(x),{headers});};
function context(fetch){const writes=[];let time=1000;return{c:{host:{fetch,now:()=>time,credentials:{write:async(ref,value)=>writes.push({ref,value})}},signal:new AbortController().signal,credentialRef:'test-account',scope:'test-account'},writes,advance:()=>time+=3000};}
test('QR polling owns the credential target, verifies account and exposes no Cookie',async()=>{
  let state=86101;const t=context(async u=>String(u).includes('/generate')?json({code:0,data:{qrcode_key:'key',url:'https://passport.bilibili.com/scan?key=key'}}):String(u).includes('/poll')?json({code:0,data:{code:state}},{'Set-Cookie':['SESSDATA=test; Path=/; Secure','bili_jct=csrf; Path=/; Secure']}):json({code:0,data:{isLogin:true,mid:42,uname:'Test'}}));
  const login=new BilibiliSessions();const challenge=await login.begin(t.c);assert.equal(challenge.method,'qr');
  await assert.rejects(login.poll(challenge.id,{...t.c,credentialRef:'other'}),{code:'expired'});
  assert.equal((await login.poll(challenge.id,t.c)).state,'pending');await assert.rejects(login.poll(challenge.id,t.c),{code:'busy'});
  state=86090;t.advance();assert.equal((await login.poll(challenge.id,t.c)).state,'scanned');
  state=0;t.advance();const result=await login.poll(challenge.id,t.c);assert.equal(result.state,'authenticated');assert.equal(result.account.id,'42');assert(!JSON.stringify(result).includes('SESSDATA'));assert.equal(t.writes.length,1);assert.equal(login.diagnostics().sessions,0);
});
test('Cancelled QR never commits credentials and disposal drops challenges',async()=>{
  const t=context(async()=>json({code:0,data:{qrcode_key:'key',url:'https://passport.bilibili.com/scan'}}));const login=new BilibiliSessions();const q=await login.begin(t.c);await login.cancel(q.id,t.c);await assert.rejects(login.poll(q.id,t.c),{code:'expired'});await login.begin(t.c);login.dispose();assert.equal(login.diagnostics().sessions,0);assert.equal(t.writes.length,0);await assert.rejects(login.begin(t.c),{code:'disposed'});
});
test('Cancelling in-flight QR polling aborts its network work and prevents a late credential commit',async()=>{
  let cancelled=false;const t=context(async(u,{signal})=>String(u).includes('/generate')?json({code:0,data:{qrcode_key:'key',url:'https://account.bilibili.com/scan'}}):new Promise((_,reject)=>signal.addEventListener('abort',()=>{cancelled=true;reject(signal.reason);},{once:true})));
  const login=new BilibiliSessions();const q=await login.begin(t.c);const poll=login.poll(q.id,t.c);const rejected=assert.rejects(poll,{code:'cancelled'});await login.cancel(q.id,t.c);await rejected;assert(cancelled);assert.equal(t.writes.length,0);assert.equal(login.diagnostics().sessions,0);login.dispose();
});
test('Invalid account sessions do not become an empty personal library',async()=>{
  const t=context(async()=>json({code:0,data:{isLogin:false}}));t.c.credential={cookie:'SESSDATA=invalid'};await assert.rejects(bilibiliAccount(t.c),{code:'authentication'});await assert.rejects(bilibiliLibrary({},t.c),{code:'authentication'});
});
