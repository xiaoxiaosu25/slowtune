import test from 'node:test';
import assert from 'node:assert/strict';
import { resourceId } from '../dist/index.js';
import { createNodeHost, YtDlpResolver } from '../dist/node.js';
import { MediaDelivery, createMusicService } from '../dist/service.js';

const ref = { provider: 'youtube', kind: 'video', id: 'jNQXAC9IVRw' };
const entry = { ref, resourceId: resourceId(ref), title: 'ASMR fixture', url: 'https://www.youtube.com/watch?v=' + ref.id };
const playback = () => ({ resourceId: entry.resourceId, entry,
  format: { id: 'hls-230', codec: 'avc1', mimeType: 'application/vnd.apple.mpegurl', container: 'hls', hasAudio: true, bitrate: 250000 },
  delivery: { url: 'https://manifest.googlevideo.com/video/index.m3u8?signature=private', transport: 'hls', requiresHost: true,
    hls: { video: 'https://manifest.googlevideo.com/video/index.m3u8?signature=private', audio: 'https://manifest.googlevideo.com/audio/index.m3u8?signature=private' } } });
const urls = text => [...text.matchAll(/(?:URI="|\n)(\/v1\/media\/[\w-]+\/[\w-]+)/g)].map(match => match[1]);
const read = (delivery, lease, url, init) => delivery.read(lease.leaseId, new Request('https://local.test' + url, init), undefined, url.split('/')[4]);
const vod = segment => `#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:5,\n${segment}\n#EXT-X-ENDLIST\n`;

test('extractor pairs real HLS audio and video, retains earlier expiration and never treats silent video alone as playable', async t => {
  const formats = [
    { format_id: '230', vcodec: 'avc1.4d401e', ext: 'mp4', protocol: 'm3u8_native', width: 640, height: 360, tbr: 500, url: 'https://manifest.googlevideo.com/api/expire/1900000100/video.m3u8' },
    { format_id: '233', vcodec: 'none', audio_ext: 'mp4', protocol: 'm3u8_native', source_preference: -1, url: 'https://manifest.googlevideo.com/api/expire/1900000000/low.m3u8' },
    { format_id: '234', vcodec: 'none', audio_ext: 'mp4', protocol: 'm3u8_native', source_preference: 0, url: 'https://manifest.googlevideo.com/api/expire/1900000000/audio.m3u8' },
  ];
  const make = formats => { const resolver = new YtDlpResolver({ executable: process.execPath, prefixArgs: ['-e', `process.stdout.write(${JSON.stringify(JSON.stringify({ formats }))})`, '--'] }); t.after(() => resolver.dispose()); return resolver; };
  const context = { host: createNodeHost({ fetch }), scope: 'anonymous', signal: new AbortController().signal };
  const result = await make(formats).resolve({ ref, media: 'video', codecs: ['avc1'] }, entry, context);
  assert.equal(result.delivery.transport, 'hls'); assert.equal(result.format.hasAudio, true); assert.equal(result.format.height, 360);
  assert.equal(result.format.audioCodec, undefined, 'do not invent a missing codec');
  assert.equal(result.delivery.hls.audio, formats[2].url); assert.equal(result.delivery.expiresAt, 1900000000000);
  await assert.rejects(make(formats.slice(0, 1)).resolve({ ref, media: 'video' }, entry, context), { code: 'unsupported' });
});

test('HLS delivery hides upstream URLs, rewrites audio/video/map/key resources and preserves segment ranges and HEAD', async t => {
  let calls = 0;
  const host = createNodeHost({ fetch: async (url, init) => {
    calls++;
    if (url.includes('index.m3u8')) return new Response('#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-TARGETDURATION:5\n#EXT-X-MAP:URI="init.mp4"\n#EXT-X-KEY:METHOD=AES-128,URI="https://a.googlevideo.com/key?signature=private"\n#EXTINF:5,\nchunk.m4s?signature=private\n#EXT-X-ENDLIST\n');
    if (init.headers.Range) return new Response(init.method === 'HEAD' ? null : '23', { status: 206, headers: { 'Content-Range': 'bytes 2-3/4', 'Content-Length': '2' } });
    return new Response(init.method === 'HEAD' ? null : '0123', { headers: { 'Content-Length': '4' } });
  } });
  const delivery = new MediaDelivery(host); t.after(() => delivery.dispose());
  const lease = await delivery.publish(playback(), 'https://local.test');
  assert(!JSON.stringify(lease).includes('googlevideo')); assert(!JSON.stringify(lease).includes('signature'));
  assert.equal(lease.delivery.transport, 'hls'); assert.equal(lease.delivery.hls, undefined);
  const master = await (await delivery.read(lease.leaseId, new Request(lease.delivery.url))).text();
  const renditions = urls(master); assert.equal(renditions.length, 2); assert.equal(calls, 0);
  assert.match(master, /TYPE=AUDIO/); assert(!master.includes('googlevideo'));
  for (const rendition of renditions) {
    const playlist = await (await read(delivery, lease, rendition)).text(); assert(!playlist.includes('signature')); assert(!playlist.includes('googlevideo'));
    const resources = urls(playlist); assert.equal(resources.length, 3);
    const segment = await read(delivery, lease, resources[2], { headers: { Range: 'bytes=2-3' } });
    assert.equal(segment.status, 206); assert.equal(await segment.text(), '23');
    const head = await read(delivery, lease, resources[2], { method: 'HEAD' }); assert.equal(await head.text(), ''); assert.equal(head.headers.get('content-length'), '4');
    const playlistHead = await read(delivery, lease, rendition, { method: 'HEAD' }); assert.equal(playlistHead.headers.get('content-length'), null);
    assert.equal((await read(delivery, lease, rendition, { headers: { Range: 'bytes=0-10' } })).status, 416);
  }
  const other = await delivery.publish(playback(), 'https://local.test');
  await assert.rejects(delivery.read(other.leaseId, new Request('https://local.test' + renditions[0]), undefined, renditions[0].split('/')[4]), { code: 'not-found' });
  assert.equal(delivery.diagnostics().activeReads, 0);
});

test('HLS refuses external/unsafe URI targets, live playlists and oversized documents', async t => {
  let body;
  const delivery = new MediaDelivery(createNodeHost({ fetch: async () => new Response(body) })); t.after(() => delivery.dispose());
  const lease = await delivery.publish(playback(), 'https://local.test');
  const rendition = urls(await (await delivery.read(lease.leaseId, new Request(lease.delivery.url))).text())[0];
  for (const value of ['http://a.googlevideo.com/segment', 'https://evil.test/a', 'https://a.googlevideo.com.evil.test/a', 'https://user@a.googlevideo.com/a', 'https://a.googlevideo.com:81/a']) {
    body = vod(value); await assert.rejects(read(delivery, lease, rendition), { code: 'restricted' });
  }
  body = vod('segment.ts').replace('#EXT-X-ENDLIST', ''); await assert.rejects(read(delivery, lease, rendition), { code: 'unsupported' });
  body = '#EXTM3U\n#EXT-X-DEFINE:NAME="url",VALUE="https://evil.test"'; await assert.rejects(read(delivery, lease, rendition), { code: 'unsupported' });
  body = '#EXTM3U\n' + 'x'.repeat(4 * 1024 * 1024); await assert.rejects(read(delivery, lease, rendition), { code: 'upstream' });
  assert.equal(delivery.diagnostics().activeReads, 0);
});

test('ordinary long signed VOD playlists over 512 KiB remain within the bounded delivery budget', async t => {
  const segments = Array.from({ length: 600 }, (_, i) => `#EXTINF:6,\nhttps://a.googlevideo.com/segment/${i}?signature=${'x'.repeat(1100)}`).join('\n');
  const body = `#EXTM3U\n#EXT-X-TARGETDURATION:6\n${segments}\n#EXT-X-ENDLIST\n`;
  assert(body.length > 512 * 1024);
  const delivery = new MediaDelivery(createNodeHost({ fetch: async () => new Response(body) })); t.after(() => delivery.dispose());
  const lease = await delivery.publish(playback(), 'https://local.test');
  const rendition = urls(await (await delivery.read(lease.leaseId, new Request(lease.delivery.url))).text())[0];
  const text = await (await read(delivery, lease, rendition)).text();
  assert.equal(urls(text).length, 600); assert(!text.includes('signature=')); assert.equal(delivery.diagnostics().activeReads, 0);
});

test('release cancels a pending playlist read even when the host ignores fetch abort', async t => {
  let started, cancelled = 0;
  const pending = new Promise(resolve => { started = resolve; });
  const delivery = new MediaDelivery(createNodeHost({ fetch: async () => new Response(new ReadableStream({ start() { started(); }, cancel() { cancelled++; } })) }));
  t.after(() => delivery.dispose());
  const lease = await delivery.publish(playback(), 'https://local.test');
  const rendition = urls(await (await delivery.read(lease.leaseId, new Request(lease.delivery.url))).text())[0];
  const work = read(delivery, lease, rendition); const rejected = assert.rejects(work, { code: 'cancelled' });
  await pending; await new Promise(resolve => setImmediate(resolve));
  await delivery.release(lease.leaseId); await rejected;
  assert.equal(cancelled, 1); assert.deepEqual(delivery.diagnostics(), { leases: 0, activeReads: 0, disposed: false });
});

test('HLS segment streams cancel on release and HTTP child routes inherit authorization and lease expiry', async t => {
  let cancelled = 0, now = 100;
  const host = createNodeHost({ fetch: async url => url.includes('index.m3u8') ? new Response(vod('segment.ts')) : new Response(new ReadableStream({ start(c) { c.enqueue(new Uint8Array([1])); }, cancel() { cancelled++; } })) });
  host.now = () => now;
  const delivery = new MediaDelivery(host, { ttlMs: 500 }); t.after(() => delivery.dispose());
  const app = createMusicService({}, delivery, { baseUrl: 'https://local.test', providers: ['youtube'], authorize: async request => { if (!request.headers.has('x-test-session')) throw new Error('unauthorized'); } });
  const lease = await delivery.publish(playback(), 'https://local.test');
  const request = url => app.request(url, { headers: { 'x-test-session': 'fixture' } });
  const rendition = urls(await (await request(lease.delivery.url)).text())[0];
  assert.notEqual((await app.request(rendition)).status, 200);
  const resource = urls(await (await request(rendition)).text())[0];
  const stream = await request(resource), reader = stream.body.getReader(); await reader.read();
  await delivery.release(lease.leaseId); await assert.rejects(reader.read()); assert.equal(cancelled, 1);
  const expired = await delivery.publish(playback(), 'https://local.test'); now += 501;
  assert.notEqual((await request(expired.delivery.url)).status, 200); assert.equal(delivery.diagnostics().activeReads, 0);
});
