import test from 'node:test';
import assert from 'node:assert/strict';
import { MusicSources, MusicSourceError, resourceId, identify, normalizeMusicInput } from '../dist/index.js';
import { BilibiliProvider } from '../dist/bilibili.js';
import { createNodeHost, YtDlpResolver } from '../dist/node.js';
import { MediaDelivery, createMusicService } from '../dist/service.js';
import { MusicClient } from '../dist/client.js';
import { MusicPlayerBridge } from '../dist/player.js';

const ref = { provider: 'bilibili', kind: 'video', id: 'BV1NPtC6qEeA', part: '123' };
const entry = { ref, resourceId: resourceId(ref), title: 'Original', url: 'https://www.bilibili.com/video/' + ref.id };
const audio = { id: '1', codec: 'mp4a.40.2', mimeType: 'audio/mp4', container: 'mp4' };
const playback = { entry, resourceId: entry.resourceId, format: audio, delivery: { url: 'https://a.bilivideo.com/audio?token=secret', alternatives: ['https://b.bilivideo.com/audio?token=secret'], headers: { Cookie: 'private-cookie', Authorization: 'private-auth', Referer: 'https://www.bilibili.com/' }, requiresHost: true } };
const json = value => new Response(JSON.stringify(value));
const tick = () => new Promise(resolve => setImmediate(resolve));
function baseProvider(overrides = {}) { return { capabilities: { provider: 'bilibili', operations: ['metadata', 'prepare', 'formats'], anonymous: true, limitations: [] }, metadata: async () => entry, formats: async () => [audio], prepare: async () => playback, ...overrides }; }

test('same-format CDN fallback preserves Range, strips cross-host credentials and reports no secrets', async t => {
  const events = [], calls = []; let cancelled = false;
  const host = createNodeHost({ onDiagnostic: event => events.push(event), fetch: async (url, options) => {
    calls.push({ url, options });
    if (String(url).includes('a.bilivideo')) return new Response(new ReadableStream({ cancel() { cancelled = true; } }), { status: 502 });
    return new Response('abc', { status: 200, headers: { 'Content-Range': 'bytes 0-2/3', 'Content-Length': '3' } });
  } });
  const delivery = new MediaDelivery(host); t.after(() => delivery.dispose()); const p = await delivery.publish(playback, 'http://test.local');
  const r = await delivery.read(p.leaseId, new Request(p.delivery.url, { headers: { Range: 'bytes=0-2' } }));
  assert.equal(r.status, 206); assert.equal(await r.text(), 'abc'); assert(cancelled); assert.equal(calls.length, 2);
  assert.equal(calls[1].options.headers.Range, 'bytes=0-2'); assert.equal(calls[1].options.headers.Cookie, undefined); assert.equal(calls[1].options.headers.Authorization, undefined);
  assert.equal(new Set(events.map(e => e.requestId)).size, 1); assert(events.some(e => e.code === 'fallback')); assert(events.some(e => e.status === 502));
  assert(!/secret|private-cookie|private-auth|leaseId|token/.test(JSON.stringify(events))); assert.equal(delivery.diagnostics().activeReads, 0);
});

test('network failure, invalid Range response and HEAD can use bounded alternatives', async t => {
  for (const mode of ['network', 'range', 'head']) {
    let calls = 0;
    const delivery = new MediaDelivery(createNodeHost({ fetch: async () => { calls++; if (calls === 1) { if (mode === 'network') throw new Error('private-url'); return new Response(null, { status: mode === 'head' ? 503 : 200 }); } return new Response(mode === 'head' ? null : 'abc', { status: 206, headers: { 'Content-Range': 'bytes 0-2/3', 'Content-Length': '3' } }); } }));
    t.after(() => delivery.dispose()); const p = await delivery.publish(playback, 'http://test.local');
    const r = await delivery.read(p.leaseId, new Request(p.delivery.url, { method: mode === 'head' ? 'HEAD' : 'GET', headers: { Range: 'bytes=0-2' } }));
    assert.equal(r.status, 206); assert.equal(await r.text(), mode === 'head' ? '' : 'abc'); assert.equal(calls, 2);
  }
});

test('permissions, throttling and disallowed alternative hosts never trigger broad retries', async t => {
  for (const status of [403, 429]) {
    let calls = 0; const delivery = new MediaDelivery(createNodeHost({ fetch: async () => { calls++; return new Response(null, { status, headers: { 'Retry-After': '4' } }); } }));
    t.after(() => delivery.dispose()); const p = await delivery.publish(playback, 'http://test.local');
    await assert.rejects(delivery.read(p.leaseId, new Request(p.delivery.url)), status === 403 ? { code: 'restricted' } : { code: 'rate-limited', retryAfterMs: 4000 }); assert.equal(calls, 1);
  }
  let calls = 0; const bad = new MediaDelivery(createNodeHost({ fetch: async () => { calls++; return new Response(null, { status: 502 }); } })); t.after(() => bad.dispose());
  const p = await bad.publish({ ...playback, delivery: { ...playback.delivery, alternatives: ['https://evil.example/audio'] } }, 'http://test.local');
  await assert.rejects(bad.read(p.leaseId, new Request(p.delivery.url)), { code: 'restricted' }); assert.equal(calls, 1);
});

test('candidate limit, cancellation and release own every upstream attempt', async t => {
  let calls = 0; const limited = new MediaDelivery(createNodeHost({ fetch: async () => { calls++; return new Response(null, { status: 502 }); } }), { maxCandidates: 1 }); t.after(() => limited.dispose());
  const p = await limited.publish(playback, 'http://test.local'); await assert.rejects(limited.read(p.leaseId, new Request(p.delivery.url)), { code: 'upstream' }); assert.equal(calls, 1);
  let active = 0, stopped = false; const pending = new MediaDelivery(createNodeHost({ fetch: async (_u, { signal }) => { active++; return new Promise((_, reject) => signal.addEventListener('abort', () => { setTimeout(() => { active--; stopped = true; reject(signal.reason); }, 10); }, { once: true })); } })); t.after(() => pending.dispose());
  const q = await pending.publish(playback, 'http://test.local'); const work = pending.read(q.leaseId, new Request(q.delivery.url)); const rejected = assert.rejects(work, { code: 'cancelled' }); await tick(); await pending.release(q.leaseId); await rejected; assert(stopped); assert.equal(active, 0); assert.equal(pending.diagnostics().activeReads, 0);
});

test('stream truncation does not splice an alternative; timeouts error pending consumers and await cleanup', async t => {
  let calls = 0, cancelled = false;
  const d = new MediaDelivery(createNodeHost({ fetch: async () => { calls++; return new Response(new ReadableStream({ start(c) { c.enqueue(new Uint8Array([1])); c.close(); } }), { headers: { 'Content-Length': '3' } }); } })); t.after(() => d.dispose());
  const p = await d.publish(playback, 'http://test.local'); const r = await d.read(p.leaseId, new Request(p.delivery.url)); await assert.rejects(r.arrayBuffer(), { code: 'protocol' }); assert.equal(calls, 1);
  const slow = new MediaDelivery(createNodeHost({ fetch: async () => new Response(new ReadableStream({ async cancel() { await tick(); cancelled = true; } })) }), { readTimeoutMs: 25 }); t.after(() => slow.dispose());
  const q = await slow.publish(playback, 'http://test.local'); const stream = await slow.read(q.leaseId, new Request(q.delivery.url)); const keepAlive = setTimeout(() => {}, 100);
  try { await assert.rejects(stream.arrayBuffer(), { code: 'timeout' }); await slow.dispose(); assert(cancelled); assert.equal(slow.diagnostics().activeReads, 0); } finally { clearTimeout(keepAlive); }
});

test('format facts exclude delivery data; quality selection obeys codec constraints', async t => {
  const host = createNodeHost({ fetch: async url => {
    if (String(url).includes('/view?')) return json({ code: 0, data: { bvid: ref.id, title: 'Source', pages: [{ cid: 123, part: 'A', duration: 3 }] } });
    if (String(url).includes('/nav')) return json({ data: { wbi_img: { img_url: 'https://i.test/' + 'a'.repeat(32) + '.png', sub_url: 'https://i.test/' + 'b'.repeat(32) + '.png' } } });
    const format = (id, bandwidth, codecs = 'mp4a.40.2') => ({ id, bandwidth, codecs, mimeType: 'audio/mp4', baseUrl: 'https://a.bilivideo.com/private?token=secret', backupUrl: ['https://b.bilivideo.com/private'] });
    return json({ code: 0, data: { dash: { audio: [format(1, 64000), format(2, 192000)], flac: { audio: format(3, 900000, 'fLaC') } } } });
  } });
  const api = new MusicSources(host, { bilibili: new BilibiliProvider() }); t.after(() => api.dispose());
  const formats = await api.formats(ref); assert.equal(formats.length, 3); assert(!/private|token|headers|delivery|lease/.test(JSON.stringify(formats)));
  assert.equal((await api.prepare({ ref })).format.id, '2'); assert.equal((await api.prepare({ ref, quality: 'lowest' })).format.id, '1');
  assert.equal((await api.prepare({ ref, codecs: ['fLaC'], quality: 'lossless' })).format.id, '3');
  assert.equal((await api.prepare({ ref, quality: 'lossless' })).format.id, '3');
  await assert.rejects(api.prepare({ ref, quality: 'lossless', codecs: ['mp4a'] }), { code: 'unsupported' });
  assert.throws(() => api.prepare({ ref, quality: 'invented' }), { code: 'invalid-input' });
  await assert.rejects(api.prepare({ ref, formatId: 'missing' }), { code: 'unsupported' });
});

test('HTTP format parity and Retry-After propagation require no leases or repeated requests', async t => {
  const api = new MusicSources(createNodeHost({ fetch }), { bilibili: baseProvider({ search: async () => { throw new MusicSourceError({ code: 'rate-limited', retryable: true, retryAfterMs: 5000 }); } }) });
  const d = new MediaDelivery(createNodeHost({ fetch })); t.after(async () => { await d.dispose(); await api.dispose(); });
  const app = createMusicService(api, d, { baseUrl: 'http://test.local', providers: ['bilibili'] }); const client = await MusicClient.connect('http://test.local', { fetch: (u, o) => app.request(u, o) }); t.after(() => client.dispose());
  assert.deepEqual(await client.formats(ref), await api.formats(ref)); assert.equal(d.diagnostics().leases, 0);
  await assert.rejects(client.search('bilibili', { query: 'x' }), { code: 'rate-limited', retryAfterMs: 5000 });
});

test('source bridge preserves explicit quality and format on initial prepare and refresh', async t => {
  const requests = []; const bridge = new MusicPlayerBridge(baseProvider({ prepare: async request => { requests.push(request); return { ...playback, delivery: { url: 'https://host.test/media', requiresHost: false } }; } }), { codecs: ['mp4a'], quality: 'lowest', formatId: '1' }); t.after(() => bridge.dispose());
  const source = await bridge.source(ref), context = { signal: new AbortController().signal };
  const plan = await source.prepare(context); await bridge.resolver.resolveUrl(plan.resourceId, plan, 'expired', context);
  assert.equal(requests.length, 2); for (const request of requests) { assert.equal(request.quality, 'lowest'); assert.equal(request.formatId, '1'); }
});

test('supported source links normalize ordinal parts and list identities without implicit short-link requests', async () => {
  assert.deepEqual(identify('https://space.bilibili.com/42/favlist?fid=7'), { provider: 'bilibili', kind: 'playlist', id: 'fav:7' });
  assert.equal(identify('https://space.bilibili.com/42/channel/collectiondetail?sid=9').id, 'season:42:9');
  const parts = [{ ...entry, ref: { ...ref, part: '123' } }, { ...entry, ref: { ...ref, part: '456' } }];
  const api = { metadata: async () => ({ ...entry, parts }) };
  assert.equal((await normalizeMusicInput(api, entry.url + '?p=2')).part, '456');
  await assert.rejects(normalizeMusicInput(api, entry.url + '?p=3'), { code: 'invalid-input' });
  await assert.rejects(normalizeMusicInput(api, entry.url + '?p=0'), { code: 'invalid-input' });
  await assert.rejects(normalizeMusicInput(api, 'https://b23.tv/short'), { code: 'invalid-input' });
  for (const url of ['https://space.bilibili.com.evil/42/favlist?fid=7', 'https://user:pass@www.bilibili.com/video/' + ref.id, 'ftp://www.bilibili.com/video/' + ref.id]) assert.throws(() => identify(url), { code: 'invalid-input' });
});

test('shared metadata cancellation is isolated, returns detached results and awaits final-owner cleanup', async t => {
  let calls = 0, release;
  const api = new MusicSources(createNodeHost({ fetch }), { bilibili: baseProvider({ metadata: async (_ref, { signal }) => { calls++; return new Promise((resolve, reject) => { release = () => resolve(entry); signal.addEventListener('abort', () => reject(signal.reason), { once: true }); }); } }) }); t.after(() => api.dispose());
  const a = new AbortController(), first = api.metadata(ref, { signal: a.signal }), rejected = assert.rejects(first, { code: 'cancelled' }), second = api.metadata({part:ref.part,id:ref.id,kind:ref.kind,provider:ref.provider});
  await tick(); assert.equal(calls, 1); a.abort(); await rejected; release(); const result = await second; assert.equal(result.title, entry.title);
  const third = api.metadata(ref), fourth = api.metadata(ref); await tick(); release(); const results = await Promise.all([third, fourth]); results[0].title = 'Changed'; assert.equal(results[1].title, entry.title);
  const final = api.metadata(ref), finalRejection = assert.rejects(final, { code: 'cancelled' }); await tick(); await api.dispose(); await finalRejection; assert.equal(api.diagnostics().pending, 0);
});

test('shared metadata is scoped to provider, credential revision and identity', async t => {
  let revision = 'a', calls = 0;
  const api = new MusicSources(createNodeHost({ fetch, credentials: { read: async () => ({ revision }) } }), { bilibili: baseProvider({ metadata: async () => { calls++; await tick(); return entry; } }) }); t.after(() => api.dispose());
  await Promise.all([api.metadata(ref, { credentialRef: 'one' }), api.metadata(ref, { credentialRef: 'two' })]); assert.equal(calls, 2);
  const old = api.metadata(ref, { credentialRef: 'one' }); await tick(); revision = 'b'; await api.metadata(ref, { credentialRef: 'one' }); await old; assert.equal(calls, 4);
});

test('YouTube tool format listing and selection use the same audio-only extraction', async t => {
  const yt = { provider: 'youtube', kind: 'video', id: 'jNQXAC9IVRw' }, e = { ...entry, ref: yt, resourceId: resourceId(yt) };
  const data = { formats: [{ format_id: 'a', ext: 'm4a', acodec: 'mp4a.40.2', vcodec: 'none', protocol: 'https', url: 'https://a.googlevideo.com/private', abr: 64 }, { format_id: 'b', ext: 'm4a', acodec: 'mp4a.40.2', vcodec: 'none', protocol: 'https', url: 'https://a.googlevideo.com/private', abr: 192 }, { format_id: 'v', ext: 'mp4', acodec: 'mp4a', vcodec: 'avc1', protocol: 'https', url: 'https://a.googlevideo.com/video' }] };
  const tool = new YtDlpResolver({ executable: process.execPath, prefixArgs: ['-e', 'process.stdout.write(' + JSON.stringify(JSON.stringify(data)) + ')', '--'] }); t.after(() => tool.dispose());
  const c = { host: createNodeHost({ fetch }), signal: new AbortController().signal, scope: 'anonymous' };
  const formats = await tool.formats(yt, e, c); assert.equal(formats.length, 2); assert(!JSON.stringify(formats).includes('private'));
  assert.equal((await tool.resolve({ ref: yt, quality: 'lowest' }, e, c)).format.id, 'a'); assert.equal(tool.diagnostics().active, 0);
});

test('format queries sanitize adapter output and anonymous initialization is shared', async t => {
  const api = new MusicSources(createNodeHost({ fetch }), { bilibili: baseProvider({ formats: async () => [{ ...audio, url: 'private-secret', headers: { Cookie: 'private' } }] }) }); t.after(() => api.dispose()); assert.deepEqual(await api.formats(ref), [audio]);
  let visits=0,signatures=0;
  const host=createNodeHost({fetch:async url=>{
    if(String(url).includes('/spi')){visits++;await tick();return json({code:0,data:{b_3:'visitor3',b_4:'visitor4'}});}
    if(String(url).includes('/nav')){signatures++;await tick();return json({data:{wbi_img:{img_url:'https://i.test/'+'a'.repeat(32)+'.png',sub_url:'https://i.test/'+'b'.repeat(32)+'.png'}}});}
    if(String(url).includes('/view?'))return json({code:0,data:{bvid:ref.id,title:'Source',pages:[{cid:123,part:'A',duration:3}]}});
    if(String(url).includes('/playurl?'))return json({code:0,data:{dash:{audio:[{id:1,bandwidth:64000,codecs:'mp4a.40.2',mimeType:'audio/mp4',baseUrl:'https://a.bilivideo.com/audio'}]}}});
    return json({code:0,data:{result:[],numPages:0}});
  }});
  const actual=new MusicSources(host,{bilibili:new BilibiliProvider()});t.after(()=>actual.dispose());
  await Promise.all([actual.search('bilibili',{query:'a'}),actual.search('bilibili',{query:'b'})]);assert.equal(visits,1);
  await Promise.all([actual.prepare({ref}),actual.prepare({ref})]);assert.equal(signatures,1);
});

test('rate-limit response waiting info survives direct and HTTP errors; observers cannot break delivery',async t=>{
  let calls=0;const api=new MusicSources(createNodeHost({fetch:async()=>{calls++;return new Response(null,{status:429,headers:{'Retry-After':'999999'}});}}),{bilibili:new BilibiliProvider()});t.after(()=>api.dispose());
  await assert.rejects(api.search('bilibili',{query:'x'}),{code:'rate-limited',retryAfterMs:3600000});assert.equal(calls,1);
  const d=new MediaDelivery(createNodeHost({onDiagnostic:()=>{throw new Error('observer');},fetch:async()=>new Response('abc')}));t.after(()=>d.dispose());
  const p=await d.publish(playback,'http://test.local');p.format.mimeType='private-mutated';p.entry.ref.provider='youtube';
  const r=await d.read(p.leaseId,new Request(p.delivery.url));assert.equal(r.headers.get('content-type'),'audio/mp4');assert.equal(await r.text(),'abc');
});

test('a final shared caller waits for owned cancellation cleanup and normalization honors preabort',async t=>{
  let cleaned=false;const api=new MusicSources(createNodeHost({fetch}),{bilibili:baseProvider({metadata:async(_r,{signal})=>new Promise((_,reject)=>signal.addEventListener('abort',()=>setTimeout(()=>{cleaned=true;reject(signal.reason);},15),{once:true}))})});t.after(()=>api.dispose());
  const abort=new AbortController(),work=api.metadata(ref,{signal:abort.signal}),rejected=assert.rejects(work,{code:'cancelled'});await tick();abort.abort();await rejected;assert(cleaned);
  await assert.rejects(normalizeMusicInput(api,entry.url,{signal:abort.signal}),{code:'cancelled'});
});
