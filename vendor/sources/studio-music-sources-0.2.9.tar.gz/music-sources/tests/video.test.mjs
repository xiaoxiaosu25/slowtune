import test from 'node:test';
import assert from 'node:assert/strict';
import { MusicSources, resourceId } from '../dist/index.js';
import { BilibiliProvider } from '../dist/bilibili.js';
import { createNodeHost, YtDlpResolver } from '../dist/node.js';
import { MusicPlayerBridge } from '../dist/player.js';
import { MediaDelivery, createMusicService } from '../dist/service.js';
import { MusicClient } from '../dist/client.js';

const ref = { provider: 'bilibili', kind: 'video', id: 'BV1NPtC6qEeA', part: '123' };
const entry = { ref, resourceId: resourceId(ref), title: 'ASMR 耳语', url: `https://www.bilibili.com/video/${ref.id}` };
const json = value => Response.json(value);

test('general video search covers all partitions while the default music scope and cursor binding remain intact', async t => {
  const scopes = [];
  const api = new MusicSources(createNodeHost({ fetch: async input => {
    const url = new URL(input);
    if (url.pathname.endsWith('/spi')) return json({ code: 0, data: { b_3: 'visitor3', b_4: 'visitor4' } });
    scopes.push(url.searchParams.get('tids'));
    return json({ code: 0, data: { numPages: 2, result: [{ bvid: ref.id, title: '<em>ASMR</em> 耳语', author: '作者', mid: 7, tag: 'ASMR,耳语', duration: '01:20' }] } });
  } }), { bilibili: new BilibiliProvider() });
  t.after(() => api.dispose());
  const video = await api.search('bilibili', { query: 'ASMR', mode: 'video', limit: 5 });
  assert.deepEqual(video.items[0].tags, ['ASMR', '耳语']); assert.equal(video.items[0].uploader.name, '作者');
  assert.equal(video.items[0].title, 'ASMR 耳语');
  await api.search('bilibili', { query: 'ASMR', limit: 5 });
  await assert.rejects(api.search('bilibili', { query: 'ASMR', mode: 'music', limit: 5, cursor: video.nextCursor }), { code: 'stale-cursor' });
  assert.deepEqual(scopes, ['0', '3']);
});

test('Bilibili mixed search cards retain video order and pagination without parsing courses or live rooms', async t => {
  const first = { type: 'video', bvid: ref.id, title: '李荣浩《恋人》', duration: '4:34' };
  const second = { type: 'video', bvid: 'BV1pE421N7Vi', title: '李荣浩《恋人》MV', duration: '4:37' };
  const course = { type: 'ketang', bvid: '', title: '挽回恋人的课程', duration: '' };
  const pages = [[first, course, second, { type: 'live_room', bvid: ref.id }], [course], [second]];
  const api = new MusicSources(createNodeHost({ fetch: async input => {
    const url = new URL(input);
    if (url.pathname.endsWith('/spi')) return json({ code: 0, data: { b_3: 'visitor3', b_4: 'visitor4' } });
    assert.equal(url.searchParams.get('keyword'), '恋人');
    return json({ code: 0, data: { numPages: 3, result: pages[Number(url.searchParams.get('page')) - 1] } });
  } }), { bilibili: new BilibiliProvider() });
  t.after(() => api.dispose());
  for (const mode of ['video', 'music']) {
    const request = { query: '恋人', mode, limit: 20 };
    const page = await api.search('bilibili', request);
    assert.deepEqual(page.items.map(item => item.ref.id), [first.bvid, second.bvid]);
    assert.equal(page.items[0].durationSeconds, 274);
    const empty = await api.search('bilibili', { ...request, cursor: page.nextCursor });
    assert.deepEqual(empty.items, []); assert(empty.nextCursor);
    const last = await api.search('bilibili', { ...request, cursor: empty.nextCursor });
    assert.deepEqual(last.items.map(item => item.ref.id), [second.bvid]); assert.equal(last.nextCursor, undefined);
  }
});

test('Bilibili malformed video rows and search envelopes still fail explicitly', async t => {
  let data;
  const api = new MusicSources(createNodeHost({ fetch: async input => new URL(input).pathname.endsWith('/spi')
    ? json({ code: 0, data: { b_3: 'visitor3', b_4: 'visitor4' } }) : json(data)
  }), { bilibili: new BilibiliProvider() });
  t.after(() => api.dispose());
  for (const result of [[{ type: 'video', bvid: '', title: '恋人' }], [{ type: 'video', bvid: ref.id }], [null], [{ type: 7 }], {}]) {
    data = { code: 0, data: { numPages: 1, result } };
    await assert.rejects(api.search('bilibili', { query: '恋人', mode: 'video' }), { code: 'upstream' });
  }
  data = { code: -352 }; await assert.rejects(api.search('bilibili', { query: '恋人' }), { code: 'restricted' });
});

test('Bilibili video explicitly selects a single progressive MP4 and refuses segmented or video-only responses', async t => {
  let response = { format: 'mp4', video_codecid: 7, quality: 16, durl: [{ url: 'https://a.bilivideo.com/video.mp4', size: 1024, backup_url: ['https://b.bilivideo.com/video.mp4'] }] };
  const requested = [];
  const api = new MusicSources(createNodeHost({ fetch: async input => {
    const url = new URL(input);
    if (url.pathname.endsWith('/view')) return json({ code: 0, data: { bvid: ref.id, title: entry.title, pages: [{ cid: 123, part: '第一段', duration: 80 }] } });
    if (url.pathname.endsWith('/nav')) return json({ data: { wbi_img: { img_url: `https://test/${'a'.repeat(32)}.png`, sub_url: `https://test/${'b'.repeat(32)}.png` } } });
    requested.push(Object.fromEntries(url.searchParams)); return json({ code: 0, data: response });
  } }), { bilibili: new BilibiliProvider() }); t.after(() => api.dispose());
  const video = await api.prepare({ ref, media: 'video', codecs: ['avc1'] });
  assert.equal(video.format.mimeType, 'video/mp4'); assert.equal(video.format.audioCodec, 'mp4a');
  assert.equal(video.entry.ref.part, '123'); assert.equal(requested[0].fnval, '1'); assert.equal(requested[0].qn, '16');
  assert.equal(video.delivery.alternatives.length, 1);
  await assert.rejects(api.prepare({ ref, media: 'video', codecs: ['vp9'] }), { code: 'unsupported' });
  await assert.rejects(api.prepare({ ref, media: 'video', quality: 'lossless' }), { code: 'unsupported' });
  response = { ...response, durl: [...response.durl, ...response.durl] };
  await assert.rejects(api.prepare({ ref, media: 'video' }), { code: 'unsupported' });
  response = { dash: { video: [{ baseUrl: 'https://a.bilivideo.com/silent' }] } };
  await assert.rejects(api.prepare({ ref, media: 'video' }), { code: 'unsupported' });
  assert.throws(() => api.prepare({ ref, media: 'invented' }), { code: 'invalid-input' });
});

test('YouTube selects progressive video with audio without admitting unpaired HLS, DRM, live or silent tracks', async t => {
  const yt = { provider: 'youtube', kind: 'video', id: 'jNQXAC9IVRw' }, metadata = { ...entry, ref: yt, resourceId: resourceId(yt) };
  const formats = [
    { format_id: 'a', ext: 'm4a', acodec: 'mp4a', vcodec: 'none', protocol: 'https', url: 'https://a.googlevideo.com/audio' },
    { format_id: 'silent', ext: 'mp4', acodec: 'none', vcodec: 'avc1', protocol: 'https', url: 'https://a.googlevideo.com/silent', tbr: 9000 },
    { format_id: 'hls', ext: 'mp4', acodec: 'mp4a', vcodec: 'avc1', protocol: 'm3u8_native', url: 'https://a.googlevideo.com/hls', tbr: 10000 },
    { format_id: 'drm', ext: 'mp4', acodec: 'mp4a', vcodec: 'avc1', protocol: 'https', url: 'https://a.googlevideo.com/protected', has_drm: true, tbr: 12000 },
    { format_id: '18', ext: 'mp4', acodec: 'mp4a.40.2', vcodec: 'avc1.42001E', protocol: 'https', url: 'https://a.googlevideo.com/video', tbr: 300, width: 640, height: 360 },
  ];
  const tool = new YtDlpResolver({ executable: process.execPath, prefixArgs: ['-e', `process.stdout.write(${JSON.stringify(JSON.stringify({ formats }))})`, '--'] });
  t.after(() => tool.dispose());
  const context = { host: createNodeHost({ fetch }), scope: 'anonymous', signal: new AbortController().signal };
  const result = await tool.resolve({ ref: yt, media: 'video', codecs: ['avc1'] }, metadata, context);
  assert.equal(result.format.id, '18'); assert.equal(result.format.audioCodec, 'mp4a.40.2'); assert.equal(result.format.height, 360);
  assert.equal((await tool.resolve({ ref: yt }, metadata, context)).format.id, 'a');
  const live = new YtDlpResolver({ executable: process.execPath, prefixArgs: ['-e', `process.stdout.write(${JSON.stringify(JSON.stringify({ is_live: true, formats }))})`, '--'] });
  t.after(() => live.dispose());
  await assert.rejects(live.resolve({ ref: yt, media: 'video' }, metadata, context), { code: 'unsupported' });
});

test('video media choice survives HTTP and source bridge refresh with host-only addresses hidden', async t => {
  const calls = [];
  const provider = { capabilities: { provider: 'bilibili', operations: ['metadata', 'prepare', 'video-prepare'], anonymous: true, limitations: [] }, metadata: async () => entry,
    prepare: async request => { calls.push(request); return { resourceId: entry.resourceId, entry,
      format: { id: 'video', mimeType: 'video/mp4', codec: 'avc1', audioCodec: 'mp4a', container: 'mp4' },
      delivery: { url: 'https://a.bilivideo.com/private', headers: { Referer: 'https://www.bilibili.com/' }, requiresHost: true } }; } };
  const host = createNodeHost({ fetch }), api = new MusicSources(host, { bilibili: provider }), delivery = new MediaDelivery(host);
  const app = createMusicService(api, delivery, { baseUrl: 'http://test.local', providers: ['bilibili'] });
  const client = await MusicClient.connect('http://test.local', { fetch: (u, o) => app.request(u, o) });
  const bridge = new MusicPlayerBridge(client, { media: 'video', codecs: ['avc1'] });
  t.after(async () => { await bridge.dispose(); await client.dispose(); await delivery.dispose(); await api.dispose(); });
  const source = await bridge.source(ref), context = { signal: new AbortController().signal };
  const first = await source.prepare(context), next = await bridge.resolver.resolveUrl(first.resourceId, first, 'expired', context);
  assert.equal(first.mediaType, 'video'); assert.equal(next.mediaType, 'video'); assert(calls.every(request => request.media === 'video'));
  assert(!JSON.stringify(first).includes('private')); assert(!JSON.stringify(first).includes('Referer'));
});
