import test from 'node:test';
import assert from 'node:assert/strict';
import {BilibiliCatalogue,BilibiliCharts,bilibiliCatalogueEntry,parseYoutubeMusicCatalogue} from '../dist/discovery.js';
test('directory projection preserves native cid, genuine classification and unknown tags/time',()=>{
 const r=bilibiliCatalogueEntry({bvid:'BV0000000001',title:'歌曲',tid:31,pages:[{cid:11}],owner:{name:'作者',mid:4}});
 assert.equal(r.ref.part,'11');assert.equal(r.board,'31');assert.equal(r.tags,undefined);assert.equal(r.categories,undefined);assert.equal(r.publishedAt,undefined);
 assert.equal(parseYoutubeMusicCatalogue({lockupViewModel:{contentType:'LOCKUP_CONTENT_TYPE_PLAYLIST',contentId:'RDCLfixture123',metadata:{lockupMetadataViewModel:{title:{content:'Canto Flow'}}}}})[0].title,'Canto Flow');
});
test('signed directory initialization shares requests and isolates caller cancellation',async()=>{
 let calls=0;const catalogue=new BilibiliCatalogue(),a=new AbortController(),b=new AbortController();
 const host={now:Date.now,md5:()=> 'protocol-fixture',fetch:async(input,options)=>{if(String(input).includes('/nav?')){calls++;await new Promise((resolve,reject)=>{const t=setTimeout(resolve,20);options.signal.addEventListener('abort',()=>{clearTimeout(t);reject(options.signal.reason);},{once:true});});return Response.json({code:0,data:{isLogin:true,wbi_img:{img_url:'https://i/'+ 'a'.repeat(32)+'.png',sub_url:'https://i/'+ 'b'.repeat(32)+'.png'}}});}return Response.json({code:0,data:{item:[]}});}};
 const c=signal=>({host,signal,scope:'account:revision',credential:{revision:'r',cookie:'fixture'}});
 const one=catalogue.json('/x/web-interface/wbi/index/top/feed/rcmd',{},c(a.signal),true);const rejection=assert.rejects(one);const two=catalogue.json('/x/web-interface/wbi/index/top/feed/rcmd',{},c(b.signal),true);await new Promise(r=>setTimeout(r,1));a.abort();await rejection;assert.deepEqual(await two,{item:[]});assert.equal(calls,1);await catalogue.dispose();
});
test('chart results cannot mutate cached periods or tracks',async()=>{
 const requests=[],host={now:()=>1000,fetch:async input=>{
  const url=new URL(input);requests.push(url);
  return Response.json({code:0,data:url.pathname.endsWith('/all_period')?{list:{latest:[{ID:7,priod:3,publish_time:100}]}}:
   {list:[{mv_bvid:'BV0000000001',music_title:'Track',singer:'Artist'}]}});
 }};
 const charts=new BilibiliCharts(),signal=new AbortController().signal;
 const first=await charts.read(host,signal);first.period.id=99;first.period.number=99;first.periods[0].publishedAt=0;
 first.shelf.page.items[0].title='Changed';
 const second=await charts.read(host,signal);
 assert.deepEqual(second.period,{id:7,number:3,publishedAt:100000});
 assert.deepEqual(second.periods,[second.period]);assert.notEqual(second.period,second.periods[0]);
 assert.equal(second.shelf.page.items[0].title,'Track');assert.equal(requests.length,2);
 assert.equal(requests[1].searchParams.get('list_id'),'7');assert.ok(second.sourceUrl.endsWith('list_id=7'));
 assert.deepEqual((await charts.read(host,signal,7)).period,second.period);
});
