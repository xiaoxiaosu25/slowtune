import test from 'node:test';
import assert from 'node:assert/strict';
import { MusicSources } from '../dist/index.js';
import { YoutubeProvider } from '../dist/youtube.js';
import { createNodeHost } from '../dist/node.js';

// Exercise the installed SDK's real session and parsers using controlled HTTP bodies.
test('YouTube SDK session, video metadata and search work through the public provider', async t => {
  const id = 'jNQXAC9IVRw', calls = [];
  const device = Array(108).fill(null);
  Object.assign(device, { 0: 'en', 1: 'US', 13: 'fixture-visitor', 16: '2.20261026.00.00', 17: 'Windows', 18: '10', 79: 'UTC', 86: 'Chrome', 87: '130' });
  const host = createNodeHost({ fetch: async (input, init) => {
    const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
    calls.push(url.pathname);
    if (url.pathname === '/sw.js_data') return new Response(")]}'\n" + JSON.stringify([[null, null, [[device], 'fixture-key']]]));
    if (url.pathname.endsWith('/config')) return Response.json({});
    if (url.pathname.endsWith('/player')) return Response.json({ playabilityStatus: { status: 'OK' }, videoDetails: {
      videoId: id, title: 'Fixture song', author: 'Fixture artist', channelId: 'UC_fixture', lengthSeconds: '120', keywords: ['music'],
      thumbnail: { thumbnails: [{ url: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' }] },
    } });
    if (url.pathname.endsWith('/search')) {
      assert.equal(JSON.parse(init.body).query, 'fixture');
      return Response.json({ contents: { twoColumnSearchResultsRenderer: { primaryContents: { sectionListRenderer: { contents: [
        { itemSectionRenderer: { contents: [{ videoRenderer: {
          videoId: id, title: { runs: [{ text: 'Fixture song' }] }, lengthText: { simpleText: '2:00' },
          ownerText: { runs: [{ text: 'Fixture artist', navigationEndpoint: { browseEndpoint: { browseId: 'UC_fixture' } } }] },
          thumbnail: { thumbnails: [{ url: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' }] },
        } }] } },
      ] } } } } });
    }
    throw new Error('Unexpected SDK request: ' + url.pathname);
  } });
  const provider = new YoutubeProvider({ resolver: 'yt-dlp', tool: { dispose: async () => {} } });
  const api = new MusicSources(host, { youtube: provider });
  t.after(() => api.dispose());
  const metadata = await api.metadata({ provider: 'youtube', kind: 'video', id });
  assert.equal(metadata.title, 'Fixture song');
  assert.equal(metadata.uploader.id, 'UC_fixture');
  assert.equal(metadata.durationSeconds, 120);
  assert.deepEqual(metadata.tags, ['music']);
  const result = await api.search('youtube', { query: 'fixture', mode: 'video', limit: 10 });
  assert.equal(result.items.length, 1);
  assert.equal(result.items[0].ref.id, id);
  assert.equal(result.items[0].title, metadata.title);
  assert.equal(result.items[0].durationSeconds, 120);
  assert.equal(calls.filter(path => path === '/sw.js_data').length, 1);
});
