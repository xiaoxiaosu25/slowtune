import {test} from 'node:test';
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {MediaDelivery} from '../dist/service.js';
const ref={provider:'bilibili',kind:'video',id:'BV0000000001',part:'1'};
const playback={entry:{ref,title:'fixture',url:'https://www.bilibili.com/video/'+ref.id},resourceId:'fixture',format:{id:'aac',codec:'aac',container:'mp4',mimeType:'audio/mp4'},delivery:{url:'https://x.bilivideo.com/audio',requiresHost:true}};
const policy={connectMs:90,firstByteMs:90,idleMs:90};
async function setup(t,fetch,options={}){
  const delivery=new MediaDelivery({now:Date.now,fetch},{readTimeoutMs:90,...options});t.after(()=>delivery.dispose());
  const lease=await delivery.publish(playback,'http://localhost');return {delivery,lease};
}
const request=lease=>new Request(lease.delivery.url,{headers:{Range:'bytes=0-9'}});
test('continuous slow reads outlive legacy lifetime; default still has the original total limit',async t=>{
  const upstream=async()=>new Response(new ReadableStream({async pull(c){await delay(20);c.enqueue(new Uint8Array([1]));}}),{status:206,headers:{'Content-Range':'bytes 0-9/10'}});
  for(const explicit of [false,true]){
    const {delivery,lease}=await setup(t,upstream);const response=await delivery.read(lease.leaseId,request(lease),undefined,undefined,explicit?policy:undefined),reader=response.body.getReader();
    if(explicit){for(let n=0;n<10;n++)assert.equal((await reader.read()).value.length,1);await reader.cancel();}
    else await assert.rejects((async()=>{for(let n=0;n<10;n++)await reader.read();})(),{code:'timeout'});
    await delivery.release(lease.leaseId);assert.equal(delivery.diagnostics().activeReads,0);
  }
});
test('connection, first byte, genuine stall and explicit total timeout are distinct and release capacity',async t=>{
  for(const phase of ['connect','first','idle','total']){
    let cancelled=0,reads=0;
    const {delivery,lease}=await setup(t,async(_url,{signal})=>{
      if(phase==='connect'){await delay(500,undefined,{signal});}
      return new Response(new ReadableStream({pull(c){if(phase==='idle'&&reads++===0)c.enqueue(new Uint8Array([1]));if(phase==='total')return delay(15).then(()=>c.enqueue(new Uint8Array([1])));},cancel(){cancelled++;}}),{status:206,headers:{'Content-Range':'bytes 0-9/10'}});
    });
    await assert.rejects((async()=>{const response=await delivery.read(lease.leaseId,request(lease),undefined,undefined,{...policy,...(phase==='total'?{totalMs:70}:{})});await response.arrayBuffer();})(),{code:'timeout'});
    await delivery.release(lease.leaseId);assert.equal(delivery.diagnostics().activeReads,0);if(phase!=='connect')assert.equal(cancelled,1);
  }
});
test('downstream backpressure is not upstream idle; active cancel, lease release and ranges retain ownership',async t=>{
  let cancelled=0;
  const {delivery,lease}=await setup(t,async(_url,{headers})=>{
    assert.equal(new Headers(headers).get('Range'),'bytes=0-9');
    return new Response(new ReadableStream({pull(c){c.enqueue(new Uint8Array([1]));},cancel(){cancelled++;}}),{status:206,headers:{'Content-Range':'bytes 0-9/10'}});
  });
  const response=await delivery.read(lease.leaseId,request(lease),undefined,undefined,policy),reader=response.body.getReader();await reader.read();await delay(180);assert.equal((await reader.read()).value.length,1);await reader.cancel();
  const second=await delivery.read(lease.leaseId,request(lease),undefined,undefined,policy);await delivery.release(lease.leaseId);await assert.rejects(second.arrayBuffer(),{code:'cancelled'});
  assert.equal(cancelled,2);assert.deepEqual(delivery.diagnostics(),{leases:0,activeReads:0,disposed:false});
});
