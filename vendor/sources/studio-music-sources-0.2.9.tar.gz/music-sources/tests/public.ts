import { MusicSources, normalizeMusicInput, resolveMusicParts, resolveMusicEntries, type MusicApi, type MusicHost, type EntryRef, type PrepareRequest } from '@studio/music-sources';
import { MusicClient } from '@studio/music-sources/client';
declare const host: MusicHost, api: MusicApi, ref: EntryRef;
const request: PrepareRequest = { ref, quality: 'lowest', codecs: ['mp4a'] };
void new MusicSources(host, {}); void api.formats?.(ref); void normalizeMusicInput(api, 'BV1NPtC6qEeA'); void MusicClient; void request;
void resolveMusicParts(api,ref,{mode:'selected',parts:['123']});void resolveMusicEntries(api,[ref]);
// @ts-expect-error Quality policy must be a known value.
const bad: PrepareRequest = { ref, quality: 'invented' };
void bad;
const video: PrepareRequest = { ref, media: 'video', codecs: ['avc1'] };
void api.prepare(video);
// @ts-expect-error Media selection is explicit and closed.
const badMedia: PrepareRequest = { ref, media: 'live' };
void badMedia;
