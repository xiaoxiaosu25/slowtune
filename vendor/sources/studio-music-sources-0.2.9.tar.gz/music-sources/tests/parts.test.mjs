import test from 'node:test';
import assert from 'node:assert/strict';
import { selectMusicParts, resolveMusicParts, resolveMusicEntries, resourceId } from '../dist/index.js';
const ref = { provider: 'bilibili', kind: 'video', id: 'BV1tX4y1W7Xm' };
const parts = ['900', '12', '340'].map((part, index) => ({ ref: { ...ref, part }, resourceId: 'untrusted-id', title: 'P' + (index + 1), url: 'https://www.bilibili.com/video/' + ref.id }));
const entry = { ...parts[1], parts };

test('one, selected, all and continuous parts use cid and platform order, with detached results', () => {
  assert.deepEqual(selectMusicParts(entry, { mode: 'single' }).map(e => e.ref.part), ['12']);
  assert.deepEqual(selectMusicParts(entry, { mode: 'selected', parts: ['340', '900'] }).map(e => e.ref.part), ['900', '340']);
  assert.deepEqual(selectMusicParts(entry, { mode: 'from', part: '12' }).map(e => e.ref.part), ['12', '340']);
  const all = selectMusicParts(entry, { mode: 'all' }); assert.equal(all.length, 3); assert(all.every(e => !e.parts));
  assert.equal(all[0].resourceId, resourceId(parts[0].ref)); all[0].title = 'mutated'; all[0].ref.part = '1'; assert.equal(parts[0].title, 'P1'); assert.equal(parts[0].ref.part, '900');
});
test('stale/duplicate/empty selections and spoofed metadata remain failures', () => {
  for (const selection of [{ mode: 'selected', parts: [] }, { mode: 'selected', parts: ['900', '900'] }, { mode: 'single', part: '0' }]) assert.throws(() => selectMusicParts(entry, selection), { code: 'invalid-input' });
  assert.throws(() => selectMusicParts(entry, { mode: 'single', part: '999' }), { code: 'not-found' });
  assert.throws(() => selectMusicParts({ ...entry, parts: [parts[0], parts[0]] }, { mode: 'all' }), { code: 'protocol' });
  assert.throws(() => selectMusicParts({ ...entry, parts: [{ ...parts[0], ref: { ...parts[0].ref, id: 'BV1NPtC6qEeA' } }] }, { mode: 'all' }), { code: 'protocol' });
});
test('batch resolve reads each video once and preserves duplicates; cancellation prevents a result', async () => {
  let calls = 0; const api = { metadata: async () => { calls++; return entry; } };
  const result = await resolveMusicEntries(api, [parts[2].ref, parts[0].ref, parts[2].ref]); assert.equal(calls, 1); assert.deepEqual(result.map(e => e.ref.part), ['340', '900', '340']);
  assert.deepEqual((await resolveMusicParts(api, entry.ref, { mode: 'all' })).map(e => e.ref.part), ['900', '12', '340']);
  const abort = new AbortController(); const stopped = { metadata: async () => { abort.abort(); return entry; } };
  await assert.rejects(resolveMusicEntries(stopped, [parts[0].ref], { signal: abort.signal }), { code: 'cancelled' });
});
test('YouTube remains one video and has no invented multipart identity', async () => {
  const video = { ref: { provider: 'youtube', kind: 'video', id: 'jNQXAC9IVRw' }, title: 'One video', url: 'https://youtube.com/watch?v=jNQXAC9IVRw' };
  assert.equal(selectMusicParts(video, { mode: 'all' }).length, 1);
  assert.throws(() => selectMusicParts(video, { mode: 'from', part: '12' }), { code: 'unsupported' });
  assert.equal((await resolveMusicEntries({ metadata: async () => video }, [video.ref])).length, 1);
});
