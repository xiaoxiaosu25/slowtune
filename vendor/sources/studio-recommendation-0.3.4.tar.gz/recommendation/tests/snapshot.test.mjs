import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CONFIG, execute, executeSnapshot, evaluateCandidate, identityKey,compilePhraseRules } from '../dist/index.js';
const config = () => ({...structuredClone(DEFAULT_CONFIG),algorithm:'literal-case-v1',budget:{...DEFAULT_CONFIG.budget,candidates:100000},diversity:{author:0,directory:0}});
const access={user:'u',authorizationRevision:'a',sourceRevision:'s',grants:[{source:'a',roots:['/']},{source:'b',roots:['/']}]};
const candidate=(i,source='a')=>({identity:{namespace:source,id:'/声音'+i+'.wav'},source,authorized:true,available:true,media:'audio',originalTitle:'第'+i+'段.wav',displayTitle:'声音 '+i,path:'/声音'+i+'.wav',directory:'/目录'+(i%7),tags:[],categories:[],listened:false,provenance:'fixed'});
function* pages(rows){for(let i=0;i<rows.length;i+=500)yield rows.slice(i,i+500);}
test('separate titles and compatibility normalization preserve literal collections and real listening facts',()=>{
 const c=config();c.include.groups=[{id:'g',fields:['originalTitle','displayTitle'],mode:'any',terms:['A  B']}];
 const row={...candidate(1),originalTitle:'Ａ Ｂ.wav',displayTitle:'other'};
 assert.equal(evaluateCandidate(row,c,access).pass,false);
 row.displayTitle='a  b';assert.equal(evaluateCandidate(row,c,access).pass,true);
 c.include.groups[0].terms=['bother'];row.originalTitle='b';row.displayTitle='other';assert.equal(evaluateCandidate(row,c,access).pass,false);
 c.include.groups=[];c.scope.unheard=true;delete row.listened;assert.equal(evaluateCandidate(row,c,access).truth,'unknown');
 row.listened=true;assert.equal(evaluateCandidate(row,c,access).pass,false);row.listened=false;assert.equal(evaluateCandidate(row,c,access).pass,true);
});
test('stream selection equals pooled selection for every order, source balancing and partition cap',()=>{
 const rows=Array.from({length:900},(_,i)=>({...candidate(i,i%10?'a':'b'),timestamp:i%20?i:undefined}));
 for(const order of ['upstream','random','name','time','score'])for(const cap of [0,1,2])for(const balanced of [false,true]){
  const c=config();c.order=order;c.diversity.directory=cap;c.mix=balanced?[{source:'a',weight:1},{source:'b',weight:1}]:[];
  const expected=execute({candidates:rows,config:c,access,seed:'fixed'});
  const actual=executeSnapshot({pages:pages(rows),base:[config()],selections:[{id:'one',config:c,seed:'fixed'}],access});
  assert.deepEqual(actual.selections[0].items.map(r=>r.key),expected.items.map(r=>r.key),`${order}/${cap}/${balanced}`);
 }
});
test('eight columns deduplicate 192 choices independently of 100 recent identities',()=>{
 const c=config();c.batchSize=24;
 const rows=Array.from({length:600},(_,i)=>candidate(i));
 const result=executeSnapshot({pages:pages(rows),base:[c],selections:Array.from({length:8},(_,i)=>({id:String(i),config:c,seed:'same'})),access,recent:rows.slice(0,100).map(r=>identityKey(r.identity))});
 const keys=result.selections.flatMap(s=>s.items.map(r=>r.key));assert.equal(keys.length,192);assert.equal(new Set(keys).size,192);
 assert.ok(keys.every(k=>!rows.slice(0,100).some(r=>identityKey(r.identity)===k)));
});
test('full 100000 snapshot reaches front middle and tail and selects the sole tail match',()=>{
 const c=config();c.include.groups=[{id:'tail',fields:['originalTitle'],mode:'any',terms:['第99999段']}];
 const result=executeSnapshot({pages:(function*(){for(let i=0;i<100000;i+=500)yield Array.from({length:500},(_,n)=>candidate(i+n));})(),base:[c],selections:[{id:'tail',config:config(),seed:'tail'}],access});
 assert.equal(result.resources.read,100000);assert.equal(result.resources.pages,200);assert.equal(result.complete,true);
 assert.equal(result.selections[0].items[0].candidate.originalTitle,'第99999段.wav');assert.equal(result.diagnostics.eligible,1);
 assert.ok(result.resources.retainedBytes<=32*1024*1024);assert.ok(result.resources.coreMs<5000);
});
test('limits and cancellation never publish partial complete snapshots',()=>{
 const c=config();c.budget.candidates=1;
 assert.throws(()=>executeSnapshot({pages:pages([candidate(1),candidate(2)]),base:[c],selections:[{id:'a',config:c,seed:'s'}],access}),/candidate budget/);
 const controller=new AbortController();controller.abort();assert.throws(()=>executeSnapshot({pages:pages([candidate(1)]),base:[config()],selections:[{id:'a',config:config(),seed:'s'}],access,signal:controller.signal}),/cancelled/);
});
test('selection, constraints and rule-tree leaves share their strictest snapshot budgets',()=>{
 const rows=[candidate(1),candidate(2)];
 for(const location of ['selection','constraint','tree','selection-tree'])for(const field of ['candidates','bytes','timeoutMs']){
  const low=config();low.budget[field]=1;
  const selection={id:'one',config:location==='selection'?low:config(),seed:'s'};
  if(location==='constraint')selection.constraints=[low];
  if(location==='selection-tree')selection.tree={mode:'all',children:[low]};
  const input={pages:pages(rows),base:[config()],selections:[selection],access};
  if(location==='tree')input.tree={mode:'any',children:[config(),low]};
  if(field==='timeoutMs')input.pages=(function*(){const start=performance.now();while(performance.now()-start<10){}yield rows;})();
  assert.throws(()=>executeSnapshot(input),{code:field==='timeoutMs'?'timeout':'budget'},`${location}/${field}`);
 }
 const low=config();low.budget.candidates=1000;low.order='name';
 const many=Array.from({length:1000},(_,i)=>candidate(999-i)),byId=new Map(many.map(r=>[identityKey(r.identity),r]));
 const result=executeSnapshot({pages:pages(many),base:[config()],selections:[{id:'search',config:low,seed:'s',window:{offset:970,limit:30}}],access,
  resolve:ids=>ids.map(id=>byId.get(identityKey(id)))});
 assert.equal(result.selections[0].items.length,30);assert.equal(result.selections[0].items[0].candidate.originalTitle,'第970段.wav');
});
test('author caps agree across pool and snapshot for names, IDs, unknown policy and sources',()=>{
 const rows=[...['DJ','dj','ＤＪ',' Dj ','A  B','a b'].map((author,i)=>({...candidate(i),author})),
  {...candidate(6),author:'DJ',authorId:'id-one'},{...candidate(7),author:'renamed',authorId:'id-one'},
  {...candidate(8),author:'DJ',authorId:'id-two'},candidate(9),candidate(10),{...candidate(11,'b'),author:'dj'}];
 for(const order of ['upstream','score','time','random','name'])for(const policy of ['shared','distinct'])for(const balanced of [false,true]){
  const c=config();c.order=order;c.batchSize=12;c.diversity={author:1,directory:0,unknownAuthor:policy};
  c.mix=balanced?[{source:'a',weight:1},{source:'b',weight:1}]:[];
  const expected=execute({candidates:rows,config:c,access,seed:'author'});
  const actual=executeSnapshot({pages:pages(rows),base:[config()],selections:[{id:'one',config:c,seed:'author'}],access});
  assert.deepEqual(actual.selections[0].items.map(r=>r.key),expected.items.map(r=>r.key),`${order}/${policy}/${balanced}`);
 }
});
test('seeded source balance can select each source for library-wide single picks',()=>{
 const c=config();c.batchSize=1;c.order='random';c.mix=[{source:'a',weight:1},{source:'b',weight:1}];
 const picked=new Set();
 for(let i=0;i<64;i++)picked.add(executeSnapshot({pages:pages([candidate(1,'a'),candidate(2,'b')]),base:[config()],selections:[{id:'one',config:c,seed:'source-'+i}],access}).selections[0].items[0].candidate.source);
 assert.deepEqual([...picked].sort(),['a','b']);
});
test('large host settings compose bounded phrase leaves without changing any/all or exclusion priority',()=>{
 const groups=Array.from({length:16},(_,i)=>({id:String(i),fields:['originalTitle','displayTitle'],mode:'any',terms:Array.from({length:24},(_,j)=>`${i}-${j}-`.padEnd(120,'x'))}));
 groups[0].terms[0]='第';
 const exclude=structuredClone(groups);exclude[0].terms[0]='第7段';
 const rules={algorithm:'literal-case-v1',include:{mode:'any',groups},exclude};
 assert(Buffer.byteLength(JSON.stringify(rules))>64*1024);
 const check=compilePhraseRules(rules);assert.equal(check(candidate(1)).truth,'yes');assert.equal(check(candidate(7)).truth,'no');
 rules.include.mode='all';assert.equal(compilePhraseRules(rules)(candidate(1)).truth,'no');
});
test('compact snapshot windows preserve full natural paging through the middle and end',()=>{
 const rows=Array.from({length:1000},(_,i)=>candidate(999-i));const c=config();c.order='name';
 const byId=new Map(rows.map(r=>[identityKey(r.identity),r]));
 for(const offset of [0,350,500,970,999,1000]){
  c.budget.candidates=1000;
  const result=executeSnapshot({pages:pages(rows),base:[c],selections:[{id:'search',config:c,seed:'s',window:{offset,limit:30}}],access,
    resolve:ids=>ids.map(id=>byId.get(identityKey(id)))});
  const expected=[...rows].sort((a,b)=>new Intl.Collator('zh-CN',{numeric:true}).compare(a.originalTitle,b.originalTitle)).slice(offset,offset+30);
  assert.deepEqual(result.selections[0].items.map(r=>r.key),expected.map(r=>identityKey(r.identity)));
 }
});
test('compact windows accept both title fields and reject changed sorting facts',()=>{
 const c=config();c.order='name';c.budget.candidates=4;
 const rows=[{...candidate(3),title:'Legacy title'}, {...candidate(1),title:'Another title'}, {...candidate(2),title:'Fallback title'}];
 delete rows[2].originalTitle;
 const byId=new Map(rows.map(r=>[identityKey(r.identity),r]));
 for(const offset of [0,2]){
  const input={pages:pages(rows),base:[c],selections:[{id:'search',config:c,seed:'s',window:{offset,limit:1}}],access,
   resolve:ids=>ids.map(id=>byId.get(identityKey(id)))};
  const expected=execute({candidates:rows,config:c,access,seed:'s',all:true}).items.slice(offset,offset+1);
  assert.deepEqual(executeSnapshot(input).selections[0].items,expected.map(r=>({...r,reasons:['scope:yes']})));
  assert.throws(()=>executeSnapshot({...input,pages:pages(rows),resolve:ids=>ids.map(id=>({...byId.get(identityKey(id)),originalTitle:'Changed sort name'}))}),{code:'port'});
 }
});
test('snapshot identity deduplication follows every column filter',()=>{
 const first={...candidate(1),originalTitle:'blocked'},second={...candidate(1,'b'),identity:{...first.identity},originalTitle:'allowed'};
 const onlyB=config();onlyB.scope.sources=['b'];
 for(const kind of ['config','constraint','rules','tree']){
  const selection={id:'b',config:kind==='config'?onlyB:config(),seed:'s'};
  if(kind==='constraint')selection.constraints=[onlyB];
  if(kind==='rules')selection.rules={algorithm:'literal-case-v1',include:{mode:'any',groups:[{id:'allowed',fields:['originalTitle'],mode:'any',terms:['allowed']}]},exclude:[]};
  if(kind==='tree')selection.tree={mode:'all',children:[onlyB]};
  const result=executeSnapshot({pages:[[first],[second,second]],base:[config()],selections:[selection],access});
  assert.equal(result.selections[0].items.length,1,kind);
  assert.equal(result.selections[0].items[0].candidate.source,'b',kind);
  assert.equal(result.selections[0].diagnostics.eligible,1,kind);
  assert.equal(result.diagnostics.eligible,1,kind);
 }
 const fallback=candidate(2),onlyA=config();onlyA.scope.sources=['a'];
 const result=executeSnapshot({pages:[[first],[second,fallback]],base:[config()],selections:[{id:'b',config:onlyB,seed:'s'},{id:'a',config:onlyA,seed:'s'}],access});
 assert.deepEqual(result.selections.map(s=>s.items.map(i=>i.candidate.source)),[['b'],['a']]);
 assert.equal(result.selections[1].items[0].key,identityKey(fallback.identity));
 assert.equal(result.selections[1].diagnostics.duplicates,1);
});
