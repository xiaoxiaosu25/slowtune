import test from 'node:test';
import assert from 'node:assert/strict';
import { candidateBytes } from '../dist/executor.js';
import { row } from './fixture.mjs';

test('projection byte accounting preserves UTF-8 size across the item buffer boundary', () => {
  for (const title of ['music', 'é中😀\ud800', 'a'.repeat(16300), '中'.repeat(6000), 'x'.repeat(32768)]) {
    const candidate = row(1, { title });
    assert.equal(candidateBytes(candidate), Buffer.byteLength(JSON.stringify(candidate), 'utf8'));
  }
  assert.equal(candidateBytes(row(2)), Buffer.byteLength(JSON.stringify(row(2)), 'utf8'), 'an oversized row cannot contaminate the next measurement');
});
