import react from "@astrojs/react";
import starlight from "@astrojs/starlight";
import { defineConfig } from "astro/config";
import starlightSidebarTopics from "starlight-sidebar-topics";
import { generateTypedocDocs } from "./src/scripts/typedoc";

const docsSidebar = [
	{
		label: "概览",
		translations: { en: "Overview" },
		items: [{ slug: "guides/overview/intro" }, { slug: "guides/overview/eco" }],
	},
	{
		label: "歌词组件",
		translations: { en: "Lyric Component" },
		items: [
			{ slug: "guides/component/quickstart" },
			{ slug: "guides/component/sequence" },
			{ slug: "guides/component/seeking" },
			{ slug: "guides/component/background" },
		],
	},
	{
		label: "歌词格式",
		translations: { en: "Lyric Formats" },
		items: [
			{ slug: "guides/lyric/quickstart" },
			{ slug: "guides/lyric/formats" },
			{ slug: "guides/lyric/ttml" },
		],
	},
];

const referenceSidebar = [
	{
		label: "Core 核心",
		translations: { en: "Core" },
		collapsed: true,
		items: [{ autogenerate: { directory: "reference/core", collapsed: true } }],
	},
	{
		label: "React 绑定",
		translations: { en: "React Bindings" },
		collapsed: true,
		items: [
			{ autogenerate: { directory: "reference/react", collapsed: true } },
		],
	},
	{
		label: "React Full 组件库",
		translations: { en: "React Full Components" },
		collapsed: true,
		items: [
			{ autogenerate: { directory: "reference/react-full", collapsed: true } },
		],
	},
	{
		label: "Vue 绑定",
		translations: { en: "Vue Bindings" },
		collapsed: true,
		items: [{ autogenerate: { directory: "reference/vue", collapsed: true } }],
	},
	{
		label: "Lyric 歌词处理",
		translations: { en: "Lyric Processing" },
		collapsed: true,
		items: [
			{ autogenerate: { directory: "reference/lyric", collapsed: true } },
		],
	},
	{
		label: "TTML 歌词处理",
		translations: { en: "TTML Processing" },
		collapsed: true,
		items: [{ autogenerate: { directory: "reference/ttml", collapsed: true } }],
	},
	{
		label: "HTTP API",
		translations: { en: "HTTP API" },
		collapsed: true,
		items: [
			{
				label: "概览",
				translations: { en: "Overview" },
				slug: "reference/http-api/overview",
			},
			{
				label: "原生接口",
				translations: { en: "Native Endpoints" },
				slug: "reference/http-api/native",
			},
			{
				label: "LrcLib 接口",
				translations: { en: "LrcLib Endpoints" },
				slug: "reference/http-api/lrclib",
			},
			{
				label: "管理接口",
				translations: { en: "System Endpoints" },
				slug: "reference/http-api/system",
			},
		],
	},
];

const contributeSidebar = [
	{
		label: "开发指南",
		translations: { en: "Development" },
		items: [
			{ slug: "contribute/development/environments" },
			{ slug: "contribute/development/structure" },
		],
	},
	{
		label: "仓库规范",
		translations: { en: "Repository Guidelines" },
		items: [
			{ slug: "contribute/guidelines/pr" },
			{ slug: "contribute/guidelines/publishing" },
		],
	},
];

export default defineConfig({
	site: "https://amll.dev",
	trailingSlash: "never",
	build: {
		format: "file",
	},
	integrations: [
		react(),
		starlight({
			favicon: "favicon.ico",
			title: "AMLL Docs",
			logo: {
				src: "./src/assets/amll-logo.svg",
				alt: "AMLL",
			},
			customCss: [
				"./src/styles/consts.css",
				"./src/styles/frame.css",
				"./src/styles/content.css",
			],
			components: {
				PageFrame: "./src/components/Overrides/PageFrame.astro",
			},
			expressiveCode: {
				themes: ["github-dark", "github-light"],
				useStarlightDarkModeSwitch: true,
				useStarlightUiThemeColors: false,
			},
			locales: {
				root: { label: "简体中文", lang: "zh-CN" },
				en: { label: "English", lang: "en" },
			},
			social: [
				{
					icon: "github",
					label: "GitHub",
					href: "https://github.com/amll-dev/applemusic-like-lyrics",
				},
			],
			plugins: [
				starlightSidebarTopics([
					{
						id: "docs",
						label: { "zh-CN": "使用文档", en: "Guides" },
						link: "/guides",
						icon: "open-book",
						items: docsSidebar,
					},
					{
						id: "reference",
						label: { "zh-CN": "API 参考", en: "API Reference" },
						link: "/reference",
						icon: "information",
						items: referenceSidebar,
					},
					{
						id: "docs",
						label: { "zh-CN": "试验场", en: "Playground" },
						link: "/playground",
						icon: "puzzle",
						items: docsSidebar,
					},
					{
						id: "contribute",
						label: { "zh-CN": "贡献指南", en: "Contributing" },
						link: "/contribute",
						icon: "code-branch",
						items: contributeSidebar,
					},
				]),
				{
					name: "typedoc",
					hooks: {
						"config:setup": async (cfg) => {
							cfg.logger.info("Generating typedoc...");
							await generateTypedocDocs(cfg.logger);
							cfg.logger.info("Finished typedoc generation");
						},
					},
				},
			],
			editLink: {
				baseUrl:
					"https://github.com/amll-dev/applemusic-like-lyrics/blob/main/packages/docs/",
			},
		}),
	],
	vite: {
		build: {
			sourcemap: true,
		},
	},
});
