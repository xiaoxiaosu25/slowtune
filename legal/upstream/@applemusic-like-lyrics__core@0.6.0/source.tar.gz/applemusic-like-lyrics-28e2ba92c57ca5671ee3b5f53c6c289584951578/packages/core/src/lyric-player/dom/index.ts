/**
 * @fileoverview
 * 一个播放歌词的组件
 * @author SteveXMH
 */

import "#styles/index.css";
import type { BottomLine } from "#lyric/base/bottom-line.ts";
import { MAX_FRAME_DELTA } from "#lyric/base/consts.ts";
import { LyricPlayerBase } from "#lyric/base/index.ts";
import type { LyricLineBase } from "#lyric/base/line.ts";
import styles from "#styles/lyric-player.module.css";
import { Duration } from "#utils/time.ts";
import { BottomLineEl } from "./bottom-line.ts";
import { InterludeDotsEl } from "./interlude-dots.ts";
import { LyricLineGroup } from "./lyric-group.ts";
import { LyricLineEl } from "./lyric-line.ts";

/**
 * 歌词行鼠标相关事件，可以获取到歌词行的索引、主歌词行以及背景歌词行（如果有）元素
 */
export class LyricLineMouseEvent extends MouseEvent {
	/**
	 * 自定义标志位，用于记录外部是否调用了 `stopPropagation`
	 */
	public isPropagationStopped = false;

	constructor(
		/**
		 * 歌词行索引
		 */
		public readonly lineIndex: number,
		/**
		 * 歌词行元素
		 */
		public readonly line: LyricLineBase,
		/**
		 * 背景人声歌词行元素 (如果存在)
		 */
		public readonly bgLine: LyricLineBase | undefined,
		event: MouseEvent,
	) {
		super(`line-${event.type}`, event);
	}

	override stopPropagation(): void {
		this.isPropagationStopped = true;
		super.stopPropagation();
	}

	override stopImmediatePropagation(): void {
		this.isPropagationStopped = true;
		super.stopImmediatePropagation();
	}
}

export type LyricLineMouseEventListener = (evt: LyricLineMouseEvent) => void;

/**
 * 歌词播放组件，本框架的核心组件
 *
 * 尽可能贴切 Apple Music for iPad 的歌词效果设计，且做了力所能及的优化措施
 */
export class DomLyricPlayer extends LyricPlayerBase {
	private abortController = new AbortController();
	override currentLyricGroups: LyricLineGroup[] = [];

	override onResize(): void {
		const computedStyles = getComputedStyle(this.element);
		this._baseFontSize = Number.parseFloat(computedStyles.fontSize);
		this.rebuildStyle();
	}

	readonly supportPlusLighter: boolean = CSS.supports(
		"mix-blend-mode",
		"plus-lighter",
	);
	readonly supportMaskImage: boolean = CSS.supports("mask-image", "none");
	readonly innerSize: [number, number] = [0, 0];

	private readonly onMouseEventHandler = (e: MouseEvent) => {
		const target = e.target;
		if (!(target instanceof Element)) return;

		const groupEl = target.closest(`.${styles.lyricLineWrapper}`);
		if (!groupEl) return;

		const group = this.lyricGroupElementMap.get(groupEl);
		if (!group) return;

		const mainLine = group.mainLine;
		const bgLine = group.bgLine;
		const lineIndex = this.lyricLinesIndexes.get(mainLine) ?? -1;

		const evt = new LyricLineMouseEvent(lineIndex, mainLine, bgLine, e);
		const isDispatched = this.dispatchEvent(evt);

		if (!isDispatched || evt.defaultPrevented) {
			e.preventDefault();
		}

		if (evt.isPropagationStopped) {
			e.stopPropagation();
			e.stopImmediatePropagation();
		}
	};

	/**
	 * 是否为非逐词歌词
	 * @internal
	 */
	_getIsNonDynamic(): boolean {
		return this.isNonDynamic;
	}
	private _baseFontSize = Number.parseFloat(
		getComputedStyle(this.element).fontSize,
	);
	public get baseFontSize(): number {
		return this._baseFontSize;
	}
	constructor() {
		super();
		this.onResize();
		this.element.classList.add("amll-lyric-player", "dom");
		if (this.disableSpring) {
			this.element.classList.add(styles.disableSpring);
		}

		this.element.addEventListener("click", this.onMouseEventHandler, {
			signal: this.abortController.signal,
		});
		this.element.addEventListener("contextmenu", this.onMouseEventHandler, {
			signal: this.abortController.signal,
		});
	}

	private rebuildStyle() {
		// const width = this.innerSize[0];
		// const height = this.innerSize[1];
		// this.element.style.setProperty("--amll-lp-width", `${width.toFixed(4)}px`);
		// this.element.style.setProperty(
		// 	"--amll-lp-height",
		// 	`${height.toFixed(4)}px`,
		// );
	}

	override setWordFadeWidth(value = 0.5): void {
		super.setWordFadeWidth(value);
		for (const group of this.currentLyricGroups) {
			group.mainLine.updateMaskImageSync();
			group.bgLine?.updateMaskImageSync();
		}
	}

	protected override createInterludeDots(): InterludeDotsEl {
		return new InterludeDotsEl();
	}

	protected override createBottomLine(): BottomLine {
		return new BottomLineEl(this);
	}

	/**
	 * 重新构建歌词行和时间状态
	 *
	 * 一般用于在调用 {@link setLyricProcessConfig} 更新配置后手动刷新视图，
	 * 或在外部样式/DOM 结构发生改变后重置歌词视图
	 *
	 * @param initialTime 重建后对齐的初始时间（毫秒），默认使用当前播放进度
	 */
	protected override buildLyricGroups(): void {
		if (this.hasDuetLine) {
			this.element.classList.add(styles.hasDuetLine);
		} else {
			this.element.classList.remove(styles.hasDuetLine);
		}

		let currentGroup: LyricLineGroup | null = null;

		for (let i = 0; i < this.processedLines.length; i++) {
			const line = this.processedLines[i];
			const lineEl = new LyricLineEl(this, line);

			this.lyricLinesIndexes.set(lineEl, i);

			if (!line.isBG || !currentGroup) {
				currentGroup = new LyricLineGroup(this, lineEl);
				this.currentLyricGroups.push(currentGroup);
				this.lyricGroupElementMap.set(currentGroup.element, currentGroup);
			} else {
				currentGroup.addBgLine(lineEl);
			}
		}
	}

	public override rebuildLyricView(
		initialTime: number = this.getCurrentTime(),
	): void {
		super.rebuildLyricView(initialTime);
		this.setLinePosXSpringParams({});
		this.setLinePosYSpringParams({});
		this.setLineScaleSpringParams({});
		this.update(0);
	}

	override pause(): void {
		super.pause();
		this.element.classList.remove(styles.playing);
		for (const group of this.currentLyricGroups) {
			group.mainLine.pause();
			group.bgLine?.pause();
		}
	}

	override resume(): void {
		super.resume();
		this.element.classList.add(styles.playing);
		for (const group of this.currentLyricGroups) {
			group.mainLine.resume();
			group.bgLine?.resume();
		}
	}

	override update(delta = 0): void {
		const d = Duration.min(Duration.fromMillis(delta), MAX_FRAME_DELTA);
		super.update(Duration.asMillis(d));
		if (!this.supportMaskImage) {
			this.element.style.setProperty(
				"--amll-player-time",
				`${this.getCurrentTime()}`,
			);
		}
		if (!this.isPageVisible) return;
		for (const group of this.currentLyricGroups) {
			group.update(d);
		}

		for (const group of this.currentLyricGroups) {
			group.commitChanges();
		}
	}

	override dispose(): void {
		super.dispose();
		this.abortController.abort();
		this.element.remove();
		for (const group of this.currentLyricGroups) {
			group.dispose();
		}
	}
}
