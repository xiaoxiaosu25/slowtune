import { defineConfig } from "tsdown";
import { baseConfig } from "../../tsdown.base.ts";

export default defineConfig({
	...baseConfig,
	entry: { "amll-lyric": "./src/index.ts" },
	dts: { tsconfig: "./tsconfig.app.json" },
});
